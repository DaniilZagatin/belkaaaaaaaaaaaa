"""Model-directed passport work remains editable, versioned, and incomplete until checked."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest

from pko.errors import LlmError
from pko.llm.client import ChatResult
from pko.llm.registry import ModelSpec
from pko.progress.passport_agent import (
    _Node, _PassportSession, _handle_bind_scenario_step, _handle_declare_children, _handle_finish,
    _handle_submit_node, _handle_submit_risks, run_passport_agent,
)
from pko.progress.passport_evidence import EvidenceCorpus, NODE_FIELDS, GENERATED_FIELDS
from pko.progress.passport_workspace import ResearchWorkspace, sync_objects
from pko.progress import passport_tools
from pko.progress.risk_review import CHECKS


SPEC = ModelSpec(role="passport", base_url="http://unused.invalid", model="fixture", api_key="")
QUOTE = "2:     transport.send(report)"
REASON = "Перенос отражает фактическую передачу результата между этапами обработки."


def corpus_fixture():
    corpus = EvidenceCorpus()
    corpus.add("code", "reports.py:1", "1: def send_report(report):\n" + QUOTE)
    corpus.add("intent", "Исходный ОР", "Клиент получает отчёт по явному запросу.")
    corpus.read(["evidence-1", "evidence-2"])
    return corpus


def node_args(nid, *, name=None, outcome="Вызывается отправка отчёта; доставка не установлена."):
    kind = nid.split("-")[0]
    fields = {fid: {"value": "Не установлено: нужны дополнительные сведения об условиях исполнения.",
                    "source": "Не установлено: доступные материалы не раскрывают эти условия."}
              for fid in NODE_FIELDS[kind] - GENERATED_FIELDS.get(kind, set())}
    args = {"id": nid, "fields": fields, "fact_check": {
        "execution": {"reachability": "definition_only", "entrypoint": "Вызов извне не подтверждён.",
                      "conditions": "Обработчик получает отчёт.", "outcome": outcome,
                      "limits": "Успешная доставка клиенту не проверена.",
                      "evidence": [{"id": "evidence-1", "quote": QUOTE}]},
        "fields": {fid: {"support": "unknown", "mechanism": "unknown", "evidence": [],
                         "limits": "Сведения о поведении в доступном фрагменте отсутствуют."}
                   for fid in fields},
    }}
    if name:
        args["name"] = name
    if kind == "journey":
        args["name"] = name or "Получение отчёта"
        args["decision_boundary"] = "COMPONENT_BBB"
    return args


def session_fixture(*, filled=False):
    state = _PassportSession(agentic=True, evidence_corpus=corpus_fixture(), known_paths={"reports.py"})
    rows = [
        ("journey-1", "Получение отчёта", [], ["process-1", "process-2"]),
        ("process-1", "Подготовка отчёта", ["journey-1"], ["bbb-1"]),
        ("process-2", "Доставка отчёта", ["journey-1"], ["bbb-2"]),
        ("bbb-1", "Сбор результатов", ["process-1"], ["operation-1"]),
        ("bbb-2", "Передача результатов", ["process-2"], ["operation-2"]),
        ("operation-1", "Чтение результатов", ["bbb-1"], []),
        ("operation-2", "Отправка результатов", ["bbb-2"], []),
    ]
    for nid, name, parents, children in rows:
        state.nodes[nid] = _Node(nid, name, "Самостоятельный результат работы с отчётом.",
                                 parents=parents, children=children, filled=filled,
                                 data={"name": name, "fields": {}})
    state.counters = {"journey": 1, "process": 2, "bbb": 2, "operation": 2}
    return state


def unknown_risk_review(state):
    return [{"node": n.id, "checks": [
        {"check": key, "result": "unknown", "note": "Материалы не раскрывают поведение контура при отказе.",
         "evidence": [], "risk_titles": []} for key in CHECKS
    ]} for n in state.of_type("process")]


def approve_current_versions(state):
    sync_objects(state)
    for oid, obj in state.workspace.objects.items():
        state.workspace.reviews[oid] = {"object_id": oid, "revision": obj["revision"],
                                        "result": "supported", "reason": REASON, "evidence": []}


def tool(name, args=None):
    return {"id": "call-" + name, "type": "function",
            "function": {"name": name, "arguments": json.dumps(args or {}, ensure_ascii=False)}}


class ScriptClient:
    spec = SPEC

    def __init__(self, *responses):
        self.responses = list(responses)
        self.messages = []

    def chat(self, messages, **kwargs):
        self.messages.append(deepcopy(messages))
        if not self.responses:
            raise LlmError("Скриптованные ответы закончились.")
        response = self.responses.pop(0)
        if isinstance(response, Exception):
            raise response
        return response


class ReviewingScriptClient(ScriptClient):
    """One fake transport serving two real loops, with separate message histories."""

    def __init__(self, *responses):
        super().__init__(*responses)
        self.review_messages = []
        self.reviewed_packets = []

    def chat(self, messages, **kwargs):
        names = {schema["function"]["name"] for schema in kwargs.get("tools", [])}
        if "submit_checks" not in names:
            return super().chat(messages, **kwargs)
        self.review_messages.append(deepcopy(messages))
        packet = json.loads(messages[1]["content"])["objects"]
        if not any(message.get("role") == "tool" for message in messages):
            self.reviewed_packets.append(deepcopy(packet))
            return ChatResult(text="", usage={}, tool_calls=[tool("read_passport_evidence", {"ids": ["evidence-1"]})])
        checks = [{"object_id": obj["id"], "revision": obj["revision"], "result": "supported",
                   "reason": "Фрагмент подтверждает вызов отправки; фактическая доставка в утверждении не заявлена.",
                   "evidence": [{"id": "evidence-1", "quote": QUOTE}]} for obj in packet]
        return ChatResult(text="", usage={}, tool_calls=[tool("submit_checks", {"checks": checks})])


def complete_session_responses(*, revise_after_review=False):
    def result(*calls):
        return ChatResult(text="", usage={}, tool_calls=list(calls))

    state = session_fixture()
    state.nodes = {nid: node for nid, node in state.nodes.items() if not nid.endswith("-2")}
    risk_args = {"risks": [], "review": unknown_risk_review(state),
                 "analysis": "Проверены вход, исполнение и сохранение результатов процесса. "
                             "Доступный фрагмент подтверждает только вызов отправки; повторная доставка, "
                             "сохранение и поведение транспорта при отказе остаются неизвестными."}
    ids = ["journey-1", "process-1", "bbb-1", "operation-1", "risk-analysis"]
    replies = [
        result(tool("declare_children", {"parent": "journey-1", "children": [
            {"name": "Подготовка отчёта", "basis": "Обрабатывает явный запрос клиента."}]})),
        result(tool("declare_children", {"parent": "process-1", "children": [
            {"name": "Подготовка результата", "basis": "Собирает результат клиентского запроса."}]})),
        result(tool("declare_children", {"parent": "bbb-1", "children": [
            {"name": "Отправка отчёта", "basis": "Передаёт подготовленный отчёт транспорту."}]})),
        result(*(tool("submit_node", node_args(nid)) for nid in reversed(ids[:-1]))),
        result(tool("submit_risks", risk_args)),
        result(tool("review_passport", {"ids": ids})),
    ]
    replies[0].reasoning_content = "RESEARCHER_PRIVATE_MARKER"
    if revise_after_review:
        replies.extend([
            result(tool("submit_node", node_args("operation-1", outcome="Отчёт передаётся транспорту; получение клиентом не проверено.")),
                   tool("submit_risks", risk_args)),
            result(tool("finish")),
            result(tool("review_passport", {"ids": ids})),
        ])
    replies.append(result(tool("finish"), tool("update_research_plan", {"tasks": [
        {"id": "must-not-run", "task": "Изменение после принятого finish", "state": "doing"}]})))
    return replies


class AgenticOrderAndRevisionTests(unittest.TestCase):
    def test_nodes_can_be_filled_out_of_dfs_order_and_edited_immediately(self):
        state = session_fixture()
        state.current, state.awaiting_children_of = "journey-1", "process-1"
        state.queue = ["journey-1", "process-1"]
        reply = _handle_submit_node(state, node_args("operation-2"))
        self.assertIn("принят", reply)
        self.assertTrue(state.nodes["operation-2"].filled)
        self.assertFalse(state.nodes["journey-1"].filled)
        revision = state.workspace.objects["operation-2"]["revision"]
        approve_current_versions(state)
        state.risk_reviewed = True
        reply = _handle_submit_node(state, node_args("operation-2", name="Передача готового отчёта"))
        self.assertIn("принят", reply)
        self.assertNotEqual(state.workspace.objects["operation-2"]["revision"], revision)
        self.assertNotIn("operation-2", state.workspace.reviews)
        self.assertFalse(state.risk_reviewed)

    def test_declaring_children_does_not_require_filling_the_parent_first(self):
        state = _PassportSession(agentic=True)
        state.nodes["journey-1"] = _Node("journey-1", "Получение отчёта", "Результат для клиента.")
        state.counters["journey"] = 1
        reply = _handle_declare_children(state, {"parent": "journey-1", "children": [
            {"name": "Подготовка отчёта", "basis": "Самостоятельный процесс по запросу клиента."}]})
        self.assertNotIn("отклон", reply)
        reply = _handle_declare_children(state, {"parent": "process-1", "children": [
            {"name": "Сбор данных", "basis": "Чтение входных данных для общего отчёта."}]})
        self.assertNotIn("отклон", reply)
        self.assertEqual(state.nodes["process-1"].children, ["bbb-1"])
        self.assertFalse(state.nodes["process-1"].filled)

    def test_json_string_fact_check_is_parsed_then_subject_to_the_same_gate(self):
        state = session_fixture()
        args = node_args("operation-1")
        args["fact_check"] = json.dumps(args["fact_check"], ensure_ascii=False)
        self.assertIn("принят", _handle_submit_node(state, args))
        self.assertIsInstance(state.nodes["operation-1"].data["fact_check"], dict)
        broken = node_args("operation-2")
        broken["fact_check"] = json.dumps({"execution": {}, "fields": {}})
        for _ in range(5):
            self.assertIn("отклонён", _handle_submit_node(state, deepcopy(broken)))
        self.assertFalse(state.nodes["operation-2"].filled)

    def test_edit_invalidates_parent_relation_and_linked_risk_reviews(self):
        state = session_fixture(filled=True)
        state.relations = [{"from": "operation-1", "to": "operation-2", "kind": "feeds",
                            "basis": "Передаёт подготовленный отчёт.", "field": "report"}]
        state.risks = [{"primary_node": "operation-1", "title": "Потеря результата",
                        "linked_nodes": ["operation-1"]}]
        approve_current_versions(state)
        unrelated = state.workspace.reviews["process-2"]
        state.nodes["operation-1"].data["outcome"] = "Возвращает только заголовок отчёта."
        sync_objects(state)
        self.assertNotIn("operation-1", state.workspace.reviews)
        self.assertNotIn("bbb-1", state.workspace.reviews)
        self.assertNotIn("relation:operation-1:operation-2:feeds", state.workspace.reviews)
        self.assertFalse(any(oid.startswith("risk:") for oid in state.workspace.reviews))
        self.assertEqual(state.workspace.reviews["process-2"], unrelated)

    def test_reviewer_receipt_for_old_content_cannot_close_current_object(self):
        state = session_fixture(filled=True)
        sync_objects(state)
        old_revision = state.workspace.objects["operation-1"]["revision"]
        state.nodes["operation-1"].data["outcome"] = "Результат сохраняется только локально."
        sync_objects(state)
        state.reviewer = lambda objects: {"findings": [{"object_id": "operation-1", "revision": old_revision,
                                                       "result": "supported", "reason": REASON, "evidence": []}]}
        passport_tools.review(state, {"ids": ["operation-1"]})
        self.assertNotIn("operation-1", state.workspace.reviews)
        self.assertIn("operation-1", state.workspace.pending_reviews())


class AgenticFindingAndStructureTests(unittest.TestCase):
    def test_accepted_risk_can_be_withdrawn_explicitly_but_not_dropped_silently(self):
        state = session_fixture(filled=True)
        proposal = {"title": "Повторная доставка отчёта", "primary_node": "operation-2"}
        cid = state.workspace.candidate(proposal)
        state.workspace.risk_candidates[cid]["state"] = "accepted"
        state.risks = [deepcopy(proposal)]
        args = {"risks": [], "review": unknown_risk_review(state),
                "analysis": "Проверены вход, исполнение и сохранение результатов каждого процесса. "
                            "В материалах нет доказательств повторной доставки; гипотеза требует проверки механизма отправки."}
        self.assertIn("отклонён", _handle_submit_risks(state, args))
        self.assertEqual(state.risks, [proposal])
        reply = passport_tools.resolve(state, {"id": cid, "resolution": "withdrawn",
            "reason": "Цитата подтверждает только отправку; ранее заявленный механизм повторной доставки не обоснован.",
            "evidence": [{"id": "evidence-1", "quote": QUOTE}]})
        self.assertNotIn("отклонён", reply)
        self.assertNotIn("отклонён", _handle_submit_risks(state, args))
        self.assertEqual(state.risks, [])
        self.assertEqual(state.workspace.risk_candidates[cid]["proposal"], proposal)
        self.assertEqual(state.workspace.risk_candidates[cid]["state"], "withdrawn")
        sync_objects(state)
        self.assertIn("resolution:" + cid, state.workspace.pending_reviews())

    def test_rebinding_step_replaces_old_mapping_atomically_and_invalidates_review(self):
        state = session_fixture(filled=True)
        state.scenarios = {"scenario-1": ["Подготовить отчёт"]}
        state.nodes["process-1"].data["scenarios"] = ["scenario-1"]
        state.nodes["process-2"].data["scenarios"] = ["scenario-1"]
        old = {"scenario": "scenario-1", "step": 0}
        state.nodes["operation-1"].data["scenario_steps"] = [old]
        approve_current_versions(state)
        reply = _handle_bind_scenario_step(state, {"scenario": "scenario-1", "step": 0,
                                                   "nodes": ["operation-2", "operation-missing"], "replace": True})
        self.assertIn("отклонён", reply)
        self.assertEqual(state.nodes["operation-1"].data["scenario_steps"], [old])
        reply = _handle_bind_scenario_step(state, {"scenario": "scenario-1", "step": 0,
                                                   "nodes": ["operation-2"], "replace": True})
        self.assertNotIn("отклонён", reply)
        self.assertEqual(state.nodes["operation-1"].data["scenario_steps"], [])
        self.assertEqual(state.nodes["operation-2"].data["scenario_steps"], [old])
        self.assertNotIn("operation-1", state.workspace.reviews)
        self.assertNotIn("operation-2", state.workspace.reviews)

    def test_rejected_risk_survives_an_empty_resubmission(self):
        state = session_fixture(filled=True)
        proposal = {"title": "Повторная доставка отчёта", "primary_node": "operation-2"}
        args = {"risks": [proposal], "review": unknown_risk_review(state),
                "analysis": "Проверены вход, исполнение и сохранение результатов каждого процесса. "
                            "В материалах нет доказательств повторной доставки; гипотеза требует проверки механизма отправки."}
        self.assertIn("отклонён", _handle_submit_risks(state, args))
        candidate = deepcopy(state.workspace.risk_candidates["candidate-1"])
        self.assertEqual(candidate["proposal"], proposal)
        args["risks"] = []
        self.assertIn("отклонён", _handle_submit_risks(state, args))
        self.assertEqual(state.workspace.risk_candidates["candidate-1"], candidate)
        self.assertIn("candidate-1", state.workspace.unresolved())
        resolution = {"id": "candidate-1", "resolution": "withdrawn",
                      "reason": "В исходной гипотезе не указано условие повтора; её отзываем до исследования транспорта.",
                      "evidence": []}
        self.assertIn("отклонён", passport_tools.resolve(state, resolution))
        self.assertIn("candidate-1", state.workspace.unresolved())
        resolution["evidence"] = [{"id": "evidence-1", "quote": QUOTE}]
        reply = passport_tools.resolve(state, resolution)
        self.assertNotIn("отклонён", reply)
        self.assertEqual(state.workspace.risk_candidates["candidate-1"]["proposal"], proposal)
        self.assertEqual(state.workspace.risk_candidates["candidate-1"]["state"], "withdrawn")
        sync_objects(state)
        self.assertIn("resolution:candidate-1", state.workspace.pending_reviews())

    def test_repeated_finish_never_waives_missing_nodes_or_reviews(self):
        state = session_fixture()
        state.risk_reviewed = True
        for _ in range(5):
            self.assertIn("отклонён", _handle_finish(state, {}))
            self.assertFalse(state.finished)
        for node in state.nodes.values():
            node.filled = True
        for _ in range(5):
            self.assertIn("отклонён", _handle_finish(state, {}))
            self.assertFalse(state.finished)
        self.assertTrue(state.workspace.pending_reviews())

    def test_open_question_keeps_finish_incomplete(self):
        state = session_fixture(filled=True)
        state.risk_reviewed = True
        approve_current_versions(state)
        fid = state.workspace.reject("relation:missing", {"from": "bbb-1", "to": "bbb-2"}, "Передача не прослежена.")
        passport_tools.resolve(state, {"id": fid, "resolution": "open_question",
                                       "reason": "Внешний сервис не представлен; контракт передачи остаётся неизвестным.", "evidence": []})
        self.assertIn("отклонён", _handle_finish(state, {}))
        self.assertFalse(state.finished)

    def test_move_and_retire_preserve_history_and_never_leave_dangling_children(self):
        state = session_fixture(filled=True)
        approve_current_versions(state)
        state.risk_reviewed = True
        reply = passport_tools.structure(state, {"id": "operation-1", "action": "move",
                                                 "parents": ["bbb-2"], "reason": REASON})
        self.assertNotIn("отклонён", reply)
        self.assertNotIn("operation-1", state.nodes["bbb-1"].children)
        self.assertIn("operation-1", state.nodes["bbb-2"].children)
        self.assertEqual(state.nodes["operation-1"].parents, ["bbb-2"])
        self.assertFalse(state.risk_reviewed)
        self.assertNotIn("bbb-2", state.workspace.reviews)
        self.assertIn("отклонён", passport_tools.structure(state, {"id": "bbb-2", "action": "retire", "reason": REASON}))
        reply = passport_tools.structure(state, {"id": "bbb-1", "action": "retire", "reason": REASON})
        self.assertNotIn("отклонён", reply)
        self.assertNotIn("bbb-1", state.nodes)
        self.assertNotIn("bbb-1", state.nodes["process-1"].children)
        self.assertEqual([e["action"] for e in state.workspace.history if e["action"] in ("node_moved", "node_retired")],
                         ["node_moved", "node_retired"])

    def test_referenced_node_cannot_be_retired_to_hide_a_finding(self):
        state = session_fixture(filled=True)
        state.risks = [{"primary_node": "operation-1", "linked_nodes": ["operation-1"], "title": "Потеря отчёта"}]
        reply = passport_tools.structure(state, {"id": "operation-1", "action": "retire", "reason": REASON})
        self.assertIn("отклонён", reply)
        self.assertIn("operation-1", state.nodes)


class AgenticCheckpointTests(unittest.TestCase):
    def test_real_reviewer_loop_can_complete_and_calls_after_finish_do_not_mutate(self):
        client = ReviewingScriptClient(*complete_session_responses())
        result = run_passport_agent([], {}, [], None, SPEC, client=client, max_steps=12,
                                    evidence_corpus=corpus_fixture(), agentic=True)
        data = result.passport_data
        self.assertEqual(data["completion"]["state"], "complete", data["completion"])
        self.assertEqual(data["completion"]["pending_reviews"], [])
        self.assertEqual(data["research"]["plan"], [])
        self.assertEqual(len(client.reviewed_packets), 1)
        self.assertEqual({obj["id"] for obj in client.reviewed_packets[0]},
                         {"journey-1", "process-1", "bbb-1", "operation-1", "risk-analysis"})
        self.assertEqual(len(client.review_messages), 2)
        self.assertNotIn("RESEARCHER_PRIVATE_MARKER", json.dumps(client.review_messages))
        completed = [event for event in data["research"]["history"] if event["action"] == "review_completed"]
        self.assertEqual(len(completed), 1)
        self.assertEqual(completed[0]["reads"], ["evidence-1"])

    def test_edit_after_review_blocks_finish_until_current_versions_are_reviewed(self):
        client = ReviewingScriptClient(*complete_session_responses(revise_after_review=True))
        result = run_passport_agent([], {}, [], None, SPEC, client=client, max_steps=14,
                                    evidence_corpus=corpus_fixture(), agentic=True)
        self.assertEqual(result.passport_data["completion"]["state"], "complete", result.passport_data["completion"])
        self.assertEqual(len(client.reviewed_packets), 2)
        before, after = [{obj["id"]: obj["revision"] for obj in packet} for packet in client.reviewed_packets]
        self.assertNotEqual(before["operation-1"], after["operation-1"])
        self.assertNotEqual(before["risk-analysis"], after["risk-analysis"])
        finish_results = [message["content"] for snapshot in client.messages for message in snapshot
                          if message.get("tool_call_id") == "call-finish"]
        self.assertTrue(any("finish отклонён" in result for result in finish_results), finish_results)

    def test_workspace_checkpoint_keeps_versions_and_masks_private_fields(self):
        ws = ResearchWorkspace(source_digest="source-v1")
        ws.put("operation-1", "node", {"name": "Отправка отчёта", "password": "must-not-leak"})
        ws.reject("risk:1", {"title": "Повтор отправки"}, "Не проверена повторная отправка.")
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "checkpoint.json"
            ws.checkpoint(path, draft={"agent_filled": False})
            text = path.read_text(encoding="utf-8")
            saved = json.loads(text)
            self.assertNotIn("must-not-leak", text)
            self.assertEqual(saved["research"]["source_digest"], "source-v1")
            self.assertEqual(saved["research"]["objects"]["operation-1"]["revision"], ws.objects["operation-1"]["revision"])
            self.assertEqual(saved["research"]["findings"]["finding-1"]["state"], "open")
            self.assertFalse(path.with_suffix(".json.tmp").exists())

    def test_llm_error_saves_partial_state_and_never_claims_completion(self):
        plan = [{"id": "read-input", "task": "Проверить происхождение входных данных", "state": "doing"}]
        responses = [
            ChatResult(text="", usage={}, tool_calls=[tool("update_research_plan", {"tasks": plan})],
                       reasoning_content="PROVIDER_PRIVATE_REASONING_MARKER"),
            ChatResult(text="", usage={}, tool_calls=[tool("declare_children", {"parent": "journey-1", "children": [
                {"name": "Подготовка отчёта", "basis": "Обрабатывает явный запрос клиента."}]})]),
            ChatResult(text="", usage={}, tool_calls=[tool("submit_node", node_args("process-1"))]),
            LlmError("Соединение с моделью прервано."),
        ]
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "checkpoint.json"
            result = run_passport_agent([], {}, [], None, SPEC, client=ScriptClient(*responses), max_steps=6,
                                        evidence_corpus=corpus_fixture(), agentic=True, checkpoint_path=path)
            self.assertEqual(result.passport_data["schema_version"], 2)
            self.assertIn(result.passport_data["completion"]["state"], ("incomplete", "failed"))
            self.assertTrue(result.passport_data["agent_filled"])
            self.assertEqual(result.passport_data["nodes"]["process-1"]["name"], "Подготовка отчёта")
            self.assertTrue(result.passport_data["nodes"]["process-1"]["fields"])
            self.assertTrue(path.exists())
            text = path.read_text(encoding="utf-8")
            saved = json.loads(text)
            self.assertEqual(saved["research"]["plan"], plan)
            self.assertIn("process-1", saved["research"]["objects"])
            self.assertNotIn("PROVIDER_PRIVATE_REASONING_MARKER", text)
            self.assertTrue(result.passport_data["completion"]["unfilled_nodes"])


if __name__ == "__main__":
    unittest.main()
