"""`pko progress` целиком: четыре сессии агента (оценка, рецензент, ревизор,
паспорт) со скриптованной моделью → четыре файла на диске.

Проверяет стык, который поузловые тесты не видят: след прочитанного из
сессии оценки доходит до паспортного агента, его дерево — до
`progress_model.json` и HTML-паспорта, а карта дерева, карточка узла и
реестр собираются рендерером. Герметично: сеть не нужна, репозиторий —
автоматическая фикстура.
"""

from __future__ import annotations

import json
import io
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import pko.llm.client as client_module
from agent_script import JOURNEY_TEXT, STAGE_ID, ROUTER_EVIDENCE, full_session
from fixture_support import ensure_fixture, scripted_responses
from pko import cli
from pko.errors import PkoError
from pko.progress import pipeline
from pko.render import dashboard_data
from pko.llm.client import ChatClient
from pko.render.client_journey_passport import STATUS_BADGE_FAILED, STATUS_BADGE_FALLBACK, STATUS_BADGE_INCOMPLETE


class CliEndToEndTest(unittest.TestCase):
    def setUp(self):
        self.repo_path = ensure_fixture()
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self._cache = client_module.DEFAULT_CACHE_DIR
        client_module.DEFAULT_CACHE_DIR = Path(self.tmp.name) / "llm-cache"
        self.addCleanup(setattr, client_module, "DEFAULT_CACHE_DIR", self._cache)
        self._create = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._create)
        # Роль matcher резолвится из окружения — заглушка без сети.
        self._env = {k: os.environ.get(k) for k in (
            "PKO_MATCHER_BASE_URL", "PKO_MATCHER_MODEL", "PKO_MATCHER_API_KEY",
            "PKO_MONITOR_DIR", "PKO_MONITOR_ENABLED",
        )}
        os.environ.update({"PKO_MATCHER_BASE_URL": "https://stub.local/v1",
                           "PKO_MATCHER_MODEL": "stub-model", "PKO_MATCHER_API_KEY": "x",
                           "PKO_MONITOR_ENABLED": "false",
                           "PKO_MONITOR_DIR": str(Path(self.tmp.name) / "monitor")})
        self.addCleanup(self._restore_env)
        # `.env` разработчика может включать Phoenix; тесты в сеть не ходят.
        tracing = mock.patch.object(cli, "init_phoenix_tracing", return_value=None)
        tracing.start()
        self.addCleanup(tracing.stop)

    def _restore_env(self):
        for k, v in self._env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v

    def _run(self, *responses: dict) -> Path:
        journey = Path(self.tmp.name) / "initiative.md"
        journey.write_text(JOURNEY_TEXT, encoding="utf-8")
        out = Path(self.tmp.name) / "out"
        ChatClient._create = scripted_responses(*responses)
        code = cli.main(["progress", "--journey-file", str(journey),
                         "--repo-path", str(self.repo_path), "--out", str(out), "--quiet"])
        self.assertEqual(code, 0)
        return out

    def test_progress_writes_all_artifacts_with_agent_passport(self):
        early_html = []
        original_research = pipeline._run_passport

        def observe_research(*args, **kwargs):
            path = Path(self.tmp.name) / "out" / "dashboard.html"
            self.assertTrue(path.is_file(), "Дашборд нужен до начала третьего этапа")
            early_html.append(path.read_bytes())
            return original_research(*args, **kwargs)

        with mock.patch.dict(os.environ, {"PKO_MONITOR_ENABLED": "true"}), \
                mock.patch.object(pipeline, "_run_passport", side_effect=observe_research), \
                mock.patch.object(cli, "render_dashboard_html", wraps=cli.render_dashboard_html) as render, \
                mock.patch.object(dashboard_data, "_passport_summary", side_effect=AssertionError("Паспорт не нужен дашборду")):
            out = self._run(*full_session())
        render.assert_called_once()
        self.assertEqual(early_html, [(out / "dashboard.html").read_bytes()])

        journals = list((Path(self.tmp.name) / "monitor").glob("run_*.jsonl"))
        self.assertEqual(len(journals), 1)
        events = [json.loads(line) for line in journals[0].read_text(encoding="utf-8").splitlines()]
        self.assertEqual(events[0]["event"], "run_started")
        self.assertEqual(events[-1]["event"], "run_finished")
        self.assertEqual(events[-1]["result"], "success")
        self.assertEqual(
            [event["pass"] for event in events if event["event"] == "pass_started"],
            ["matcher", "critic", "passport"],
        )
        self.assertGreaterEqual(sum(event["event"] == "step_finished" for event in events), 4)
        self.assertTrue(any(event["event"] == "model_ready" for event in events))
        published = next(i for i, event in enumerate(events) if event["event"] == "review_report_written")
        critic_done = next(i for i, event in enumerate(events)
                           if event["event"] == "pass_finished" and event["pass"] == "critic")
        research_started = next(i for i, event in enumerate(events)
                                if event["event"] == "pass_started" and event["pass"] == "passport")
        self.assertLess(critic_done, published)
        self.assertLess(published, research_started)

        files = {p.name for p in out.iterdir()}
        self.assertEqual(files, {"progress_model.json",
                                 "dashboard.html", "client_journey_passport.html", "audit"})
        audits = list((out / "audit").glob("run_*.txt"))
        self.assertEqual(len(audits), 1)
        audit = audits[0].read_text(encoding="utf-8")
        for phase in ("matcher", "critic", "passport"):
            self.assertIn('"pass": "' + phase + '"', audit)
        for event in ("model_request", "model_response", "passport_tool_result", "final_model", "run_finished"):
            self.assertIn('"event": "' + event + '"', audit)
        self.assertNotIn('"reasoning_content"', audit)

        model = json.loads((out / "progress_model.json").read_text(encoding="utf-8"))
        dashboard = (out / "dashboard.html").read_text(encoding="utf-8")
        report, _ = json.JSONDecoder().raw_decode(dashboard.split("window.__DATA__ = ", 1)[1])
        self.assertEqual(set(report), {"meta", "readiness", "readiness_prod", "items", "summary"})
        self.assertEqual(report["readiness"], model["readiness"])
        self.assertIsNotNone(model["integrity"])
        self.assertNotIn("renderConnectivity", dashboard)
        passport = model["passport_data"]
        self.assertEqual(passport["decision-boundary"], "END_TO_END_PROCESS")
        rows = {r["id"]: r for r in passport["registry"]}
        self.assertEqual(set(rows), {"journey-1", "process-1", "bbb-1", "bbb-2",
                                     "operation-1", "operation-2"})
        self.assertEqual(rows["operation-2"]["parent"], "bbb-2")
        self.assertEqual(passport["relations"], [])
        self.assertEqual(passport["evidence_audit"]["mode"], "agentic_review")
        self.assertEqual(passport["schema_version"], 2)
        self.assertNotEqual(passport["completion"]["state"], "complete")
        self.assertTrue(passport["completion"]["pending_reviews"])
        rejected = passport["evidence_audit"]["unresolved_relations"]
        self.assertEqual([(r["from"], r["to"], r["kind"]) for r in rejected], [("bbb-1", "bbb-2", "precedes")])
        self.assertIn("proof", rejected[0]["reason"])
        self.assertTrue(passport["evidence_materials"])
        self.assertTrue(any("паспорт не завершён" in g for g in model["gaps"]), model["gaps"])

        html = (out / "client_journey_passport.html").read_text(encoding="utf-8")
        expected_badge = STATUS_BADGE_FAILED if passport["completion"]["state"] == "failed" else STATUS_BADGE_INCOMPLETE
        self.assertIn(expected_badge, html)
        self.assertIn("Передача исполнителю", html)
        self.assertNotIn("bbb.peredacha-ispolnitelyu", html)  # object-id не входит в карточку
        self.assertIn('"id":"bbb-2"', html)
        self.assertIn('<td data-col="Родитель">bbb-2</td>', html)
        # Потребности и ограничения паспорт больше не выпускает.
        self.assertNotIn('id="related-needs"', html)
        self.assertNotIn('id="related-guardrails"', html)
        self.assertNotIn('id="tpl-need"', html)
        self.assertIn('Неподтверждённая связь', html)
        self.assertNotIn("'button','tool','Что проверено'", html)
        self.assertIn("'button','tool','Как проверяли риски'", html)
        self.assertIn('Где риск не подтвердился и какие защиты найдены', html)
        # Раскладка: заголовок «Паспорт инициативы», карта на всю область с
        # зумом, карточка узла в боковой панели — строятся скриптом.
        # Путь называет агент, а не образ результата.
        self.assertIn("Паспорт системы «mini_repo»", html)
        self.assertIn("Передача задачи исполнителю с отслеживанием статуса", html)
        self.assertIn("pko-viewport", html)
        self.assertIn("pko-drawer", html)
        self.assertIn("pko-zoom", html)
        self.assertNotIn("{{", html.split("<script data-passport-fix>")[0].split("<template", 1)[0])

    def test_default_monitoring_off_keeps_reports_and_audit(self):
        os.environ.pop("PKO_MONITOR_ENABLED", None)
        captured = io.StringIO()
        with mock.patch("sys.stdout", captured):
            out = self._run(*full_session())
        self.assertFalse((Path(self.tmp.name) / "monitor").exists())
        self.assertNotIn("Мониторинг:", captured.getvalue())
        self.assertIn("Журнал анализа:", captured.getvalue())
        for name in ("dashboard.html", "progress_model.json", "client_journey_passport.html"):
            self.assertTrue((out / name).is_file(), name)
        self.assertFalse((out / "progress_report.html").exists())
        audit = next((out / "audit").glob("run_*.txt")).read_text(encoding="utf-8")
        for phase in ("matcher", "critic", "passport"):
            self.assertIn('"pass": "' + phase + '"', audit)
            self.assertIn('"phase": "' + phase + '"', audit)
        self.assertIn('"event": "final_model"', audit)
        self.assertIn('"result": "success"', audit)
        self.assertNotIn('"event": "heartbeat"', audit)

    def test_dashboard_uses_statuses_and_decision_after_critic(self):
        challenge = {
            "item_id": STAGE_ID, "bullet": 1, "status": "partial",
            "reason": "Обработчик принимает заявку и сразу возвращает заготовленный ответ: "
                      "передачи исполнителю в нём нет, сквозной путь обрывается на приёме.",
            "evidence": ROUTER_EVIDENCE,
        }
        out = self._run(*full_session(critic=[challenge]))
        data, _ = json.JSONDecoder().raw_decode(
            (out / "dashboard.html").read_text(encoding="utf-8").split("window.__DATA__ = ", 1)[1])
        self.assertEqual(data["items"][0]["assessment"][0]["status"], "partial")
        model = json.loads((out / "progress_model.json").read_text(encoding="utf-8"))
        self.assertLess(data["readiness"], 40)
        self.assertEqual(data["readiness"], model["readiness"])
        self.assertEqual(data["meta"]["decision"], "PIVOT")

    def test_dashboard_survives_research_setup_failure_or_interruption(self):
        for error, expected_code in ((PkoError("Сбой связности"), 1), (KeyboardInterrupt(), 130)):
            with self.subTest(error=type(error).__name__):
                journey = Path(self.tmp.name) / "initiative.md"
                journey.write_text(JOURNEY_TEXT, encoding="utf-8")
                out = Path(self.tmp.name) / type(error).__name__
                ChatClient._create = scripted_responses(*full_session())
                with mock.patch.object(pipeline, "_run_passport", side_effect=error):
                    code = cli.main(["progress", "--journey-file", str(journey),
                                     "--repo-path", str(self.repo_path), "--out", str(out), "--quiet"])
                self.assertEqual(code, expected_code)
                html = (out / "dashboard.html").read_text(encoding="utf-8")
                data, _ = json.JSONDecoder().raw_decode(html.split("window.__DATA__ = ", 1)[1])
                self.assertEqual(data["readiness"], 50)
                self.assertEqual(data["meta"]["decision"], "GO")
                self.assertFalse((out / "progress_model.json").exists())

    def test_dashboard_survives_passport_failure(self):
        early = []

        def fail_passport(*args, **kwargs):
            path = Path(self.tmp.name) / "out" / "dashboard.html"
            self.assertTrue(path.is_file(), "Дашборд нужен до четвёртого этапа")
            early.append(path.read_bytes())
            raise RuntimeError("Сбой паспортного агента")

        with mock.patch.object(pipeline, "run_passport_agent", side_effect=fail_passport):
            out = self._run(*full_session())
        self.assertEqual(early, [(out / "dashboard.html").read_bytes()])
        model = json.loads((out / "progress_model.json").read_text(encoding="utf-8"))
        self.assertTrue(any("паспорт не сформирован (RuntimeError)" in gap for gap in model["gaps"]))
        self.assertFalse(any("Сбой паспортного агента" in gap for gap in model["gaps"]),
                         "Исходное исключение может содержать секреты; сохраняется только категория")
        self.assertIn(STATUS_BADGE_FAILED,
                      (out / "client_journey_passport.html").read_text(encoding="utf-8"))

    def test_progress_without_passport_session_falls_back(self):
        out = self._run(*full_session(passport=False))
        model = json.loads((out / "progress_model.json").read_text(encoding="utf-8"))
        self.assertFalse(model["passport_data"]["agent_filled"])
        self.assertEqual(model["passport_data"]["evidence_audit"]["unreviewed_nodes"], ["journey-1"])
        self.assertTrue(any("паспорт" in g for g in model["gaps"]), model["gaps"])
        html = (out / "client_journey_passport.html").read_text(encoding="utf-8")
        self.assertIn("Кодовые основания не заполнены", html)
        self.assertEqual(model["passport_data"]["completion"]["state"], "failed")
        self.assertIn(STATUS_BADGE_FAILED, html)

    def test_passport_can_be_switched_off(self):
        os.environ["PKO_PASSPORT"] = "false"
        self.addCleanup(os.environ.pop, "PKO_PASSPORT", None)
        out = self._run(*full_session(passport=False))
        model = json.loads((out / "progress_model.json").read_text(encoding="utf-8"))
        self.assertFalse(model["passport_data"]["agent_filled"])
        self.assertEqual(model["passport_data"]["research_basis"], "code")
        self.assertEqual(model["passport_data"]["nodes"], {})
        self.assertTrue(any("PKO_PASSPORT=false" in g for g in model["gaps"]), model["gaps"])
        # A disabled researcher cannot fabricate a current map from OR promises.
        self.assertIn("Кодовые основания не заполнены",
                      (out / "client_journey_passport.html").read_text(encoding="utf-8"))


class ThinkingFlagTest(unittest.TestCase):
    """Флаг важнее PKO_THINKING, без флага решает переменная."""

    def test_flag_reaches_model_spec_unchanged(self):
        for flags, expected in (([], None), (["--thinking"], True), (["--no-thinking"], False)):
            with self.subTest(flags=flags), tempfile.TemporaryDirectory() as tmp, \
                    mock.patch.object(cli, "get_spec", return_value=None) as get_spec, \
                    mock.patch.object(cli, "init_phoenix_tracing", return_value=None), \
                    mock.patch("sys.stdout", io.StringIO()), mock.patch("sys.stderr", io.StringIO()):
                code = cli.main(["progress", "--journey-text", "x", "--repo-path", tmp,
                                 "--out", str(Path(tmp) / "out"), *flags])
            self.assertEqual(code, 1)  # роль не настроена — дальше не идём
            get_spec.assert_called_once_with("matcher", thinking=expected)


if __name__ == "__main__":
    unittest.main()
