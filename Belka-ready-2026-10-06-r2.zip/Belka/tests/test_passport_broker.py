"""Broker scope, budgets and provenance; no model or live repository calls."""
import hashlib
import json
import unittest

from pko.extractors.base import Fact
from pko.extractors.runner import Extraction
from pko.progress.passport_broker import BROKER_SCHEMA, EvidenceBroker
from pko.progress.passport_evidence import EvidenceCorpus


class MemoryTree:
    def __init__(self, files):
        self.files = list(files)
        self.content = dict(files)
        self.reads = []

    def read(self, path):
        self.reads.append(path)
        value = self.content[path]
        if isinstance(value, Exception):
            raise value
        return value


class EvidenceBrokerTests(unittest.TestCase):
    def broker(self, files=None, facts=(), **limits):
        tree = MemoryTree(files or {"service.py": "def run_service():\n    return prepare_result()\n"})
        corpus = EvidenceCorpus()
        corpus.add("intent", "Образ результата", "Клиент получает результат")
        broker = EvidenceBroker(tree, Extraction(facts=list(facts)), corpus, **limits)
        return broker, tree, corpus

    def test_schema_has_no_repository_mutations_or_freeform_command(self):
        schema = BROKER_SCHEMA["function"]["parameters"]
        self.assertEqual(schema["properties"]["kind"]["enum"], ["file", "callers", "callees", "search"])
        self.assertFalse(schema["additionalProperties"])

    def test_request_adds_handles_but_only_read_authorizes_citation(self):
        broker, _, corpus = self.broker()
        result = broker.request({"kind": "file", "path": "service.py"})
        self.assertTrue(result["ok"])
        row = result["records"][0]
        self.assertEqual(row["id"], "evidence-2")
        self.assertEqual((row["start_line"], row["end_line"]), (1, 2))
        self.assertNotIn("text", row)
        ref = {"id": row["id"], "quote": "return prepare_result()"}
        self.assertTrue(corpus.citations([ref], code=True))
        corpus.read([row["id"]])
        self.assertEqual(corpus.citations([ref], code=True), [])

    def test_repeated_window_is_idempotent_and_snapshot_is_cached(self):
        broker, tree, corpus = self.broker()
        request = {"kind": "file", "path": "service.py"}
        first = broker.request(request)
        tree.content["service.py"] = "changed_live_file()"
        second = broker.request(request)
        self.assertEqual(first["records"], second["records"])
        self.assertEqual(len(corpus.records), 2)
        self.assertEqual(tree.reads, ["service.py"])
        self.assertEqual(first["usage"]["chars"], second["usage"]["chars"])

    def test_secret_files_vendor_and_traversal_never_reach_tree(self):
        unsafe = [".env", "config/.env.local", "cert.pem", "service.key", "store.jks",
                  "config/.env/private.py", "../outside.py", "/absolute.py", "C:/host.py",
                  "nested/../../outside.py", "nested\\..\\outside.py", "node_modules/pkg/main.py"]
        broker, tree, corpus = self.broker({**{path: "secret_value_here" for path in unsafe},
                                           "service.py": "safe_literal_query()"})
        for path in unsafe:
            with self.subTest(path=path):
                self.assertFalse(broker.request({"kind": "file", "path": path})["ok"])
        search = broker.request({"kind": "search", "query": "secret_value_here"})
        self.assertEqual(search["records"], [])
        self.assertEqual(tree.reads, ["service.py"])
        self.assertNotIn("secret_value_here", json.dumps(broker.inventory()))
        self.assertEqual(len(corpus.records), 1)

    def test_secret_assignments_are_masked_and_unmasked_text_hash_is_separate(self):
        source = 'api_key="original-private-value"\nrun_service()'
        broker, _, corpus = self.broker({"service.py": source})
        result = broker.request({"kind": "file", "path": "service.py"})
        inventory = broker.inventory()
        digest = hashlib.sha256(source.encode()).hexdigest()
        self.assertEqual(inventory["source_hashes"], [{"path": "service.py", "sha256": digest}])
        self.assertIn("not raw file or ZIP", inventory["source_hash_scope"])
        self.assertNotEqual(digest, corpus.manifest()["sha256"])
        self.assertNotIn("original-private-value", json.dumps([result, inventory, corpus.records]))
        self.assertIn("***", corpus.records[result["records"][0]["id"]]["text"])

    def test_inventory_is_bounded_does_not_read_and_does_not_invent_archives(self):
        broker, tree, _ = self.broker({"project-a/main.py": "run_service()", "project-b/api.py": "respond()"})
        inventory = broker.inventory()
        self.assertEqual(tree.reads, [])
        self.assertEqual(inventory["files_total"], 2)
        self.assertEqual({row["path"] for row in inventory["components"]}, {"project-a", "project-b"})
        self.assertTrue(all(row["basis"] == "top_level_directory" for row in inventory["components"]))
        self.assertTrue(inventory["archive_provenance"].startswith("unknown"))
        self.assertFalse(inventory["source_hashes_complete"])

    def test_file_symbol_and_both_call_directions_use_known_extraction_facts(self):
        files = {"entry.py": "def entry():\n    return helper()", "helpers.py": "def helper():\n    return 42"}
        facts = [Fact("FUNCTION", "entry", None, "entry.py", 1),
                 Fact("FUNCTION", "helper", None, "helpers.py", 1),
                 Fact("CALLS", "entry -> helper", {"caller": "entry", "callee": "helper"}, "entry.py", 2)]
        broker, _, corpus = self.broker(files, facts)
        symbols = {row["name"]: row["id"] for row in broker.inventory()["symbols"]}
        definition = broker.request({"kind": "file", "id": symbols["helper"]})
        self.assertEqual(definition["records"][0]["path"], "helpers.py")
        callers = broker.request({"kind": "callers", "id": symbols["helper"]})
        self.assertEqual(callers["call_edges"], 1)
        self.assertEqual({r["path"] for r in callers["records"]}, {"entry.py"})
        callees = broker.request({"kind": "callees", "id": symbols["entry"]})
        self.assertEqual({r["path"] for r in callees["records"]}, {"entry.py", "helpers.py"})
        self.assertIn("approximate", callees["resolution"])
        self.assertEqual(corpus.shown, {})

    def test_search_is_literal_and_respects_component_scope(self):
        files = {"a/api.py": 'invoke("/run-step")', "b/api.py": 'invoke("/run-step")',
                 "a/other.py": "irrelevant_value()"}
        broker, _, corpus = self.broker(files)
        result = broker.request({"kind": "search", "path": "a", "query": "/run-step"})
        self.assertEqual({r["path"] for r in result["records"]}, {"a/api.py"})
        regex = broker.request({"kind": "search", "query": ".*"})
        self.assertEqual(regex["records"], [])
        self.assertIn("не доказывает", regex["scope"])
        self.assertEqual(corpus.shown, {})

    def test_sql_callers_and_ambiguous_same_name_definitions_are_not_lost(self):
        files = {"proc.sql": "CREATE PROC notify AS SELECT 1", "task.sql": "EXEC notify", "other.sql": "CREATE PROC notify AS SELECT 2"}
        facts = [Fact("SQL_PROC", "notify", "", "proc.sql", 1),
                 Fact("SQL_PROC", "notify", "", "other.sql", 1),
                 Fact("SQL_CALL", "notify", "", "task.sql", 1)]
        broker, _, _ = self.broker(files, facts)
        result = broker.request({"kind": "callers", "id": "symbol-1"})
        self.assertEqual(result["call_edges"], 1)
        self.assertEqual(result["records"][0]["path"], "task.sql")
        self.assertEqual(broker.inventory()["symbols_total"], 2)
        self.assertIn("same-name", result["resolution"])

    def test_window_can_retrieve_omitted_tail_without_whole_file_in_corpus(self):
        source = "\n".join(f"line_{i}()" for i in range(1, 301))
        broker, _, corpus = self.broker({"large.py": source}, window_lines=20)
        result = broker.request({"kind": "file", "path": "large.py", "line": 250})
        row = result["records"][0]
        self.assertEqual((row["start_line"], row["end_line"]), (240, 259))
        text = corpus.records[row["id"]]["text"]
        self.assertIn("250: line_250()", text)
        self.assertNotIn("1: line_1()", text)

    def test_new_file_budget_does_not_count_files_already_in_initial_corpus(self):
        tree = MemoryTree({"known.py": "known_operation()", "new.py": "new_operation()", "other.py": "other_operation()"})
        corpus = EvidenceCorpus()
        corpus.add("code", "known.py:1", "1: known_operation()")
        broker = EvidenceBroker(tree, Extraction(), corpus, max_new_files=1)
        self.assertTrue(broker.request({"kind": "file", "path": "known.py"})["ok"])
        self.assertTrue(broker.request({"kind": "file", "path": "new.py"})["ok"])
        result = broker.request({"kind": "file", "path": "other.py"})
        self.assertEqual(result["error"], "new_file_budget")
        self.assertNotIn("other.py", tree.reads)
        self.assertEqual(broker.inventory()["audit"][-1]["omitted"][0]["reason"], "new_file_budget")

    def test_request_character_and_symbol_limits_are_enforced(self):
        broker, _, _ = self.broker(max_requests=1)
        broker.request({"kind": "file", "path": "service.py"})
        self.assertEqual(broker.request({"kind": "file", "path": "service.py"})["error"], "request_budget")
        broker, _, corpus = self.broker(max_chars=5)
        self.assertEqual(broker.request({"kind": "file", "path": "service.py"})["error"], "corpus_character_budget")
        self.assertEqual(len(corpus.records), 1)
        facts = [Fact("FUNCTION", "one", None, "service.py", 1), Fact("FUNCTION", "two", None, "service.py", 2)]
        broker, _, _ = self.broker(facts=facts, max_symbols=1)
        self.assertTrue(broker.request({"kind": "callers", "id": "symbol-1"})["ok"])
        self.assertEqual(broker.request({"kind": "callers", "id": "symbol-2"})["error"], "symbol_budget")

    def test_search_source_budget_and_failed_reads_do_not_become_proof_of_absence(self):
        broker, tree, _ = self.broker({"a.py": "nothing_here()", "b.py": "expected_control()"}, max_source_files=1)
        result = broker.request({"kind": "search", "query": "expected_control"})
        self.assertTrue(result["truncated"])
        self.assertEqual(tree.reads, ["a.py"])
        self.assertFalse(broker.inventory()["source_hashes_complete"])
        broker, _, _ = self.broker({"bad.py": RuntimeError("password=private-exception")})
        result = broker.request({"kind": "file", "path": "bad.py"})
        self.assertFalse(result["ok"])
        self.assertNotIn("private-exception", json.dumps([result, broker.inventory()]))
        search = broker.request({"kind": "search", "query": "no_match"})
        self.assertTrue(search["truncated"])
        self.assertEqual(search["unreadable_files"], 1)

    def test_invalid_model_arguments_never_raise_or_read(self):
        broker, tree, _ = self.broker()
        bad = [None, [], {}, {"kind": []}, {"kind": "file", "path": "service.py", "line": True},
               {"kind": "file", "path": "service.py", "line": 0},
               {"kind": "search", "query": "x"}, {"kind": "search", "query": "xxx", "command": "rm"},
               {"kind": "callers", "id": "symbol-999"}, {"kind": "file", "path": "service.py", "id": []}]
        for args in bad:
            with self.subTest(args=args):
                self.assertFalse(broker.request(args)["ok"])
        self.assertEqual(tree.reads, [])
        self.assertEqual(len(broker.inventory()["audit"]), len(bad))

    def test_documents_do_not_become_code_and_outside_line_does_not_add_evidence(self):
        broker, _, corpus = self.broker({"intent.md": "Always verify and deliver the result"})
        result = broker.request({"kind": "file", "path": "intent.md"})
        eid = result["records"][0]["id"]
        corpus.read([eid])
        self.assertTrue(corpus.citations([{"id": eid, "quote": "Always verify and deliver the result"}], code=True))
        before = len(corpus.records)
        self.assertEqual(broker.request({"kind": "file", "path": "intent.md", "line": 999})["error"], "line_outside_file")
        self.assertEqual(len(corpus.records), before)


if __name__ == "__main__":
    unittest.main()
