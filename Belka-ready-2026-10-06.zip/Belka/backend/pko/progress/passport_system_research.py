"""Qualitative system research inside the passport session, without a second agent.

Only delivered, masked corpus windows can establish source references. This
adapter reuses coherence guards and models, but owns no repository tools and
calculates neither readiness nor GO/PIVOT.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, dataclass, field, is_dataclass
import json
import re
from typing import Any

from pko.progress.coherence import (
    _SUBMIT_SYSTEM_SCHEMA, _SUBMIT_FLOW_SCHEMA, _SUBMIT_FLAW_SCHEMA,
    _SUBMIT_INTEGRITY_SCHEMA, _match_bullets, _text_problem,
)
from pko.progress.passport_evidence import EvidenceCorpus
from pko.progress.passport_workspace import digest
from pko.progress.schema import (
    EvidenceRef, FlowTrace, IntegrityReview, SystemFlaw, SystemPurpose,
    FLAW_KINDS, FLAW_SEVERITIES, INTEGRITY_LEVELS, PURPOSE_VERDICTS,
    integrity_level_problem, purpose_verdict_problem,
)
from pko.progress.verify import verify_evidence

MAX_SOURCE_LINE = 1_000_000
MAX_EVIDENCE = 12
MAX_FLAWS = 12
MAX_FLAW_REFS = 32
_COMPARATIVE_VERDICTS = tuple(value for value in PURPOSE_VERDICTS if value != "code_derived")
_NUMBERED = re.compile(r"^\s*(\d+): ?(.*)$")
_NAMES = ("submit_system", "submit_flow", "submit_flaw", "submit_integrity")
_SOURCE_SCHEMA = {"type": "array", "minItems": 1, "maxItems": MAX_EVIDENCE,
    "description": "Только прочитанные code-фрагменты. Строка и путь должны относиться к конкретной цитате.",
    "items": {"type": "object", "properties": {
        "id": {"type": "string"}, "quote": {"type": "string", "minLength": 12},
        "path": {"type": "string", "maxLength": 512}, "line": {"type": "integer", "minimum": 1, "maximum": MAX_SOURCE_LINE},
        "basis": {"type": "string", "maxLength": 300}, "note": {"type": "string", "maxLength": 400}},
        "required": ["id", "quote", "path", "line", "basis"]}}


def _schemas() -> list[dict]:
    result = deepcopy([_SUBMIT_SYSTEM_SCHEMA, _SUBMIT_FLOW_SCHEMA,
                       _SUBMIT_FLAW_SCHEMA, _SUBMIT_INTEGRITY_SCHEMA])
    descriptions = {
        "submit_system": "Сохранить или пересмотреть фактическое назначение системы по прочитанному коду. Не переписывает оценки пунктов ОР.",
        "submit_flow": "Сохранить или пересмотреть сквозной путь системы, включая доказанный обрыв либо границу знания. Неизвестное продолжение не означает доказанный разрыв.",
        "submit_flaw": "Сохранить изъян связности; id пересматривает существующий. action=withdraw с id, reason и evidence отзывает ошибочный вывод с историей и проверкой.",
        "submit_integrity": "Сохранить или пересмотреть качественный вывод о связности. unknown — исследовано, но связность не установлена; выдумывать изъян для этого не нужно. Код перепроверяет согласованность при завершении.",
    }
    for schema in result:
        fn = schema["function"]
        fn["description"] = descriptions[fn["name"]]
        params = fn["parameters"]
        params["properties"]["evidence"] = deepcopy(_SOURCE_SCHEMA)
        params["required"] = list(dict.fromkeys(params.get("required", []) + ["evidence"]))
        if fn["name"] == "submit_flaw":
            params["properties"].update(id={"type": "string"},
                action={"type": "string", "enum": ["upsert", "withdraw"]}, reason={"type": "string"})
            params["required"] = ["evidence"]
        elif fn["name"] == "submit_flow":
            params["properties"]["complete"]["description"] = "true — весь путь подтверждён; false — доказан обрыв либо продолжение не установлено. Различие обязательно объясни в break_point."
            params["properties"]["break_point"]["description"] = "При complete=false: конкретный доказанный обрыв или граница прослеженного пути с указанием недостающих данных."
    return result


def system_research_schemas(research_basis: str = "result_image") -> list[dict]:
    """Expose the session's research contract without mutating legacy schemas."""
    result = _schemas()
    system = result[0]["function"]
    system["parameters"]["properties"]["verdict"]["enum"] = list(_COMPARATIVE_VERDICTS)
    if research_basis != "code":
        return result
    for schema in result:
        fn = schema["function"]
        params = fn["parameters"]
        props = params["properties"]
        params["additionalProperties"] = False
        if fn["name"] == "submit_system":
            fn["description"] = "Сохранить или пересмотреть назначение системы, восстановленное по прочитанному коду: кому она помогает, как работает и где проходят границы подтверждённого поведения."
            props.pop("verdict", None)
            params["required"] = [key for key in params["required"] if key != "verdict"]
            props["not_does"]["description"] = "120–600 символов: границы наблюдаемого поведения, делегированные действия и неизвестные результаты. Не выдавай отсутствие доказательства за доказанное отсутствие возможности."
        elif fn["name"] == "submit_flaw":
            props.pop("bullets", None)
            props["kind"]["enum"] = [kind for kind in FLAW_KINDS if kind != "scope_mismatch"]
            props["kind"]["description"] = (
                "broken_chain — обрыв пути; no_orchestration — отсутствует требуемое наблюдаемым механизмом управление; "
                "state_lost — теряется состояние; one_way_integration — обратное действие не подключено; "
                "result_not_delivered — результат не достигает потребителя наблюдаемого пути; data_not_used — данные не используются; "
                "stub_on_seam — заглушка на стыке; catalog_empty — используемый каталог не наполнен; "
                "manual_trigger — ручной запуск нарушает подтверждённый механизм; duplicate_logic — расходящиеся дубли; "
                "no_feedback_loop — действие остаётся без необходимого подтверждения. Сам по себе ручной запуск или неизвестное продолжение не доказывают изъян.")
            props["severity"]["description"] = "blocker — подтверждённый изъян блокирует исследуемый путь; major — нарушает существенную часть поведения; minor — изъян есть, но путь проходит."
            props["detail"]["description"] = "120–600 символов: что работает, где подтверждён дефект и как он влияет на фактический бизнес-путь. Без имён функций и путей; цитаты кода — в evidence."
            for key, label in (("nodes", "узлов"), ("scenarios", "сценариев")):
                props[key] = {"type": "array", "maxItems": MAX_FLAW_REFS, "uniqueItems": True,
                    "items": {"type": "string"}, "description": f"ID действующих {label}, затронутых изъяном, если они уже выделены. Список можно дополнить при пересмотре."}
        elif fn["name"] == "submit_integrity":
            props["note"]["description"] = "60–400 символов: как исследованные части складываются в бизнес-путь, каковы подтверждённые ограничения и что осталось неизвестным."
    return result


SYSTEM_RESEARCH_SCHEMAS = system_research_schemas()


def _numbered(text: str) -> dict[int, str]:
    return {int(m[1]): m[2] for line in text.splitlines()
            if (m := _NUMBERED.match(line)) and 0 < int(m[1]) <= MAX_SOURCE_LINE}


class _EvidenceTree:
    """Sparse source view; gaps are comments so nearby anchors cannot verify them."""

    def __init__(self, corpus: EvidenceCorpus | None):
        self._lines: dict[str, dict[int, str]] = {}
        self._cache: dict[str, str] = {}
        conflicts = set()
        if corpus is not None:
            for eid, delivered in corpus.shown.items():
                row = corpus.records.get(eid, {})
                if row.get("kind") != "code":
                    continue
                path = str(row.get("label", "")).rsplit(":", 1)[0]
                if not path:
                    continue
                known = self._lines.setdefault(path, {})
                for text in delivered:
                    for line, value in _numbered(text).items():
                        if line in known and known[line] != value:
                            conflicts.add(path)
                        known[line] = value
        self._lines = {path: lines for path, lines in self._lines.items() if lines and path not in conflicts}
        self.files = sorted(self._lines)
        self.files_set = frozenset(self.files)

    def read(self, path: str) -> str | None:
        lines = self._lines.get(path)
        if not lines:
            return None
        if path not in self._cache:
            self._cache[path] = "\n".join(lines.get(number, "#") for number in range(1, max(lines) + 1))
        return self._cache[path]


def evidence_tree(corpus: EvidenceCorpus | None) -> _EvidenceTree:
    """Tree-compatible view of actually delivered code; performs no source I/O."""
    return _EvidenceTree(corpus)


def verified_corpus_evidence(corpus: EvidenceCorpus | None, refs: Any) -> tuple[list[EvidenceRef], list[str]]:
    """Validate citations and legacy path/line/anchor links against the same read text."""
    if corpus is None:
        return [], ["нужен корпус прочитанных оснований"]
    if not isinstance(refs, list) or not 1 <= len(refs) <= MAX_EVIDENCE:
        return [], [f"evidence должен содержать 1–{MAX_EVIDENCE} прочитанных цитат кода"]
    errors = corpus.citations(refs, code=True)
    if errors:
        return [], errors
    tree = evidence_tree(corpus)
    verified = []
    for ref in refs:
        path, line, basis = ref.get("path"), ref.get("line"), ref.get("basis")
        eid, quote = ref["id"], ref["quote"]
        record_path = str(corpus.records[eid].get("label", "")).rsplit(":", 1)[0]
        if not isinstance(path, str) or len(path) > 512 or path != record_path:
            errors.append(f"{eid}: path должен совпадать с путём процитированного фрагмента")
            continue
        if type(line) is not int or not 1 <= line <= MAX_SOURCE_LINE:
            errors.append(f"{eid}: нужен целый номер строки 1–{MAX_SOURCE_LINE}")
            continue
        rows = _numbered(corpus.records[eid].get("text", ""))
        code = rows.get(line, "").strip()
        # Accept a quote omitting the numbered prefix only if it still contains
        # source from the specific target line, not an adjacent anchor.
        quoted_rows = _numbered(quote)
        if (line not in quoted_rows if quoted_rows else not (code and (quote.strip() in code or code in quote))):
            errors.append(f"{eid}: строка {line} должна находиться в этой цитате")
            continue
        if not isinstance(basis, str) or not basis.strip() or len(basis) > 300:
            errors.append(f"{eid}: нужен конкретный якорь basis из кода, до 300 символов")
            continue
        if not isinstance(ref.get("note", ""), str) or len(ref.get("note", "")) > 400:
            errors.append(f"{eid}: note должен быть текстом до 400 символов")
            continue
        verdict = verify_evidence(path, line, basis, tree)
        if not verdict.ok:
            errors.append(verdict.reason)
            continue
        verified.append(EvidenceRef(path, line, basis.strip(), True, verdict.reason,
                                    str(ref.get("note") or "").strip()))
    return ([] if errors else verified), errors


@dataclass
class _SystemResearch:
    purpose: SystemPurpose | None = None
    flow: FlowTrace | None = None
    flaws: dict[str, SystemFlaw] = field(default_factory=dict)
    level: str = ""
    note: str = ""
    records: dict[str, dict] = field(default_factory=dict)
    retirements: dict[str, dict] = field(default_factory=dict)
    next_flaw: int = 1
    context_basis: str = ""


def _research(state: Any) -> _SystemResearch:
    current = getattr(state, "system_research_state", None)
    if current is None:
        current = _SystemResearch()
        state.system_research_state = current
    return current


def _basis(state: Any) -> str:
    return "code" if getattr(state, "research_basis", "result_image") == "code" else "result_image"


def _flaw_refs(state: Any, values: Any, label: str) -> list[str]:
    if not isinstance(values, list) or len(values) > MAX_FLAW_REFS or any(not isinstance(v, str) for v in values):
        raise ValueError(f"{label}: нужен массив до {MAX_FLAW_REFS} действующих ID")
    if len(set(values)) != len(values):
        raise ValueError(f"{label}: ID не должны повторяться")
    if label == "nodes":
        live = getattr(state, "nodes", {})
    else:
        conn = getattr(state, "connectivity_state", None)
        live = getattr(conn, "order", getattr(state, "scenarios", {}))
    if any(value not in live for value in values):
        raise ValueError(f"{label}: ссылка на неизвестный или отозванный объект; пересмотри изъян")
    return list(values)


def _text(value: Any, label: str, minimum: int, maximum: int, tree: _EvidenceTree) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{label}: нужен текст")
    text = " ".join(value.split())
    if not minimum <= len(text) <= maximum:
        raise ValueError(f"{label}: нужно {minimum}–{maximum} символов; текст не обрезается автоматически")
    problem = _text_problem(label, text, tree)
    if problem:
        raise ValueError(problem)
    return text


def _context(state: Any) -> dict:
    connectivity = getattr(state, "connectivity_state", None)
    scenarios = getattr(connectivity, "scenarios", {}) if connectivity is not None else {}
    return {"research_basis": _basis(state),
            "scenarios": {sid: asdict(s) if is_dataclass(s) else s for sid, s in scenarios.items()},
            "scenario_definitions": getattr(state, "scenarios", {}),
            "scenario_context": getattr(state, "scenario_context", {}),
            "trace_versions": getattr(connectivity, "trace_versions", {}),
            "scenario_revisions": getattr(connectivity, "revisions", {}),
            "nodes": {nid: {"name": node.name, "data": node.data, "parents": node.parents, "children": node.children,
                            "planned": node.planned, "filled": node.filled}
                      for nid, node in getattr(state, "nodes", {}).items()},
            "relations": getattr(state, "relations", []), "defects": getattr(state, "defects", []),
            "guardrails": getattr(state, "guardrails", []), "risks": getattr(state, "risks", [])}


def _source_refs(refs: list[dict]) -> list[dict]:
    # Full quoted materials remain in the corpus and audit event. Reviewers read
    # them independently instead of receiving repeated multi-page quotations.
    return [{**{key: ref[key] for key in ("id", "path", "line", "basis", "note") if key in ref},
             "quote_sha256": digest(ref.get("quote", "")), "quote_chars": len(ref.get("quote", ""))}
            for ref in refs]


def _review_record(state: Any, record: dict, *, nested: bool = False) -> dict:
    value = deepcopy(record["value"])
    value.pop("links", None)  # Coordinates are already present in evidence.
    if "bullets" in value:
        bullets = value.pop("bullets")
        if record.get("research_basis", "result_image") != "code":
            plan = getattr(state, "plan_bullets", [])
            value["bullet_indices"] = [i for i, text in enumerate(plan) if text in bullets]
    refs = record.get("evidence", [])
    return {"type": record["type"], "value": value, "revision": digest(record),
            "research_basis": record.get("research_basis", "result_image"),
            "evidence_ids": list(dict.fromkeys(ref["id"] for ref in refs)),
            **({} if nested else {"evidence": _source_refs(refs)})}


def _preview(value: Any, limit: int = 160) -> str:
    text = str(value or "")
    return text if len(text) <= limit else text[:limit] + "… [сокращённая подпись]"


def _pack(rows: list[dict], budget: int) -> dict:
    selected, size = [], 0
    for row in rows:
        chars = len(json.dumps(row, ensure_ascii=False))
        if size + chars > budget:
            continue
        selected.append(row)
        size += chars
    return {"items": selected, "total": len(rows), "omitted": len(rows) - len(selected)}


def _review_context(state: Any, context: dict) -> dict:
    nodes = [{"id": nid, "name": _preview(row["name"], 120), "parents": row["parents"],
              "scenarios": row["data"].get("scenarios", []), "planned": row["planned"]}
             for nid, row in context["nodes"].items()]
    scenarios = []
    for sid, row in context["scenarios"].items():
        checks = [{"step": handoff.get("step"), "check": check.get("check"), "result": check.get("result"),
                   "note": _preview(check.get("note"), 100)}
                  for handoff in row.get("handoffs", []) for check in handoff.get("checks", [])]
        scenarios.append({"id": sid, "title": _preview(row.get("title")),
                          "entry": _preview(row.get("entry")), "outcome": _preview(row.get("outcome")),
                          "steps": [_preview(step, 100) for step in row.get("steps", [])],
                          "checks": _pack(checks, 1800)})
    if not scenarios:
        scenarios = [{"id": sid, "steps": [_preview(step, 100) for step in steps]}
                     for sid, steps in context["scenario_definitions"].items()]
    return {"research_basis": _basis(state),
            "business_nodes": _pack(nodes, 6500), "scenarios": _pack(scenarios, 4500),
            **({} if _basis(state) == "code" else {"intent_evidence_ids": [
                eid for eid, row in getattr(state.evidence_corpus, "records", {}).items() if row.get("kind") == "intent"]}),
            "scope": "Краткий контекст; полный состав учтён в revision. Сокращённые подписи не являются доказательством; прочитай evidence из корпуса."}


def sync_system_research_objects(state: Any) -> set[str]:
    """Return live IDs for workspace synchronization; dependencies flow one way."""
    if not getattr(state, "research_enabled", False):
        return set()
    research = _research(state)
    basis = _basis(state)
    if research.context_basis and research.context_basis != basis:
        state.risk_reviewed = False
    research.context_basis = basis
    context = _context(state)
    context_revision, preview = digest(context), _review_context(state, context)
    live = set()
    for oid, record in research.records.items():
        live.add(oid)
        content = {**_review_record(state, record), "system_context_revision": context_revision,
                   "context": preview}
        if oid == "system:integrity":
            content["conclusions"] = {key: _review_record(state, value, nested=True)
                                      for key, value in research.records.items() if key != oid}
        state.workspace.put(oid, "claim", content)
    for oid in research.retirements:
        live.add(oid)
        state.workspace.put(oid, "claim", state.workspace.retirements[oid])
    return live


def system_review(state: Any) -> IntegrityReview | None:
    """Export accepted content even if research stopped before its final judgment."""
    research = getattr(state, "system_research_state", None)
    if research is None or not (research.records or research.retirements):
        return None
    return IntegrityReview(level=research.level, note=research.note,
        purpose=deepcopy(research.purpose), flow=deepcopy(research.flow),
        flaws=deepcopy(list(research.flaws.values())),
        checked=0 if _basis(state) == "code" else len(getattr(state, "plan_bullets", [])))


def system_research_blockers(state: Any) -> list[str]:
    if not getattr(state, "research_enabled", False):
        return []
    research = _research(state)
    errors = []
    for oid, record in research.records.items():
        if record.get("research_basis", "result_image") != _basis(state):
            errors.append(f"{oid}: вывод относится к другому основанию исследования; пересмотри его")
        if record["type"] == "submit_flaw" and record.get("research_basis") == "code":
            for key in ("nodes", "scenarios"):
                try:
                    _flaw_refs(state, record["value"].get(key, []), key)
                except ValueError as exc:
                    errors.append(f"{oid}: {exc}")
    if research.purpose is None:
        errors.append("не описано фактическое назначение системы: submit_system")
    if research.flow is None:
        errors.append("не прослежен сквозной путь системы: submit_flow")
    if not research.level:
        errors.append("нет качественного вывода о связности: submit_integrity")
    else:
        problem = integrity_level_problem(research.level, list(research.flaws.values()))
        if problem:
            errors.append(problem)
        if research.level == "coherent" and research.flow is not None and not research.flow.complete:
            errors.append("связность объявлена полной, но весь сквозной путь не подтверждён")
        if research.level == "coherent" and (broken := _broken_scenarios(state)):
            errors.append("связность объявлена полной при подтверждённых разрывах сценариев: " + ", ".join(broken))
    if research.purpose is not None:
        problem = purpose_verdict_problem(research.purpose.verdict, list(research.flaws.values()))
        if problem:
            errors.append(problem)
    return errors


def _broken_scenarios(state: Any) -> list[str]:
    conn = getattr(state, "connectivity_state", None)
    scenarios = getattr(conn, "scenarios", {})
    return [sid for sid in getattr(conn, "order", list(scenarios))
            if sid in scenarios and scenarios[sid].status == "broken"]


def handle_system_research(state: Any, name: str, args: dict) -> str:
    if name not in _NAMES or not getattr(state, "research_enabled", False):
        return f"{name} отклонён: системное исследование недоступно в этой сессии."
    try:
        return _handle(state, name, args)
    except (ValueError, TypeError, KeyError, AttributeError) as exc:
        message = str(exc) if isinstance(exc, ValueError) else "некорректная структура аргументов"
        return f"{name} отклонён: {message}"


def _handle(state: Any, name: str, args: dict) -> str:
    if not isinstance(args, dict):
        raise ValueError("нужен объект аргументов")
    code_mode = _basis(state) == "code"
    if code_mode:
        params = next(s["function"]["parameters"] for s in system_research_schemas("code")
                      if s["function"]["name"] == name)
        if set(args) - set(params["properties"]):
            raise ValueError("переданы поля вне контракта исследования кода; verdict и bullets здесь не задаются")
    corpus = getattr(state, "evidence_corpus", None)
    evidence, errors = verified_corpus_evidence(corpus, args.get("evidence"))
    if errors:
        raise ValueError("; ".join(errors[:8]))
    tree, research = evidence_tree(corpus), _research(state)
    oid = {"submit_system": "system:purpose", "submit_flow": "system:flow",
           "submit_integrity": "system:integrity"}.get(name, "")
    value: Any = None
    if name == "submit_system":
        verdict = "code_derived" if code_mode else args.get("verdict")
        if not code_mode and verdict not in _COMPARATIVE_VERDICTS:
            raise ValueError("verdict: " + ", ".join(_COMPARATIVE_VERDICTS))
        value = SystemPurpose(_text(args.get("does"), "does", 200, 700, tree),
            _text(args.get("not_does"), "not_does", 120, 600, tree), verdict, evidence)
    elif name == "submit_flow":
        if type(args.get("complete")) is not bool:
            raise ValueError("complete должен быть true или false")
        steps = args.get("steps")
        if not isinstance(steps, list) or not 2 <= len(steps) <= 7:
            raise ValueError("steps должен содержать 2–7 шагов")
        complete = args["complete"]
        value = FlowTrace(_text(args.get("entry"), "entry", 1, 160, tree),
            [_text(step, "step", 1, 160, tree) for step in steps],
            _text(args.get("outcome"), "outcome", 1, 160, tree), complete,
            "" if complete else _text(args.get("break_point"), "break_point", 1, 600, tree), evidence)
    elif name == "submit_flaw":
        action, fid = args.get("action", "upsert"), args.get("id")
        if action not in ("upsert", "withdraw"):
            raise ValueError("action: upsert или withdraw")
        if fid is not None and fid not in research.flaws:
            raise ValueError("неизвестный id изъяна; новый изъян передавай без id")
        if action == "withdraw":
            if not fid:
                raise ValueError("для отзыва нужен id существующего изъяна")
            reason = _text(args.get("reason"), "reason", 30, 600, tree)
            rid = "retirement:" + fid
            decision = {"previous": deepcopy(research.records[fid]), "reason": reason,
                        "evidence": deepcopy(args["evidence"])}
            research.retirements[rid] = decision
            state.workspace.retirements[rid] = {"object_id": fid,
                "previous": _review_record(state, research.records[fid]), "reason": reason,
                "evidence": _source_refs(args["evidence"]), "revision": digest(decision)}
            state.workspace.event("system_flaw_withdrawn", object_id=fid, decision=decision)
            del research.flaws[fid]
            del research.records[fid]
            state.risk_reviewed = False
            state.workspace.objects.pop(fid, None)
            state.workspace.reviews.pop(fid, None)
            sync_system_research_objects(state)
            return f"{name} принят: {fid} отозван; решение {rid} требует независимой проверки."
        if fid is None and len(research.flaws) >= MAX_FLAWS:
            raise ValueError(f"достигнут предел {MAX_FLAWS} изъянов; пересмотри существующие по id")
        kind, severity = args.get("kind"), args.get("severity")
        if kind not in FLAW_KINDS or severity not in FLAW_SEVERITIES:
            raise ValueError("kind и severity должны принадлежать закрытым спискам схемы")
        if code_mode and kind == "scope_mismatch":
            raise ValueError("scope_mismatch сравнивает с замыслом; у исследования кода такого вердикта нет")
        title = _text(args.get("title"), "title", 1, 80, tree)
        if any(key != fid and flaw.kind == kind and flaw.title.casefold() == title.casefold()
               for key, flaw in research.flaws.items()):
            raise ValueError("такой изъян уже принят; пересмотри его по существующему id")
        value = SystemFlaw(kind, severity, title, _text(args.get("detail"), "detail", 120, 600, tree),
            [] if code_mode else _match_bullets(args.get("bullets"), getattr(state, "plan_bullets", [])), evidence,
            **({key: _flaw_refs(state, args.get(key, []), key) for key in ("nodes", "scenarios")} if code_mode else {}))
        oid = fid or f"system:flaw-{research.next_flaw}"
    else:
        level = args.get("level")
        if level not in INTEGRITY_LEVELS:
            raise ValueError("level: " + ", ".join(INTEGRITY_LEVELS))
        problem = integrity_level_problem(level, list(research.flaws.values()))
        if problem:
            raise ValueError(problem)
        if research.purpose is not None and research.records["system:purpose"].get("research_basis", "result_image") == _basis(state):
            problem = purpose_verdict_problem(research.purpose.verdict, list(research.flaws.values()))
            if problem:
                raise ValueError(problem)
        if level == "coherent" and research.flow is not None and not research.flow.complete:
            raise ValueError("coherent требует подтверждённого сквозного пути")
        if level == "coherent" and _broken_scenarios(state):
            raise ValueError("coherent противоречит подтверждённому разрыву сценария")
        value = {"level": level, "note": _text(args.get("note"), "note", 60, 400, tree)}
    record = {"type": name, "value": value.to_dict() if hasattr(value, "to_dict") else deepcopy(value),
              "evidence": deepcopy(args["evidence"]), "research_basis": _basis(state)}
    if name != "submit_integrity" and research.records.get(oid) != record:
        state.risk_reviewed = False
    state.workspace.event("system_conclusion_updated", object_id=oid,
                          previous=research.records.get(oid), content=record)
    research.records[oid] = record
    if name == "submit_system":
        research.purpose = value
    elif name == "submit_flow":
        research.flow = value
    elif name == "submit_flaw":
        research.flaws[oid] = value
        if args.get("id") is None:
            research.next_flaw += 1
    else:
        research.level, research.note = value["level"], value["note"]
    sync_system_research_objects(state)
    return f"{name} принят: {oid}. Текущая версия требует независимой проверки; исследование можно продолжать."
