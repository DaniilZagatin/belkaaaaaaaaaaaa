"""Code reconstruction never inherits OR ratings or unfilled OR copy."""
import copy
import json
import re
import unittest
from html.parser import HTMLParser
from unittest.mock import patch

from pko.extractors.runner import Extraction
from pko.progress.plan_input import parse_plan_text
from pko.progress.schema import (
    ConnectivityReview, CriterionVerdict, EvidenceRef, HANDOFF_CHECKS,
    Handoff, HandoffCheck, ItemVerdict, PlanItem, ProgressModel, Scenario,
)
from pko.render.client_journey_passport import render_passport_from_model
from pko.render.passport_map import build_passport_map
from test_passport_completion_ui import passport_fixture
from test_passport_v2_model import execution


PROMISE = "ОР_ОБЕЩАЕТ_ПОЛНОЕ_ОФОРМЛЕНИЕ"


def code_model(*, empty=False, grounded=True):
    data = passport_fixture()
    data.update(schema_version=2, research_basis="code", research_mode="code_reconstruction",
                completion={"state": "incomplete", "reason": "Остались вопросы по источникам."})
    for node in data["nodes"].values():
        node.update(agent_contract=2, research_basis="code", bullets=[PROMISE])
    operation = data["nodes"]["operation-1"]
    if grounded:
        operation["fact_check"] = execution()
    else:
        operation.update(fields={}, fact_check={})
    if empty:
        data.update(agent_filled=False, nodes={}, tree=[], registry=[])
    model = ProgressModel(meta={}, items={"item-1": PlanItem(
        id="item-1", title="ОР", criteria=[PROMISE], origin="user")},
        verdicts=[ItemVerdict(item_id="item-1", applicable=True, criteria=[
            CriterionVerdict(applicable=True, status="planned", proof="", how="")])])
    model.passport_data = data
    model.readiness = 0
    return model


def scenario(sid, *, result="ok"):
    reference = EvidenceRef(path="worker.py", line=8, basis="prepare_result", verified=True, reason="code")
    return Scenario(id=sid, title="Обработка запроса " + sid,
                    entry="Получен запрос", outcome="Подготовлен результат", steps=["Вход", "Обработка"],
                    handoffs=[Handoff(step=0, checks=[
                        HandoffCheck(check=check, result=result if check == "reachability" else "ok",
                                     note="Переход проверен по коду", evidence=[reference],
                                     support="code", confidence="high") for check in HANDOFF_CHECKS])])


def render(model):
    plan = parse_plan_text("Клиентский путь: ОР_ПУТЬ\nПроект: ОР_ПРОЕКТ\n"
                           "До: ОР_ДО\nПосле: ОР_ПОСЛЕ\n## ОР_ЭТАП\n- " + PROMISE + ".\n")
    plan.context.update(before="ОР_ДО", after="ОР_ПОСЛЕ")
    html = render_passport_from_model(model, plan, "repo/system", Extraction(facts=[]), "abc123", "main")
    match = re.search(r"var SCHEMA=(.*?); var meta=", html, re.S)
    return html, json.loads(match.group(1))


class PassportCodePresentationTests(unittest.TestCase):
    def test_code_map_is_invariant_to_or_readiness_and_verdict(self):
        model = code_model()
        model.connectivity = ConnectivityReview(scenarios=[scenario("scenario-1")], basis="code")
        first = build_passport_map(model)
        model.readiness = 100
        model.verdicts[0].criteria[0].status = "done"
        second = build_passport_map(model)
        self.assertEqual(first, second)
        self.assertEqual(first["summary"]["connectivity"]["percent"], 100)
        node = next(n for n in first["nodes"] if n["id"] == "operation-1")
        self.assertEqual(node["implementation_status"], "implemented")
        for field in ("readiness", "requirements", "bullets", "band"):
            self.assertNotIn(field, node)
        self.assertNotIn("criteria", node["assessment_inputs"])
        self.assertNotIn("требованиям инициативы", node["explanation"])

    def test_code_map_never_calls_the_legacy_minimum(self):
        for empty in (False, True):
            with self.subTest(empty=empty), patch.object(ProgressModel, "solution_assessment", side_effect=AssertionError("legacy scoring")):
                data = build_passport_map(code_model(empty=empty))
                for field in ("assessment", "requirements_total", "requirements_mapped", "mapping_coverage"):
                    self.assertNotIn(field, data["summary"])
                self.assertEqual(data["research_basis"], "code")
                self.assertEqual(data["research_mode"], "code_reconstruction")

    def test_connectivity_denominator_is_the_reconstructed_scenario_set(self):
        model = code_model()
        model.connectivity = ConnectivityReview(scenarios=[scenario("scenario-1"),
            scenario("scenario-2", result="unknown")], basis="code")
        data = build_passport_map(model)
        self.assertEqual(data["summary"]["connectivity"]["total"], 2)
        self.assertEqual(data["summary"]["connectivity"]["percent"], 50)
        self.assertEqual(data["summary"]["connectivity"]["counts"]["unknown"], 1)
        self.assertFalse(data["breaks"], "unknown handoff is not a demonstrated break")
        self.assertNotIn("assessment", data["summary"])

    def test_unproven_node_stays_unknown_with_a_done_or_item(self):
        model = code_model(grounded=False)
        model.verdicts[0].criteria[0].status = "done"
        node = next(n for n in build_passport_map(model)["nodes"] if n["id"] == "operation-1")
        self.assertEqual(node["implementation_status"], "unknown")
        self.assertNotIn("образа результата", " ".join(node["problems"]))

    def test_nodes_without_any_or_item_use_code_and_keep_real_breaks(self):
        model = code_model()
        model.items, model.verdicts = {}, []
        model.passport_data["nodes"]["process-1"]["scenarios"] = ["scenario-1"]
        model.passport_data["nodes"]["operation-1"]["scenario_steps"] = [{"scenario": "scenario-1", "step": 0}]
        model.connectivity = ConnectivityReview(scenarios=[scenario("scenario-1", result="broken")], basis="code")
        data = build_passport_map(model)
        node = next(n for n in data["nodes"] if n["id"] == "operation-1")
        self.assertEqual(node["implementation_status"], "implemented")
        self.assertEqual(data["handoffs"][0]["result"], "broken")
        self.assertTrue(data["breaks"])
        self.assertTrue(data["defects"])

    def test_saved_older_code_passport_keeps_its_recorded_absent_block(self):
        model = code_model()
        model.passport_data["nodes"]["process-1"].update(planned=True, scenarios=["scenario-1"])
        model.connectivity = ConnectivityReview(scenarios=[scenario("scenario-1")], basis="code")
        data = build_passport_map(model)
        process = next(n for n in data["nodes"] if n["id"] == "process-1")
        self.assertEqual(process["implementation_status"], "not_implemented")
        self.assertIn("подтверждённо", data["breaks"][0]["reason"])
        self.assertTrue(any("Подтверждённо не реализован" in row["title"] for row in data["defects"]))
        self.assertNotIn("образа результата", json.dumps(data, ensure_ascii=False))

    def test_risks_survive_without_affecting_local_status(self):
        model = code_model()
        before = build_passport_map(model)
        model.passport_data["risks"] = [{"id": "risk-1", "title": "Потеря результата",
            "scope": "local", "primary_node": "operation-1", "nodes": ["operation-1"],
            "linked_nodes": ["operation-1"], "confidence": "inferred",
            "cause": "Запись прерывается", "event": "Результат теряется", "consequence": "Повторная обработка"}]
        after = build_passport_map(model)
        self.assertEqual([n["implementation_status"] for n in before["nodes"]],
                         [n["implementation_status"] for n in after["nodes"]])
        self.assertEqual(len(after["risks"]), 1)
        self.assertEqual(after["summary"]["risks_total"], 1)

    def test_partial_render_does_not_fill_missing_fields_from_or(self):
        model = code_model()
        before = copy.deepcopy(model.passport_data)
        html, data = render(model)
        for marker in (PROMISE, "ОР_ПУТЬ", "ОР_ДО", "ОР_ПОСЛЕ", "ОР_ЭТАП"):
            self.assertNotIn(marker, html)
        self.assertIn("Паспорт системы «repo/system»", html)
        self.assertIn("Основание по коду не установлено", html)
        self.assertIn("доставка клиенту не проверена", html)
        self.assertEqual(data["completion"]["state"], "incomplete")
        self.assertIn("полнота проекта", data["meta"]["research_scope"])
        self.assertEqual(model.passport_data, before)

    def test_empty_code_passport_does_not_invent_a_fallback_tree(self):
        model = code_model(empty=True)
        model.passport_data["unpublished_nodes"] = [{"id": "process-7", "name": "Неподтверждённый кандидат",
                                                     "reason": "Контейнер не подтверждён кодом."}]
        html, data = render(model)
        self.assertEqual(data["nodes"], [])
        self.assertEqual(data["summary"]["functional_nodes"], 0)
        self.assertNotRegex(html, r'id="(?:journey|process|bbb|operation)-1"')
        self.assertNotIn(PROMISE, html)
        self.assertFalse(data["meta"]["filled_by_agent"])
        self.assertEqual(data["unpublished_nodes"], model.passport_data["unpublished_nodes"])
        self.assertNotRegex(html, r'id="process-7"')
        self.assertIn("Рабочих кандидатов вне текущей карты", html)

    def test_process_connection_review_preserves_unknown_and_source_boundaries(self):
        model = code_model()
        refs = [{"id": "read-code", "quote": "return prepare_result()"}]
        model.passport_data["evidence_materials"] = {"read-code": {"kind": "code", "label": "worker.py:8-12"}}
        review = {"process": "process-1", "checks": [
            {"aspect": aspect, "result": result, "detail": "Механизм исследован; доставка за границей снимка не проверена.",
             "nodes": ["operation-1"], "relations": [], "evidence": refs + refs, "finding_ids": []}
            for aspect, result in zip(("input", "output", "dependencies", "recovery"),
                                      ("supported", "finding", "unknown", "not_applicable"))]}
        model.passport_data["connection_review"] = [review]
        before = copy.deepcopy(model.passport_data)
        html, data = render(model)
        process = next(n for n in data["nodes"] if n["id"] == "process-1")
        checks = process["connection_review"]["checks"]
        self.assertEqual([c["result"] for c in checks], ["supported", "finding", "unknown", "not_applicable"])
        self.assertTrue(all(c["sources"] == ["worker.py:8-12"] for c in checks))
        self.assertFalse(any("connection_review" in n for n in data["nodes"] if n["type"] != "process"))
        self.assertIn("Необходимые связи процесса", html)
        self.assertIn("Вывод и границы", html)
        self.assertEqual(model.passport_data, before)

    def test_connection_review_cannot_inject_html_or_close_script(self):
        model = code_model()
        attack = '</script><img src=x onerror="alert(1)">'
        model.passport_data["connection_review"] = [{"process": "process-1", "checks": [
            {"aspect": "input", "result": "unknown", "detail": attack,
             "nodes": [], "relations": [], "evidence": [{"id": "read-code", "quote": attack}], "finding_ids": []}]}]
        model.passport_data["evidence_materials"] = {"read-code": {"kind": "code", "label": attack}}
        html, data = render(model)
        process = next(n for n in data["nodes"] if n["id"] == "process-1")
        self.assertEqual(process["connection_review"]["checks"][0]["detail"], attack)
        self.assertEqual(process["connection_review"]["checks"][0]["sources"], [attack])
        self.assertFalse(attack in html, "source and detail must be escaped in the embedded JSON")
        class ParsedTags(HTMLParser):
            def __init__(self):
                super().__init__()
                self.tags = []

            def handle_starttag(self, tag, attrs):
                self.tags.append(tag)

        parsed = ParsedTags()
        parsed.feed(html)
        self.assertNotIn("img", parsed.tags, "markup in a connection finding must remain script data, not become HTML")

    def test_legacy_keeps_or_score_and_copy(self):
        model = code_model()
        model.passport_data.pop("research_basis")
        model.passport_data.pop("research_mode")
        for node in model.passport_data["nodes"].values():
            node.pop("research_basis")
        model.passport_data["connection_review"] = [{"process": "process-1", "checks": []}]
        data = build_passport_map(model)
        self.assertIn("assessment", data["summary"])
        self.assertEqual(data["nodes"][0]["readiness"], 0)
        self.assertIn("По требованиям инициативы", data["nodes"][0]["explanation"])
        self.assertFalse(any("connection_review" in n for n in data["nodes"]))
        html, _ = render(model)
        self.assertIn("Паспорт инициативы", html)
        self.assertTrue("ОР_ДО" in html, "legacy keeps the original context fallback")


if __name__ == "__main__":
    unittest.main()
