// Headless UI regression: run with NODE_PATH pointing to bundled Playwright.
const { chromium } = require('playwright');
const { pathToFileURL } = require('url');
const fs = require('fs');
const path = require('path');
const assert = require('node:assert/strict');

(async () => {
  const browser = await chromium.launch({ channel: 'msedge', headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 1440, height: 960 }, reducedMotion: 'reduce' });
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    const source = path.resolve(process.argv[2] || 'reports/example/passport_audit_preview.html');
    await page.goto(pathToFileURL(source).href);
    await page.locator('.pko-object').first().waitFor();
    const reviewButton = page.getByRole('button', { name: 'Как проверяли риски', exact: true });
    await reviewButton.focus();
    await reviewButton.press('Enter');
    assert(await page.locator('.pko-drawer.open .pko-risk-review').isVisible());
    assert(await page.getByText('Подробности проверок для этого объекта не сохранены.', { exact: true }).isVisible());
    await page.keyboard.press('Escape');
    assert(await reviewButton.evaluate(button => button === document.activeElement));
    const node = page.locator('.pko-object').filter({ has: page.locator('.risk') }).first();
    await node.focus();
    await node.press('Enter');
    await page.locator('.pko-action').click();
    const card = page.locator('.pko-drawer-body');
    assert.equal(await card.locator('details[open]').count(), 0);
    await card.locator('.pko-node-assessment > details').first().locator('summary').click();
    assert(await card.getByText('Подробный протокол расчёта в этом старом паспорте не сохранён.', { exact: false }).isVisible());
    fs.mkdirSync('reports/audit-validation', { recursive: true });
    await page.screenshot({ path: 'reports/audit-validation/card-explanation.png' });
    await card.getByRole('tab', { name: 'Риски', exact: true }).click();
    const risk = card.locator('.pko-risk-card').first();
    const disclosure = risk.locator('.pko-risk-disclosure > summary');
    if (await disclosure.count()) await disclosure.click();
    await risk.locator('.pko-evidence > summary').click();
    assert(await risk.getByText('Механизм:', { exact: false }).isVisible() || await risk.getByText('Причина:', { exact: false }).isVisible());
    await page.screenshot({ path: 'reports/audit-validation/risk-explanation.png' });
    await page.setViewportSize({ width: 375, height: 812 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    assert(await card.evaluate(el => el.scrollWidth <= el.clientWidth));
    await page.screenshot({ path: 'reports/audit-validation/mobile-explanation.png' });

    // Synthetic audit data tests the new contract; it is never saved into the user's example.
    const original = fs.readFileSync(source, 'utf8');
    const match = original.match(/var SCHEMA=(.*?); var meta/s);
    const schema = JSON.parse(match[1]);
    const scenarioProcess = schema.nodes.find(node => node.type === 'process');
    schema.risk_review = { complete: true, summary: 'Тестовый разбор: проверены доступные факты. <img src=x onerror="alert(1)">',
      check_labels: { input: 'Проверка входа' }, result_labels: { unknown: 'Недостаточно данных' },
      processes: [{ node: scenarioProcess.id, checks: [{ check: 'input', result: 'unknown', note: 'Тестовая гипотеза требует подтверждения.', evidence: [], risk_titles: [] }] }] };
    const fixture = original.replace(match[0], 'var SCHEMA=' + JSON.stringify(schema).replace(/</g, '\\u003c') + '; var meta');
    await page.route('http://passport-audit.test/', route => route.fulfill({ contentType: 'text/html', body: fixture }));
    await page.goto('http://passport-audit.test/');
    await page.locator('.pko-object').first().waitFor();
    await reviewButton.click();
    assert.equal(await card.locator('img').count(), 0);
    await card.locator('.pko-review-process > summary').click();
    assert(await card.getByText('Результат: Недостаточно данных', { exact: true }).isVisible());
    assert(await card.getByText('Тестовая гипотеза требует подтверждения.', { exact: true }).isVisible());
    assert.deepEqual(errors, []);
    console.log('PASS: legacy fallback, explanations, risk audit, keyboard, escaping, 1440/375px');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
