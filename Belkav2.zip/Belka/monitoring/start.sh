#!/usr/bin/env bash
set -euo pipefail

monitor_enabled="${PKO_MONITOR_ENABLED:-}"
monitor_enabled="${monitor_enabled//[[:space:]]/}"
case "${monitor_enabled,,}" in
    1|true|yes|on) ;;
    *) echo 'Мониторинг выключен. Для запуска явно задайте PKO_MONITOR_ENABLED=true.'; exit 0 ;;
esac

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
export PKO_MONITOR_DIR="${PKO_MONITOR_DIR:-$HOME/.pko/monitoring}"
mkdir -p -- "$PKO_MONITOR_DIR"
PKO_MONITOR_DIR="$(cd -- "$PKO_MONITOR_DIR" && pwd)"
export PKO_MONITOR_DIR

command -v podman >/dev/null || { echo 'Podman не найден в PATH' >&2; exit 1; }
podman info >/dev/null
podman compose version >/dev/null || {
    echo 'Для podman compose нужен compose provider (podman-compose или docker-compose).' >&2
    exit 1
}
podman compose -f "$script_dir/compose.yaml" up -d --build
echo 'Grafana: http://localhost:3000/d/pko-cli-monitoring'
echo "Журнал CLI: $PKO_MONITOR_DIR"
