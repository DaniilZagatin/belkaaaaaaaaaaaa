
(function(){
  'use strict';
  var SCHEMA=__PKO_SCHEMA__; var meta=SCHEMA.meta||{};
  var TYPE_ORDER=['need','journey','process','bbb','operation','guardrail'];
  var TYPE_NAME={need:'Потребности',journey:'Клиентский путь',process:'Автономные процессы',bbb:'BBB',operation:'Атомарные операции',guardrail:'Ограничения исполнения'};
  var TYPE_LABEL={need:'Потребность клиента',journey:'Клиентский путь',process:'Автономный процесс',bbb:'BBB',operation:'Атомарная операция',guardrail:'Ограничение исполнения'};
  var COLORS={need:'var(--g1)',journey:'var(--g1)',process:'var(--g1)',bbb:'var(--g1)',operation:'var(--g1)',guardrail:'var(--g1)'};
  var HIER={addresses:'закрывается путём',contains:'включает процесс',uses:'использует BBB',implements:'исполняется операцией',guards:'ограничивает'};

  // --- 1. Данные: карточки шаблона (DOM) + схема (код) ---
  var store=document.createElement('div'); store.id='pko-store';
  var els={};
  Array.prototype.forEach.call(document.querySelectorAll('.node[id]'),function(el){els[el.id]=el;});
  var byId={}, objects=[];
  function addObject(o){if(byId[o.id]) return; byId[o.id]=o; objects.push(o);}
  (SCHEMA.nodes||[]).forEach(function(n){
    addObject({id:n.id,type:n.type,name:n.name||n.id,parents:(n.parents||[]).slice(),children:[],data:n,
      steps:n.steps||[],scen:{},status:n.implementation_status||'',statusLabel:n.implementation_label||''});
  });
  objects.forEach(function(o){o.parents=o.parents.filter(function(p){return byId[p]}); o.parents.forEach(function(p){byId[p].children.push(o.id)});});
  var journey=objects.filter(function(o){return o.type==='journey'})[0]||null;
  (meta.needs||[]).forEach(function(nd){addObject({id:nd.id,type:'need',name:nd.name,text:nd.purpose||nd.text||'',source:nd.source,parents:[],children:[],targets:nd.targets||[],data:{},steps:[],scen:{}});});
  (meta.guardrails||[]).forEach(function(g){addObject({id:g.id,type:'guardrail',name:g.name,text:g.invariant||g.text||'',condition:g.condition||'',effect:g.effect_label||g.effect||'',source:g.source,parents:[],children:[],targets:g.targets||[],data:{},steps:[],scen:{}});});
  // Иерархические рёбра: один ко многим — BBB в нескольких процессах, операция в нескольких BBB.
  var edges=[];
  objects.forEach(function(o){
    if(o.type==='need') o.targets.forEach(function(t){if(byId[t]) edges.push({id:'e'+edges.length,source:o.id,target:t,type:'addresses'})});
    else if(o.type==='guardrail') o.targets.forEach(function(t){if(byId[t]) edges.push({id:'e'+edges.length,source:o.id,target:t,type:'guards'})});
    else o.parents.forEach(function(p){var pt=byId[p].type; var kind=pt==='journey'?'contains':pt==='process'?'uses':'implements'; edges.push({id:'e'+edges.length,source:p,target:o.id,type:kind});});
  });
  var relations=(SCHEMA.relations||[]).filter(function(r){return r.kind!=='includes'&&byId[r.from]&&byId[r.to]});
  var paths=SCHEMA.paths||[];
  var defects=SCHEMA.defects||[]; var defectById={}; defects.forEach(function(d){defectById[d.id]=d});
  var risks=SCHEMA.risks||[]; var riskById={}; risks.forEach(function(r){riskById[r.id]=r});
  // Принадлежность сценариям: узел — по шагам; предки — по потомкам.
  objects.forEach(function(o){o.steps.forEach(function(s){o.scen[s.scenario]=true})});
  function ancestors(id,out){out=out||{}; (byId[id]?byId[id].parents:[]).forEach(function(p){if(!out[p]){out[p]=true; ancestors(p,out);}}); return out;}
  function descendants(id,out){out=out||{}; (byId[id]?byId[id].children:[]).forEach(function(c){if(!out[c]){out[c]=true; descendants(c,out);}}); return out;}
  objects.forEach(function(o){ if(!Object.keys(o.scen).length) return; Object.keys(ancestors(o.id)).forEach(function(a){Object.keys(o.scen).forEach(function(s){byId[a].scen[s]=true})}); });
  objects.forEach(function(o){ if(o.type==='need'||o.type==='guardrail'){ o.targets.forEach(function(t){Object.keys((byId[t]||{scen:{}}).scen).forEach(function(s){o.scen[s]=true})}); } });
  // Разрывы отделены от статусов узлов: отсутствующий обязательный стык или
  // не реализованный обязательный шаг сценария. Неопределённость — не разрыв.
  var breakRows=Array.isArray(SCHEMA.breaks)?SCHEMA.breaks:[];
  var breaks={}; breakRows.forEach(function(br){ (br.nodes||[]).forEach(function(id){(breaks[id]=breaks[id]||[]).push(br)}); });
  var brokenCount=breakRows.length;

  // --- 2. Страница ---
  var header=document.querySelector('header'); var page=header?header.parentElement:document.body; page.classList.add('pko-page');
  var h1=header?header.querySelector('h1'):null; var badgeEl=header?header.querySelector('div>div:last-child'):null;
  Array.prototype.slice.call(page.children).forEach(function(el){store.appendChild(el)});
  function el(tag,cls,text){var n=document.createElement(tag); if(cls) n.className=cls; if(text!=null) n.textContent=text; return n;}
  function add(parent,tag,cls,text){var n=el(tag,cls,text); parent.appendChild(n); return n;}
  var riskIcon='<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 2 19 18H1Z" fill="var(--dpss-warning)" stroke="#805C00" stroke-width="1.2"/><path d="M10 7v5m0 3v.1" stroke="#183454" stroke-width="1.7" stroke-linecap="round"/></svg>';
  var head=el('div','pko-head'); var hl=add(head,'div'); add(hl,'div','eyebrow','Паспорт инициативы'); add(hl,'h1',null,h1?h1.textContent.trim().replace(/^Паспорт инициативы\s*/, '').replace(/^«|»$/g,''):'Инициатива');
  if(meta.filled_by_agent===false) add(hl,'div','pko-preview-note','Агент не заполнил паспорт. Показаны только доступные данные оценки.');
  var legend=add(hl,'div','pko-legend');
  var lk=add(legend,'span'); add(lk,'b'); lk.appendChild(document.createTextNode('связь'));
  var lp=add(legend,'span'); add(lp,'span','pin','!'); lp.appendChild(document.createTextNode('разрыв процесса'));
  var lrisk=add(legend,'span'); add(lrisk,'span','risk-icon').innerHTML=riskIcon; lrisk.appendChild(document.createTextNode('операционный риск (количество)'));
  var relsHidden=false;
  var headActions=add(head,'div','pko-head-actions');
  var metrics=add(headActions,'div','pko-metrics');
  function metric(label,value,danger){var m=add(metrics,'div','pko-metric'); add(m,'span',null,label); add(m,'strong',danger?'danger':null,String(value));}
  metric('Процессов',objects.filter(function(o){return o.type==='process'}).length,false);
  metric('Разрывов',brokenCount,brokenCount>0);
  var resetBtn=add(headActions,'button','tool','Сбросить выбор'); resetBtn.type='button'; resetBtn.disabled=true;
  var body=el('div','pko-body'); var viewport=add(body,'div','pko-viewport'); viewport.tabIndex=0;
  var canvas=add(viewport,'div','pko-canvas');
  var zoomBox=add(viewport,'div','pko-zoom'); zoomBox.setAttribute('role','group'); zoomBox.setAttribute('aria-label','Масштаб графа');
  zoomBox.innerHTML='<button type="button" data-z="out" aria-label="Отдалить" title="Отдалить">−</button><span class="lvl" aria-label="Текущий масштаб">100%</span><button type="button" data-z="in" aria-label="Приблизить" title="Приблизить">+</button><button type="button" data-z="fit" class="fit" aria-label="Показать весь граф" title="Показать весь граф"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/></svg></button>';
  var drawer=add(body,'aside','pko-drawer'); var dh=add(drawer,'div','pko-drawer-head'); var dTitle=add(dh,'span',null,'Описание объекта'); var dClose=add(dh,'button','pko-drawer-close','×'); dClose.type='button'; var dBody=add(drawer,'div','pko-drawer-body');
  var reviewButton=add(headActions,'button','tool','Как проверяли риски'); reviewButton.type='button';
  reviewButton.addEventListener('click',function(){openDrawer('Обоснование анализа рисков'); appendRiskReview(dBody,null,true);});
  var evidenceButton=add(headActions,'button','tool','Что проверено'); evidenceButton.type='button';
  evidenceButton.addEventListener('click',function(){openDrawer('Границы проверки паспорта'); appendEvidenceAudit(dBody);});
  page.appendChild(head); page.appendChild(body); page.appendChild(store);

  // --- 3. Раскладка рядами по уровням; при выборе — перестроение ---
  // Карточки создаются один раз; положение задаёт layout(scope): без выбора
  // ряды центрированы, потомки под родителями; при выборе объекты его
  // сценария съезжают влево и выстраиваются под своими родителями, остальные
  // уезжают вправо за разрыв. Перестроение анимируется, рёбра пересчитываются
  // на каждом кадре — линии остаются гладкими кривыми без подписей.
  var positions={}, buttons={}, pins=[], svg=null, sceneW=1, sceneH=1, actionBtn=null;
  var edgeEls=[], relEls=[], rowsData=[], anim=null;
  var CARD=224, GAP=22, LABEL=142, OUTER=22, ROWGAP=40, SPLIT=110;
  function bary(o,prevPos){ var refs=o.type==='need'||o.type==='guardrail'?o.targets:o.parents; var xs=refs.map(function(p){return prevPos[p]}).filter(function(v){return v!=null}); return xs.length?xs.reduce(function(a,b){return a+b},0)/xs.length:null; }
  function orderRow(list,prevPos){
    var key={}; list.forEach(function(o,i){ var b=bary(o,prevPos); key[o.id]=b==null?1e9+i:b; });
    return list.slice().sort(function(a,b){return key[a.id]-key[b.id]||a.id.localeCompare(b.id,undefined,{numeric:true})});
  }
  function computeLayout(scopeIds){
    var target={}; var prevPos={}; var full=LABEL+OUTER;
    rowsData.forEach(function(row){
      var list=row.nodes;
      if(!scopeIds){
        var ordered=orderRow(list,prevPos); var start=full+(sceneW-LABEL-OUTER*2-(ordered.length*(CARD+GAP)-GAP))/2;
        ordered.forEach(function(o,i){target[o.id]=start+i*(CARD+GAP)});
      } else {
        var inn=orderRow(list.filter(function(o){return scopeIds[o.id]}),prevPos), out=orderRow(list.filter(function(o){return !scopeIds[o.id]}),prevPos);
        inn.forEach(function(o,i){target[o.id]=full+i*(CARD+GAP)});
        var x0=full+(inn.length?inn.length*(CARD+GAP)-GAP+SPLIT:0);
        out.forEach(function(o,i){target[o.id]=x0+i*(CARD+GAP)});
      }
      var rowPos={}; list.forEach(function(o){rowPos[o.id]=target[o.id]}); prevPos=rowPos;
    });
    return target;
  }
  function nodeStatusChip(o){
    return o.status?el('span','st '+o.status,o.statusLabel||o.status):null;
  }
  function svgEl(tag,attrs){var n=document.createElementNS('http://www.w3.org/2000/svg',tag); Object.keys(attrs||{}).forEach(function(k){n.setAttribute(k,attrs[k])}); return n;}
  function render(){
    canvas.innerHTML=''; positions={}; buttons={}; pins=[]; edgeEls=[]; relEls=[]; rowsData=[];
    svg=document.createElementNS('http://www.w3.org/2000/svg','svg'); svg.setAttribute('class','pko-links'); canvas.appendChild(svg);
    var y=18;
    TYPE_ORDER.forEach(function(t){ var list=objects.filter(function(o){return o.type===t}); if(list.length) rowsData.push({type:t,nodes:list}); });
    sceneW=Math.max.apply(null,[1].concat(rowsData.map(function(r){return r.nodes.length})))*(CARD+GAP)-GAP+LABEL+OUTER*2+SPLIT;
    rowsData.forEach(function(row){
      var lab=add(canvas,'div','pko-row-title',TYPE_NAME[row.type]); lab.style.left=OUTER+'px'; lab.style.top=(y+12)+'px'; add(lab,'span','count',String(row.nodes.length));
      var maxH=0;
      row.nodes.forEach(function(o){
        var b=add(canvas,'button','pko-object'); b.type='button'; b.dataset.id=o.id; b.dataset.type=o.type; b.style.setProperty('--color',COLORS[o.type]); b.style.top=y+'px'; b.style.left='0px';
        add(b,'span','kind',TYPE_LABEL[o.type]); add(b,'strong',null,o.name);
        // Show the backend's node status unchanged; breaks remain separate `!` markers.
        var d=o.data||{};
        var chip=nodeStatusChip(o), riskCount=Array.isArray(d.risks)?d.risks.length:0;
        if(chip||riskCount){
          var badges=add(b,'span','badges'); if(chip) badges.appendChild(chip);
          if(riskCount){var riskBadge=add(badges,'span','risk'); riskBadge.innerHTML=riskIcon; add(riskBadge,'span',null,String(riskCount)); riskBadge.title='Операционных рисков: '+riskCount;}
        }
        b.title=o.name+(Array.isArray(d.risks)&&d.risks.length?' · операционных рисков: '+d.risks.length:'');
        b.setAttribute('aria-label',TYPE_LABEL[o.type]+' «'+o.name+'»'+(o.status?'; '+(o.statusLabel||o.status):'')+(breaks[o.id]?'; разрыв процесса':'')+(Array.isArray(d.risks)&&d.risks.length?'; операционных рисков: '+d.risks.length:''));
        b.addEventListener('click',function(e){if(!moved||e.detail===0) selectObject(o.id);});
        buttons[o.id]=b; positions[o.id]={x:0,y:y,w:CARD,h:b.offsetHeight}; maxH=Math.max(maxH,b.offsetHeight);
      });
      y+=maxH+ROWGAP;
    });
    sceneH=y+20; canvas.style.width=sceneW+'px'; canvas.style.height=sceneH+'px'; svg.setAttribute('width',sceneW); svg.setAttribute('height',sceneH);
    var drawnPairs={};
    function once(a,b){var key=[a,b].sort().join('|'); if(a===b||drawnPairs[key]) return false; drawnPairs[key]=true; return true;}
    edges.forEach(function(e){if(!once(e.source,e.target)) return; var p=svgEl('path',{'class':'link'}); p.dataset.edge=e.id; p.dataset.pair=[e.source,e.target].sort().join('|'); svg.appendChild(p); edgeEls.push({e:e,el:p}); });
    relations.forEach(function(r,i){if(!once(r.from,r.to)) return; var p=svgEl('path',{'class':'link'}); p.dataset.rel=String(i); p.dataset.pair=[r.from,r.to].sort().join('|'); svg.appendChild(p); relEls.push({r:r,i:i,el:p}); });
    if(!objects.length){var msg=add(canvas,'div','pko-empty','Объекты паспорта не собраны.'); msg.style.width='450px'; sceneW=600; sceneH=400;}
    Object.keys(breaks).forEach(function(id){ if(!positions[id]) return; var b=add(canvas,'button','pko-pin','!'); b.type='button'; var titles=breaks[id].map(function(h){return h.scenario_title}); b.title='Разрыв: '+titles.filter(function(v,i,a){return a.indexOf(v)===i}).join(', '); b.addEventListener('click',function(e){e.stopPropagation(); if(moved&&e.detail!==0) return; showBreaks(id);}); pins.push({id:id,button:b}); });
    var t0=computeLayout(null); Object.keys(t0).forEach(function(id){positions[id].x=t0[id]}); place(); selection(); requestAnimationFrame(fit);
  }
  function edgePath(e){
    var a=positions[e.source], b=positions[e.target]; if(!a||!b) return '';
    var x1=a.x+a.w/2, y1=a.y+a.h, x2=b.x+b.w/2, y2=b.y;
    if(e.type==='guards'){ var top=a.y<b.y?a:b, bottom=a.y<b.y?b:a; var lane=Math.max(top.x+top.w,bottom.x+bottom.w)+14; return 'M'+(top.x+top.w)+','+(top.y+top.h/2)+' C'+lane+','+(top.y+top.h/2)+' '+lane+','+(bottom.y+bottom.h/2)+' '+(bottom.x+bottom.w)+','+(bottom.y+bottom.h/2); }
    var mid=(y1+y2)/2; return 'M'+x1+','+y1+' C'+x1+','+mid+' '+x2+','+mid+' '+x2+','+y2;
  }
  function relPath(r,i){
    var a=positions[r.from], b=positions[r.to]; if(!a||!b) return '';
    if(Math.abs(a.y-b.y)<8){ var ltr=a.x<b.x; var x1=a.x+a.w*(ltr?.7:.3), x2=b.x+b.w*(ltr?.3:.7), yy=a.y, h=26+(i%3)*6; return 'M'+x1+','+yy+' C'+x1+','+(yy-h)+' '+x2+','+(yy-h)+' '+x2+','+yy; }
    var down=b.y>a.y; var sx=a.x+a.w/2, sy=down?a.y+a.h:a.y, tx2=b.x+b.w/2, ty2=down?b.y:b.y+b.h; var mid=(sy+ty2)/2; return 'M'+sx+','+sy+' C'+sx+','+mid+' '+tx2+','+mid+' '+tx2+','+ty2;
  }
  function place(){
    Object.keys(buttons).forEach(function(id){buttons[id].style.left=positions[id].x+'px'});
    edgeEls.forEach(function(x){x.el.setAttribute('d',edgePath(x.e))}); relEls.forEach(function(x){x.el.setAttribute('d',relPath(x.r,x.i))});
    pins.forEach(function(p){var pos=positions[p.id]; p.button.style.left=(pos.x-9)+'px'; p.button.style.top=(pos.y-8)+'px';});
    if(actionBtn&&focus&&positions[focus]){actionBtn.style.left=positions[focus].x+'px'; actionBtn.style.top=(positions[focus].y+positions[focus].h+6)+'px';}
  }
  function layout(scopeIds){
    var target=computeLayout(scopeIds); var from={}; Object.keys(positions).forEach(function(id){from[id]=positions[id].x});
    if(anim) cancelAnimationFrame(anim);
    var t0=performance.now(), dur=window.matchMedia('(prefers-reduced-motion: reduce)').matches?0:700;
    function frame(now){
      var k=dur?Math.min(1,(now-t0)/dur):1; var e=ease(k);
      Object.keys(target).forEach(function(id){positions[id].x=from[id]+(target[id]-from[id])*e});
      place(); if(k<1) anim=requestAnimationFrame(frame); else anim=null;
    }
    anim=requestAnimationFrame(frame);
    if(scopeIds) fitTo(scopeIds,target); else fit(true);
  }
  // Камера наводится на собранную группу: по её габаритам, не крупнее 100%.
  function fitTo(scopeIds,target){
    var minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
    Object.keys(scopeIds).forEach(function(id){var p=positions[id]; if(!p) return; var x=target?target[id]:p.x; minX=Math.min(minX,x); maxX=Math.max(maxX,x+p.w); minY=Math.min(minY,p.y); maxY=Math.max(maxY,p.y+p.h);});
    if(!isFinite(minX)) return;
    var pad=60, w=maxX-minX+pad*2, h=maxY-minY+pad*2;
    // Leave a bottom lane for the zoom controls and the node action.
    var visibleH=Math.max(240,viewport.clientHeight-108);
    var next=Math.max(.2,Math.min(1,(viewport.clientWidth-460)/w,(visibleH-40)/h));
    animateCamera(next,(viewport.clientWidth-460-w*next)/2-(minX-pad)*next,Math.max(12,(visibleH-h*next)/2-(minY-pad)*next));
  }
  // Плавность: ease-in-out (квинтика) — без рывка в начале и в конце.
  function ease(k){return k<.5?16*k*k*k*k*k:1-Math.pow(-2*k+2,5)/2;}
  var camAnim=null;
  function animateCamera(ns,ntx,nty){
    if(camAnim) cancelAnimationFrame(camAnim);
    var s0=scale,x0=tx,y0=ty,t0=performance.now(),dur=window.matchMedia('(prefers-reduced-motion: reduce)').matches?0:600;
    function frame(now){var k=dur?Math.min(1,(now-t0)/dur):1; var e=ease(k); scale=s0+(ns-s0)*e; tx=x0+(ntx-x0)*e; ty=y0+(nty-y0)*e; apply(); if(k<1) camAnim=requestAnimationFrame(frame); else camAnim=null;}
    camAnim=requestAnimationFrame(frame);
  }

  // --- 4. Выбор: весь сценарий объекта ---
  var focus=null, moved=false;
  // Процесс = сценарий: область выбора — процессы, в которые объект входит,
  // и всё их содержимое; у пути — все процессы, у BBB до развилки — те,
  // которые он запускает.
  function processesOf(id){
    var out={}; var o=byId[id]; if(!o) return out;
    if(o.type==='process'){out[id]=true; return out;}
    if(o.type==='journey'){objects.forEach(function(x){if(x.type==='process') out[x.id]=true}); return out;}
    if(o.type==='need'||o.type==='guardrail'){o.targets.forEach(function(t){Object.keys(processesOf(t)).forEach(function(k){out[k]=true})}); return out;}
    Object.keys(ancestors(id)).forEach(function(a){if(byId[a].type==='process') out[a]=true});
    if(o.data&&o.data.before_fork) relations.forEach(function(r){if(r.from===id&&r.kind==='triggers'&&byId[r.to]&&byId[r.to].type==='process') out[r.to]=true});
    return out;
  }
  function scope(id){
    var o=byId[id]; var ids={}; ids[id]=true; var procs=processesOf(id);
    Object.keys(procs).forEach(function(p){ ids[p]=true; Object.keys(descendants(p)).forEach(function(c){ids[c]=true}); Object.keys(ancestors(p)).forEach(function(a){ids[a]=true}); });
    Object.keys(ancestors(id)).forEach(function(a){ids[a]=true});
    if(o.type==='need'||o.type==='guardrail') o.targets.forEach(function(t){ids[t]=true; Object.keys(ancestors(t)).forEach(function(a){ids[a]=true});});
    if(o.type==='journey'||!Object.keys(procs).length) Object.keys(descendants(id)).forEach(function(c){ids[c]=true});
    objects.forEach(function(x){ if((x.type==='need'||x.type==='guardrail')&&x.targets.some(function(t){return ids[t]})) ids[x.id]=true; });
    var edgeSet={}; edges.forEach(function(e){ if(ids[e.source]&&ids[e.target]) edgeSet[e.id]=true; });
    var relSet={}; relations.forEach(function(r,i){ if(ids[r.from]&&ids[r.to]) relSet[i]=true; });
    return {ids:ids,edges:edgeSet,rels:relSet,procs:procs};
  }
  function selection(){
    var sc=focus?scope(focus):null;
    Object.keys(buttons).forEach(function(id){var b=buttons[id]; b.classList.toggle('dim',!!sc&&!sc.ids[id]); b.classList.toggle('related',!!sc&&!!sc.ids[id]&&id!==focus); b.classList.toggle('selected',focus===id);});
    edgeEls.forEach(function(x){ var active=sc&&sc.edges[x.e.id]; x.el.classList.toggle('dim',!!sc&&!active); x.el.classList.toggle('selected',!!sc&&!!active); });
    relEls.forEach(function(x){ var active=sc&&sc.rels[x.i]; x.el.classList.toggle('dim',!!sc&&!active); x.el.classList.toggle('selected',!!sc&&!!active); });
    pins.forEach(function(p){p.button.classList.toggle('dim',!!sc&&!sc.ids[p.id])});
    resetBtn.disabled=!focus;
    if(actionBtn){actionBtn.remove(); actionBtn=null;}
    if(!focus){ layout(null); return; }
    actionBtn=add(canvas,'button','pko-action','Открыть описание →'); actionBtn.type='button'; actionBtn.addEventListener('click',function(e){e.stopPropagation(); if(moved&&e.detail!==0) return; showObject(focus);});
    layout(sc.ids);
  }
  function selectObject(id){ if(!byId[id]) return; if(focus===id){reset(); return;} focus=id; closeDrawer(); selection(); history.replaceState(null,'',location.pathname+location.search+'#'+encodeURIComponent(id)); }
  function reset(){ focus=null; closeDrawer(); selection(); history.replaceState(null,'',location.pathname+location.search); }

  // --- 5. Описание объекта ---
  function link(id){var a=el('a',null,byId[id]?byId[id].name:id); a.href='#'+encodeURIComponent(id); a.addEventListener('click',function(e){e.preventDefault(); selectObject(id); showObject(id);}); return a;}
  function evidence(parent,text,label){var panel=add(parent,'details','pko-evidence'); add(panel,'summary',null,label||'Обоснование'); add(panel,'div',null,text||'Подробное обоснование не сохранено в этом паспорте. Новые запуски запрашивают его у агента.'); return panel;}
  function literalQuotes(parent,refs){
    var records=((SCHEMA.evidence_audit||{}).manifest||{}).records||[];
    (refs||[]).forEach(function(ref){var row=records.filter(function(r){return r.id===ref.id})[0]; add(parent,'p',null,(row?row.label:ref.id)+' — '+ref.quote);});
  }
  function appendFactCheck(parent,audit){
    if(!audit){add(parent,'p',null,'Проверка буквальных оснований этого узла не сохранена.'); return;}
    var panel=evidence(parent,'Код сверил происхождение цитат. Правильность их трактовки требует содержательной проверки.','Основания и границы полей');
    var ex=audit.execution||{}, labels={connected:'Вход и эффект описаны с цитатами',definition_only:'Найдено определение; вызов не подтверждён',unknown:'Достижимость не установлена',planned:'Планируемый узел'};
    add(panel,'p',null,labels[ex.reachability]||'Достижимость не описана');
    [['entrypoint','Точка входа'],['conditions','Условия'],['outcome','Результат'],['limits','Границы']].forEach(function(pair){if(ex[pair[0]]) add(panel,'p',null,pair[1]+': '+ex[pair[0]]);});
    literalQuotes(panel,ex.entry_evidence); literalQuotes(panel,ex.evidence);
    var supports={code:'Код',inference:'Вывод',intent:'Намерение',unknown:'Не установлено'};
    var mechanisms={runtime:'Механизм исполнения',prompt:'Инструкция модели',schema:'Схема данных',intent:'Намерение',unknown:'Не установлено'};
    Object.keys(audit.fields||{}).sort().forEach(function(fid){var f=audit.fields[fid]; var detail=evidence(panel,f.limits,'Поле '+fid+' · '+(supports[f.support]||f.support)); add(detail,'p',null,mechanisms[f.mechanism]||f.mechanism||''); literalQuotes(detail,f.evidence);});
    Object.keys(audit.generated_fields||{}).sort().forEach(function(fid){evidence(panel,audit.generated_fields[fid],'Поле '+fid+' · Сформировано автоматически');});
  }
  function appendEvidenceAudit(parent){
    var audit=SCHEMA.evidence_audit||{}, manifest=audit.manifest||{};
    add(parent,'p',null,audit.mode==='literal_citations'?'В новом прогоне проверялось происхождение цитат для переданных полей, связей и анализа контролей. Это не доказательство полноты и истинности всех выводов.':'Этот паспорт создан без проверки буквальных оснований.');
    if(manifest.scope) add(parent,'p',null,manifest.scope);
    if(manifest.sha256) evidence(parent,manifest.sha256,'Отпечаток корпуса оснований');
    if((manifest.omitted||[]).length) evidence(parent,manifest.omitted.join('\n'),'Материалы, не вошедшие в корпус');
    (audit.unresolved_relations||[]).forEach(function(r){add(parent,'p',null,'Неподтверждённая связь: '+(byId[r.from]?byId[r.from].name:r.from)+' → '+(byId[r.to]?byId[r.to].name:r.to)+'. Основание не прошло проверку. Нужно уточнить направление, условия и механизм по источникам.');});
    objects.filter(function(o){return o.data&&['journey','process','bbb','operation'].indexOf(o.type)>=0}).forEach(function(o){var box=add(parent,'section','pko-field'); box.appendChild(link(o.id)); appendFactCheck(box,o.data.fact_check);});
  }
  function appendRiskReview(parent,id,expanded){
    var review=SCHEMA.risk_review||{}, section=add(parent,'section','pko-node-risks pko-risk-review');
    var panel=evidence(section,review.summary,'Общее обоснование анализа рисков'); panel.open=!!expanded;
    add(panel,'p',null,review.complete?'Агент завершил чек-лист. Отсутствие находки не гарантирует безопасность.':'Полнота анализа не подтверждена или чек-лист не сохранён.');
    var owners=id?Object.keys(processesOf(id)):[]; if(id&&byId[id]&&byId[id].type==='process') owners.push(id);
    var rows=(review.processes||[]).filter(function(row){return !id||(byId[id]&&byId[id].type==='journey')||owners.indexOf(row.node)>=0});
    if(!rows.length) add(panel,'p',null,'Подробности проверок для этого объекта не сохранены.');
    rows.forEach(function(row){
      var group=add(panel,'details','pko-review-process'); add(group,'summary',null,byId[row.node]?byId[row.node].name:row.node);
      (row.checks||[]).forEach(function(check){
        var item=add(group,'section','pko-field'); add(item,'h3',null,(review.check_labels||{})[check.check]||check.check);
        add(item,'p',null,'Результат: '+((review.result_labels||{})[check.result]||check.result));
        add(item,'p',null,check.note||'Объяснение не сохранено.');
        (check.evidence||[]).forEach(function(ev){add(item,'p',null,ev.where+' — '+ev.basis)});
        if((check.risk_titles||[]).length) add(item,'p',null,'Связанные риски: '+check.risk_titles.join('; '));
      });
    });
  }
  var drawerReturnFocus=null;
  function openDrawer(title){drawerReturnFocus=document.activeElement; dTitle.textContent=title; dBody.innerHTML=''; drawer.classList.add('open'); dClose.focus({preventScroll:true}); Object.keys(buttons).forEach(function(k){buttons[k].classList.remove('inspected')});}
  function closeDrawer(){var hadFocus=drawer.contains(document.activeElement); drawer.classList.remove('open'); Object.keys(buttons).forEach(function(k){buttons[k].classList.remove('inspected')}); if(hadFocus){if(drawerReturnFocus&&drawerReturnFocus.isConnected) drawerReturnFocus.focus({preventScroll:true}); else if(focus&&buttons[focus]) buttons[focus].focus({preventScroll:true});}}
  function cardTabs(card,id){
    var heading=card.querySelector('.pko-card-heading');
    var description=el('section','pko-tab-panel'), riskPanel=el('section','pko-tab-panel'), linksPanel=el('section','pko-tab-panel');
    Array.prototype.slice.call(card.children).forEach(function(child){
      if(child===heading) return;
      var cls=child.classList;
      (cls.contains('pko-node-risks')?riskPanel:
       cls.contains('pko-node-links')||cls.contains('pko-links-list')||cls.contains('pko-node-scenarios')||cls.contains('pko-node-relations')||cls.contains('pko-node-risk-links')?linksPanel:description).appendChild(child);
    });
    if(!riskPanel.querySelector('.pko-risk-card')) riskPanel.prepend(el('p',null,'Для этого узла риски в отчёте не указаны.'));
    if(!linksPanel.childNodes.length) add(linksPanel,'p',null,'Связи для этого объекта не указаны.');
    var tabs=add(card,'div','pko-card-tabs'); tabs.setAttribute('role','tablist'); tabs.setAttribute('aria-label','Разделы описания объекта');
    var panels=[description,riskPanel,linksPanel], buttons=[];
    function activate(index,moveFocus){
      buttons.forEach(function(button,i){var active=i===index; button.setAttribute('aria-selected',String(active)); button.tabIndex=active?0:-1; panels[i].hidden=!active;});
      dBody.scrollTop=0;
      if(moveFocus) buttons[index].focus({preventScroll:true});
    }
    ['Описание','Риски','Связи'].forEach(function(label,i){
      var button=add(tabs,'button',null,label); button.type='button'; button.id='pko-tab-'+id+'-'+i;
      button.setAttribute('role','tab'); button.setAttribute('aria-controls','pko-panel-'+id+'-'+i);
      panels[i].id='pko-panel-'+id+'-'+i; panels[i].setAttribute('role','tabpanel'); panels[i].setAttribute('aria-labelledby',button.id); panels[i].tabIndex=0;
      button.addEventListener('click',function(){activate(i,false)});
      button.addEventListener('keydown',function(e){
        var next=e.key==='Home'?0:e.key==='End'?2:e.key==='ArrowRight'?(i+1)%3:e.key==='ArrowLeft'?(i+2)%3:null;
        if(next!==null){e.preventDefault(); activate(next,true);}
      });
      buttons.push(button);
    });
    panels.forEach(function(panel){card.appendChild(panel)}); activate(0,false);
  }
  function showObject(id){
    var o=byId[id]; if(!o) return; openDrawer('Описание объекта'); if(buttons[id]) buttons[id].classList.add('inspected');
    if(o.type==='need'||o.type==='guardrail'){
      var box=add(dBody,'div','pko-simple'); var heading=add(box,'div','pko-card-heading'); add(heading,'div','type',TYPE_LABEL[o.type]); add(heading,'h2',null,o.name);
      if(o.type==='guardrail'){ add(box,'p',null,'Что защищаем: '+(o.text||'—')); add(box,'p',null,'Когда срабатывает: '+(o.condition||'—')); add(box,'p',null,'Эффект: '+(o.effect||'—')); }
      else add(box,'p',null,o.text||'');
      evidence(box,o.source);
      if(o.targets.length){var tl=add(box,'p','pko-node-links',(o.type==='need'?'Закрывается: ':'Ограничивает: ')); o.targets.forEach(function(t,i){if(i) tl.appendChild(document.createTextNode(', ')); tl.appendChild(link(t));});}
      appendRisks(box,risks.filter(function(r){return (r.linked_nodes||[]).indexOf(id)>=0||(r.guardrails||[]).indexOf(id)>=0}));
      cardTabs(box,id);
      return;
    }
    var src=els[id]; if(!src){add(dBody,'p',null,o.name); return;}
    var clone=el('article','node pko-clean-card');
    var chead=add(clone,'div','pko-card-heading'); add(chead,'div','type',TYPE_LABEL[o.type]); add(chead,'h2',null,o.name);
    var d=o.data||{};
    appendFactCheck(clone,d.fact_check);
    if(d.scenario_entry||d.scenario_outcome){
      function scenarioPoint(label,value){
        if(!value) return;
        var point=add(clone,'section','pko-field');
        add(point,'h3',null,label);
        add(point,'p',null,value);
        evidence(point,'Целевой сценарий: '+(paths.filter(function(p){return p.id===d.scenario}).map(function(p){return p.title}).join('; ')||d.scenario||'не сохранён')+'. Условие и результат сформулированы ревизором по образу результата.\n\n'+(d.structure_explanation||d.basis||''));
      }
      scenarioPoint('Условие запуска',d.scenario_entry);
      scenarioPoint('Ожидаемый результат',d.scenario_outcome);
    }
    var hiddenFields=['4.2.3','4.3.2','4.3.3','4.3.6','4.3.9','4.4.2','4.4.3','4.4.4','4.4.6','4.4.7','4.5.2','4.5.3','4.5.5'];
    Array.prototype.forEach.call(src.querySelectorAll('[data-field]'),function(f){
      if(f.closest('.node')!==src) return;
      var fid=f.getAttribute('data-field'); if(hiddenFields.indexOf(fid)>=0) return;
      if(['4.2.1','4.2.5','4.3.1','4.4.1','4.5.1','4.5.4'].indexOf(fid)<0) return;
      if(d.planned&&((meta.planned_fields||{})[o.type]||[]).indexOf(fid)<0) return;
      var value=f.querySelector('[data-fill="value"]'), source=f.querySelector('[data-fill="source"]'), heading=f.querySelector('h4');
      if(!value||!value.textContent.trim()) return;
      var section=add(clone,'section','pko-field'); section.dataset.field=fid;
      var title=heading?heading.textContent.trim():'Описание';
      var text=value.textContent.trim();
      if(fid==='4.5.4') text=text.replace(/^Проверяемый эффект:\s*/i,'');
      add(section,'h3',null,title); add(section,'p',null,text);
      evidence(section,source?source.textContent.trim():'');
    });
    var assessment=el('div','pko-node-assessment'); var flags=el('div','pko-node-flags');
    if(d.before_fork) add(flags,'span',null,'до развилки · выполняется до выбора процесса');
    if(o.parents.length>1) add(flags,'span',null,'общий узел · родителей: '+o.parents.length);
    if(d.planned) add(flags,'span','planned','в коде нет · планируется');
    if(d.branching&&d.branching!=='sequence') add(flags,'span',null,d.branching_label||d.branching);
    add(assessment,'h3','lbl','Статус узла');
    add(assessment,'div','state',d.implementation_label||'Недостаточно данных');
    if(d.readiness!=null) add(assessment,'div',null,'Взвешенная полнота по пунктам: '+d.readiness+'%');
    if(d.requirements&&d.requirements.total) add(assessment,'div',null,'Полностью выполнено обещаний: '+d.requirements.done+' из '+d.requirements.total+' ('+d.requirements.done_percent+'%)');
    if(d.scenario_status_label) add(assessment,'div',null,'Связность сценария: '+d.scenario_status_label);
    if(Array.isArray(d.problems)&&d.problems.length){var ul=add(assessment,'ul'); d.problems.forEach(function(p){add(ul,'li',null,p)});}
    evidence(assessment,d.explanation||['Сохранённый статус: '+(d.implementation_label||'Недостаточно данных'),d.basis,(d.bullets||[]).map(function(b){return b.text+' — '+b.status_label+'\n'+(b.actual||'')}).join('\n\n'),'Подробный протокол расчёта в этом старом паспорте не сохранён.'].filter(Boolean).join('\n\n'));
    var nodeHandoffs=(SCHEMA.handoffs||[]).filter(function(h){return h.scenario===d.scenario||(h.from_nodes||[]).indexOf(id)>=0||(h.to_nodes||[]).indexOf(id)>=0});
    if(nodeHandoffs.length){var hp=evidence(assessment,'Связность проверяется отдельно от реализации узла. Разрыв означает подтверждённо сломанный обязательный стык; неизвестное не является разрывом.','Обоснование связности и блокеров'); nodeHandoffs.forEach(function(h){add(hp,'h4',null,h.from_step+' → '+h.to_step); add(hp,'p',null,h.result_label); (h.checks||[]).forEach(function(c){add(hp,'p',null,c.check_label+': '+c.result_label+' — '+(c.note||'Объяснение не сохранено.')+'\n'+(c.links||[]).map(function(e){return e.path+':'+e.line+' — '+e.basis}).join('\n'))});});}
    clone.appendChild(assessment);
    var links=el('div','pko-links-list');
    function list(label,ids){ if(!ids.length) return; links.appendChild(document.createTextNode(label)); ids.forEach(function(c,i){if(i) links.appendChild(document.createTextNode(', ')); links.appendChild(link(c));}); }
    list(o.parents.length>1?'Родители ('+o.parents.length+'): ':'Родитель: ',o.parents); list(' · Дети: ',o.children);
    if(flags.childNodes.length) links.prepend(flags);
    if(links.childNodes.length){evidence(links,d.structure_explanation||d.basis); clone.appendChild(links);}
    if(o.type==='bbb'||o.type==='operation'){ var ps=Object.keys(processesOf(o.id)); if(ps.length){ var sbox=el('div','pko-node-scenarios'); add(sbox,'div','lbl','Процессы'); var sul=add(sbox,'ul'); ps.forEach(function(pid){var li=add(sul,'li'); li.appendChild(link(pid)); var chip=nodeStatusChip(byId[pid]); if(chip) li.appendChild(chip);}); clone.appendChild(sbox); } }
    var rels=relations.filter(function(r){return r.from===id||r.to===id});
    if(rels.length){ var rbox=el('div','pko-node-relations'); add(rbox,'div','lbl','Связи'); var rul=add(rbox,'ul'); rels.forEach(function(r){var li=add(rul,'li'); add(li,'span','kind',r.kind_label||r.kind); if(r.from===id){li.appendChild(document.createTextNode(' → ')); li.appendChild(link(r.to));} else {li.appendChild(document.createTextNode(' · ')); li.appendChild(link(r.from)); li.appendChild(document.createTextNode(' → этот объект'));} evidence(li,r.basis);}); clone.appendChild(rbox); }
    var dfs=(d.defects||[]).map(function(x){return defectById[x]}).filter(Boolean);
    if(dfs.length){ var dbox=el('div','pko-node-defects'); add(dbox,'div','lbl','Дефекты'); var dul=add(dbox,'ul'); dfs.forEach(function(df){var li=add(dul,'li',null,df.title+(df.blocking?' — блокирует':'')); evidence(li,[(df.source==='code'?'Сформирован кодом из принятых оценок и проверок стыков.':'Вывод паспортного агента, принятый гейтом.'),'Тип: '+(df.kind_label||df.kind),df.where,'Влияние: '+(df.blocking?'блокирует связанный сценарий':'блокировка сценария этой записью не установлена'),(df.scenarios||[]).map(function(s){return paths.filter(function(p){return p.id===s}).map(function(p){return p.title}).join(', ')}).join('; ')].filter(Boolean).join('\n\n'));}); clone.insertBefore(dbox,assessment.nextSibling); }
    var rks=(d.risks||[]).map(function(x){return riskById[x]}).filter(Boolean);
    appendRisks(clone,rks);
    var inherited=(d.descendant_risks||[]).map(function(x){return riskById[x]}).filter(Boolean);
    appendRisks(clone,inherited,'Риски дочерних шагов');
    appendRiskReview(clone,id,false);
    cardTabs(clone,id);
    dBody.appendChild(clone); dBody.scrollTop=0;
  }
  function appendRisks(target,rks,heading){
    if(rks.length){
      var many=rks.length>1;
      var kbox=el('div','pko-node-risks'+(many?' multi':''));
      if(heading) add(kbox,'h3',null,heading);
      var kul=add(kbox,'ul');
      var riskLinks=el('section','pko-node-risk-links'), hasRiskLinks=false;
      add(riskLinks,'div','lbl','Связи по рискам');
      rks.forEach(function(rk){
        var li=add(kul,'li','pko-risk-card'), content=li;
        var problem=rk.problem||[rk.trigger||rk.cause,rk.negative_event,(rk.consequences||[])[0]].filter(Boolean).join(' → ')||rk.title;
        if(many){var disclosure=add(li,'details','pko-risk-disclosure'); add(disclosure,'summary',null,problem); content=add(disclosure,'div','pko-risk-details');}
        else add(li,'h3',null,problem);
        function riskText(label,text,cls,parent){if(!text) return; var p=add(parent||content,'p',cls); add(p,'span','risk-label',label); p.appendChild(document.createTextNode(text));}
        riskText('В чём пробел',rk.control_gap,'gap');
        if(rk.recommendation||rk.confirmation_needed||rk.closure_criterion){
          var actions=add(content,'details','pko-risk-actions'); add(actions,'summary',null,'Что сделать и проверить');
          riskText('Что изменить',rk.recommendation,null,actions);
          riskText('Что проверить',rk.confirmation_needed,null,actions);
          riskText('Критерий закрытия',rk.closure_criterion,null,actions);
        }
        var linked=(rk.display_nodes||rk.linked_nodes||[]).filter(function(nid){return !!byId[nid]});
        var gids=(rk.guardrails||[]).filter(function(gid){return !!byId[gid]});
        if(linked.length||gids.length){
          hasRiskLinks=true;
          var item=add(riskLinks,'div','pko-risk-link-item'); add(item,'h3',null,rk.title);
          if(linked.length){var np=add(item,'p',null,'Связанные узлы: '); linked.forEach(function(nid,i){if(i) np.appendChild(document.createTextNode(', ')); np.appendChild(link(nid));});}
          if(gids.length){var gp=add(item,'p',null,'Связанные ограничения: '); gids.forEach(function(gid,i){if(i) gp.appendChild(document.createTextNode(', ')); gp.appendChild(link(gid));});}
        }
        var proof=(rk.evidence||[]).map(function(ev){return ev.where+' — '+ev.basis}).join('; ');
        var ep=evidence(content,[rk.trigger?'Условие: '+rk.trigger:'',rk.cause?'Причина: '+rk.cause:'',rk.mechanism?'Механизм: '+rk.mechanism:'',rk.negative_event?'Негативное событие: '+rk.negative_event:'',(rk.consequences||[]).length?'Бизнес-последствия: '+rk.consequences.join('; '):'',rk.confidence_label?'Доказательность: '+rk.confidence_label:'',rk.confidence_note?'Почему выбран этот уровень: '+rk.confidence_note:'',proof?'Факты и ссылки:\n'+proof:'','Пробел после учёта контролей: '+(rk.control_gap||'не указан')].filter(Boolean).join('\n\n'));
        if(ep&&(rk.existing_controls||[]).length) add(ep,'p',null,'Учтённые контроли: '+rk.existing_controls.map(function(c){return c.description+' — '+c.basis}).join('; '));
        if(ep&&rk.control_review){var cr=rk.control_review; add(ep,'p',null,'Область проверки: '+cr.scope); add(ep,'p',null,'Проверенные контроли: '+cr.checked_controls); add(ep,'p',null,cr.conclusion); add(ep,'p',null,'Границы: '+cr.limits); literalQuotes(ep,cr.evidence);}
      });
      target.appendChild(kbox);
      if(hasRiskLinks) target.appendChild(riskLinks);
    }
  }
  function showBreaks(id){
    openDrawer('Разрыв процесса'); var box=add(dBody,'div','pko-simple'); add(box,'div','type','Точка разрыва'); add(box,'h2',null,byId[id].name);
    (breaks[id]||[]).forEach(function(br){
      var p=add(box,'p'); add(p,'strong',null,br.scenario_title+(br.critical?' · критический процесс':'')); p.appendChild(document.createElement('br'));
      if(br.kind==='node') p.appendChild(document.createTextNode(br.reason+(br.step_text?' — «'+br.step_text+'»':'')));
      else p.appendChild(document.createTextNode('Переход «'+br.from_step+'» → «'+br.to_step+'»'));
      var ul=add(box,'ul'); (br.checks||[]).forEach(function(c){ if(c.result==='broken'){ add(ul,'li',null,c.check_label+': '+c.result_label+(c.note?' — '+c.note:'')+((c.links||[]).length?' · '+c.links.map(function(l){return l.path+(l.line?':'+l.line:'')}).join(', '):'')); } });
      evidence(box,[br.reason,br.kind==='node'?'Разрыв отмечен кодом по не реализованному обязательному узлу сценария.':'Разрыв отмечен кодом по подтверждённо сломанному обязательному стыку.',br.critical?'Сценарий критический: его разрыв удерживает блокировку связности независимо от общей доли.':'Критичность сценария не установлена.',(byId[id].data||{}).explanation].filter(Boolean).join('\n\n'));
    });
    var b=add(box,'button','tool','Открыть описание объекта'); b.type='button'; b.style.marginTop='12px'; b.addEventListener('click',function(){showObject(id)});
  }

  // --- 6. Масштаб и панорама ---
  var scale=1,tx=0,ty=0,drag=null;
  function apply(){canvas.style.transform='translate('+tx+'px,'+ty+'px) scale('+scale+')'; zoomBox.querySelector('.lvl').textContent=Math.round(scale*100)+'%';}
  function fit(smooth){ if(!viewport.clientWidth) return; var ns=Math.max(.2,Math.min(1,(viewport.clientWidth-24)/sceneW,(viewport.clientHeight-60)/sceneH)); var ntx=(viewport.clientWidth-sceneW*ns)/2, nty=Math.max(12,(viewport.clientHeight-48-sceneH*ns)/2); if(smooth===true){animateCamera(ns,ntx,nty); return;} scale=ns; tx=ntx; ty=nty; apply(); }
  function zoom(f,x,y){var next=Math.max(.15,Math.min(2.6,scale*f)); tx=x-(x-tx)*next/scale; ty=y-(y-ty)*next/scale; scale=next; apply();}
  viewport.addEventListener('wheel',function(e){e.preventDefault(); var r=viewport.getBoundingClientRect(); zoom(Math.exp(-e.deltaY*.0015),e.clientX-r.left,e.clientY-r.top);},{passive:false});
  viewport.addEventListener('pointerdown',function(e){ if(e.button!==0||e.target.closest('.pko-zoom')) return; drag={x:e.clientX,y:e.clientY,tx:tx,ty:ty}; moved=false; });
  window.addEventListener('pointermove',function(e){ if(!drag) return; var dx=e.clientX-drag.x, dy=e.clientY-drag.y; if(Math.abs(dx)+Math.abs(dy)>5) moved=true; if(moved){viewport.classList.add('dragging'); tx=drag.tx+dx; ty=drag.ty+dy; apply();} });
  window.addEventListener('pointerup',function(){ drag=null; viewport.classList.remove('dragging'); setTimeout(function(){moved=false},0); });
  window.addEventListener('pointercancel',function(){drag=null; moved=false; viewport.classList.remove('dragging');});
  viewport.addEventListener('click',function(e){ if(!moved&&!e.target.closest('button')&&focus) reset(); });
  zoomBox.addEventListener('click',function(e){var b=e.target.closest('button'); if(!b) return; if(b.dataset.z==='fit') fit(); else zoom(b.dataset.z==='in'?1.2:1/1.2,viewport.clientWidth/2,viewport.clientHeight/2);});
  window.addEventListener('resize',fit);
  resetBtn.addEventListener('click',reset); dClose.addEventListener('click',closeDrawer);
  dClose.setAttribute('aria-label','Закрыть описание');
  document.addEventListener('keydown',function(e){ if(e.key==='Escape'){ if(drawer.classList.contains('open')) closeDrawer(); else reset(); } });
  function start(){
    render();
    var initial=decodeURIComponent(location.hash.slice(1)); if(byId[initial]){focus=initial; selection();}
  }
  // Measure node geometry only after the embedded typeface is ready.
  if(document.fonts){
    Promise.all([400,600,700].map(function(weight){return document.fonts.load(weight+' 14px "SB Sans Display"');})).then(start,start);
  } else start();
})();
