
window.pkoPassportMap=function(viewport,nodes,options){
  options=options||{};
  var TYPE_LABEL={journey:'КП',process:'Процесс',bbb:'BBB',operation:'Операция'};
  // Виды связей: подпись и цвет — один список для рёбер, подписей и легенды.
  var REL_KINDS=[
    {kind:'precedes',label:'предшествует',color:'#475569',dash:''},
    {kind:'feeds',label:'передаёт данные',color:'#2563EB',dash:''},
    {kind:'triggers',label:'запускает',color:'#C2410C',dash:''},
    {kind:'depends_on',label:'зависит от',color:'#7C3AED',dash:'5 3'},
    {kind:'fallback',label:'запасной путь для',color:'#B45309',dash:'9 4'},
    {kind:'confirms',label:'подтверждает',color:'#15803D',dash:'2 4'}
  ];
  var REL_BY_KIND={}; REL_KINDS.forEach(function(k){REL_BY_KIND[k.kind]=k});
  var seq=(window.__pkoMapSeq=(window.__pkoMapSeq||0)+1), mid='pko'+seq+'-';
  var byId={}, order=[];
  (nodes||[]).forEach(function(n){
    if(!n||!n.id||byId[n.id]) return;
    var parents=(n.parents||(n.parent?[n.parent]:[])).slice();
    byId[n.id]={id:n.id,type:n.type||n.id.split('-')[0],name:n.name||'',basis:n.basis||'',parents:parents,parent:parents[0]||null,children:[],beforeFork:!!n.before_fork,planned:!!n.planned,branching:n.branching||'',data:n};
    order.push(n.id);
  });
  // Родитель, которого нет среди узлов («—» у корня в реестре), — не родитель.
  // Первый родитель — место узла в дереве; остальные — включения поверх дерева.
  order.forEach(function(id){var n=byId[id]; n.parents=n.parents.filter(function(p){return !!byId[p]}); n.parent=n.parents[0]||null; n.parents.forEach(function(p){byId[p].children.push(id);});});
  var relations=(options.relations||[]).filter(function(r){return r&&byId[r.from]&&byId[r.to]&&r.kind!=='includes'});
  var roots=order.filter(function(id){return byId[id].type==='journey'&&!byId[id].parent});

  viewport.classList.add('pko-viewport');
  var canvas=document.createElement('div'); canvas.className='pko-canvas';
  var moved=false, current=null, hovered=null;
  function box(n){
    var b=document.createElement('button'); b.type='button'; b.className='pko-box'; b.dataset.id=n.id; b.dataset.type=n.type;
    b.innerHTML='<span class="t"></span><span class="n"></span><span class="i"></span>';
    b.querySelector('.t').textContent=TYPE_LABEL[n.type]||n.type;
    b.querySelector('.n').textContent=n.name||'[без названия]';
    b.querySelector('.i').textContent=n.id;
    var d=n.data||{};
    if(n.beforeFork){var g=document.createElement('span'); g.className='sh gate'; g.textContent='до развилки'; b.appendChild(g);}
    if(n.parents.length>1){var sh=document.createElement('span'); sh.className='sh'; sh.textContent='общий · родителей: '+n.parents.length; b.appendChild(sh);}
    if(n.branching&&n.branching!=='sequence'){var br=document.createElement('span'); br.className='sh branch'; br.textContent=d.branching_label||n.branching; b.appendChild(br);}
    if(Array.isArray(d.defects)&&d.defects.length){var df=document.createElement('span'); df.className='sh defects'; df.textContent='дефектов: '+d.defects.length; b.appendChild(df);}
    if(Array.isArray(d.risks)&&d.risks.length){var rk=document.createElement('span'); rk.className='sh risks'; rk.textContent='рисков: '+d.risks.length; b.appendChild(rk);}
    b.setAttribute('aria-label',(TYPE_LABEL[n.type]||n.type)+' «'+(n.name||'[без названия]')+'»'+(d.mark==='broken'?'; разрыв процесса':'')+(Array.isArray(d.risks)&&d.risks.length?'; операционных рисков: '+d.risks.length:''));
    if(d.mark==='broken'){ var m=document.createElement('span'); m.className='m broken'; m.textContent='!'; m.title='Разрыв процесса'; b.appendChild(m); }
    b.addEventListener('click',function(e){if(e.detail===0) select(n.id);});
    return b;
  }
  function subtree(n){
    var item=document.createElement('li'); item.appendChild(box(n));
    // Общий узел раскрывается только под первым родителем: под остальными
    // его место показывает пунктирное ребро.
    var kids=n.children.filter(function(c){return byId[c].parent===n.id});
    if(n.type==='journey'){
      // Узлы до развилки — полосой между путём и процессами: они выполняются
      // до выбора процесса, и на схеме стоят раньше него.
      var gates=kids.filter(function(c){return byId[c].beforeFork}), procs=kids.filter(function(c){return !byId[c].beforeFork});
      if(gates.length){
        var lane=document.createElement('ul'); var laneLi=document.createElement('li'); laneLi.className='pko-lane';
        var gate=document.createElement('div'); gate.className='pko-gate';
        var row=document.createElement('ul'); row.className='pko-gate-row';
        gates.forEach(function(c){row.appendChild(subtree(byId[c]))});
        gate.appendChild(row);
        var cap=document.createElement('div'); cap.className='gc'; cap.innerHTML='<span class="gl">До развилки</span><span class="gs">выполняется до выбора процесса, для всех процессов</span>'; gate.appendChild(cap);
        laneLi.appendChild(gate);
        if(procs.length){var pul=document.createElement('ul'); procs.forEach(function(c){pul.appendChild(subtree(byId[c]))}); laneLi.appendChild(pul);}
        lane.appendChild(laneLi); item.appendChild(lane);
        return item;
      }
      kids=procs;
    }
    if(kids.length){var ul=document.createElement('ul'); kids.forEach(function(c){ul.appendChild(subtree(byId[c]))}); item.appendChild(ul);}
    return item;
  }
  var tree=document.createElement('ul'); tree.className='pko-tree';
  roots.forEach(function(id){tree.appendChild(subtree(byId[id]))});
  canvas.appendChild(tree);
  // Пути сценариев, вторые родители и связи — SVG поверх дерева в
  // координатах холста: масштаб и сдвиг применяются к холсту целиком,
  // пересчитывать линии при зуме не надо.
  var svg=document.createElementNS('http://www.w3.org/2000/svg','svg'); svg.setAttribute('class','pko-paths'); canvas.appendChild(svg);
  var tip=document.createElement('div'); tip.className='pko-tip'; viewport.appendChild(tip);
  var paths=(options.paths||[]).slice();
  var activePaths={}; paths.forEach(function(p){activePaths[p.id]=true;});
  var layers={relations:true,labels:true,parents:true};
  // Уровень детализации: при отдалении узлы схлопываются до процессов, при
  // приближении раскрываются до операций. Рёбра к скрытому узлу ведут к его
  // ближайшему видимому предку.
  var LEVEL={journey:0,process:1,bbb:2,operation:3};
  var detail='operation', autoDetail=true;
  function visibleId(id){
    var n=byId[id];
    while(n&&LEVEL[n.type]>LEVEL[detail]&&n.parent) n=byId[n.parent];
    return n?n.id:id;
  }
  function applyDetail(){
    Array.prototype.forEach.call(viewport.querySelectorAll('.pko-tree li'),function(li){
      var b=li.querySelector(':scope > .pko-box'); if(!b) return;
      li.classList.toggle('pko-hidden',LEVEL[b.dataset.type]>LEVEL[detail]);
    });
  }
  function setDetail(next,manual){
    if(manual) autoDetail=false;
    if(next===detail){applyDetail(); return;}
    detail=next; applyDetail(); drawPaths();
  }
  function anchor(id){
    id=visibleId(id);
    var b=viewport.querySelector('.pko-box[data-id="'+id+'"]'); if(!b) return null;
    var r=b.getBoundingClientRect(), c=canvas.getBoundingClientRect();
    return {x:(r.left-c.left)/scale, y:(r.top-c.top)/scale, w:r.width/scale, h:r.height/scale};
  }
  // Разводка рёбер поверх дерева, всегда от a к b (стрелка на конце). Узлы
  // в одной строке соединяет дуга над ними; узлы на разных уровнях —
  // ортогональный маршрут: выход из узла вверх или вниз, полка над/под
  // строкой, спуск по коридору сбоку от целевого узла и вход в его боковую
  // грань. `off` — номер полки: рёбра одного узла и параллельные пути
  // сценариев идут по соседним полкам, а не друг по другу.
  var LANE=16, GUTTER=8, STEP=5;
  function curve(a,b,off){
    off=off||0;
    var ac=a.x+a.w/2, bc=b.x+b.w/2, o=off*STEP;
    if(Math.abs(a.y-b.y)<8){
      var ltr=a.x<b.x, x1=a.x+a.w*(ltr?.72:.28), x2=b.x+b.w*(ltr?.28:.72), y=Math.min(a.y,b.y), h=26+o;
      return {d:'M'+x1+','+y+' C'+x1+','+(y-h)+' '+x2+','+(y-h)+' '+x2+','+y, mx:(x1+x2)/2, my:y-h*.75-2};
    }
    if(b.y>a.y+a.h-1){
      var dir=bc>ac?1:-1, side=dir>0?b.x:b.x+b.w, gx=side-dir*(GUTTER+o), ly=a.y+a.h+LANE+o, ty=b.y+b.h/2;
      if(Math.abs(gx-ac)<8) return {d:'M'+ac+','+(a.y+a.h)+' L'+ac+','+b.y, mx:ac+6, my:(a.y+a.h+b.y)/2};
      return {d:'M'+ac+','+(a.y+a.h)+' L'+ac+','+ly+' L'+gx+','+ly+' L'+gx+','+ty+' L'+side+','+ty, mx:(ac+gx)/2, my:ly};
    }
    var dir2=bc>ac?1:-1, side2=dir2>0?b.x:b.x+b.w, gx2=side2-dir2*(GUTTER+o), ly2=a.y-LANE-o, ty2=b.y+b.h/2;
    if(gx2>a.x-GUTTER&&gx2<a.x+a.w+GUTTER){ dir2=-dir2; side2=dir2>0?b.x:b.x+b.w; gx2=side2-dir2*(GUTTER+o); }
    return {d:'M'+ac+','+a.y+' L'+ac+','+ly2+' L'+gx2+','+ly2+' L'+gx2+','+ty2+' L'+side2+','+ty2, mx:(ac+gx2)/2, my:ly2};
  }
  function svgEl(tag,cls){var el=document.createElementNS('http://www.w3.org/2000/svg',tag); if(cls) el.setAttribute('class',cls); return el;}
  function marker(id,color){
    var m=svgEl('marker'); m.setAttribute('id',id); m.setAttribute('viewBox','0 0 10 10'); m.setAttribute('refX','9'); m.setAttribute('refY','5');
    m.setAttribute('markerWidth','9'); m.setAttribute('markerHeight','9'); m.setAttribute('markerUnits','userSpaceOnUse'); m.setAttribute('orient','auto');
    var p=svgEl('path'); p.setAttribute('d','M0,0 L10,5 L0,10 z'); p.setAttribute('fill',color); m.appendChild(p); return m;
  }
  function defs(){
    var d=svgEl('defs');
    REL_KINDS.forEach(function(k){d.appendChild(marker(mid+k.kind,k.color))});
    d.appendChild(marker(mid+'includes','#6D4BE0'));
    d.appendChild(marker(mid+'ok','#2CB6B0')); d.appendChild(marker(mid+'broken','#E2556F')); d.appendChild(marker(mid+'unknown','#92A2B0'));
    return d;
  }
  function pill(cls,x,y,text){
    var g=svgEl('g','lbl '+cls); var w=Math.max(28,text.length*5.6+12);
    var r=svgEl('rect'); r.setAttribute('x',x-w/2); r.setAttribute('y',y-8); r.setAttribute('width',w); r.setAttribute('height',16);
    var t=svgEl('text'); t.setAttribute('x',x); t.setAttribute('y',y+.5); t.textContent=text;
    g.appendChild(r); g.appendChild(t); return g;
  }
  function label(cls,x,y,text){var t=svgEl('text',cls); t.setAttribute('x',x); t.setAttribute('y',y-5); t.textContent=text; return t;}
  function edgeKey(r){return r.from+'>'+r.to+'>'+r.kind}
  function showTip(e,html){tip.innerHTML=html; tip.style.display='block'; moveTip(e);}
  function moveTip(e){var r=viewport.getBoundingClientRect(); var x=e.clientX-r.left+14, y=e.clientY-r.top+14; if(x+tip.offsetWidth>r.width-8) x=Math.max(8,x-tip.offsetWidth-28); if(y+tip.offsetHeight>r.height-8) y=Math.max(8,y-tip.offsetHeight-28); tip.style.left=x+'px'; tip.style.top=y+'px';}
  function hideTip(){tip.style.display='none';}
  function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]});}
  function nodeName(id){return byId[id]?byId[id].name:id}
  function attachHover(hit,line,lbl,html){
    hit.addEventListener('pointerenter',function(e){line.classList.add('hover'); if(lbl) lbl.classList.add('hover'); showTip(e,html);});
    hit.addEventListener('pointermove',moveTip);
    hit.addEventListener('pointerleave',function(){line.classList.remove('hover'); if(lbl) lbl.classList.remove('hover'); hideTip();});
  }
  function drawPaths(){
    while(svg.firstChild) svg.removeChild(svg.firstChild);
    // SVG нулевого размера Chrome не рисует даже с overflow:visible —
    // оверлей растягивается на весь холст.
    svg.setAttribute('width',canvas.scrollWidth); svg.setAttribute('height',canvas.scrollHeight);
    var sel=current?byId[current]:null;
    svg.classList.toggle('focus',!!sel); viewport.classList.toggle('focus',!!sel);
    var drawnPairs={}, onPath={};
    function connect(from,to){
      var aId=visibleId(from), bId=visibleId(to), key=[aId,bId].sort().join('|');
      if(aId===bId||drawnPairs[key]) return;
      var a=anchor(aId), b=anchor(bId); if(!a||!b) return;
      drawnPairs[key]=true;
      var hl=sel&&(sel.id===aId||sel.id===bId);
      var path=svgEl('path','connection'+(hl?' hl':''));
      path.setAttribute('d',curve(a,b,0).d); path.dataset.pair=key; svg.appendChild(path);
    }
    order.forEach(function(id){byId[id].parents.forEach(function(parent){connect(parent,id)});});
    relations.forEach(function(r){connect(r.from,r.to)});
    paths.forEach(function(p){
      if(!activePaths[p.id]) return;
      (p.nodes||[]).forEach(function(n){onPath[n.id]=true});
      (p.edges||[]).forEach(function(e){connect(e.from,e.to)});
    });
    // Процесс задействован в сценарии, если на пути стоит хотя бы один его
    // узел (через любого из родителей); иначе он гаснет вместе с блоками.
    Object.keys(onPath).forEach(function(id){
      var frontier=[id], seen={};
      while(frontier.length){
        var cur=frontier.pop(); if(seen[cur]||!byId[cur]) continue; seen[cur]=true;
        if(byId[cur].type==='process') onPath[cur]=true; else frontier=frontier.concat(byId[cur].parents);
      }
    });
    var any=paths.some(function(p){return activePaths[p.id]});
    Array.prototype.forEach.call(viewport.querySelectorAll('.pko-box'),function(b){
      b.classList.toggle('dim',any&&paths.length>0&&!onPath[b.dataset.id]&&b.dataset.type!=='journey');
    });
  }
  viewport.appendChild(canvas);
  var legend=null, legendHost=options.legendHost||null;
  function sample(color,dash,width){return '<svg viewBox="0 0 26 10"><line x1="1" y1="5" x2="21" y2="5" stroke="'+color+'" stroke-width="'+(width||2)+'"'+(dash?' stroke-dasharray="'+dash+'"':'')+' stroke-linecap="round"/><path d="M20,1 L25,5 L20,9 z" fill="'+color+'"/></svg>';}
  if(paths.length||options.legend!==false){
    legend=document.createElement('div'); legend.className='pko-legend'+(legendHost?' inline':'');
    var key=document.createElement('div'); key.className='pko-key';
    // Статусы реализации остаются в карточках и реестре. На самой карте
    // единственная статусная отметка — подтверждённый разрыв.
    key.innerHTML='<span class="kh">обозначение</span><span title="Подтверждённо не работает обязательный переход либо не реализован обязательный шаг сценария"><b style="background:#E2556F;color:#fff;text-align:center;line-height:9px">!</b>разрыв процесса</span>';
    var lines=document.createElement('div'); lines.className='pko-key';
    lines.textContent='Линия — связь. Пояснения — в карточках узлов.';
    legend.appendChild(key); legend.appendChild(lines);
    var row=document.createElement('div'); row.className='row';
    function layerChip(key,text,title){
      var chip=document.createElement('button'); chip.type='button'; chip.className='pko-chip layer on'; chip.textContent=text; chip.title=title; chip.setAttribute('aria-pressed','true');
      chip.addEventListener('click',function(e){e.stopPropagation(); layers[key]=!layers[key]; chip.classList.toggle('on',layers[key]); chip.setAttribute('aria-pressed',String(layers[key])); drawPaths();});
      return chip;
    }
    paths.forEach(function(p){
      var chip=document.createElement('button'); chip.type='button'; chip.className='pko-chip on'; chip.dataset.path=p.id;
      chip.setAttribute('aria-pressed','true');
      chip.innerHTML='<span></span>';
      chip.lastChild.textContent=p.title+(p.critical?' · критический':'');
      chip.title=(p.status_label||'')+(p.critical?' · критический: без этого сценария замысел инициативы не выполняется':'')+(p.break_point?' — разрыв: '+p.break_point:'')+' · клик — скрыть/показать путь';
      chip.addEventListener('click',function(e){e.stopPropagation(); activePaths[p.id]=!activePaths[p.id]; chip.classList.toggle('on',activePaths[p.id]); chip.setAttribute('aria-pressed',String(activePaths[p.id])); drawPaths();});
      row.appendChild(chip);
    });
    legend.appendChild(row);
    (legendHost||viewport).appendChild(legend);
  }
  var zoom=document.createElement('div'); zoom.className='pko-zoom';
  zoom.innerHTML='<button type="button" data-z="in" title="Приблизить" aria-label="Приблизить">+</button><button type="button" data-z="out" title="Отдалить" aria-label="Отдалить">−</button><button type="button" data-z="fit" class="pko-zoom-fit" title="Вписать в окно" aria-label="Вписать схему в окно">FIT</button>';
  viewport.appendChild(zoom);
  var hint=document.createElement('div'); hint.className='pko-hint'; hint.textContent='Колесо — масштаб · перетаскивание — сдвиг · клик по узлу — паспорт узла · наведение на линию — основание связи'; viewport.appendChild(hint);

  var scale=1, tx=0, ty=0;
  function apply(){canvas.style.transform='translate('+tx+'px,'+ty+'px) scale('+scale+')';}
  function autoLevel(){return scale<.42?'process':scale<.68?'bbb':'operation';}
  function setScale(next,cx,cy){
    next=Math.min(3,Math.max(.2,next));
    if(cx===undefined){cx=viewport.clientWidth/2; cy=viewport.clientHeight/2;}
    tx=cx-(cx-tx)*next/scale; ty=cy-(cy-ty)*next/scale; scale=next; apply();
    if(autoDetail&&autoLevel()!==detail){detail=autoLevel(); applyDetail(); drawPaths();}
  }
  function place(minScale){
    var w=canvas.scrollWidth, h=canvas.scrollHeight, vw=viewport.clientWidth, vh=viewport.clientHeight;
    if(!w||!h||!vw||!vh) return;
    scale=Math.min(1.1,Math.max(minScale,Math.min(vw/w,vh/h)));
    var topInset=legend&&!legendHost?legend.offsetHeight+20:20;
    var padTop=vw<=768?116:88;
    var minTy=Math.max(0,topInset-padTop*scale);
    tx=(vw-w*scale)/2; ty=Math.max(minTy,(vh-h*scale)/2); apply(); drawPaths();
  }
  function fit(){place(.2);}
  function readable(){
    var shortViewport=viewport.clientHeight<560;
    place(viewport.clientWidth<=768?(shortViewport?.48:.64):(shortViewport?.56:.72));
  }
  zoom.addEventListener('click',function(e){
    var b=e.target.closest('button'); if(!b) return;
    if(b.dataset.z==='in') setScale(scale*1.2); else if(b.dataset.z==='out') setScale(scale/1.2); else fit();
  });
  viewport.addEventListener('wheel',function(e){
    e.preventDefault();
    var r=viewport.getBoundingClientRect();
    setScale(scale*(e.deltaY<0?1.1:1/1.1),e.clientX-r.left,e.clientY-r.top);
  },{passive:false});
  // Панорама и выбор узла — одной парой pointerdown/pointerup без захвата
  // указателя: с setPointerCapture click уходил на область, а не на узел.
  var drag=null;
  viewport.addEventListener('pointerdown',function(e){
    if(e.button!==0||e.target.closest('.pko-zoom')||e.target.closest('.pko-legend')) return;
    drag={x:e.clientX,y:e.clientY,tx:tx,ty:ty,target:e.target.closest('.pko-box')}; moved=false;
  });
  window.addEventListener('pointermove',function(e){
    if(!drag) return;
    var dx=e.clientX-drag.x, dy=e.clientY-drag.y;
    if(!moved&&Math.abs(dx)+Math.abs(dy)>4){moved=true; viewport.classList.add('dragging'); hideTip();}
    if(moved){tx=drag.tx+dx; ty=drag.ty+dy; apply();}
  });
  window.addEventListener('pointerup',function(){
    if(!drag) return;
    var target=drag.target, wasMoved=moved;
    drag=null; viewport.classList.remove('dragging'); moved=false;
    if(!wasMoved&&target&&target.dataset.id) select(target.dataset.id);
  });
  window.addEventListener('pointercancel',function(){drag=null; moved=false; viewport.classList.remove('dragging');});
  window.addEventListener('resize',readable);

  function relatedIds(n){
    var out={};
    n.parents.forEach(function(p){out[p]=true}); n.children.forEach(function(c){out[c]=true});
    relations.forEach(function(r){ if(r.from===n.id) out[r.to]=true; if(r.to===n.id) out[r.from]=true; });
    return out;
  }
  function highlight(id){
    var n=id?byId[id]:null, rel=n?relatedIds(n):{};
    Array.prototype.forEach.call(viewport.querySelectorAll('.pko-box'),function(b){
      b.classList.toggle('active',!!n&&b.dataset.id===id);
      b.classList.toggle('related',!!n&&b.dataset.id!==id&&!!rel[b.dataset.id]);
    });
    drawPaths();
  }
  function select(id){
    var n=byId[id]; if(!n) return; current=id;
    // Выбранный узел должен быть виден: раскрываем до его уровня.
    if(LEVEL[n.type]>LEVEL[detail]){detail=n.type; autoDetail=false; applyDetail();}
    highlight(id);
    if(options.onSelect) options.onSelect(n, byId, relations);
  }
  function clear(){current=null; highlight(null);}
  function showPaths(ids){
    paths.forEach(function(p){activePaths[p.id]=!ids||ids.indexOf(p.id)>=0;});
    Array.prototype.forEach.call(viewport.querySelectorAll('.pko-chip[data-path]'),function(chip){chip.classList.toggle('on',!!activePaths[chip.dataset.path]); chip.setAttribute('aria-pressed',String(!!activePaths[chip.dataset.path]));});
    drawPaths();
  }
  readable();
  return {select:select, clear:clear, fit:fit, redraw:drawPaths, nodes:byId, order:order, relations:relations, paths:paths, kinds:REL_KINDS, setDetail:function(d){setDetail(d,true)}, showPaths:showPaths};
};
