"""Детерминированные факты для паспорта поверх фактов экстракторов.

Считаются в паспортном этапе, после ранней выдачи дашборда: входы ревьюера
(факты, карта возможностей, инструменты) не меняются.

* **Вызовы маршрутов из интерфейса.** Фронтенд Белка не разбирает, поэтому
  объявленный backend-маршрут выглядел «достижимым», даже когда интерфейс
  его не вызывает. Здесь маршруты сопоставляются со строковыми литералами
  путей во фронтенд-файлах.
* **Возможности системы** — маршруты, задания, инструменты, узлы графа: по
  ним код проверяет, что паспорт рассмотрел всё, что система умеет
  (обратное сопоставление «код → паспорт»).
* **Факты экспозиции** — вызовы модели и внешних систем, значения по
  умолчанию настроек контура, предупреждения пользователю: без них чек-лист
  рисков не видит, куда уходят данные.

Всё это сигналы, а не приговоры: URL, собранный динамически, вызов через
реестр или конфигурацию статический поиск не видит. «Не найден» — повод
проверить, а не доказательство отсутствия.
"""

from __future__ import annotations

import re
from bisect import bisect_left
from dataclasses import dataclass, field
from typing import Any, Iterable

FRONTEND_SUFFIXES = (".js", ".jsx", ".ts", ".tsx", ".vue", ".svelte", ".mjs", ".cjs")
_FRONTEND_SKIP_PARTS = ("node_modules/", "/dist/", "/build/", "/.next/", "/coverage/",
                        "/vendor/", "/__tests__/", "/__mocks__/", "/e2e/", "/cypress/")
_FRONTEND_TEST_RE = re.compile(r"\.(test|spec|stories)\.[jt]sx?$|\.min\.[jt]s$")
# Потолки обхода: сигнал должен считаться за секунды и на большом монорепо.
MAX_FRONTEND_FILES = 3000
MAX_FILE_CHARS = 1_500_000
MAX_CALLS_PER_ROUTE = 5
# Сколько возможностей код предъявляет паспортному агенту для обратного
# сопоставления: остальные учитываются в счётчике, но не в списке.
MAX_CAPABILITIES = 40
# Виды фактов-возможностей по убыванию приоритета.
CAPABILITY_KINDS = ("ROUTE", "JAVA_JOB", "ENTRYPOINT", "TOOL", "GRAPH_NODE")
CAPABILITY_KIND_LABEL = {
    "ROUTE": "HTTP-маршрут",
    "JAVA_JOB": "задание по расписанию",
    "ENTRYPOINT": "точка входа",
    "TOOL": "инструмент агента",
    "GRAPH_NODE": "узел графа исполнения",
}
# Причины, по которым возможность сознательно не входит в паспорт.
DISMISS_REASONS = {
    "auxiliary": "вспомогательная или техническая",
    "admin": "администрирование и сопровождение",
    "legacy": "устаревшая или не вызывается",
    "out_of_scope": "вне результата инициативы",
    "duplicate": "дублирует другую возможность",
}
MAX_EXPOSURES = 40
# Сколько фактов внешнего вызова обязаны получить ссылку в чек-листе рисков.
MAX_REQUIRED_EXPOSURES = 8
_REQUIRED_EXTERNAL_MECHANISMS = ("llm", "http_client")

_LITERAL_RE = re.compile(r"""(['"`])((?:https?://[^'"`\s/]+)?/[^'"`\s]{1,200}?)\1""")
_PARAM_RE = re.compile(r"^(\{[^}]*\}|<[^>]*>|:\w+|\*)$")
_PY_DEF_RE = re.compile(r"^(\s*)(?:async\s+)?def\s+(\w+)")
_JAVA_DEF_RE = re.compile(r"^(\s*)(?:public|private|protected)\s[\w<>\[\],.\s]*?(\w+)\s*\(")
_ENV_DEFAULT_RE = re.compile(
    r"""os\.(?:getenv|environ\.get)\(\s*['"]([A-Z][A-Z0-9_]{2,60})['"]\s*,\s*([^)\n]{1,80})\)""")
_ENV_INTERESTING = re.compile(
    r"ENV|DEPLOY|CONTOUR|CIRCUIT|BASE_URL|_URL|ENDPOINT|HOST|PROVIDER|MODEL|RETR|TIMEOUT|MTLS|TLS|"
    r"INTERNAL|EXTERNAL|REGION|LLM|OPENAI|ROUTER|PROXY")
_ENV_SECRET = re.compile(r"KEY|TOKEN|SECRET|PASSWORD|PASSWD|PASS\b|CREDENTIAL|PRIVATE")
_UI_WARNING_RE = re.compile(
    r"конфиденциальн|персональн\w* данн|не загружайте|коммерческ\w* тайн|confidential|sensitive data|"
    r"do not upload|personal data", re.IGNORECASE)
_DOC_MARKER_RE = re.compile(
    r"внешн\w*\s+контур|внутренн\w*\s+контур|DEPLOYMENT_ENV|внешн\w*\s+провайдер|external\s+provider",
    re.IGNORECASE)
MAX_UI_WARNINGS = 10
MAX_DOC_MARKERS = 8
MAX_ENV_DEFAULTS = 30


# --- общие утилиты ---------------------------------------------------------------

def is_frontend_file(path: str) -> bool:
    low = "/" + path.lower()
    if not low.endswith(FRONTEND_SUFFIXES):
        return False
    if any(part in low for part in _FRONTEND_SKIP_PARTS):
        return False
    return not _FRONTEND_TEST_RE.search(low)


def _is_vendor(path: str) -> bool:
    try:
        from pko.extractors.base import is_vendor
    except ImportError:  # pragma: no cover — экстракторы поставляются вместе
        return False
    return is_vendor(path)


def _read(tree: Any, path: str) -> str:
    try:
        text = tree.read(path)
    except Exception:  # noqa: BLE001 — нечитаемый файл просто не даёт сигнала
        return ""
    if not isinstance(text, str) or len(text) > MAX_FILE_CHARS:
        return ""
    return text


def _mask(text: str) -> str:
    from pko.progress.agent_tools import _mask_secrets
    return _mask_secrets(text)


def _segments(path: str) -> list[str]:
    path = re.sub(r"^[a-z]+://[^/]+", "", str(path).strip(), flags=re.IGNORECASE)
    path = path.split("?", 1)[0].split("#", 1)[0]
    return [s for s in path.strip("/").split("/") if s]


def _is_param(segment: str) -> bool:
    return bool(_PARAM_RE.match(segment)) or "${" in segment or "{" in segment


def _static(segments: list[str]) -> list[str]:
    return [s for s in segments if not _is_param(s)]


def _same(route: list[str], literal: list[str]) -> bool:
    if len(route) != len(literal):
        return False
    shared_static = 0
    for a, b in zip(route, literal):
        if _is_param(a) or _is_param(b):
            continue
        if a != b:
            return False
        shared_static += 1
    return shared_static > 0


def _line_of(text: str, index: int) -> int:
    return text.count("\n", 0, index) + 1


def _declaration_span(text: str, line: int, path: str = "") -> tuple[int, int, str]:
    """Строки объявления, начинающегося у `line` (декоратор допустим), и имя.

    Конец — последняя строка перед кодом с отступом не больше, чем у `def`.
    Разбор приблизительный: он нужен, чтобы понять, цитирует ли узел код
    именно этой возможности, а не соседней.
    """
    lines = text.splitlines()
    if not 1 <= line <= len(lines):
        return line, line, ""
    pattern = _JAVA_DEF_RE if path.endswith((".java", ".kt")) else _PY_DEF_RE
    start = line
    def_index, indent, name = None, 0, ""
    for index in range(line - 1, min(len(lines), line + 6)):
        match = pattern.match(lines[index])
        if match:
            def_index = index
            indent = len(match.group(1) or "")
            name = match.group(2) or ""
            break
    if def_index is None:
        return start, start, ""
    end = def_index + 1
    for index in range(def_index + 1, min(len(lines), def_index + 400)):
        raw = lines[index]
        stripped = raw.strip()
        if not stripped or stripped.startswith(("#", "//", "*")):
            continue
        if len(raw) - len(raw.lstrip()) <= indent and not stripped.startswith((")", "}", "]")):
            break
        end = index + 1
    return start, max(start, end), name


# --- вызовы маршрутов из интерфейса ------------------------------------------------

@dataclass
class RouteInfo:
    key: str
    method: str
    path: str
    decl_path: str
    decl_line: int
    handler: str = ""
    calls: list[dict[str, Any]] = field(default_factory=list)

    @property
    def called(self) -> bool:
        return bool(self.calls)


@dataclass
class RouteUsage:
    frontend_files: int = 0
    scanned_files: int = 0
    truncated: bool = False
    routes: list[RouteInfo] = field(default_factory=list)

    @property
    def frontend_present(self) -> bool:
        return self.frontend_files > 0

    def route_at(self, path: str, line: int, window: int = 2) -> RouteInfo | None:
        for route in self.routes:
            if route.decl_path == path and abs(route.decl_line - line) <= window:
                return route
        return None

    def digest(self, limit: int = 60) -> str:
        if not self.routes:
            return ""
        if not self.frontend_present:
            return ("Вызовы маршрутов из интерфейса: фронтенд в переданных материалах не найден — "
                    "клиентский вызов маршрутов не проверялся; маршрут остаётся точкой входа для внешних клиентов.")
        called = sum(1 for r in self.routes if r.called)
        lines = [f"Вызовы маршрутов из интерфейса (статический поиск литералов путей в {self.frontend_files} "
                 f"фронтенд-файлах; «не найден» — сигнал, не доказательство): найдено {called} из {len(self.routes)}."]
        for route in self.routes[:limit]:
            if route.called:
                where = ", ".join(f"{c['path']}:{c['line']}" for c in route.calls[:3])
                lines.append(f"- {route.key} → вызывается: {where}")
            else:
                lines.append(f"- {route.key} → во фронтенде не найден")
        if len(self.routes) > limit:
            lines.append(f"… ещё {len(self.routes) - limit} маршрутов")
        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        return {
            "frontend_files": self.frontend_files,
            "scanned_files": self.scanned_files,
            "truncated": self.truncated,
            "routes_total": len(self.routes),
            "routes_called": sum(1 for r in self.routes if r.called),
            "routes": [{"key": r.key, "declared": f"{r.decl_path}:{r.decl_line}",
                        "called": r.called, "calls": [f"{c['path']}:{c['line']}" for c in r.calls]}
                       for r in self.routes],
            "scope": "Статический поиск литералов путей; динамически собранный URL не виден.",
        }


def route_usage(tree: Any, facts: Iterable[Any]) -> RouteUsage:
    """Сопоставить backend-маршруты с литералами путей во фронтенде."""
    usage = RouteUsage()
    seen: set[tuple[str, str, int]] = set()
    for fact in facts:
        if getattr(fact, "kind", "") != "ROUTE" or not getattr(fact, "path", ""):
            continue
        value = fact.value if isinstance(fact.value, dict) else {}
        path = str(value.get("path") or fact.key.split(" ", 1)[-1] or "")
        method = str(value.get("method") or fact.key.split(" ", 1)[0] or "")
        line = int(fact.line or 0)
        marker = (fact.path, path, line)
        if marker in seen or not _static(_segments(path)):
            continue
        seen.add(marker)
        text = _read(tree, fact.path)
        _, _, handler = _declaration_span(text, line, fact.path) if text and line else (0, 0, "")
        usage.routes.append(RouteInfo(key=f"{method} {path}".strip(), method=method, path=path,
                                      decl_path=fact.path, decl_line=line, handler=handler))
    files = [p for p in getattr(tree, "files", []) if is_frontend_file(p)]
    usage.frontend_files = len(files)
    if not usage.routes or not files:
        return usage
    if len(files) > MAX_FRONTEND_FILES:
        usage.truncated = True
        files = files[:MAX_FRONTEND_FILES]
    route_segments = [(route, _segments(route.path)) for route in usage.routes]
    literals: list[tuple[str, int, list[str], bool, str]] = []
    for path in files:
        text = _read(tree, path)
        if not text:
            continue
        # Бандл без переносов строк — сборка, а не исходник.
        if len(text) > 20000 and text.count("\n") < len(text) / 2000:
            continue
        usage.scanned_files += 1
        source_lines = text.splitlines()
        breaks = [i for i, ch in enumerate(text) if ch == "\n"]
        for match in _LITERAL_RE.finditer(text):
            raw = match.group(2)
            segments = _segments(raw)
            if not segments or not _static(segments):
                continue
            line = bisect_left(breaks, match.start()) + 1
            snippet = source_lines[line - 1].strip()[:160] if line <= len(source_lines) else ""
            literals.append((path, line, segments, raw.rstrip().endswith("/"), _mask(snippet)))
    # Базовый префикс API-клиента: литерал вроде '/api', который является
    # началом хотя бы двух маршрутов, а сам маршрутом не является.
    prefixes = {
        tuple(segs) for _, _, segs, _, _ in literals
        if len(segs) <= 2 and not any(len(r) == len(segs) and _same(r, segs) for _, r in route_segments)
        and sum(1 for _, r in route_segments if len(r) > len(segs) and r[:len(segs)] == segs) >= 2
    }
    # Индекс по статическим сегментам: маршрут сравнивается только с
    # литералами, где встречается его последний статический сегмент.
    by_segment: dict[str, list[int]] = {}
    for index, (_, _, segs, _, _) in enumerate(literals):
        for segment in set(_static(segs)):
            by_segment.setdefault(segment, []).append(index)
    for route, segs in route_segments:
        for index in by_segment.get(_static(segs)[-1], []):
            path, line, lit, open_tail, snippet = literals[index]
            if len(route.calls) >= MAX_CALLS_PER_ROUTE:
                break
            base = [lit, lit + ["{param}"]] if open_tail else [lit]
            candidates = base + [list(prefix) + c for prefix in prefixes for c in base]
            hit = any(_same(segs, c) for c in candidates)
            if not hit:
                # Префикс роутера (APIRouter(prefix=…)) в факте маршрута не виден:
                # литерал длиннее и заканчивается путём маршрута.
                hit = any(len(c) > len(segs) and len(c) - len(segs) <= 3
                          and all(not _is_param(s) for s in c[:len(c) - len(segs)])
                          and _same(segs, c[len(c) - len(segs):]) for c in candidates)
            if hit:
                route.calls.append({"path": path, "line": line, "snippet": snippet})
    return usage


# --- возможности системы для обратного сопоставления --------------------------------

@dataclass
class Capability:
    id: str
    kind: str
    label: str
    path: str
    line: int
    span: tuple[int, int]
    names: list[str] = field(default_factory=list)

    @property
    def where(self) -> str:
        return f"{self.path}:{self.line}"

    def describe(self) -> str:
        return f"{self.id} · {CAPABILITY_KIND_LABEL.get(self.kind, self.kind)} «{self.label}» · {self.where}"


def capabilities(tree: Any, facts: Iterable[Any], limit: int = MAX_CAPABILITIES) -> tuple[list[Capability], int]:
    """Возможности системы по приоритету вида; второе значение — всего найдено."""
    order = {kind: index for index, kind in enumerate(CAPABILITY_KINDS)}
    picked = []
    seen: set[tuple[str, str, int]] = set()
    for fact in facts:
        kind = getattr(fact, "kind", "")
        if kind not in order or not getattr(fact, "path", "") or _is_vendor(fact.path):
            continue
        marker = (kind, fact.path, int(fact.line or 0))
        if marker in seen:
            continue
        seen.add(marker)
        picked.append(fact)
    picked.sort(key=lambda f: (order[f.kind], f.path, int(f.line or 0)))
    total = len(picked)
    out: list[Capability] = []
    texts: dict[str, str] = {}
    for fact in picked[:limit]:
        line = int(fact.line or 0)
        if fact.path not in texts:
            texts[fact.path] = _read(tree, fact.path)
        start, end, handler = _declaration_span(texts[fact.path], line, fact.path) if line else (line, line, "")
        names = [n for n in (handler, str(fact.key)) if n]
        if fact.kind == "ROUTE":
            value = fact.value if isinstance(fact.value, dict) else {}
            if value.get("path"):
                names.append(str(value["path"]))
        if fact.kind == "GRAPH_NODE":
            start = end = line
        out.append(Capability(id=f"cap-{len(out) + 1}", kind=fact.kind, label=str(fact.key),
                              path=fact.path, line=line, span=(start, end),
                              names=list(dict.fromkeys(names))))
    return out, total


def _quote_lines(record: dict[str, str], quote: str) -> list[int]:
    """Номера строк исходника, которые покрывает дословная цитата фрагмента."""
    text = record.get("text") or ""
    index = text.find(quote) if quote else -1
    if index < 0:
        return []
    first = text.rfind("\n", 0, index) + 1
    lines = text[first:index + len(quote)].splitlines() or [""]
    out = []
    for raw in lines:
        match = re.match(r"^(\d+): ", raw)
        if match:
            out.append(int(match.group(1)))
    return out


def _citations(fact_check: Any) -> list[dict[str, Any]]:
    if not isinstance(fact_check, dict):
        return []
    refs: list[Any] = []
    execution = fact_check.get("execution")
    if isinstance(execution, dict):
        refs.extend(execution.get("evidence") or [])
        refs.extend(execution.get("entry_evidence") or [])
    for row in (fact_check.get("fields") or {}).values():
        if isinstance(row, dict):
            refs.extend(row.get("evidence") or [])
    return [r for r in refs if isinstance(r, dict)]


def _node_texts(data: dict[str, Any]) -> str:
    parts: list[str] = []
    for cell in (data.get("fields") or {}).values():
        if isinstance(cell, dict):
            parts.append(str(cell.get("source") or ""))
            parts.append(str(cell.get("value") or ""))
    audit = data.get("fact_check")
    if isinstance(audit, dict) and isinstance(audit.get("execution"), dict):
        parts.extend(str(audit["execution"].get(k) or "") for k in ("entrypoint", "limits", "outcome"))
    return "\n".join(parts)


def auto_mapped(caps: list[Capability], nodes: dict[str, dict[str, Any]],
                records: dict[str, dict[str, str]]) -> dict[str, list[str]]:
    """Возможность → узлы, которые на неё опираются: цитата кода в пределах её
    объявления, `путь:строка` внутри него или имя обработчика/путь маршрута в
    основаниях полей. Упоминание файла без строки не считается: в одном файле
    живут десятки маршрутов."""
    out: dict[str, list[str]] = {}
    for nid, data in nodes.items():
        cited: dict[str, set[int]] = {}
        for ref in _citations(data.get("fact_check")):
            record = records.get(str(ref.get("id") or ""))
            if not record or record.get("kind") != "code":
                continue
            path = str(record.get("label") or "").rsplit(":", 1)[0]
            cited.setdefault(path, set()).update(_quote_lines(record, str(ref.get("quote") or "")))
        text = _node_texts(data)
        for cap in caps:
            start, end = cap.span
            hit = any(start <= n <= end for n in cited.get(cap.path, ()))
            if not hit:
                for match in re.finditer(re.escape(cap.path) + r":(\d+)", text):
                    if start <= int(match.group(1)) <= end:
                        hit = True
                        break
            if not hit:
                for name in cap.names:
                    # Путь маршрута — целиком: «/tasks» не засчитывается по «/tasks/{task_id}».
                    if len(name) >= 4 and re.search(r"(?<![\w/])" + re.escape(name) + r"(?![\w/{-])", text):
                        hit = True
                        break
            if hit:
                out.setdefault(cap.id, []).append(nid)
    return out


# --- факты экспозиции --------------------------------------------------------------

def exposure_facts(tree: Any, facts: Iterable[Any]) -> list[dict[str, Any]]:
    """Куда система отправляет данные и в каком контуре работает — по коду.

    `required` — вызов модели или внешнего HTTP-сервиса: чек-лист рисков
    обязан на него сослаться (с любым результатом, включая «неизвестно»).
    """
    facts = list(facts)
    out: list[dict[str, Any]] = []

    def add(kind: str, label: str, detail: str, where: list[tuple[str, int]], required: bool) -> None:
        if len(out) >= MAX_EXPOSURES:
            return
        out.append({"id": f"exposure-{len(out) + 1}", "kind": kind, "label": label,
                    "detail": _mask(detail)[:200], "where": [f"{p}:{n}" for p, n in where[:3]],
                    "anchors": [[p, n] for p, n in where[:3]], "required": required})

    llm_by_file: dict[str, list[int]] = {}
    for fact in facts:
        if getattr(fact, "kind", "") == "LLM_CALL" and fact.path and not _is_vendor(fact.path):
            llm_by_file.setdefault(fact.path, []).append(int(fact.line or 0))
    for path, lines in sorted(llm_by_file.items()):
        add("llm_call", "Вызов языковой модели", f"{len(lines)} вызов(ов) в файле", [(path, n) for n in sorted(lines)], True)

    external: dict[str, list[Any]] = {}
    for fact in facts:
        if getattr(fact, "kind", "") == "EXTERNAL" and fact.path and not _is_vendor(fact.path):
            external.setdefault(str(fact.key), []).append(fact)
    for system, items in sorted(external.items()):
        mechanism = str(getattr(items[0], "mechanism", "") or "")
        add("external", f"Внешняя система: {system}", f"механизм {mechanism or 'не указан'}; мест: {len(items)}",
            [(f.path, int(f.line or 0)) for f in items], mechanism in _REQUIRED_EXTERNAL_MECHANISMS)

    files = list(getattr(tree, "files", []))
    env_rows = 0
    for path in files:
        if env_rows >= MAX_ENV_DEFAULTS or not path.endswith(".py") or _is_vendor(path) or "/tests/" in "/" + path:
            continue
        text = _read(tree, path)
        if "getenv" not in text and "environ.get" not in text:
            continue
        for match in _ENV_DEFAULT_RE.finditer(text):
            name, default = match.group(1), match.group(2).strip()
            if _ENV_SECRET.search(name) or not _ENV_INTERESTING.search(name):
                continue
            add("env_default", f"Настройка {name}", f"значение по умолчанию: {default}",
                [(path, _line_of(text, match.start()))], False)
            env_rows += 1
            if env_rows >= MAX_ENV_DEFAULTS:
                break

    warnings = 0
    for path in files:
        if warnings >= MAX_UI_WARNINGS or not is_frontend_file(path):
            continue
        text = _read(tree, path)
        for match in _UI_WARNING_RE.finditer(text):
            line = _line_of(text, match.start())
            snippet = text.splitlines()[line - 1].strip()
            add("ui_warning", "Предупреждение пользователю в интерфейсе", snippet, [(path, line)], False)
            warnings += 1
            break

    markers = 0
    for path in files:
        if markers >= MAX_DOC_MARKERS or not path.lower().endswith((".md", ".rst", ".txt")) or _is_vendor(path):
            continue
        text = _read(tree, path)
        match = _DOC_MARKER_RE.search(text)
        if match:
            line = _line_of(text, match.start())
            add("doc_marker", "Документация о контуре развёртывания", text.splitlines()[line - 1].strip(),
                [(path, line)], False)
            markers += 1

    required = [row for row in out if row["required"]]
    for row in required[MAX_REQUIRED_EXPOSURES:]:
        row["required"] = False
    return out


def exposure_digest(exposures: list[dict[str, Any]]) -> str:
    if not exposures:
        return ""
    lines = ["Факты экспозиции (детерминированно из кода и документации; основание — строка кода, "
             "а не вывод о риске). Факты с пометкой «обязательно» сошли на них в чек-листе рисков "
             "полем exposures у проверки input или dependencies хотя бы одного процесса — результат "
             "может быть finding, no_finding или unknown с объяснением; конфигурация развёртывания "
             "без фактов остаётся неизвестной:"]
    for row in exposures:
        mark = " · обязательно" if row["required"] else ""
        lines.append(f"- {row['id']}{mark}: {row['label']} — {row['detail']} ({', '.join(row['where'])})")
    return "\n".join(lines)


# --- расширение корпуса ------------------------------------------------------------

def neighbour_anchors(facts: Iterable[Any], known: set[str]) -> dict[str, set[int]]:
    """Соседи по графу вызовов на один шаг от уже известных файлов.

    Вызывающие: факт `CALLS` в другом файле, чей вызываемый объявлен в
    известном. Вызываемые: объявление в другом файле, которое вызывает
    известный. Имя, объявленное больше одного раза, пропускается: к какому
    файлу оно относится, по имени не понять.
    """
    facts = list(facts)
    declared: dict[str, list[tuple[str, int]]] = {}
    for fact in facts:
        if getattr(fact, "kind", "") in ("FUNCTION", "CLASS_DEF", "TOOL", "JAVA_METHOD") and fact.path:
            declared.setdefault(str(fact.key), []).append((fact.path, int(fact.line or 0)))
    unique = {name: spots[0] for name, spots in declared.items() if len(spots) == 1}
    out: dict[str, set[int]] = {}
    for fact in facts:
        if getattr(fact, "kind", "") != "CALLS" or not isinstance(fact.value, dict):
            continue
        callee = unique.get(str(fact.value.get("callee") or ""))
        if callee is None:
            continue
        caller_path, callee_path = fact.path, callee[0]
        if caller_path == callee_path:
            continue
        if callee_path in known and caller_path not in known and fact.line:
            out.setdefault(caller_path, set()).add(int(fact.line))
        if caller_path in known and callee_path not in known and callee[1]:
            out.setdefault(callee_path, set()).add(callee[1])
    return out
