"""Present calculation inputs and accepted evidence without assigning statuses."""
from pko.progress.risk_review import CHECKS
from pko.progress.schema import POC_WEIGHT


def explain_node(node, raw, children, criteria):
    lines = ["Статус рассчитан кодом из пунктов ОР, оснований полей и дочерних шагов.",
             "Итог: " + node.get("implementation_label", "Недостаточно данных") + "."]
    signals = node.get("assessment_inputs") or {}
    if signals:
        lines.append("Собственные сигналы: поля — " + signals.get("fields", "")
                     + "; пункты ОР — " + signals.get("criteria", "") + ".")
        if signals.get("field_note"):
            lines.append("Основание оценки полей: " + signals["field_note"])
    if node.get("planned"):
        lines.append("Агент отметил объект как планируемый; этот признак задаёт отсутствие реализации.")
    lines.append("Подтверждённое отсутствие основного эффекта имеет приоритет над широким пунктом ОР в локальной оценке. "
                 "Затем учитываются дочерние шаги. Смесь работающих и отсутствующих частей даёт частичную реализацию. "
                 "Неизвестное не понижает подтверждённую оценку. Связность и риски не меняют статус реализации.")
    if raw.get("explanation") or node.get("basis"):
        lines.append("Почему выделен узел: " + (raw.get("explanation") or node["basis"]))
    for bullet in node.get("bullets") or []:
        criterion = criteria.get(bullet["text"])
        lines.append("Пункт ОР: " + bullet["text"] + "\nОценка: " + bullet["status_label"]
                     + "\nПроверка: " + (bullet.get("actual") or "Объяснение не сохранено."))
        if criterion:
            for ev in criterion.verified_evidence:
                lines.append(f"Подтверждённая ссылка: {ev.path}:{ev.line} — {ev.basis}" + (f". {ev.note}" if ev.note else ""))
    if node.get("readiness") is not None:
        lines.append("Полнота по пунктам: " + str(node["readiness"]) + "% — результат calculate_progress: "
                     "среднее весов применимых пунктов (" + ", ".join(f"{key}={weight}" for key, weight in POC_WEIGHT.items()) + ").")
    for child in children:
        lines.append("Дочерний шаг: " + child["name"] + " — " + child.get("implementation_label", ""))
    for fid, cell in (raw.get("fields") or {}).items():
        if isinstance(cell, dict) and cell.get("source"):
            lines.append(f"Поле {fid}: {cell.get('value', '')}\nОбоснование: {cell['source']}")
    return "\n\n".join(lines)


def risk_review_data(passport):
    review = passport.get("risk_review") or {}
    labels = {"finding": "Найден риск", "no_finding": "Обоснованная находка не получена",
              "unknown": "Недостаточно данных", "not_applicable": "Неприменимо"}
    return {**review, "check_labels": CHECKS, "result_labels": labels}
