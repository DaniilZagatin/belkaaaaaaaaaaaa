"""Самодостаточный HTML-дашборд готовности в формате dox_manager.html.

Шаблон dashboard_template.html восстановлен из исходного код-ревьюера.
Готовность, решение и шкала приходят готовыми из dashboard_data/schema.
В отчёт входят только meta, readiness, readiness_prod, items, summary.
Связность и паспорт сохраняются отдельно в модели и HTML-паспорте.
Тексты вставляются через textContent, символ < в JSON экранируется.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

_DASHBOARD_TEMPLATE_PATH = Path(__file__).parent / "dashboard_template.html"

# Маркер в шаблоне, который заменяется на JSON-литерал с данными агента.
# Валидный JS-комментарий → файл остаётся открываемым как заглушка (нет данных
# → window.__DATA__ = ; был бы синтаксической ошибкой, поэтому заменяем весь
# маркер вместе с `/* */`).
_DATA_MARKER = "/*__DATA__*/"
# Ответы команды. При выпуске отчёта их ещё нет — пустой объект; заполняет их
# сама страница, когда файл открывают и сохраняют с правками.
_ANSWERS_MARKER = "/*__ANSWERS__*/"

# Отчёт готовности сохраняет состав эталонного dox_manager.html.
# Ревизия связности, сценарии и паспорт остаются в модели и отдельном
# паспорте. Новые поля общего результата не расширяют скачиваемый отчёт.
_REPORT_FIELDS = frozenset({"meta", "readiness", "readiness_prod", "items", "summary"})


def render_dashboard_html(result: dict[str, Any]) -> str:
    """Собрать самодостаточный HTML-дашборд из данных оценки.

    `result` — данные build_review_dashboard_data; дополнительные поля не включаются.
    """
    template = _DASHBOARD_TEMPLATE_PATH.read_text(encoding="utf-8")
    # Проекция не меняет общий результат: потребители модели используют его целиком.
    data_json = _to_safe_json({key: value for key, value in result.items() if key in _REPORT_FIELDS})
    page = template.replace(_DATA_MARKER, data_json, 1)
    # Ответы команды при выпуске пусты: их проставляют в самом файле, когда
    # отчёт открывают и сохраняют с правками.
    return page.replace(_ANSWERS_MARKER, "{}", 1)


def _to_safe_json(result: dict[str, Any]) -> str:
    """JSON-литерал, безопасный для встраивания в `<script>` HTML-страницы.

    `json.dumps` сам по себе не экранирует `<`/`>` — строка вроде `"</script>"`
    в данных агента досрочно закрыла бы тег `<script>` с данными. Замена `<` на
    `\\u003c` делает литерал безопасным: JS раскрывает последовательность
    обратно в `<`, а в HTML-потоке её нет. `>` экранировать не нужно — без `<>`
    тег не сформировать.
    """
    return json.dumps(result, ensure_ascii=False).replace("<", "\\u003c")
