"""Эталон v1: защищённый исходный код и три воспроизводимых проекта.

Ответы LLM фиксированы: тест проверяет гейты и расчёты, а не качество модели.
Интеграцию всех четырёх проходов проверяет test_cli_end_to_end.
"""

import importlib.util
import json
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from agent_script import tool_call
from fixture_support import scripted_responses
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.progress.local_source import build_target_repo_from_uploads
from pko.progress.pipeline import run_progress
from pko.render.dashboard_data import build_review_dashboard_data

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "tests/fixtures/reviewer_v1"
_spec = importlib.util.spec_from_file_location("reviewer_baseline_check", ROOT / "scripts/check_reviewer_baseline.py")
baseline = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(baseline)


def run_case(folder: Path, workspace: Path) -> dict:
    case = json.loads((folder / "case.json").read_text(encoding="utf-8"))
    source = (folder / "service.py").read_text(encoding="utf-8").encode("utf-8")
    target = build_target_repo_from_uploads([("service.py", source)], workspace)
    spec = ModelSpec(role="matcher", base_url="https://stub.local/v1", model="baseline-v1", api_key="x")
    responses = [tool_call(f"baseline_{i}", turn["name"], **turn["args"])
                 for i, turn in enumerate(case["turns"])]
    snapshots = []
    env = {"PKO_CRITIC": "true", "PKO_COHERENCE": "false", "PKO_PASSPORT": "false"}
    with mock.patch.dict(os.environ, env), mock.patch.object(ChatClient, "_create", scripted_responses(*responses)):
        model = run_progress((folder / "initiative.md").read_text(encoding="utf-8"),
                             folder.name, target, spec, client=ChatClient(spec=spec, use_cache=False),
                             on_review_ready=snapshots.append)
    if len(snapshots) != 1:
        raise AssertionError("Результат ревью должен выдаваться один раз")
    review = snapshots[0]
    if review.integrity is not None or review.passport_data is not None:
        raise AssertionError("Эталон ревью не должен содержать результаты расширений")
    actual = {
        "statuses": [criterion.status for verdict in review.verdicts for criterion in verdict.criteria],
        "readiness": review.readiness,
        "readiness_prod": review.readiness_prod,
        "decision": review.summary.decision,
    }
    if actual != case["expected"]:
        raise AssertionError(f"{folder.name}: {actual} != {case['expected']}; {model.gaps}")
    report = build_review_dashboard_data(review)
    # Только время и технический идентификатор временного источника переменны.
    report["meta"]["generated_at"] = "2026-09-28 00:00"
    report["meta"]["commit"] = "baseline-fixture"
    return report


class ReviewerBaselineTest(unittest.TestCase):
    def test_protected_reviewer_matches_v1(self):
        self.assertEqual(baseline.check(ROOT), [])

    def test_guard_allows_passport_changes_but_detects_review_changes(self):
        manifest = json.loads((ROOT / baseline.BASELINE / "manifest.json").read_text(encoding="utf-8"))
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            shutil.copytree(ROOT / baseline.BASELINE, root / baseline.BASELINE)
            for name in set(manifest["files"]) | set(manifest["symbols"]):
                dest = root / name
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(ROOT / name, dest)
            schema = root / "backend/pko/progress/schema.py"
            source = schema.read_text(encoding="utf-8")
            schema.write_text(source.replace('NODE_IMPLEMENTATION_LABEL = {',
                                            'NODE_IMPLEMENTATION_LABEL = {"extra": "Паспорт",'), encoding="utf-8")
            self.assertEqual(baseline.check(root), [])
            schema.write_text(source.replace("READY_THRESHOLD = 40", "READY_THRESHOLD = 41"), encoding="utf-8")
            self.assertTrue(any("READY_THRESHOLD" in error for error in baseline.check(root)))

    def test_control_projects_match_review_and_dashboard_v1(self):
        cases = sorted(FIXTURES.glob("*/case.json"))
        self.assertEqual(len(cases), 3)
        for case in cases:
            with self.subTest(project=case.parent.name), tempfile.TemporaryDirectory() as raw:
                actual = run_case(case.parent, Path(raw))
                expected = json.loads((case.parent / "expected_dashboard.json").read_text(encoding="utf-8"))
                self.assertEqual(actual, expected)


if __name__ == "__main__":
    unittest.main()
