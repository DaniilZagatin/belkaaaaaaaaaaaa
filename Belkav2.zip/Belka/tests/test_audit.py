import io
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from pko.audit import AuditedClient, audit_run, sanitize
from pko.llm.client import ChatResult
from pko.llm.tracing import trace_span
from pko.progress.passport_agent import _PassportSession, _handle_submit_risks
from pko.render.passport_map import build_passport_map
import test_passport_gate as fixtures
from pko.progress.passport_gate import normalize_passport

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from export_phoenix_trace import fetch_trace


class AuditTest(unittest.TestCase):
    def test_masks_secrets_and_private_reasoning_in_nested_json(self):
        value = {"api_key": "secret-value", "reasoning_content": "private-one",
                 "output.value": json.dumps({"reasoning": "private-two", "text": "public"}),
                 "content": "<think>private-three</think>answer password=hunter2 Bearer abc.def",
                 "blocks": [{"type": "thinking", "text": "private-four"}]}
        with patch.dict("os.environ", {"PKO_MATCHER_API_KEY": "environment-secret"}):
            value["error"] = "failure environment-secret"
            rendered = json.dumps(sanitize(value))
        for secret in ("secret-value", "private-one", "private-two", "private-three", "private-four", "hunter2", "abc.def", "environment-secret"):
            self.assertNotIn(secret, rendered)
        self.assertIn("public", rendered)

    def test_last_tool_result_survives_session_exit_without_phoenix(self):
        answer = ChatResult(text="public", usage={}, tool_calls=[], reasoning_content="private")
        delegate = SimpleNamespace(spec=SimpleNamespace(model="stub"), chat=lambda *a, **k: answer)
        messages = [{"role": "system", "content": "task"}]
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "audit.txt"
            with audit_run(path, "test"):
                client = AuditedClient(delegate)
                with trace_span("passport_session") as span:
                    self.assertIs(client.chat(messages), answer)
                    messages.append({"role": "tool", "tool_call_id": "last", "content": "finish rejected: missing evidence"})
                    span.add_event("risks_rejected", count=1)
                content = path.read_text(encoding="utf-8")
                self.assertIn("finish rejected: missing evidence", content)
                self.assertIn("risks_rejected", content)
            self.assertNotIn('"reasoning_content"', path.read_text(encoding="utf-8"))
            self.assertEqual(messages[0]["content"], "task")

    def test_interruption_and_unwritable_journal_do_not_lose_control(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "audit.txt"
            with self.assertRaises(KeyboardInterrupt), audit_run(path, "test"):
                raise KeyboardInterrupt()
            self.assertIn('"result": "interrupted"', path.read_text(encoding="utf-8"))
            with patch("sys.stderr", io.StringIO()), audit_run(Path(tmp), "unwritable") as audit:
                self.assertTrue(audit.failed)

    def test_risk_analysis_required_even_for_empty_risks(self):
        state = _PassportSession(tree_done=True)
        self.assertIn("analysis", _handle_submit_risks(state, {"risks": [], "review": []}))
        self.assertFalse(state.risk_reviewed)
        summary = "Проверены доступные материалы и границы анализа. Процессов нет; гипотезы не обоснованы. Для содержательной проверки нужны шаги сценария и сведения о контролях."
        self.assertIn("принят", _handle_submit_risks(state, {"risks": [], "review": [], "analysis": summary}))
        self.assertEqual(state.risk_analysis, summary)

    def test_explanations_do_not_change_statuses_or_decision(self):
        model = fixtures.PassportMapTest()._model(normalize_passport(fixtures._valid()))
        before = build_passport_map(model)
        model.passport_data["nodes"]["bbb-1"]["explanation"] = "Обоснование границ объекта: при отказе внешней системы требуется дополнительная проверка."
        model.passport_data["risk_review"] = {"complete": True, "summary": "Проверены риски", "processes": []}
        after = build_passport_map(model)
        self.assertEqual([(n["id"], n["implementation_status"]) for n in before["nodes"]],
                         [(n["id"], n["implementation_status"]) for n in after["nodes"]])
        self.assertEqual(before["summary"], after["summary"])
        self.assertEqual(after["risk_review"]["summary"], "Проверены риски")
        node = next(n for n in after["nodes"] if n["id"] == "bbb-1")
        self.assertIn("Обоснование границ", node["explanation"])


class PhoenixExportTest(unittest.TestCase):
    def test_all_pages_and_trace_filter(self):
        tid = "a" * 32
        calls = []
        def opener(request, timeout):
            calls.append(request.full_url)
            span = {"context": {"trace_id": tid, "span_id": str(len(calls))}, "start_time": str(len(calls))}
            return io.StringIO(json.dumps({"data": [span], "next_cursor": "next" if len(calls) == 1 else None}))
        spans = fetch_trace("http://localhost:6006", "a project", tid, opener=opener)
        self.assertEqual(len(spans), 2)
        self.assertIn("a%20project", calls[0])
        self.assertIn("trace_id=" + tid, calls[1])
        self.assertIn("cursor=next", calls[1])

    def test_rejects_ignored_filter_and_repeated_cursor(self):
        tid = "a" * 32
        def wrong(*args, **kwargs):
            return io.StringIO(json.dumps({"data": [{"context": {"trace_id": "b" * 32, "span_id": "1"}}]}))
        with self.assertRaisesRegex(ValueError, "фильтр"):
            fetch_trace("http://localhost:6006", "p", tid, opener=wrong)
        def repeated(*args, **kwargs):
            return io.StringIO(json.dumps({"data": [], "next_cursor": "same"}))
        with self.assertRaisesRegex(ValueError, "курсор"):
            fetch_trace("http://localhost:6006", "p", tid, opener=repeated)
