"""Детерминированные факты паспорта: вызовы маршрутов из фронтенда, обратное
сопоставление «код → паспорт», факты экспозиции и спор со статусом оценки."""
import unittest

from pko.extractors.python_code import extract
from pko.progress import passport_facts
from pko.progress.passport_agent import (
    _Node, _PassportSession, _build_passport_data, _handle_bind_capability,
    _handle_dismiss_capability, _handle_finish, _handle_status_dispute,
)
from pko.progress.passport_evidence import build_corpus, check_node_audit, entry_note
from pko.progress.risk_review import CHECKS, validate_review
from pko.progress.schema import POC_WEIGHT, capability_coverage
from test_passport_evidence import MemoryTree

API = (
    "from fastapi import APIRouter\n"                       # 1
    "router = APIRouter()\n"                                 # 2
    "\n"                                                     # 3
    "@router.post('/api/identify-product')\n"                # 4
    "def identify_product(req):\n"                           # 5
    "    return lookup(req)\n"                               # 6
    "\n"                                                     # 7
    "@router.get('/api/documents/{doc_id}')\n"               # 8
    "def read_document(doc_id):\n"                           # 9
    "    return load(doc_id)\n"                              # 10
    "\n"                                                     # 11
    "@router.post('/api/documents')\n"                       # 12
    "def create_document(req):\n"                            # 13
    "    return save(req)\n"                                 # 14
)
FRONT = (
    "export async function openDocument(id) {\n"             # 1
    "  const url = `/api/documents/${id}`;\n"                # 2
    "  return fetch(url);\n"                                 # 3
    "}\n"                                                    # 4
    "export const create = (body) => fetch('/api/documents', {method: 'POST', body});\n"  # 5
)


def repo(files):
    tree = MemoryTree(files)
    facts, _, _ = extract(tree)
    return tree, facts


def full_audit(evidence, entry=None, reach="connected"):
    execution = {"reachability": reach, "entrypoint": "Вход клиента", "conditions": "Запрос клиента",
                 "outcome": "Ответ сервиса", "limits": "Только этот обработчик", "evidence": evidence}
    if entry is not None:
        execution["entry_evidence"] = entry
    return {"execution": execution, "fields": {}}


class RouteUsageTests(unittest.TestCase):
    def test_called_and_uncalled_routes_are_distinguished(self):
        tree, facts = repo({"app/api.py": API, "web/src/api.js": FRONT,
                            "web/node_modules/lib/index.js": "fetch('/api/identify-product')",
                            "web/src/api.test.js": "fetch('/api/identify-product')"})
        usage = passport_facts.route_usage(tree, facts)
        by_key = {r.key: r for r in usage.routes}
        self.assertTrue(usage.frontend_present)
        self.assertFalse(by_key["POST /api/identify-product"].called)
        self.assertEqual(by_key["GET /api/documents/{doc_id}"].calls[0]["line"], 2)
        self.assertTrue(by_key["POST /api/documents"].called)
        self.assertEqual(by_key["POST /api/identify-product"].handler, "identify_product")
        self.assertIn("во фронтенде не найден", usage.digest())

    def test_router_prefix_and_client_base_url_are_matched(self):
        api = ("from fastapi import APIRouter\nrouter = APIRouter(prefix='/api/v1')\n"
               "@router.get('/tasks')\ndef tasks():\n    return []\n"
               "@router.get('/items')\ndef items():\n    return []\n")
        front = "const api = axios.create({baseURL: '/api'});\napi.get('/documents');\nfetch('/api/v1/tasks');\n"
        docs = ("from fastapi import APIRouter\nrouter = APIRouter()\n@router.get('/api/documents')\n"
                "def docs():\n    return []\n@router.get('/api/other')\ndef other():\n    return []\n")
        tree, facts = repo({"app/tasks.py": api, "app/docs.py": docs, "web/app.ts": front})
        usage = passport_facts.route_usage(tree, facts)
        by_key = {r.key: r for r in usage.routes}
        self.assertTrue(by_key["GET /tasks"].called)
        self.assertTrue(by_key["GET /api/documents"].called)
        self.assertFalse(by_key["GET /items"].called)

    def test_without_frontend_nothing_is_claimed_about_client_calls(self):
        tree, facts = repo({"app/api.py": API})
        usage = passport_facts.route_usage(tree, facts)
        self.assertFalse(usage.frontend_present)
        self.assertIn("не проверялся", usage.digest())


class EntryGateTests(unittest.TestCase):
    def setUp(self):
        self.tree, self.facts = repo({"app/api.py": API, "web/src/api.js": FRONT})
        self.corpus = build_corpus(self.tree, {"app/api.py"}, [], "Образ результата",
                                   extra={"web/src/api.js": ("ui_call", {2})})
        self.corpus.route_usage = passport_facts.route_usage(self.tree, self.facts)
        self.corpus.read(["evidence-2", "evidence-3"])
        self.effect = [{"id": "evidence-2", "quote": "6:     return lookup(req)"}]

    def test_uncalled_route_declaration_does_not_prove_connected(self):
        entry = [{"id": "evidence-2", "quote": "4: @router.post('/api/identify-product')"}]
        errors = check_node_audit(self.corpus, full_audit(self.effect, entry), {})
        self.assertTrue(any("endpoint_only" in e for e in errors), errors)
        audit = full_audit(self.effect, reach="endpoint_only")
        self.assertEqual(check_node_audit(self.corpus, audit, {}), [])
        self.assertIn("вызов из интерфейса не подтверждён", entry_note(self.corpus, audit))

    def test_frontend_call_site_proves_entry(self):
        effect = [{"id": "evidence-2", "quote": "10:     return load(doc_id)"}]
        entry = [{"id": "evidence-3", "quote": "const url = `/api/documents/${id}`"}]
        self.assertEqual(check_node_audit(self.corpus, full_audit(effect, entry), {}), [])
        declared = [{"id": "evidence-2", "quote": "8: @router.get('/api/documents/{doc_id}')"}]
        self.assertEqual(check_node_audit(self.corpus, full_audit(effect, declared), {}), [])

    def test_route_is_a_legal_entry_when_frontend_is_absent(self):
        tree, facts = repo({"app/api.py": API})
        corpus = build_corpus(tree, {"app/api.py"}, [], "ОР")
        corpus.route_usage = passport_facts.route_usage(tree, facts)
        corpus.read(["evidence-2"])
        audit = full_audit(self.effect, [{"id": "evidence-2", "quote": "4: @router.post('/api/identify-product')"}])
        self.assertEqual(check_node_audit(corpus, audit, {}), [])
        self.assertIn("фронтенда нет", entry_note(corpus, audit))


class CorpusExpansionTests(unittest.TestCase):
    def test_extra_files_are_windows_with_reasons_and_summaries_follow_code(self):
        big = "\n".join(f"x{i} = {i}" for i in range(1, 900)) + "\n"
        tree = MemoryTree({"main.py": "run()\n", "web/big.js": big})
        plain = build_corpus(tree, {"main.py"}, [], "ОР")
        corpus = build_corpus(tree, {"main.py"}, [], "ОР", extra={"web/big.js": ("ui_call", {450})},
                              summaries=[("Факты экспозиции", "- exposure-1: вызов модели")])
        self.assertEqual(plain.records["evidence-2"], corpus.records["evidence-2"])
        labels = [r["label"] for r in corpus.records.values()]
        self.assertIn("web/big.js:401", labels)
        self.assertNotIn("web/big.js:1", labels)
        self.assertEqual(labels[-1], "Факты экспозиции")
        self.assertEqual(corpus.included, {"main.py": "evaluation", "web/big.js": "ui_call"})
        manifest = corpus.manifest()
        self.assertIn("место вызова маршрута во фронтенде", {r["reason_label"] for r in manifest["included"]})

    def test_neighbours_follow_calls_in_both_directions(self):
        tree, facts = repo({
            "app/service.py": "def handle():\n    return compute()\n",
            "app/calc.py": "def compute():\n    return 1\n",
            "app/entry.py": "from app.service import handle\ndef main():\n    handle()\n",
        })
        anchors = passport_facts.neighbour_anchors(facts, {"app/service.py"})
        self.assertEqual(anchors, {"app/calc.py": {1}, "app/entry.py": {3}})


class CapabilityTests(unittest.TestCase):
    def setUp(self):
        self.tree, self.facts = repo({"app/api.py": API, "web/src/api.js": FRONT})
        self.caps, self.total = passport_facts.capabilities(self.tree, self.facts)
        self.corpus = build_corpus(self.tree, {"app/api.py"}, [], "ОР")
        self.corpus.route_usage = passport_facts.route_usage(self.tree, self.facts)
        self.corpus.read(["evidence-2"])

    def session(self):
        state = _PassportSession(evidence_corpus=self.corpus, tree_done=True, risk_reviewed=True,
                                 capabilities=self.caps, capabilities_total=self.total)
        state.nodes["operation-1"] = _Node(id="operation-1", name="Открытие документа", basis="Показ документа",
                                           filled=True, data={"fields": {}, "fact_check": full_audit(
                                               [{"id": "evidence-2", "quote": "10:     return load(doc_id)"}])})
        return state

    def test_capabilities_are_listed_with_declaration_spans(self):
        self.assertEqual([c.label for c in self.caps],
                         ["POST /api/identify-product", "GET /api/documents/{doc_id}", "POST /api/documents"])
        self.assertEqual(self.caps[1].span, (8, 10))

    def test_citation_inside_declaration_maps_but_file_mention_does_not(self):
        mapped = passport_facts.auto_mapped(self.caps, {
            "operation-1": {"fact_check": full_audit([{"id": "evidence-2", "quote": "10:     return load(doc_id)"}])},
            "operation-2": {"fields": {"4.5.4": {"value": "Файл маршрутов", "source": "Установлено: app/api.py"}}},
            "operation-3": {"fields": {"4.5.4": {"value": "Создание", "source": "Установлено: create_document сохраняет"}}},
        }, self.corpus.records)
        self.assertEqual(mapped, {self.caps[1].id: ["operation-1"], self.caps[2].id: ["operation-3"]})
        # Путь маршрута засчитывается целиком, а не префиксом другого маршрута.
        prefix = passport_facts.auto_mapped(self.caps, {"operation-4": {"fields": {"4.5.4": {
            "value": "Чтение", "source": "Выведено: маршрут /api/documents/{doc_id} отдаёт документ"}}}}, {})
        self.assertEqual(prefix, {self.caps[1].id: ["operation-4"]})

    def test_finish_requires_decision_on_every_capability_once(self):
        state = self.session()
        reply = _handle_finish(state, {})
        self.assertIn("возможности системы не рассмотрены", reply)
        self.assertIn(self.caps[0].id, reply)
        self.assertIn("bbb", _handle_bind_capability(state, {"capability": self.caps[2].id, "nodes": ["journey-1"]}))
        self.assertIn("привязана", _handle_bind_capability(state, {"capability": self.caps[2].id, "nodes": ["operation-1"]}))
        self.assertIn("отклонён", _handle_dismiss_capability(state, {"capability": self.caps[0].id, "reason": "old",
                                                                        "basis": "Функция идентификации не используется"}))
        self.assertIn("отклонён", _handle_dismiss_capability(state, {"capability": self.caps[1].id, "reason": "legacy",
                                                                        "basis": "Маршрут устарел и не вызывается интерфейсом"}))
        self.assertIn("отмечена", _handle_dismiss_capability(state, {"capability": self.caps[0].id, "reason": "legacy",
                                                                        "basis": "Интерфейс не вызывает идентификацию продукта"}))
        self.assertEqual(_handle_finish(state, {}), "паспорт завершён")
        coverage = _build_passport_data(state, "scope", "2026-09-30")["capability_coverage"]
        self.assertEqual((coverage["mapped_count"], coverage["dismissed_count"], coverage["unreviewed_count"]), (2, 1, 0))
        self.assertEqual({r["by"] for r in coverage["mapped"]}, {"code", "agent"})

    def test_second_finish_accepts_and_keeps_remainder_in_remarks(self):
        state = self.session()
        self.assertIn("отклонён", _handle_finish(state, {}))
        self.assertEqual(_handle_finish(state, {}), "паспорт завершён")
        self.assertTrue(any("возможности системы без узла" in r for r in state.remarks))

    def test_dismissing_a_described_capability_is_rejected(self):
        state = self.session()
        reply = _handle_dismiss_capability(state, {"capability": self.caps[1].id, "reason": "out_of_scope",
                                                   "basis": "Просмотр документа не относится к пути"})
        self.assertIn("уже описана узлами", reply)

    def test_coverage_counts_unlisted_capabilities_as_unreviewed(self):
        self.assertEqual(capability_coverage(50, 40, 30, 5),
                         {"total": 50, "listed": 40, "mapped_count": 30, "dismissed_count": 5,
                          "unreviewed_count": 15, "omitted_count": 10, "reviewed_percent": 70, "mapped_percent": 60})
        self.assertIsNone(capability_coverage(0, 0, 0, 0)["reviewed_percent"])


class ExposureTests(unittest.TestCase):
    def test_model_calls_env_defaults_and_ui_warnings_are_collected(self):
        tree, facts = repo({
            "app/llm.py": ("import os\nimport openai\nclient = openai.OpenAI()\n"
                           "ENV = os.getenv('DEPLOYMENT_ENV', 'external')\n"
                           "KEY = os.getenv('LLM_API_KEY', 'secret-value')\n"
                           "def ask(text):\n    return client.chat.completions.create(model='m', messages=[text])\n"),
            "web/Upload.tsx": "export const Note = () => <p>Не загружайте конфиденциальные данные</p>;\n",
            "docs/run.md": "Сервис работает во внешнем контуре.\n",
        })
        rows = passport_facts.exposure_facts(tree, facts)
        kinds = {r["kind"] for r in rows}
        self.assertEqual(kinds, {"llm_call", "external", "env_default", "ui_warning", "doc_marker"})
        self.assertTrue(all(r["required"] for r in rows if r["kind"] == "llm_call"))
        self.assertFalse(any("LLM_API_KEY" in r["label"] for r in rows))
        env = next(r for r in rows if r["kind"] == "env_default")
        self.assertIn("external", env["detail"])
        self.assertIn("обязательно", passport_facts.exposure_digest(rows))

    def review(self, exposures=None, check="dependencies"):
        rows = [{"node": "process-1", "checks": [
            {"check": key, "result": "unknown", "note": "Сведений о поведении провайдера в материалах нет",
             "evidence": [], "risk_titles": []} for key in CHECKS]}]
        if exposures is not None:
            next(c for c in rows[0]["checks"] if c["check"] == check)["exposures"] = exposures
        return rows

    def test_required_exposure_needs_input_or_dependencies_reference(self):
        facts = {"exposure-1": True, "exposure-2": False}
        self.assertTrue(any("exposure-1" in e for e in validate_review(self.review(), {"process-1"}, [], exposures=facts)))
        self.assertEqual(validate_review(self.review(["exposure-1"]), {"process-1"}, [], exposures=facts), [])
        self.assertTrue(validate_review(self.review(["exposure-1"], check="execution"), {"process-1"}, [], exposures=facts))
        self.assertTrue(validate_review(self.review(["exposure-9"]), {"process-1"}, [], exposures=facts))
        self.assertEqual(validate_review(self.review(), {"process-1"}, []), [])


class StatusDisputeTests(unittest.TestCase):
    BULLET = "Каждая инициатива показывает, какую боль она закрывает"

    def setUp(self):
        tree = MemoryTree({"app/cards.py": "def card(option):\n    return {'benefit': option.benefit}\n"})
        self.corpus = build_corpus(tree, {"app/cards.py"}, [], "ОР")
        self.corpus.read(["evidence-2"])
        self.state = _PassportSession(evidence_corpus=self.corpus, tree_done=True,
                                      plan_bullets=[self.BULLET], bullet_status={self.BULLET: "done"})
        self.state.nodes["journey-1"] = _Node(id="journey-1", name="Выбор инициативы", basis="путь",
                                              filled=True, children=["process-1"])
        self.state.nodes["process-1"] = _Node(id="process-1", name="Подбор инициатив", basis="процесс",
                                              parents=["journey-1"], filled=True, children=["bbb-1"])
        self.state.nodes["bbb-1"] = _Node(id="bbb-1", name="Карточка инициативы", basis="Показ инициатив",
                                          parents=["process-1"], filled=True, data={"bullets": [self.BULLET]})
        self.args = {"bullet": self.BULLET, "suggested_status": "limited",
                     "limitation": "Карточка показывает пользу и механизм, но не называет закрываемую боль клиента.",
                     "evidence": [{"id": "evidence-2", "quote": "return {'benefit': option.benefit}"}]}

    def test_accepted_dispute_only_lowers_and_keeps_status(self):
        self.assertIn("спор принят", _handle_status_dispute(self.state, dict(self.args)))
        self.assertEqual(self.state.bullet_status[self.BULLET], "done")
        dispute = self.state.status_disputes[0]
        self.assertEqual((dispute["status"], dispute["suggested_status"], dispute["nodes"]), ("done", "limited", ["bbb-1"]))
        self.assertLess(POC_WEIGHT[dispute["suggested_status"]], POC_WEIGHT[dispute["status"]])
        self.assertIn("по этому пункту спор уже принят", _handle_status_dispute(self.state, dict(self.args)))
        data = _build_passport_data(self.state, "scope", "2026-09-30")
        self.assertEqual(data["status_disputes"][0]["nodes"], ["bbb-1"])

    def test_upgrade_code_in_text_and_invented_quote_are_rejected(self):
        for change in ({"suggested_status": "done"}, {"limitation": "Функция card_view() не показывает боль клиента в карточке."},
                       {"evidence": [{"id": "evidence-2", "quote": "return {'pain': option.pain}"}]},
                       {"bullet": "Пункта с таким текстом в образе результата нет вовсе"}):
            with self.subTest(change=change):
                self.assertIn("отклонён", _handle_status_dispute(self.state, {**self.args, **change}))
        self.assertEqual(self.state.status_disputes, [])

    def test_dispute_requires_literal_corpus(self):
        self.state.evidence_corpus = None
        self.assertIn("недоступен", _handle_status_dispute(self.state, dict(self.args)))


if __name__ == "__main__":
    unittest.main()
