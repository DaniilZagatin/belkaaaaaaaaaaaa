"""Coverage cannot be declared complete by omitting a difficult review unit."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from contextlib import redirect_stdout, redirect_stderr
from io import StringIO

SPEC = importlib.util.spec_from_file_location(
    "passport_validation", Path(__file__).resolve().parents[1] / "scripts/passport_validation.py"
)
validation = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(validation)


def fixture():
    schema = {
        "nodes": [
            {"id": "journey-1", "type": "journey", "name": "Путь"},
            {"id": "process-1", "type": "process", "name": "Процесс", "parents": ["journey-1"]},
        ],
        "meta": {"guardrails": [{"id": "guardrail-1", "name": "Контроль", "invariant": "Сумма положительна", "targets": ["process-1"]}]},
        "risks": [{"id": "risk-1", "primary_node": "process-1", "linked_nodes": ["process-1"]}],
        "relations": [],
    }
    html = '<section class="node" id="journey-1"><div data-field="4.2.1"><h4>Смысл</h4><p data-fill="value">Принимает заявку. Сохраняет результат.</p><span data-fill="source">Установлено: app.py:20.</span></div></section>'
    html += '<section class="node" id="process-1"></section>'
    html += '<script>var SCHEMA=' + json.dumps(schema, ensure_ascii=False) + '; window.untrusted();</script>'
    return validation.inventory(html, "passport-hash")


def annotation():
    return {"result": "верно", "note": "Проверено по указанному месту.", "evidence": ["app.py:20 — маршрут заявки"]}


def completed(inv):
    report = validation.review_template(inv)
    report["reviewer"] = "synthetic test reviewer"
    report["global_checks"] = {key: annotation() for key in validation.GLOBAL_CHECKS}
    for unit in report["units"]:
        unit["checks"] = {key: annotation() for key in unit["checks"]}
    for node, expected in zip(report["nodes"], inv["nodes"]):
        node["checks"] = {key: annotation() for key in validation.CHECKS}
        for field, original in zip(node["fields"], expected["fields"]):
            field.update(annotation())
            field["claims"] = [{"part": part, "quote": original[part], **annotation()}
                               for part in ("value", "source") if original[part]]
        for item in node["attachments"]:
            item.update(annotation())
    return report


class PassportValidationTest(unittest.TestCase):
    def setUp(self):
        self.inv = fixture()
        self.report = completed(self.inv)

    def test_inventory_includes_map_objects_and_incident_links(self):
        self.assertEqual([n["id"] for n in self.inv["nodes"]], ["journey-1", "process-1", "guardrail-1"])
        self.assertEqual(len(self.inv["nodes"][1]["attachments"]), 3)

    def test_unsupported_html_does_not_become_empty_success(self):
        with self.assertRaises(ValueError):
            validation.inventory("<html>Неизвестный формат</html>", "h")

    def test_blank_template_is_not_complete(self):
        result = validation.check_review(self.inv, validation.review_template(self.inv))
        self.assertFalse(result["complete"])
        self.assertTrue(all(r["state"] == "Не завершён" for r in result["rows"]))

    def test_complete_annotation_is_accepted_without_claiming_semantic_truth(self):
        result = validation.check_review(self.inv, self.report)
        self.assertTrue(result["complete"], result["errors"])

    def test_omitted_node_cannot_disappear_from_summary(self):
        self.report["nodes"].pop()
        result = validation.check_review(self.inv, self.report)
        self.assertFalse(result["complete"])
        self.assertEqual(len(result["rows"]), 3)
        self.assertEqual(result["rows"][-1]["state"], "Не завершён")

    def test_field_and_incident_link_are_each_required(self):
        for key in ("fields", "attachments"):
            with self.subTest(key=key):
                report = deepcopy(self.report)
                report["nodes"][0][key].pop()
                self.assertFalse(validation.check_review(self.inv, report)["complete"])

    def test_skipped_sentence_and_source_are_detected(self):
        self.report["nodes"][0]["fields"][0]["claims"] = [{"part": "value", "quote": "Принимает заявку.", **annotation()}]
        result = validation.check_review(self.inv, self.report)
        self.assertTrue(any("/value: остался текст" in e for e in result["errors"]))
        self.assertTrue(any("/source: остался текст" in e for e in result["errors"]))

    def test_unknown_is_visible_and_prevents_full_completion(self):
        self.report["nodes"][0]["checks"]["reverse_search"]["result"] = "неясно"
        result = validation.check_review(self.inv, self.report)
        self.assertFalse(result["complete"])
        self.assertFalse(result["errors"])
        self.assertEqual(result["rows"][0]["state"], "Остались вопросы")

    def test_confirmed_error_does_not_mean_unreviewed(self):
        self.report["nodes"][0]["checks"]["implementation"]["result"] = "ошибка"
        result = validation.check_review(self.inv, self.report)
        self.assertTrue(result["complete"])
        self.assertTrue(result["rows"][0]["issues"])

    def test_passport_hash_mismatch_rejected(self):
        self.report["passport_sha256"] = "another-passport"
        self.assertFalse(validation.check_review(self.inv, self.report)["complete"])

    def test_positive_field_cannot_hide_negative_claim(self):
        self.report["nodes"][0]["fields"][0]["claims"][0]["result"] = "ошибка"
        self.assertFalse(validation.check_review(self.inv, self.report)["complete"])

    def test_duplicates_and_invented_review_nodes_rejected(self):
        for nid in ("journey-1", "invented"):
            with self.subTest(nid=nid):
                report = deepcopy(self.report)
                node = deepcopy(report["nodes"][0])
                node["id"] = nid
                report["nodes"].append(node)
                self.assertFalse(validation.check_review(self.inv, report)["complete"])

    def test_not_applicable_cannot_hide_existing_text(self):
        self.report["nodes"][0]["fields"][0]["result"] = "не применимо"
        self.assertFalse(validation.check_review(self.inv, self.report)["complete"])

    def test_full_node_review_cannot_hide_omitted_global_risk(self):
        self.report["units"] = [u for u in self.report["units"] if u["id"] != "/risks/1"]
        result = validation.check_review(self.inv, self.report)
        self.assertFalse(result["complete"])
        self.assertTrue(all(r["state"] == "Проверен полностью" for r in result["rows"]))

    def test_each_risk_criterion_and_process_search_area_is_required(self):
        for uid, key in (("/risks/1", "D4.3"), ("/nodes/process-1/risk_search", "recovery")):
            report = deepcopy(self.report)
            next(u for u in report["units"] if u["id"] == uid)["checks"].pop(key)
            self.assertFalse(validation.check_review(self.inv, report)["complete"])

    def test_unresolved_global_search_prevents_completion(self):
        self.report["global_checks"]["reverse_coverage"]["result"] = "неясно"
        result = validation.check_review(self.inv, self.report)
        self.assertFalse(result["complete"])
        self.assertFalse(result["errors"])

    def test_orphan_and_unknown_schema_content_remains_in_scope(self):
        schema = {"nodes": [{"id": "journey-1", "type": "journey", "name": "Путь", "new_property": "важный факт"}],
                  "risks": [{"id": "orphan", "linked_nodes": ["absent"]}],
                  "future_section": [{"value": "не пропускать"}], "handoffs": [{"from": "absent"}]}
        inv = validation.inventory('<script>var SCHEMA=' + json.dumps(schema) + ';</script>', "h")
        units = {u["id"]: u for u in inv["units"]}
        self.assertIn("/risks/1", units)
        self.assertIn("/handoffs/1", units)
        self.assertEqual(units["/future_section/1"]["content"]["value"], "не пропускать")
        self.assertEqual(units["/nodes/journey-1/metadata"]["content"]["new_property"], "важный факт")

    def test_existing_link_cannot_be_dismissed_as_not_applicable(self):
        self.report["nodes"][0]["attachments"][0]["result"] = "не применимо"
        self.assertFalse(validation.check_review(self.inv, self.report)["complete"])

    def test_claims_cannot_hide_text_with_not_applicable(self):
        for claim in self.report["nodes"][0]["fields"][0]["claims"]:
            claim["result"] = "не применимо"
        self.assertFalse(validation.check_review(self.inv, self.report)["complete"])

    def test_cli_prepares_without_manual_input_and_rejects_unfilled_review(self):
        with tempfile.TemporaryDirectory() as directory, redirect_stdout(StringIO()), redirect_stderr(StringIO()):
            root = Path(directory)
            passport = root / "passport.html"
            schema = {"nodes": [{"id": "journey-1", "type": "journey", "name": "Путь"}]}
            passport.write_text('<script>var SCHEMA=' + json.dumps(schema) + ';</script>', encoding="utf-8")
            args = ["prepare", "--passport", str(passport), "--out", str(root / "input")]
            self.assertEqual(validation.main(args), 0)
            self.assertTrue((root / "input/inventory.json").is_file())
            self.assertEqual(validation.main(args), 1)  # Existing work is preserved.
            result = validation.main(["check", "--passport", str(passport),
                                      "--review", str(root / "input/node-review-template.json"),
                                      "--out", str(root / "checked.md")])
            self.assertEqual(result, 2)
            self.assertIn("Не завершён", (root / "checked.md").read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
