"""Regression checks for provenance; these do not simulate semantic LLM accuracy."""
import json
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from pko.progress.passport_evidence import (
    EvidenceCorpus, build_corpus, check_node_audit, check_relation_proof,
    check_control_review, NODE_FIELDS, GENERATED_FIELDS,
)
from pko.progress.passport_agent import (
    _PassportSession, _Node, _handle_submit_node, _handle_link_nodes,
    _compact_history, run_passport_agent,
)
from pko.progress.passport_gate import normalize_passport
from pko.progress.pipeline import _run_passport
from pko.render.passport_map import passport_map_nodes, passport_map_relations


class MemoryTree:
    def __init__(self, files):
        self.files = sorted(files)
        self.content = files
        self.reads = []

    def read(self, path):
        self.reads.append(path)
        return self.content[path]


def corpus_fixture():
    corpus = EvidenceCorpus()
    corpus.add("code", "reports.py:1", "1: next_report.save()\n2: transport.send(report)\n3: retry_transport()")
    corpus.add("intent", "Образ результата", "Отчёт отправляется, затем сохраняется дата следующей отправки.")
    corpus.add("summary", "След оценки", "Все отчёты доставляются ровно один раз без потерь и повторов.")
    corpus.read(list(corpus.records)[:2])
    return corpus


def audit_fixture(fields):
    quote = {"id": "evidence-1", "quote": "2: transport.send(report)"}
    return {"execution": {"reachability": "definition_only", "entrypoint": "Внешний вызов не установлен",
                          "conditions": "Условия вне фрагмента неизвестны", "outcome": "Вызов отправки",
                          "limits": "Успешная доставка не доказана", "evidence": [quote]},
            "fields": {fid: {"support": "unknown", "mechanism": "unknown",
                             "limits": "Требуется проверить конфигурацию развёртывания", "evidence": []}
                       for fid in fields}}


class EvidenceCorpusTests(unittest.TestCase):
    def test_full_summary_and_intent_available_beyond_brief_limit(self):
        text = "Начало " + "а" * 35000 + " Уникальный хвост"
        c = build_corpus(MemoryTree({}), set(), [text], text)
        ids = [r["id"] for r in c.index("Уникальный хвост")["records"]]
        self.assertEqual(len(ids), 2)
        self.assertTrue(all("Уникальный хвост" in r["text"] for r in c.read(ids)["records"]))

    def test_blocks_secret_file_before_read_and_masks_literals(self):
        tree = MemoryTree({".env": "PASSWORD=secret-value", "main.py": 'api_key="private-value"\nrun_service()'})
        c = build_corpus(tree, set(tree.files), [], "")
        self.assertNotIn(".env", tree.reads)
        self.assertNotIn("private-value", json.dumps(c.records))
        self.assertTrue(any(".env" in x for x in c.omitted))

    def test_cannot_read_unselected_repository_files(self):
        tree = MemoryTree({"main.py": "start_process()", "other.py": "hidden_process()"})
        c = build_corpus(tree, {"main.py"}, [], "")
        self.assertEqual(tree.reads, ["main.py"])
        self.assertEqual(c.index("hidden_process")["total"], 0)
        self.assertIn("error", c.read(["other.py"])["records"][0])

    def test_documents_are_not_runtime_code(self):
        c = build_corpus(MemoryTree({"prompt.md": "Always deliver exactly once"}), {"prompt.md"}, [], "")
        c.read(["evidence-1"])
        self.assertTrue(c.citations([{"id": "evidence-1", "quote": "Always deliver exactly once"}], code=True))

    def test_omitted_tail_is_disclosed(self):
        c = build_corpus(MemoryTree({"big.py": "call_service()\n" * 1800}), {"big.py"}, [], "")
        self.assertTrue(any("1601" in x for x in c.omitted))

    def test_verified_anchor_beyond_file_head_is_retained(self):
        source = "call_service()\n" * 1900 + "important_control()\n"
        c = build_corpus(MemoryTree({"big.py": source}), {"big.py"}, [], "", anchors={"big.py": {1901}})
        self.assertEqual(c.index("important_control")["total"], 1)
        self.assertTrue(c.omitted)
        self.assertTrue(any("big.py:1801" == r["label"] for r in c.records.values()))

    def test_hash_changes_with_source_not_with_read_tracking(self):
        c = corpus_fixture()
        before = c.manifest()["sha256"]
        c.read(["evidence-3"])
        self.assertEqual(before, c.manifest()["sha256"])
        c.add("code", "more.py:1", "different_source()")
        self.assertNotEqual(before, c.manifest()["sha256"])

    def test_search_does_not_mark_unread_source_as_read(self):
        c = corpus_fixture()
        c.index("ровно один раз")
        self.assertTrue(c.citations([{"id": "evidence-3", "quote": "Все отчёты доставляются ровно один раз"}]))

    def test_context_compaction_keeps_handles_and_allows_rereading(self):
        c = EvidenceCorpus()
        c.add("code", "big.py:1", "call_service()\n" * 2500)
        messages = [{"role": "tool", "tool_call_id": key,
                     "content": json.dumps(c.read([key]), ensure_ascii=False)} for key in c.records]
        messages.append({"role": "assistant", "content": "Фрагменты прочитаны"})
        _compact_history(messages)
        self.assertNotIn('"text":', messages[0]["content"])
        self.assertIn("evidence-1", messages[0]["content"])
        self.assertIn("call_service()", c.read(["evidence-1"])["records"][0]["text"])
        self.assertEqual(c.citations([{"id": "evidence-1", "quote": "call_service()"}], code=True), [])

    def test_compaction_never_hides_new_batch_before_model_sees_it(self):
        c = EvidenceCorpus()
        c.add("code", "big.py:1", "call_service()\n" * 2500)
        messages = [{"role": "assistant", "content": None}]
        messages.extend({"role": "tool", "content": json.dumps(c.read([key]))} for key in c.records)
        _compact_history(messages)
        self.assertTrue(all('"text":' in m["content"] for m in messages[1:]))

    def test_invented_quote_rejected_but_literal_quote_retained(self):
        c = corpus_fixture()
        self.assertTrue(c.citations([{"id": "evidence-1", "quote": "send_exactly_once(report)"}], code=True))
        self.assertEqual(c.citations([{"id": "evidence-1", "quote": "2: transport.send(report)"}], code=True), [])

    def test_summaries_cannot_establish_runtime_guarantee(self):
        c = corpus_fixture()
        c.read(["evidence-3"])
        self.assertTrue(c.citations([{"id": "evidence-3", "quote": "Все отчёты доставляются ровно один раз"}], code=True))


class PassportFactGateTests(unittest.TestCase):
    def setUp(self):
        self.corpus = corpus_fixture()
        self.fields = {"4.5.4": {"value": "Отчёт передан транспорту",
                                 "source": "Установлено: reports.py вызывает отправку отчёта"}}
        self.audit = audit_fixture(self.fields)
        self.audit["fields"]["4.5.4"] = {"support": "code", "mechanism": "runtime",
            "limits": "Не гарантирует успешную доставку", "evidence": [{"id": "evidence-1", "quote": "2: transport.send(report)"}]}

    def test_retains_narrow_supported_effect(self):
        self.assertEqual(check_node_audit(self.corpus, self.audit, self.fields), [])

    def test_prompt_and_schema_not_accepted_as_enforced_behavior(self):
        for mechanism in ("prompt", "schema"):
            with self.subTest(mechanism=mechanism):
                self.audit["fields"]["4.5.4"]["mechanism"] = mechanism
                self.assertTrue(check_node_audit(self.corpus, self.audit, self.fields))

    def test_each_field_must_be_accounted_for(self):
        self.fields["4.5.6"] = {"value": "Повтор неизвестен", "source": "Не установлено: данных нет"}
        self.assertTrue(check_node_audit(self.corpus, self.audit, self.fields))

    def test_connected_requires_separate_entrypoint_citation(self):
        self.audit["execution"]["reachability"] = "connected"
        self.assertTrue(check_node_audit(self.corpus, self.audit, self.fields))
        self.audit["execution"]["entry_evidence"] = [{"id": "evidence-1", "quote": "2: transport.send(report)"}]
        self.assertEqual(check_node_audit(self.corpus, self.audit, self.fields), [])

    def test_unknown_must_be_visible_in_field_source(self):
        self.audit["fields"]["4.5.4"]["support"] = "unknown"
        self.assertTrue(check_node_audit(self.corpus, self.audit, self.fields))

    def test_provenance_rejection_cannot_be_bypassed_by_retries(self):
        state = _PassportSession(evidence_corpus=self.corpus, current="operation-1")
        state.nodes["operation-1"] = _Node(id="operation-1", name="Отправка отчёта", basis="Доставка результата")
        for _ in range(6):
            result = _handle_submit_node(state, {"id": "operation-1", "name": "Отправка отчёта", "fields": self.fields})
            self.assertIn("отклонён", result)
        self.assertFalse(state.nodes["operation-1"].filled)

    def test_missing_template_fields_rejected_even_with_valid_partial_audit(self):
        state = _PassportSession(evidence_corpus=self.corpus, current="operation-1")
        state.nodes["operation-1"] = _Node(id="operation-1", name="Отправка отчёта", basis="Доставка результата")
        result = _handle_submit_node(state, {"id": "operation-1", "fields": self.fields, "fact_check": self.audit})
        self.assertIn("Не проверены поля", result)

    def test_malformed_field_returns_rejection_not_exception(self):
        state = _PassportSession(evidence_corpus=self.corpus, current="operation-1")
        state.nodes["operation-1"] = _Node(id="operation-1", name="Отправка отчёта", basis="Доставка результата")
        result = _handle_submit_node(state, {"id": "operation-1", "fields": {"4.5.4": "bad cell"}, "fact_check": self.audit})
        self.assertIn("отклонён", result)

    def test_explicit_unknown_mode_does_not_force_inventing_auto(self):
        from pko.progress.passport_gate import PassportCheck, check_node_fields
        check = PassportCheck()
        check_node_fields(check, "process-1", {"fields": {"4.3.6": {
            "value": "Не установлено: режим запуска зависит от неизвестной конфигурации.",
            "source": "Не установлено: настройки развёртывания отсутствуют."}}})
        self.assertEqual(check.errors, [])

    def test_interrupted_strict_session_keeps_manifest_and_unreviewed_node(self):
        from test_passport_gate import SPEC
        client = SimpleNamespace(chat=lambda *a, **kw: SimpleNamespace(tool_calls=[], text="Нет данных"))
        result = run_passport_agent([], {}, [], None, SPEC, client=client, max_steps=1, evidence_corpus=self.corpus)
        self.assertFalse(result.passport_data["agent_filled"])
        self.assertEqual(result.passport_data["evidence_audit"]["unreviewed_nodes"], ["journey-1"])
        self.assertEqual(result.passport_data["evidence_materials"], self.corpus.records)

    def test_complete_operation_with_unknowns_and_supported_effect_is_accepted(self):
        fields = {fid: {"value": "Не установлено: требуется анализ условий развёртывания.",
                        "source": "Не установлено: в доступных фрагментах нет этих условий."}
                  for fid in NODE_FIELDS["operation"] - GENERATED_FIELDS["operation"]}
        fields.update(self.fields)
        audit = audit_fixture(fields)
        audit["fields"].update(self.audit["fields"])
        state = _PassportSession(evidence_corpus=self.corpus, current="operation-1")
        state.nodes["operation-1"] = _Node(id="operation-1", name="Отправка отчёта", basis="Передача клиенту подготовленного результата")
        result = _handle_submit_node(state, {"id": "operation-1", "fields": fields, "fact_check": audit})
        self.assertIn("принят", result)
        self.assertTrue(state.nodes["operation-1"].filled)
        self.assertEqual(state.nodes["operation-1"].data["fact_check"], audit)

    def test_intended_order_is_not_proof_of_runtime_relation(self):
        proof = {"direction": "Сначала отчёт, потом дата", "condition": "При отправке",
                 "mechanism": "Последовательные вызовы", "limits": "Только отчёты",
                 "evidence": [{"id": "evidence-2", "quote": "Отчёт отправляется, затем сохраняется дата"}]}
        self.assertTrue(check_relation_proof(self.corpus, proof, "precedes", ""))

    def test_feeds_requires_actual_data_name(self):
        proof = {"direction": "От отправителя получателю", "condition": "При отправке", "mechanism": "Аргумент вызова",
                 "limits": "Доставка не гарантируется", "evidence": [{"id": "evidence-1", "quote": "2: transport.send(report)"}]}
        self.assertTrue(check_relation_proof(self.corpus, proof, "feeds", ""))
        self.assertEqual(check_relation_proof(self.corpus, proof, "feeds", "report"), [])

    def test_rejected_relation_remains_visible_and_success_clears_it(self):
        state = _PassportSession(evidence_corpus=self.corpus, tree_done=True)
        for nid in ("operation-1", "operation-2"):
            state.nodes[nid] = _Node(id=nid, name=nid, basis="Отдельное действие")
        args = {"from": "operation-1", "to": "operation-2", "kind": "precedes", "basis": "Дата сохраняется до отправки"}
        self.assertIn("отклонена", _handle_link_nodes(state, args))
        self.assertTrue(state.unresolved_relations)
        args["proof"] = {"direction": "Сохранить дату, затем отправить", "condition": "Обработка отчёта",
                         "mechanism": "Последовательные вызовы", "limits": "Только этот обработчик",
                         "evidence": [{"id": "evidence-1", "quote": "1: next_report.save()\n2: transport.send(report)"}]}
        self.assertIn("принята", _handle_link_nodes(state, args))
        self.assertFalse(state.unresolved_relations)

    def test_risk_needs_control_check_with_code_not_summary(self):
        self.corpus.read(["evidence-3"])
        review = {"scope": "Отправка отчёта", "checked_controls": "Повторы транспорта",
                  "conclusion": "Внешний эффект может повторяться", "limits": "Не проверено развёртывание",
                  "evidence": [{"id": "evidence-3", "quote": "Все отчёты доставляются ровно один раз"}]}
        self.assertTrue(check_control_review(self.corpus, review))
        review["evidence"] = [{"id": "evidence-1", "quote": "3: retry_transport()"}]
        self.assertEqual(check_control_review(self.corpus, review), [])

    def test_normalization_and_map_keep_audit_and_proof(self):
        from test_passport_gate import _valid
        data = _valid()
        data["nodes"]["operation-1"]["fact_check"] = self.audit
        data["relations"] = [{"from": "operation-1", "to": "operation-2", "kind": "precedes", "basis": "Обоснование", "proof": {"limits": "Только эта ветка"}}]
        normalized = normalize_passport(data)
        self.assertTrue(any(n.get("fact_check") == self.audit for n in passport_map_nodes(normalized)))
        self.assertEqual(passport_map_relations(normalized)[0]["proof"]["limits"], "Только эта ветка")

    def test_production_pipeline_always_supplies_corpus(self):
        result = SimpleNamespace(items=[], context={}, verdicts=[], summary=None, knowledge=["main.py прочитан"])
        target = SimpleNamespace(tree=MemoryTree({"main.py": "send_report()"}), sha="abc", extraction=SimpleNamespace(capabilities=[]))
        with patch("pko.progress.pipeline.passport_enabled", return_value=True), \
             patch("pko.progress.pipeline._capability_digest", return_value=""), \
             patch("pko.progress.pipeline.run_passport_agent", return_value=SimpleNamespace(passport_data={}, notes=[])) as run:
            _run_passport(result, SimpleNamespace(source_text="Отправить отчёт"), target, "project", None, None, None)
        corpus = run.call_args.kwargs["evidence_corpus"]
        self.assertTrue(corpus.index("send_report")["total"])
        self.assertEqual(corpus.commit, "abc")


if __name__ == "__main__":
    unittest.main()
