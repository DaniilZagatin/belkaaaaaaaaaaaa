"""Привязка цитаты к утверждению: происхождение цитаты не делает её основанием
для любого вывода. Имя из утверждения, файл и строка, числа — сверяются кодом."""
import unittest

from pko.progress.passport_evidence import (
    EvidenceCorpus, check_control_review, check_node_audit, check_relation_proof, claim_citation_errors,
)

AGENT = "\n".join([
    "1: import logging",
    "2: LLM_MAX_RETRIES = int(os.getenv('LLM_MAX_RETRIES', '1'))",
    "3: ",
    "4: def _invoke_with_retry(call, retries=LLM_MAX_RETRIES):",
    "5:     for attempt in range(retries + 1):",
    "6:         try:",
    "7:             return call()",
    "8:         except TimeoutError:",
    "9:             continue",
    "10:     raise StepFailure(503)",
])
API = "\n".join([
    "40: @router.post('/api/steps/run')",
    "41: def run_step_ep(req):",
    "42:     if not req.config:",
    "43:         raise HTTPException(status_code=400)",
    "44:     payload = build_payload(req.target_image)",
    "45:     return run_step(payload)",
])


def corpus():
    c = EvidenceCorpus()
    c.add("code", "app/agent.py:1", AGENT)
    c.add("code", "app/api.py:1", API)
    c.read(["evidence-1", "evidence-2"])
    return c


def cite(record, quote):
    return [{"id": record, "quote": quote}]


class ClaimCitationTests(unittest.TestCase):
    def setUp(self):
        self.c = corpus()

    def test_unrelated_line_does_not_support_named_mechanism_or_numbers(self):
        errors = claim_citation_errors(
            self.c, "Повтор до трёх попыток; при недоступности — ошибка 400 или 500.\nУстановлено: _invoke_with_retry",
            cite("evidence-1", "1: import logging"),
            numbers_from="Повтор до трёх попыток; при недоступности — ошибка 400 или 500.")
        self.assertTrue(any("нет ни одного имени" in e for e in errors), errors)
        numbers = next(e for e in errors if e.startswith("числа"))
        self.assertIn("3", numbers)
        self.assertIn("400", numbers)
        self.assertIn("500", numbers)

    def test_quote_inside_named_declaration_supports_claim(self):
        claim = "Не более 1 повтора после первой попытки.\nУстановлено: app/agent.py, _invoke_with_retry"
        self.assertEqual(claim_citation_errors(
            self.c, claim, cite("evidence-1", "5:     for attempt in range(retries + 1):"),
            numbers_from="Не более 1 повтора после первой попытки."), [])

    def test_name_in_quote_itself_supports_claim(self):
        self.assertEqual(claim_citation_errors(
            self.c, "Установлено: число повторов задаёт LLM_MAX_RETRIES",
            cite("evidence-1", "LLM_MAX_RETRIES = int(os.getenv('LLM_MAX_RETRIES', '1'))")), [])

    def test_file_and_line_from_source_must_match_the_quote(self):
        wrong_line = claim_citation_errors(self.c, "Установлено: app/agent.py:30 повторяет вызов",
                                           cite("evidence-1", "5:     for attempt in range(retries + 1):"))
        self.assertTrue(any("не совпадает с процитированными строками" in e for e in wrong_line), wrong_line)
        self.assertEqual(claim_citation_errors(self.c, "Установлено: app/agent.py:5 повторяет вызов",
                                               cite("evidence-1", "5:     for attempt in range(retries + 1):")), [])
        wrong_file = claim_citation_errors(self.c, "Установлено: core/prototype.py повторяет вызов",
                                           cite("evidence-1", "5:     for attempt in range(retries + 1):"))
        self.assertTrue(any("из других файлов" in e for e in wrong_file), wrong_file)

    def test_status_codes_must_be_the_quoted_ones(self):
        value = "Недоступность провайдера — ошибка 503, неверная конфигурация — 400."
        self.assertEqual(claim_citation_errors(
            self.c, value, [*cite("evidence-1", "raise StepFailure(503)"),
                            *cite("evidence-2", "raise HTTPException(status_code=400)")], numbers_from=value), [])
        errors = claim_citation_errors(self.c, "ошибка 502", cite("evidence-1", "raise StepFailure(503)"),
                                       numbers_from="ошибка 502")
        self.assertTrue(errors and "502" in errors[0])

    def test_line_prefixes_field_ids_and_modes_are_not_claims(self):
        # «10:» — номер строки фрагмента, а не значение; «4.5.4» — номер поля;
        # AUTO — слово словаря паспорта, а не имя в коде.
        self.assertEqual(claim_citation_errors(
            self.c, "Режим AUTO по полю 4.5.4", cite("evidence-1", "10:     raise StepFailure(503)"),
            numbers_from="Режим AUTO по полю 4.5.4"), [])
        errors = claim_citation_errors(self.c, "Повторов 10", cite("evidence-1", "10:     raise StepFailure(503)"),
                                       numbers_from="Повторов 10")
        self.assertTrue(errors)

    def test_summary_and_unshown_quotes_are_left_to_provenance_check(self):
        c = corpus()
        c.add("summary", "След оценки", "всё работает с _invoke_with_retry")
        self.assertEqual(claim_citation_errors(c, "Установлено: _invoke_with_retry",
                                               cite("evidence-3", "всё работает с _invoke_with_retry")), [])


class GateIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.c = corpus()

    def audit(self, row):
        return {"execution": {"reachability": "unknown", "entrypoint": "Не установлен", "conditions": "Не установлены",
                              "outcome": "Не установлен", "limits": "Только фрагменты", "evidence": []},
                "fields": {"4.5.6": row}}

    def test_code_field_needs_claim_bound_quote_but_inference_does_not(self):
        fields = {"4.5.6": {"value": "Повтор до трёх попыток.", "source": "Установлено: _invoke_with_retry повторяет вызов"}}
        row = {"support": "code", "mechanism": "runtime", "limits": "Только транспорт",
               "evidence": cite("evidence-1", "5:     for attempt in range(retries + 1):")}
        errors = check_node_audit(self.c, self.audit(row), fields)
        self.assertTrue(any("числа из утверждения" in e and "3" in e for e in errors), errors)
        fields["4.5.6"]["value"] = "Повтор после первой неудачной попытки."
        self.assertEqual(check_node_audit(self.c, self.audit(row), fields), [])
        fields["4.5.6"] = {"value": "Повтор до трёх попыток.", "source": "Выведено: по описанию шага"}
        row = {**row, "support": "inference"}
        self.assertEqual(check_node_audit(self.c, self.audit(row), fields), [])

    def test_feeds_relation_must_quote_the_transferred_data(self):
        proof = {"direction": "Целевой образ передаётся в запуск шага", "condition": "При запуске шага",
                 "mechanism": "Аргумент вызова", "limits": "Только этот обработчик",
                 "evidence": cite("evidence-2", "45:     return run_step(payload)")}
        errors = check_relation_proof(self.c, proof, "feeds", "target_image")
        self.assertTrue(any("target_image" in e for e in errors), errors)
        # Имя функции в механизме не заменяет передаваемые данные.
        named = {**proof, "mechanism": "Аргумент вызова run_step"}
        self.assertTrue(any(e.startswith("field:") for e in check_relation_proof(self.c, named, "feeds", "target_image")))
        proof["evidence"] = cite("evidence-2", "payload = build_payload(req.target_image)")
        self.assertEqual(check_relation_proof(self.c, proof, "feeds", "target_image"), [])

    def test_control_review_numbers_come_from_quoted_code(self):
        review = {"scope": "Вызов модели", "checked_controls": "Повтор до 3 раз при тайм-ауте",
                  "conclusion": "Резервной модели нет", "limits": "Конфигурация сервера неизвестна",
                  "evidence": cite("evidence-1", "8:         except TimeoutError:")}
        self.assertTrue(any("3" in e for e in check_control_review(self.c, review)))
        review["checked_controls"] = "Повтор при тайм-ауте, число повторов из настройки"
        self.assertEqual(check_control_review(self.c, review), [])


if __name__ == "__main__":
    unittest.main()
