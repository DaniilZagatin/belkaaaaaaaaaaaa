"""Хранение ответов команд из HTML-отчётов."""
import tempfile
import unittest
from pathlib import Path
from unittest import mock
from pko.errors import PkoError
from pko.answers import feedback


class FeedbackStoreTest(unittest.TestCase):
    """Хранилище отдельно от веба: правила ответа не зависят от транспорта."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.store = feedback.FeedbackStore(path=Path(self.tmp.name) / "f.db")
        self.addCleanup(self.store.close)

    def _dispute(self, **kwargs) -> feedback.Dispute:
        base = dict(analysis_id="an_1", bullet_index=0, verdict="accept")
        base.update(kwargs)
        return feedback.Dispute(**base)

    def test_accept_needs_no_comment(self):
        saved = self.store.save(self._dispute())
        self.assertGreater(saved.id, 0)
        self.assertTrue(saved.created_at)

    def test_reject_without_comment_is_refused(self):
        """Возражение без объяснения нечем обработать."""
        with self.assertRaises(PkoError) as ctx:
            self.store.save(self._dispute(verdict="reject"))
        self.assertIn("комментари", ctx.exception.message.lower())

    def test_accept_with_note_without_comment_is_refused(self):
        with self.assertRaises(PkoError):
            self.store.save(self._dispute(verdict="accept_with_note"))

    def test_unknown_verdict_is_refused(self):
        with self.assertRaises(PkoError):
            self.store.save(self._dispute(verdict="maybe"))

    def test_comment_is_stored_and_trimmed(self):
        saved = self.store.save(self._dispute(
            verdict="reject", comment="  Пункт   сделан,\n вот  где  ",
        ))
        self.assertEqual(saved.comment, "Пункт сделан, вот где")

    def test_long_comment_is_capped(self):
        saved = self.store.save(self._dispute(verdict="reject", comment="я" * 5000))
        self.assertEqual(len(saved.comment), feedback.MAX_COMMENT_CHARS)

    def test_survives_reopening_the_file(self):
        """Реестр анализов живёт в памяти; возражения так терять нельзя."""
        self.store.save(self._dispute(verdict="reject", comment="не согласны"))
        self.store.close()
        again = feedback.FeedbackStore(path=self.store.path)
        self.addCleanup(again.close)
        self.assertEqual(len(again.list()), 1)
        self.assertEqual(again.list()[0].comment, "не согласны")

    def test_only_the_tools_own_directory_is_hardened(self):
        """Права ужимаются на `~/.pko`, а не на каталог, выбранный оператором.

        Прежний вызов закрывал ещё и родителя: при пути по умолчанию —
        домашний каталог целиком, при `/tmp/feedback.db` — `/tmp` и `/`.
        """
        with mock.patch.object(feedback, "harden_dir") as harden:
            self.store.connect()
        harden.assert_not_called()

        default_dir = Path(self.tmp.name) / ".pko"
        with mock.patch.object(feedback, "DEFAULT_DB_PATH", default_dir / "feedback.db"), \
                mock.patch.object(feedback, "harden_dir") as harden:
            store = feedback.FeedbackStore(path=default_dir / "feedback.db")
            self.addCleanup(store.close)
            store.connect()
        harden.assert_called_once_with(default_dir)

    def test_list_filters_by_analysis_and_orders_newest_first(self):
        self.store.save(self._dispute(analysis_id="an_1", bullet_index=0))
        self.store.save(self._dispute(analysis_id="an_2", bullet_index=1))
        self.store.save(self._dispute(analysis_id="an_1", bullet_index=2))
        only_first = self.store.list(analysis_id="an_1")
        self.assertEqual([d.bullet_index for d in only_first], [2, 0])
        self.assertEqual(len(self.store.list()), 3)



if __name__ == "__main__":
    unittest.main()
