"""Бюджет распаковки ZIP проверяется до чтения элемента в память."""
import io
import zipfile
import unittest
from pathlib import Path
from pko.errors import PkoError
from pko.progress import local_source


class ZipBomb(unittest.TestCase):
    """Бюджет распаковки считается до чтения элемента в память."""

    def _archive(self, name: str, data: bytes) -> tuple[str, bytes]:
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr(name, data)
        return ("repo.zip", buffer.getvalue())

    def test_declared_size_is_checked_before_reading(self) -> None:
        """Ноль-байты жмутся в тысячи раз: маленький архив, огромная память."""
        payload = b"\0" * (local_source.MAX_WORKSPACE_BYTES + 1)
        upload = self._archive("big.bin", payload)
        self.assertLess(len(upload[1]), 1_000_000)

        reads: list[str] = []
        original = zipfile.ZipFile.read

        def counting_read(self_, member, pwd=None):  # type: ignore[no-untyped-def]
            reads.append(getattr(member, "filename", str(member)))
            return original(self_, member, pwd)

        zipfile.ZipFile.read = counting_read
        self.addCleanup(setattr, zipfile.ZipFile, "read", original)

        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(PkoError) as ctx:
                local_source.build_target_repo_from_uploads([upload], Path(tmp))
        self.assertIn("слишком большие", ctx.exception.message.lower())
        # Главное: до чтения в память дело не дошло.
        self.assertEqual(reads, [])

    def test_normal_archive_still_extracts(self) -> None:
        import tempfile

        upload = self._archive("src/main.py", b"def main():\n    return 1\n")
        with tempfile.TemporaryDirectory() as tmp:
            target = local_source.build_target_repo_from_uploads([upload], Path(tmp))
        self.assertIn("src/main.py", target.tree.files)


if __name__ == "__main__":
    unittest.main()
