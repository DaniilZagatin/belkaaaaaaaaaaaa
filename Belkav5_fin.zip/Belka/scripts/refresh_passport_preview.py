"""Re-render an existing HTML passport without rerunning or inventing analysis."""
import argparse
import json
from html import escape, unescape
from pathlib import Path
import re
from types import SimpleNamespace

from pko.render.client_journey_passport import _finalize_html
from pko.render.passport_map import _build_breaks
from pko.render.passport_content import compact_template


def refresh(source: Path, target: Path, editorial: Path | None = None):
    text = source.read_text(encoding="utf-8")
    match = re.search(r"var SCHEMA=(.*?); var meta", text, re.S)
    if not match:
        raise ValueError("HTML не содержит встроенной схемы паспорта")
    schema = json.loads(match[1])
    # Derive break markers from the existing facts, not from new assumptions.
    if "breaks" not in schema:
        scenarios = {p["id"]: SimpleNamespace(**p) for p in schema.get("paths", [])}
        schema["breaks"] = _build_breaks(schema["nodes"], schema.get("handoffs", []), scenarios)
    schema.setdefault("meta", {})["preview_note"] = (
        "Пример нового оформления на данных исходного паспорта. Повторная оценка кода и рисков не выполнялась."
    )
    text = re.sub(r"<(script|style)\b[^>]*data-passport-fix[^>]*>.*?</\1>", "", text, flags=re.S)
    text = re.sub(r"<style\b[^>]*data-passport-fonts[^>]*>.*?</style>", "", text, flags=re.S)
    if editorial:
        # Explicit example copy edits, not new model findings or code evidence.
        edits = json.loads(editorial.read_text(encoding="utf-8"))
        text = compact_template(text)
        for nid, meaning in edits.get("business_meaning", {}).items():
            pattern = r'(<section class="node" id="' + re.escape(nid) + r'">.*?<p data-fill="value">).*?(</p>)'
            text, count = re.subn(pattern, lambda m: m[1] + escape(meaning) + m[2], text, count=1, flags=re.S)
            if count != 1:
                raise ValueError(f"Узел редакционной правки не найден: {nid}")
        by_id = {r["id"]: r for r in schema.get("risks", [])}
        allowed = {"title", "cause", "negative_event", "consequences", "control_gap", "confirmation_needed"}
        for rid, fields in edits.get("risks", {}).items():
            if rid not in by_id or set(fields) - allowed:
                raise ValueError(f"Недопустимая редакционная правка риска: {rid}")
            by_id[rid].update(fields)
        # Reviewed copy edits keep the saved assessment and source locations.
        # Exact before-text checks also make the file safe to apply again.
        nodes = {node["id"]: node for node in schema.get("nodes", [])}
        for edit in edits.get("field_edits", []):
            nid, part = edit["node"], edit["part"]
            if part == "basis":
                if nodes[nid].get("basis") not in (edit["before"], edit["after"]):
                    raise ValueError(f"Основание узла изменилось: {nid}")
                nodes[nid]["basis"] = edit["after"]
                continue
            if part not in ("value", "source"):
                raise ValueError(f"Недопустимое поле редакторской правки: {part}")
            pattern = (r'(<section class="node" id="' + re.escape(nid)
                       + r'">(?:(?!<section class="node").)*?<div data-field="'
                       + re.escape(edit["field"]) + r'">(?:(?!<div data-field=).)*?'
                       + r'<(?:p|span) data-fill="' + part + r'">)(.*?)(</(?:p|span)>)')
            def replace_field(match):
                current = unescape(re.sub(r"<[^>]+>", "", match[2])).strip()
                if current not in (edit["before"], edit["after"]):
                    raise ValueError(f"Текст поля изменился: {nid}/{edit['field']}/{part}")
                return match[1] + escape(edit["after"]) + match[3]
            text, count = re.subn(pattern, replace_field, text, count=1, flags=re.S)
            if count != 1:
                raise ValueError(f"Поле редакторской правки не найдено: {nid}/{edit['field']}/{part}")
        for edit in edits.get("risk_edits", []):
            key = edit["field"]
            if not re.fullmatch(r"(?:evidence\.\d+\.basis|existing_controls\.\d+\.basis|control_gap|confidence_note|confirmation_needed)", key):
                raise ValueError(f"Недопустимая редакторская правка риска: {key}")
            risk_target = by_id[edit["risk"]]
            parts = key.split(".")
            for segment in parts[:-1]:
                risk_target = risk_target[int(segment)] if isinstance(risk_target, list) else risk_target[segment]
            if risk_target.get(parts[-1]) not in (edit["before"], edit["after"]):
                raise ValueError(f"Текст риска изменился: {edit['risk']}/{key}")
            risk_target[parts[-1]] = edit["after"]
        for edit in edits.get("card_edits", []):
            group, key = edit["group"], edit["field"]
            if (group, key) not in {("needs", "purpose"), ("guardrails", "name"), ("guardrails", "source")}:
                raise ValueError(f"Недопустимая редакторская правка карточки: {group}/{key}")
            card = next((item for item in schema["meta"].get(group, []) if item["id"] == edit["id"]), None)
            if card is None or card.get(key) not in (edit["before"], edit["after"]):
                raise ValueError(f"Текст карточки изменился: {edit['id']}/{key}")
            card[key] = edit["after"]
        schema["meta"]["editorial_review"] = True
    if schema["meta"].get("editorial_review"):
        schema["meta"]["preview_note"] += " Формулировки отредактированы для читаемости; оценки и ссылки сохранены."
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(_finalize_html(text, schema), encoding="utf-8")
    print(f"{target}: {target.stat().st_size} bytes (source {source.stat().st_size})")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("target", type=Path)
    parser.add_argument("--editorial", type=Path, help="Явные редакционные правки примера, без переоценки")
    args = parser.parse_args()
    refresh(args.source, args.target, args.editorial)
