// Verify the rendered geometry, independently of the layout's stored positions.
const { chromium } = require('playwright');
const { pathToFileURL } = require('url');
const path = require('path');
const assert = require('node:assert/strict');

async function checkGeometry(page, label) {
  const result = await page.evaluate(() => {
    const nodes = [...document.querySelectorAll('.pko-object')];
    const byId = Object.fromEntries(nodes.map(node => [node.dataset.id, node]));
    const near = (a, b) => Math.abs(a - b) < 1;
    function onBorder(point, node) {
      const box = node.getBoundingClientRect();
      return ((near(point.y, box.top) || near(point.y, box.bottom)) &&
        point.x >= box.left - 1 && point.x <= box.right + 1) ||
        ((near(point.x, box.left) || near(point.x, box.right)) &&
        point.y >= box.top - 1 && point.y <= box.bottom + 1);
    }
    const detachedLinks = [...document.querySelectorAll('.pko-links path.link')].filter(link => {
      const pair = link.dataset.pair.split('|').map(id => byId[id]);
      const matrix = link.getScreenCTM();
      const start = link.getPointAtLength(0).matrixTransform(matrix);
      const end = link.getPointAtLength(link.getTotalLength()).matrixTransform(matrix);
      return !((onBorder(start, pair[0]) && onBorder(end, pair[1])) ||
        (onBorder(start, pair[1]) && onBorder(end, pair[0])));
    }).map(link => link.dataset.pair);
    const canvas = document.querySelector('.pko-canvas');
    const scale = new DOMMatrix(getComputedStyle(canvas).transform).a;
    const misplacedPins = [...document.querySelectorAll('.pko-pin')].filter(pin => {
      const box = pin.getBoundingClientRect();
      return !nodes.some(node => {
        const target = node.getBoundingClientRect();
        return near(box.left, target.left - 9 * scale) && near(box.top, target.top - 8 * scale);
      });
    }).length;
    const action = document.querySelector('.pko-action');
    const selected = document.querySelector('.pko-object.selected');
    let actionAttached = true;
    if (action && selected) {
      const a = action.getBoundingClientRect(), n = selected.getBoundingClientRect();
      actionAttached = near(a.left, n.left) && near(a.top, n.bottom + 6 * scale);
    }
    return {
      sizes: [...new Set(nodes.map(n => `${n.offsetWidth}x${n.offsetHeight}`))],
      overflow: nodes.filter(n => n.scrollHeight > n.clientHeight + 1).map(n => n.dataset.id),
      detachedLinks, misplacedPins, actionAttached,
    };
  });
  assert.equal(result.sizes.length, 1, `${label}: unequal node sizes`);
  assert.deepEqual(result.overflow, [], `${label}: node content overflow`);
  assert.deepEqual(result.detachedLinks, [], `${label}: lines detached from nodes`);
  assert.equal(result.misplacedPins, 0, `${label}: break markers detached from nodes`);
  assert(result.actionAttached, `${label}: action detached from selected node`);
}

(async () => {
  const browser = await chromium.launch({ channel: 'msedge', headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 1440, height: 960 }, reducedMotion: 'reduce' });
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    const source = path.resolve(process.argv[2] || 'reports/example/client_journey_passport_current.html');
    await page.goto(pathToFileURL(source).href);
    await page.locator('.pko-object').first().waitFor();
    await page.getByRole('button', { name: 'Показать весь граф', exact: true }).click();
    await checkGeometry(page, 'initial');
    const node = page.locator('.pko-object[data-type="bbb"]').first();
    await node.focus();
    await node.press('Enter');
    await page.locator('.pko-action').waitFor();
    // Layout and camera updates are scheduled on animation frames even with reduced motion.
    await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
    await checkGeometry(page, 'selected');
    await page.getByRole('button', { name: 'Приблизить', exact: true }).click();
    await checkGeometry(page, 'zoomed');
    await page.getByRole('button', { name: 'Сбросить выбор', exact: true }).click();
    await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
    await checkGeometry(page, 'reset');
    await page.setViewportSize({ width: 375, height: 812 });
    await page.getByRole('button', { name: 'Показать весь граф', exact: true }).click();
    await checkGeometry(page, 'mobile');
    assert.deepEqual(errors, []);
    console.log('PASS: uniform nodes, line endpoints, break markers and action at initial/select/zoom/reset/mobile');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
