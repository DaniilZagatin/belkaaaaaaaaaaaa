"""Phoenix: один trace на запуск `pko progress` — корень, проходы, шаги, LLM и инструменты.

Спаны уходят в память (`InMemorySpanExporter`): ни сеть, ни сервер Phoenix
не нужны. Модель скриптованная, как в `test_cli_end_to_end`.
"""

from __future__ import annotations

import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

try:
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor
    from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
except ImportError:  # трассировка — необязательная зависимость
    TracerProvider = None

import pko.llm.client as client_module
from agent_script import JOURNEY_TEXT, full_session
from fixture_support import ensure_fixture, scripted_responses
from pko import cli
from pko.llm import tracing
from pko.llm.client import ChatClient, ChatResult

KIND = "openinference.span.kind"
PASSES = ["1 · Разбор пунктов", "2 · Строгая проверка",
          "3 · Ревизия связности", "4 · Паспорт клиентского пути"]


def record_spans(test: unittest.TestCase) -> "InMemorySpanExporter":
    exporter = InMemorySpanExporter()
    provider = TracerProvider(span_limits=tracing.span_limits())
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    patcher = mock.patch.object(tracing, "_tracer", provider.get_tracer("test"))
    patcher.start()
    test.addCleanup(patcher.stop)
    return exporter


class Tree:
    def __init__(self, spans):
        self.spans = sorted(spans, key=lambda s: s.start_time)
        self.by_id = {s.context.span_id: s for s in self.spans}

    def children(self, span):
        return [s for s in self.spans if s.parent is not None and s.parent.span_id == span.context.span_id]

    def kind(self, span):
        return span.attributes.get(KIND)


@unittest.skipIf(TracerProvider is None, "нужен arize-phoenix-otel (requirements-phoenix.txt)")
class CliRunTraceTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        cache = mock.patch.object(client_module, "DEFAULT_CACHE_DIR", Path(self.tmp.name) / "llm-cache")
        cache.start()
        self.addCleanup(cache.stop)
        env = mock.patch.dict(os.environ, {
            "PKO_MATCHER_BASE_URL": "https://stub.local/v1", "PKO_MATCHER_MODEL": "stub-model",
            "PKO_MATCHER_API_KEY": "x", "PKO_MONITOR_ENABLED": "false",
        })
        env.start()
        self.addCleanup(env.stop)
        # Экспортёр подменён; настоящую инициализацию Phoenix тест не делает.
        init = mock.patch.object(cli, "init_phoenix_tracing", return_value=None)
        init.start()
        self.addCleanup(init.stop)
        self.exporter = record_spans(self)

    def _run(self) -> Path:
        journey = Path(self.tmp.name) / "initiative.md"
        journey.write_text(JOURNEY_TEXT, encoding="utf-8")
        out = Path(self.tmp.name) / "out"
        with mock.patch.object(ChatClient, "_create", scripted_responses(*full_session())), \
                mock.patch("sys.stdout", io.StringIO()):
            code = cli.main(["progress", "--journey-file", str(journey),
                             "--repo-path", str(ensure_fixture()), "--out", str(out), "--quiet"])
        self.assertEqual(code, 0)
        return out

    def test_one_trace_holds_stages_steps_queue_and_tools(self):
        out = self._run()
        tree = Tree(self.exporter.get_finished_spans())

        self.assertEqual(len({s.context.trace_id for s in tree.spans}), 1, "весь запуск — один trace")
        roots = [s for s in tree.spans if s.parent is None]
        self.assertEqual(len(roots), 1)
        root = roots[0]
        self.assertTrue(root.name.startswith("pko.progress · "))
        run_id = next((out / "audit").glob("run_*.txt")).stem
        self.assertEqual(root.attributes["session.id"], run_id)
        self.assertEqual(root.attributes["input.value"], JOURNEY_TEXT)
        result = json.loads(root.attributes["output.value"])
        self.assertEqual((result["readiness"], result["decision"]), (50, "GO"))
        self.assertEqual([s.name for s in tree.children(root)],
                         ["source", "pipeline", "render_passport", "write_outputs"])

        pipeline = next(s for s in tree.children(root) if s.name == "pipeline")
        sessions = [s for s in tree.children(pipeline) if tree.kind(s) == "AGENT"]
        self.assertEqual([s.name for s in sessions], PASSES)
        self.assertIn("publish_dashboard", [s.name for s in tree.children(pipeline)])
        self.assertIn("passport_evidence", [s.name for s in tree.children(pipeline)])

        for session in sessions:
            steps = tree.children(session)
            self.assertTrue(steps, session.name)
            # Стартовая очередь прохода: системный промпт и бриф.
            opening = json.loads(session.attributes["input.value"])
            self.assertEqual([m["role"] for m in opening], ["system", "user"])
            for step in steps:
                self.assertTrue(step.name.startswith("шаг "), step.name)
                inner = tree.children(step)
                llm = [s for s in inner if tree.kind(s) == "LLM"]
                tools = [s for s in inner if tree.kind(s) == "TOOL"]
                self.assertEqual(len(llm), 1, step.name)
                llm = llm[0]
                queue = llm.attributes["pko.queue.messages"]
                self.assertEqual(llm.attributes["llm.input_messages.0.message.role"], "system")
                self.assertIn(f"llm.input_messages.{queue - 1}.message.role", llm.attributes)
                called = [llm.attributes[f"llm.output_messages.0.message.tool_calls.{i}.tool_call.function.name"]
                          for i in range(len(tools))]
                self.assertEqual([t.name for t in tools], called, step.name)
                for tool in tools:
                    self.assertGreaterEqual(tool.start_time, llm.end_time)
                    self.assertLessEqual(tool.end_time, step.end_time)
                    self.assertIn("output.value", tool.attributes)
                    self.assertEqual(tool.attributes["tool.name"], tool.name)
                self.assertEqual(step.attributes["output.value"], llm.attributes["output.value"])

        # Вход второго шага — ответы инструментов первого, в том виде, как их
        # получила модель.
        first, second = tree.children(sessions[0])[:2]
        first_ids = {tree.children(first)[0].attributes[f"llm.output_messages.0.message.tool_calls.{i}.tool_call.id"]
                     for i in range(len([s for s in tree.children(first) if tree.kind(s) == "TOOL"]))}
        queued = json.loads(second.attributes["input.value"])
        self.assertEqual({m.get("tool_call_id") for m in queued if m["role"] == "tool"}, first_ids)
        self.assertNotIn("assistant", {m["role"] for m in queued})

        # События гейта паспорта принадлежат вызову инструмента, а не всей сессии.
        passport_tools = [t for step in tree.children(sessions[3]) for t in tree.children(step)
                          if tree.kind(t) == "TOOL"]
        accepted = [t for t in passport_tools if any(e.name == "node_accepted" for e in t.events)]
        self.assertTrue(accepted)
        self.assertTrue(all(t.name == "submit_node" for t in accepted))
        self.assertFalse([e for e in sessions[3].events if e.name == "node_accepted"])

        # Журнал анализа и Phoenix связывает один trace_id.
        audit = next((out / "audit").glob("run_*.txt")).read_text(encoding="utf-8")
        self.assertIn(f"{root.context.trace_id:032x}", audit)


@unittest.skipIf(TracerProvider is None, "нужен arize-phoenix-otel (requirements-phoenix.txt)")
class TracedClientTest(unittest.TestCase):
    def test_queue_and_reply_without_reasoning_or_secrets(self):
        exporter = record_spans(self)
        answer = ChatResult(text="", usage={}, from_cache=True, reasoning_content="SECRET-THOUGHT",
                            tool_calls=[{"id": "c1", "type": "function",
                                         "function": {"name": "read_file", "arguments": '{"path": "a.py"}'}}])
        delegate = SimpleNamespace(spec=SimpleNamespace(model="stub"), chat=lambda messages, **kw: answer)
        messages = [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "доступ: password=hunter2"},
            {"role": "assistant", "content": None, "reasoning_content": "OLD-THOUGHT",
             "tool_calls": [{"id": "c0", "type": "function",
                             "function": {"name": "search", "arguments": "{}"}}]},
            {"role": "tool", "tool_call_id": "c0", "content": "найдено"},
        ]
        client = tracing.trace_client(delegate, None)
        with tracing.trace_span("agent_session"):
            with tracing.trace_span("agent.step", step=1):
                self.assertIs(client.chat(messages, tools=[{"type": "function"}], max_tokens=10), answer)

        spans = {s.attributes[KIND]: s for s in exporter.get_finished_spans()}
        llm, step = spans["LLM"], spans["CHAIN"]
        exported = json.dumps([dict(s.attributes) for s in spans.values()], ensure_ascii=False)
        for secret in ("SECRET-THOUGHT", "OLD-THOUGHT", "hunter2", "reasoning_content"):
            self.assertNotIn(secret, exported)
        self.assertTrue(llm.attributes["pko.llm.from_cache"])
        self.assertEqual(llm.attributes["pko.llm.reasoning_chars"], len("SECRET-THOUGHT"))
        self.assertEqual(llm.attributes["llm.input_messages.2.message.tool_calls.0.tool_call.function.name"], "search")
        self.assertEqual(llm.attributes["llm.input_messages.3.message.tool_call_id"], "c0")
        self.assertIn("llm.tools.0.tool.json_schema", llm.attributes)
        self.assertEqual(step.name, "шаг 1 · read_file")
        queued = json.loads(step.attributes["input.value"])
        self.assertEqual([m["role"] for m in queued], ["system", "user", "tool"])
        self.assertEqual(json.loads(step.attributes["output.value"])["tool_calls"][0]["arguments"], {"path": "a.py"})

    def test_failed_call_marks_llm_and_step(self):
        exporter = record_spans(self)

        def fail(messages, **kwargs):
            raise RuntimeError("endpoint down")

        client = tracing.trace_client(SimpleNamespace(spec=None, chat=fail), None)
        with tracing.trace_span("critic_session"):
            with tracing.trace_span("critic.step", step=1):
                with self.assertRaises(RuntimeError):
                    client.chat([{"role": "user", "content": "x"}])
        failed = [s.name for s in exporter.get_finished_spans() if not s.status.is_ok]
        self.assertEqual(sorted(failed), ["llm", "шаг 1"])


class DisabledTracingTest(unittest.TestCase):
    def test_everything_is_a_passthrough_without_phoenix(self):
        with mock.patch.object(tracing, "_tracer", None):
            client = object()
            self.assertIs(tracing.trace_client(client, None), client)
            self.assertIsNone(tracing.trace_client(None, None))
            reply = {"role": "tool", "content": "ok"}
            self.assertIs(tracing.trace_tool_call(lambda state, call: reply, None, {}), reply)
            with tracing.trace_span("pko.progress") as span:
                self.assertEqual(span.trace_id, "")
                span.set_input("x")
                span.set_output({"y": 1})

    def test_enabled_without_server_keeps_the_run_going(self):
        env = {"PKO_PHOENIX_ENABLED": "true", "PKO_PHOENIX_ENDPOINT": "http://127.0.0.1:9/v1/traces"}
        with mock.patch.dict(os.environ, env), mock.patch.object(tracing, "_initialized", False), \
                mock.patch.object(tracing, "_tracer", None), mock.patch.object(tracing, "_provider", None), \
                mock.patch("sys.stderr", io.StringIO()) as stderr:
            self.assertIsNone(tracing.init_phoenix_tracing())
            self.assertIsNone(tracing._tracer)
            self.assertIn("трассировка", stderr.getvalue())


if __name__ == "__main__":
    unittest.main()
