"""Экономия контекста связности и паспорта без потери сведений.

Окно рассуждений с откатом для эндпоинтов, которым рассуждения нужны обратно;
свёртка старых отправок паспорта с полными данными по read_node; след оценки в
брифе — оглавлением со ссылками на корпус.
"""

from __future__ import annotations

import json
import unittest
from types import SimpleNamespace

from pko.errors import LlmError
from pko.progress.context_window import KEEP_REASONING_STEPS, ReasoningWindowClient
from pko.progress.passport_agent import (
    _FOLD_MARK,
    _PassportSession,
    _Node,
    _compact_history,
    _handle_read_node,
    render_evaluation_digest,
)


def answer(i: int, reasoning: str = "", name: str = "read_passport_evidence", args: dict | None = None) -> dict:
    return {"role": "assistant", "content": None, "reasoning_content": reasoning or None,
            "tool_calls": [{"id": f"call_{i}", "type": "function",
                            "function": {"name": name, "arguments": json.dumps(args or {"ids": ["evidence-1"]},
                                                                               ensure_ascii=False)}}]}


def reply(i: int, content: str) -> dict:
    return {"role": "tool", "tool_call_id": f"call_{i}", "content": content}


class Recorder:
    spec = SimpleNamespace(model="stub")

    def __init__(self, *errors):
        self.errors, self.sent = list(errors), []

    def chat(self, messages, **kwargs):
        self.sent.append([m.get("reasoning_content") for m in messages if m.get("role") == "assistant"])
        if self.errors:
            raise self.errors.pop(0)
        return "ok"


class ReasoningWindowTest(unittest.TestCase):
    def _history(self, steps: int) -> list[dict]:
        messages = [{"role": "system", "content": "s"}, {"role": "user", "content": "u"}]
        for i in range(steps):
            messages += [answer(i, f"мысль {i}"), reply(i, "фрагмент")]
        return messages

    def test_keeps_only_recent_reasoning_in_place(self):
        delegate = Recorder()
        client = ReasoningWindowClient(delegate)
        messages = self._history(5)
        self.assertEqual(client.chat(messages), "ok")
        self.assertEqual(delegate.sent[-1], [None, None, None, "мысль 3", "мысль 4"])
        self.assertEqual(KEEP_REASONING_STEPS, 2)
        # Убранное не возвращается: начало запроса от шага к шагу стабильно.
        messages += [answer(5, "мысль 5"), reply(5, "фрагмент")]
        client.chat(messages)
        self.assertEqual(delegate.sent[-1], [None, None, None, None, "мысль 4", "мысль 5"])

    def test_endpoint_that_needs_reasoning_gets_it_back(self):
        refusal = LlmError("Модель stub отклонила запрос.", "reasoning_content is required for tool call messages")
        delegate = Recorder(refusal)
        client = ReasoningWindowClient(delegate)
        messages = self._history(4)
        self.assertEqual(client.chat(messages), "ok")
        self.assertEqual(delegate.sent[-1], ["мысль 0", "мысль 1", "мысль 2", "мысль 3"])
        self.assertFalse(client.enabled)
        messages += [answer(4, "мысль 4"), reply(4, "фрагмент")]
        client.chat(messages)
        self.assertEqual(delegate.sent[-1], [f"мысль {i}" for i in range(5)])

    def test_unrelated_errors_are_not_retried(self):
        delegate = Recorder(LlmError("Таймаут при обращении к эндпоинту.", "проверьте сеть"))
        client = ReasoningWindowClient(delegate)
        with self.assertRaises(LlmError):
            client.chat(self._history(4))
        self.assertEqual(len(delegate.sent), 1)
        self.assertTrue(client.enabled)


class FoldedSubmissionsTest(unittest.TestCase):
    def _node_args(self, quote: str) -> dict:
        return {"id": "journey-1", "name": "Получение решения", "basis": "путь клиента",
                "fields": {"4.2.1": {"value": "Клиент получает решение по обращению.",
                                     "source": "Установлено: " + "подробное обоснование " * 20}},
                "explanation": "длинное объяснение структуры",
                "fact_check": {"execution": {"evidence": [{"id": "evidence-7", "quote": quote}]},
                               "fields": {"4.2.1": {"support": "code", "evidence": [{"id": "evidence-3", "quote": quote}]}}}}

    def test_old_submissions_keep_meaning_and_drop_citations(self):
        quote = "12: def handle(request): return route(request)"
        messages = [{"role": "system", "content": "s"}, {"role": "user", "content": "u"},
                    answer(1, name="submit_node", args=self._node_args(quote)),
                    reply(1, "journey-1 отклонён (основания):\n- 4.2.1: в цитатах нет имени"),
                    answer(2, name="submit_node", args=self._node_args(quote)),
                    reply(2, "journey-1 «Получение решения» принят.\nПостроено: …"),
                    answer(3), reply(3, "{}"), answer(4), reply(4, "{}")]
        recent = [json.dumps(m, ensure_ascii=False) for m in messages[-4:]]
        _compact_history(messages)

        rejected = json.loads(messages[2]["tool_calls"][0]["function"]["arguments"])
        self.assertEqual(rejected["id"], "journey-1")
        self.assertIn("отклонённая", rejected[_FOLD_MARK])
        self.assertNotIn("fields", rejected)

        accepted = json.loads(messages[4]["tool_calls"][0]["function"]["arguments"])
        self.assertEqual(accepted["fields"]["4.2.1"]["value"], "Клиент получает решение по обращению.")
        self.assertLessEqual(len(accepted["fields"]["4.2.1"]["source"]), 121)
        self.assertEqual(accepted["evidence_ids"], ["evidence-3", "evidence-7"])
        self.assertIn("read_node", accepted[_FOLD_MARK])
        dumped = json.dumps(accepted, ensure_ascii=False)
        for gone in ("fact_check", "explanation", quote):
            self.assertNotIn(gone, dumped)
        # Два последних ответа модели уходят целиком.
        self.assertEqual([json.dumps(m, ensure_ascii=False) for m in messages[-4:]], recent)

        # Повторная свёртка ничего не меняет: начало запроса стабильно.
        calls = messages[4]["tool_calls"]
        _compact_history(messages)
        self.assertIs(messages[4]["tool_calls"], calls)

    def test_read_node_returns_what_the_history_no_longer_carries(self):
        state = _PassportSession()
        node = _Node(id="bbb-1", name="Регистрация", basis="шаг сценария")
        node.filled, node.data = True, {"fields": {"4.4.1": {"value": "Заводит заявку", "source": "Установлено: x.py:3"}},
                                         "fact_check": {"fields": {"4.4.1": {"evidence": [{"id": "evidence-2", "quote": "3: save()"}]}}}}
        state.nodes["bbb-1"] = node
        data = json.loads(_handle_read_node(state, {"id": "bbb-1"}))
        self.assertEqual(data["fact_check"]["fields"]["4.4.1"]["evidence"][0]["quote"], "3: save()")
        self.assertIn("не принят", _handle_read_node(state, {"id": "bbb-9"}))


class KnowledgeIndexTest(unittest.TestCase):
    def test_trail_becomes_an_index_with_corpus_ids(self):
        entry = "[read_file app/service.py:1-400 — def register(), def deliver(), class Queue] " + "x" * 200
        text = render_evaluation_digest([], [], None, [entry, "[search route — 3 совпадения]"],
                                        {1: "evidence-2", 2: "evidence-3"})
        self.assertIn("evidence-2: [read_file app/service.py:1-400 — def register()", text)
        self.assertIn("evidence-3: [search route — 3 совпадения]", text)
        self.assertNotIn("x" * 50, text)
        long_trail = [f"[read_file f{i}.py:1-400 — def f{i}()]" for i in range(2000)]
        capped = render_evaluation_digest([], [], None, long_trail, {i: f"evidence-{i}" for i in range(1, 2001)})
        self.assertIn("найти — search_passport_evidence", capped)
        self.assertLess(len(capped), 13_000)

    def test_without_corpus_the_full_trail_stays(self):
        entry = "[read_file app.py:1-40 — def select()] " + "y" * 150
        self.assertIn(entry, render_evaluation_digest([], [], None, [entry]))


if __name__ == "__main__":
    unittest.main()
