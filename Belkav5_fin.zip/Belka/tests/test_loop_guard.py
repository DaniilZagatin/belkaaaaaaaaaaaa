"""Агент не ходит по кругу: короткие циклы вызовов и шаги паспорта без результата.

Модель подставная и нарочно циклится; проверяется, чем и когда сессия
остановлена. Разбор и строгая проверка заморожены эталоном — у них прежнее
правило «три одинаковых вызова подряд» (`test_progress_matcher`).
"""

from __future__ import annotations

import json
import os
import unittest
from unittest import mock

from fixture_support import ensure_fixture
from pko.extractors.base import Tree
from pko.git.repo import GitRepo
from pko.llm.client import ChatResult
from pko.progress.coherence import run_coherence
from pko.progress.loop_guard import cycle_text, repeating_cycle
from pko.progress.passport_agent import IDLE_STEPS_NUDGE, IDLE_STEPS_STOP, run_passport_agent
from test_passport_evidence import corpus_fixture
from test_passport_gate import SPEC
from test_progress_coherence import result_of


class LoopingModel:
    """Модель, которая по кругу отдаёт одни и те же вызовы инструментов."""

    def __init__(self, *pattern):
        self.pattern, self.calls, self.seen = pattern, 0, []

    def chat(self, messages, **kwargs):
        self.seen = list(messages)
        item = self.pattern[self.calls % len(self.pattern)]
        name, args = item(self.calls) if callable(item) else item
        self.calls += 1
        return ChatResult(text="", usage={}, tool_calls=[{
            "id": f"call_{self.calls}", "type": "function",
            "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)}}])


READ_A = ("read_file", {"path": "backend/src/agent/graph.py"})
READ_B = ("read_file", {"path": "backend/src/agent/tools.py"})
EVIDENCE_A = ("read_passport_evidence", {"ids": ["evidence-1"]})
EVIDENCE_B = ("read_passport_evidence", {"ids": ["evidence-2"]})


class RepeatingCycleTest(unittest.TestCase):
    def test_detects_only_short_cycles_repeated_three_times(self):
        self.assertEqual(repeating_cycle(list("aaa")), 1)
        self.assertEqual(repeating_cycle(list("ababab")), 2)
        self.assertEqual(repeating_cycle(list("xabcabcabc")), 3)
        for history in ("aa", "ababa", "abab", "abcdabcdabcd", "aabab"):
            self.assertEqual(repeating_cycle(list(history)), 0, history)
        self.assertEqual(cycle_text(1), "3 одинаковых вызова подряд")


class CoherenceLoopTest(unittest.TestCase):
    def test_alternating_reads_stop_after_three_rounds(self):
        repo = GitRepo(ensure_fixture())
        model = LoopingModel(READ_A, READ_B)
        with mock.patch.dict(os.environ, {"PKO_COHERENCE": "true"}):
            out = run_coherence(result_of(), Tree.at(repo, repo.resolve("master")), SPEC, client=model)
        self.assertEqual(model.calls, 6)
        self.assertIn("цикл из 2 вызовов повторился 3 раза подряд", " ".join(out.notes))


class PassportLoopTest(unittest.TestCase):
    def _run(self, *pattern):
        model = LoopingModel(*pattern)
        result = run_passport_agent([], {}, [], None, SPEC, client=model, evidence_corpus=corpus_fixture())
        return model, " ".join(result.notes)

    def test_same_call_and_short_cycles_stop_early(self):
        for pattern, calls in (((EVIDENCE_A,), 3), ((EVIDENCE_A, EVIDENCE_B), 6)):
            with self.subTest(pattern=pattern):
                model, notes = self._run(*pattern)
                self.assertEqual(model.calls, calls)
                self.assertIn("паспорт: остановлено — ", notes)

    def test_paging_an_empty_search_is_nudged_then_stopped(self):
        # Живой агент листал пустую выдачу, прибавляя к offset по единице:
        # вызовы разные, а в паспорт ничего не попадает.
        model, notes = self._run(lambda i: ("search_passport_evidence", {"query": '"part": "1"', "offset": 47 + i}))
        self.assertEqual(model.calls, IDLE_STEPS_STOP)
        self.assertIn(f"шагов подряд: {IDLE_STEPS_STOP}", notes)
        self.assertIn("search_passport_evidence ×", notes)
        nudges = [m for m in model.seen if m.get("role") == "user"
                  and "в паспорт ничего не принято" in str(m.get("content"))]
        self.assertEqual(len(nudges), 1)
        self.assertIn('submit_node(id="journey-1")', nudges[0]["content"])
        self.assertLess(IDLE_STEPS_NUDGE, IDLE_STEPS_STOP)

    def test_empty_search_page_says_there_is_nothing_further(self):
        corpus = corpus_fixture()
        page = corpus.index('"part": "1"', offset=47)
        self.assertEqual(page["records"], [])
        self.assertIn("листать дальше нечего", page["note"])
        self.assertNotIn("note", corpus.index(""))


if __name__ == "__main__":
    unittest.main()
