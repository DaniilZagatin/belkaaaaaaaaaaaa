"""CLI journal and persistent exporter: live state, final duration, no duplicate replay."""

from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

try:
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor
    from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
except ImportError:  # трассировка — необязательная зависимость
    TracerProvider = None

from pko.audit import audit_run
from pko.llm import tracing
from pko.llm.tracing import trace_span
from pko.monitor_exporter import EventMetrics, STALE_AFTER_SECONDS
from pko.monitoring import (
    monitored_cli_run, observe_span, record_llm_call, record_llm_call_started,
    record_llm_wait_finished, current_run,
)


class DisabledMonitoringTest(unittest.TestCase):
    def test_default_and_explicit_off_have_no_monitoring_io_or_thread(self):
        for value in (None, "false", "0", "off", ""):
            with self.subTest(value=value), tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ):
                os.environ.pop("PKO_MONITOR_ENABLED", None)
                if value is not None:
                    os.environ["PKO_MONITOR_ENABLED"] = value
                with patch("pko.monitoring.monitor_dir", side_effect=AssertionError("monitoring directory accessed")), \
                     patch("pko.monitoring.threading.Thread", side_effect=AssertionError("heartbeat started")):
                    with monitored_cli_run() as journal, audit_run(Path(tmp) / "audit.txt", journal.run_id):
                        self.assertIsNone(journal.path)
                        self.assertIs(current_run(), journal)
                        with observe_span("passport_session", {}):
                            with observe_span("passport.step", {"step": 7}):
                                self.assertEqual((journal.phase, journal.step), ("passport", 7))
                                record_llm_call(duration_seconds=1, result="success", usage={"completion_tokens": 5})
                        self.assertEqual(journal.phase, "between_passes")
                    self.assertIsNone(current_run())
                audit = (Path(tmp) / "audit.txt").read_text(encoding="utf-8")
                self.assertIn('"event": "pass_started"', audit)
                self.assertIn('"event": "llm_call_finished"', audit)
                self.assertIn('"event": "run_finished"', audit)

    @unittest.skipIf(TracerProvider is None, "нужен arize-phoenix-otel (requirements-phoenix.txt)")
    def test_phoenix_root_and_four_sessions_keep_run_correlation_when_disabled(self):
        exporter = InMemorySpanExporter()
        provider = TracerProvider(span_limits=tracing.span_limits())
        provider.add_span_processor(SimpleSpanProcessor(exporter))
        with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ, {"PKO_MONITOR_ENABLED": "false"}),              patch("pko.llm.tracing._tracer", provider.get_tracer("test")):
            path = Path(tmp) / "audit.txt"
            with monitored_cli_run() as journal, audit_run(path, journal.run_id):
                with trace_span("pko.progress"):
                    for name in ("agent_session", "critic_session", "coherence_session", "passport_session"):
                        with trace_span(name):
                            pass
                self.assertIsNone(journal.path)
            spans = sorted(exporter.get_finished_spans(), key=lambda span: span.start_time)
            names = {span.context.span_id: span.attributes["pko.span"] for span in spans}
            self.assertEqual([names.get(span.parent.span_id) if span.parent else None for span in spans],
                             [None] + ["pko.progress"] * 4)
            for span in spans:
                self.assertEqual(span.attributes["pko.run_id"], journal.run_id)
                self.assertEqual(span.attributes["session.id"], journal.run_id)
            self.assertEqual(path.read_text(encoding="utf-8").count('"event": "phoenix_span"'), 5)


class MonitoringTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.previous = os.environ.get("PKO_MONITOR_DIR")
        os.environ["PKO_MONITOR_DIR"] = self.tmp.name
        self.addCleanup(self._restore_env)
        enabled = patch.dict(os.environ, {"PKO_MONITOR_ENABLED": "true"})
        enabled.start()
        self.addCleanup(enabled.stop)

    def _restore_env(self):
        if self.previous is None:
            os.environ.pop("PKO_MONITOR_DIR", None)
        else:
            os.environ["PKO_MONITOR_DIR"] = self.previous

    def test_live_steps_and_persistent_metrics(self):
        metrics = EventMetrics(Path(self.tmp.name))
        with monitored_cli_run() as journal:
            with observe_span("agent_session", {}) as span:
                with observe_span("agent.step", {"step": 1}):
                    record_llm_call_started()
                    record_llm_wait_finished()
                    record_llm_call(duration_seconds=2.5, result="success",
                                    usage={"prompt_tokens": 120, "completion_tokens": 30})
                span.set_attribute("steps_done", 1)
                span.set_attribute("finished", True)
            with observe_span("passport_session", {}) as span:
                span.add_event("risks_rejected", {"count": 2, "secret": "must-not-log"})
                span.add_event("node_accepted", {"count": 3})
                span.set_attribute("steps_done", 0)
                span.set_attribute("finished", False)
            live = metrics.render()
            self.assertIn("pko_active_runs 1", live)
            self.assertIn('pko_steps_total{pass="matcher"} 1', live)
            self.assertIn('pko_llm_tokens_total{pass="matcher",type="prompt"} 120', live)
            self.assertIn(f'pko_latest_run_info{{run_id="{journal.run_id}"}} 1', live)
            self.assertIn(f'pko_run_nodes{{run_id="{journal.run_id}"}} 3', live)
            self.assertIn(f'pko_run_llm_tokens_total{{run_id="{journal.run_id}",pass="matcher"', live)
            self.assertIn(f'pko_run_steps_completed{{run_id="{journal.run_id}",pass="matcher"', live)
            self.assertIn(f'pko_run_step_avg_duration_seconds{{run_id="{journal.run_id}",pass="matcher"', live)
            self.assertIn(f'pko_run_llm_response_avg_seconds{{run_id="{journal.run_id}",pass="matcher"', live)

        final = metrics.render()
        self.assertIn("pko_active_runs 0", final)
        self.assertIn('pko_runs_total{result="success"} 1', final)
        self.assertIn('pko_pass_results_total{pass="passport",result="incomplete"} 1', final)
        self.assertIn('pko_gate_rejections_total{pass="passport",kind="risks_rejected"} 1', final)
        self.assertIn("pko_run_duration_seconds_count 1", final)
        metrics.render()  # repeated scrape does not replay completed records
        self.assertEqual(metrics.run_results["success"], 1)
        self.assertEqual(metrics.steps["matcher"], 1)

        records = [json.loads(line) for line in journal.path.read_text(encoding="utf-8").splitlines()]
        self.assertEqual(records[0]["run_id"], journal.run_id)
        self.assertEqual(records[-1]["event"], "run_finished")
        self.assertTrue(any(event["event"] == "llm_call_started" for event in records))
        self.assertTrue(any(event["event"] == "llm_wait_finished" for event in records))
        self.assertTrue(all("secret" not in event for event in records))

        restarted = EventMetrics(Path(self.tmp.name))
        self.assertIn('pko_runs_total{result="success"} 1', restarted.render())

    def test_error_and_stale_run(self):
        with self.assertRaises(ValueError):
            with monitored_cli_run():
                raise ValueError("private error detail")
        metrics = EventMetrics(Path(self.tmp.name))
        self.assertIn('pko_runs_total{result="error"} 1', metrics.render())
        self.assertNotIn("private error detail", "".join(
            path.read_text(encoding="utf-8") for path in Path(self.tmp.name).glob("*.jsonl")))

        metrics.ingest({"event": "run_started", "run_id": "run_orphan", "at": 100.0})
        text = metrics.render(now=100.0 + STALE_AFTER_SECONDS + 1)
        self.assertIn("pko_stale_runs 1", text)

        metrics.ingest({"event": "run_started", "run_id": "run_alive", "at": 200.0})
        metrics.ingest({"event": "heartbeat", "run_id": "run_alive",
                        "at": 200.0 + STALE_AFTER_SECONDS - 1,
                        "pass": "coherence", "step": 7, "nodes": 12})
        text = metrics.render(now=200.0 + STALE_AFTER_SECONDS + 10)
        self.assertIn('pko_run_current_step{run_id="run_alive",pass="coherence"', text)
        self.assertIn('pko_run_nodes{run_id="run_alive"} 12', text)

    def test_live_llm_wait_and_completed_steps_are_per_run(self):
        metrics = EventMetrics(Path(self.tmp.name))
        metrics.ingest({"event": "run_started", "run_id": "run_one", "at": 100.0})
        metrics.ingest({"event": "pass_started", "run_id": "run_one", "at": 101.0,
                        "pass": "matcher"})
        metrics.ingest({"event": "step_started", "run_id": "run_one", "at": 102.0,
                        "pass": "matcher", "step": 1})
        metrics.ingest({"event": "llm_call_started", "run_id": "run_one", "at": 103.0,
                        "pass": "matcher"})
        live = metrics.render(now=108.0)
        self.assertIn('pko_run_llm_wait_elapsed_seconds{run_id="run_one"} 5.0', live)
        self.assertIn('pko_run_steps_completed{run_id="run_one",pass="matcher",', live)
        self.assertNotIn('pko_run_step_duration_seconds{run_id="run_one"', live)

        metrics.ingest({"event": "llm_wait_finished", "run_id": "run_one", "at": 110.0,
                        "pass": "matcher"})
        metrics.ingest({"event": "llm_call_finished", "run_id": "run_one", "at": 111.0,
                        "pass": "matcher", "result": "success", "from_cache": False,
                        "duration_seconds": 8.0})
        metrics.ingest({"event": "step_finished", "run_id": "run_one", "at": 112.0,
                        "pass": "matcher", "step": 1, "duration_seconds": 10.0})
        finished = metrics.render(now=113.0)
        self.assertIn('pko_run_llm_wait_elapsed_seconds{run_id="run_one"} 0', finished)
        self.assertIn('pko_run_llm_response_avg_seconds{run_id="run_one",pass="matcher",pass_label="1 · Разбор пунктов"} 7.0', finished)
        self.assertIn('pko_run_steps_completed{run_id="run_one",pass="matcher",pass_label="1 · Разбор пунктов"} 1', finished)
        self.assertIn('pko_run_step_avg_duration_seconds{run_id="run_one",pass="matcher",pass_label="1 · Разбор пунктов"} 10.0', finished)


if __name__ == "__main__":
    unittest.main()
