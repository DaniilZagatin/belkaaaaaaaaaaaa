"""Остановка агента, который ходит по кругу одними и теми же вызовами.

Правило первого агента — три одинаковых вызова подряд — не видит цикла из
двух-трёх разных вызовов: агент, который по очереди читает два файла, дожигал
весь бюджет шагов. Здесь то же правило обобщено: история вызовов кончается
одним и тем же коротким циклом, повторённым `CYCLE_REPEATS` раз подряд.

Цикл с меняющимися аргументами (поиск со сдвигом offset на единицу) так не
ловится: против него у паспорта отдельный счётчик шагов без принятого
результата (`passport_agent.IDLE_STEPS_STOP`).
"""

from __future__ import annotations

from typing import Hashable, Sequence

from pko.progress.matcher import _REPEAT_STOP

# Самый длинный цикл, который ловится. Сколько раз он должен повториться —
# как у первого агента: цикл длины 1 и есть его «три одинаковых подряд».
MAX_CYCLE = 3
CYCLE_REPEATS = _REPEAT_STOP


def repeating_cycle(signatures: Sequence[Hashable]) -> int:
    """Длина цикла, которым кончается история вызовов, или 0."""
    for period in range(1, MAX_CYCLE + 1):
        window = period * CYCLE_REPEATS
        if len(signatures) < window:
            break
        tail = signatures[-window:]
        if all(tail[i] == tail[i % period] for i in range(window)):
            return period
    return 0


def cycle_text(period: int) -> str:
    if period == 1:
        return f"{CYCLE_REPEATS} одинаковых вызова подряд"
    return f"цикл из {period} вызовов повторился {CYCLE_REPEATS} раза подряд"
