"""Окно рассуждений: модели уходят рассуждения только последних шагов.

В цикле вызовов инструментов эндпоинт получает обратно рассуждения всех
прошлых шагов: агент кладёт их в историю вместе с вызовом. На живом прогоне
к 30-му шагу паспорта они занимали 44% входа, и каждый шаг платил за них
заново. Модели для следующего хода нужен свой недавний ход мысли, а не
рассуждения тридцатишаговой давности: решения тех шагов уже лежат в истории
вызовами и ответами инструментов.

Эндпоинты ведут себя по-разному: одни сами выбрасывают прошлые рассуждения,
другие требуют их обратно в цепочке вызовов инструментов. Поэтому окно с
откатом: если эндпоинт отклонил запрос из-за рассуждений, они возвращаются
в историю, запрос повторяется, и до конца сессии окно выключено.

Рассуждение убирается у ответа, который только что выпал из окна, а более
старые уже убраны: начало запроса от шага к шагу не меняется, и кеш
префикса у эндпоинтов, которые его держат, продолжает работать.
"""

from __future__ import annotations

from typing import Any

from pko.audit import record
from pko.errors import LlmError

# Сколько последних ответов модели сохраняют рассуждение.
KEEP_REASONING_STEPS = 2


class ReasoningWindowClient:
    """Клиент, который перед вызовом убирает из истории старые рассуждения.

    История правится на месте: агент, журнал и трассировка видят ровно то,
    что ушло модели, а расчёт бюджета истории у связности — настоящий размер.
    """

    def __init__(self, delegate: Any, keep: int = KEEP_REASONING_STEPS) -> None:
        self.delegate = delegate
        self.keep = keep
        self.enabled = True
        self._removed: list[tuple[dict[str, Any], Any]] = []

    def __getattr__(self, name: str) -> Any:
        return getattr(self.delegate, name)

    def chat(self, messages: list[dict[str, Any]], **kwargs: Any) -> Any:
        if self.enabled:
            self._trim(messages)
        try:
            return self.delegate.chat(messages, **kwargs)
        except LlmError as exc:
            if not self._removed or not _about_reasoning(exc):
                raise
            for message, reasoning in self._removed:
                message["reasoning_content"] = reasoning
            self._removed.clear()
            self.enabled = False
            record("reasoning_window_disabled", error=exc.message, hint=exc.hint)
            return self.delegate.chat(messages, **kwargs)

    def _trim(self, messages: list[dict[str, Any]]) -> None:
        answers = [m for m in messages if m.get("role") == "assistant"]
        for message in answers[:max(0, len(answers) - self.keep)]:
            reasoning = message.get("reasoning_content")
            if reasoning:
                self._removed.append((message, reasoning))
                message["reasoning_content"] = None


def reasoning_window(client: Any, spec: Any) -> ReasoningWindowClient:
    """Окно рассуждений поверх клиента прохода; без клиента — штатный ChatClient."""
    if client is None:
        from pko.llm.client import ChatClient
        client = ChatClient(spec=spec)
    return ReasoningWindowClient(client)


def _about_reasoning(exc: LlmError) -> bool:
    text = f"{exc.message} {exc.hint}".lower()
    return "reasoning" in text or "thinking" in text
