"""Present calculation inputs and accepted evidence without assigning statuses."""
from pko.progress.risk_review import CHECKS


def explain_node(node, raw, children, criteria):
    lines = ["Статус: " + node.get("implementation_label", "Недостаточно данных") + "."]
    signals = node.get("assessment_inputs") or {}
    if signals:
        lines.append("По описанию реализации: " + signals.get("fields", "Недостаточно данных")
                     + ". По требованиям инициативы: " + signals.get("criteria", "Недостаточно данных") + ".")
        if signals.get("field_note"):
            lines.append("Причина: " + signals["field_note"])
    if node.get("planned"):
        lines.append("Узел отмечен как планируемый: реализация в переданных материалах не найдена.")
    if raw.get("explanation") or node.get("basis"):
        lines.append("Роль узла: " + (raw.get("explanation") or node["basis"]))
    for bullet in node.get("bullets") or []:
        criterion = criteria.get(bullet["text"])
        lines.append("Требование: " + bullet["text"] + "\nОценка: " + bullet["status_label"]
                     + "\nЧто найдено: " + (bullet.get("actual") or "Объяснение не сохранено."))
        if criterion:
            for ev in criterion.verified_evidence:
                lines.append(f"Подтверждённая ссылка: {ev.path}:{ev.line} — {ev.basis}" + (f". {ev.note}" if ev.note else ""))
    if node.get("readiness") is not None:
        lines.append("Полнота по требованиям: " + str(node["readiness"]) + "% с учётом частичной реализации.")
    for child in children:
        lines.append("Дочерний шаг: " + child["name"] + " — " + child.get("implementation_label", ""))
    return "\n\n".join(lines)


def risk_review_data(passport):
    review = passport.get("risk_review") or {}
    labels = {"finding": "Найден риск", "no_finding": "Обоснованная находка не получена",
              "unknown": "Недостаточно данных", "not_applicable": "Неприменимо"}
    return {**review, "check_labels": CHECKS, "result_labels": labels}
