"""Copy the single editable passport template into built Python distributions."""
from pathlib import Path

from setuptools import setup
from setuptools.command.build_py import build_py


class BuildWithPassportTemplate(build_py):
    def run(self):
        super().run()
        source = Path(__file__).parent / "passport-dpss-v3.html"
        destination = Path(self.build_lib) / "pko" / "render" / source.name
        self.mkpath(str(destination.parent))
        self.copy_file(str(source), str(destination))


setup(cmdclass={"build_py": BuildWithPassportTemplate})
