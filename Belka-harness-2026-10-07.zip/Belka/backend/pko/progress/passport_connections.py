"""Evidence-backed review of required process connections, including missing edges.

This is research coverage, not another product score. The independent reviewer
checks the conclusions against code and the current graph, not a checklist tick.
"""
from copy import deepcopy

from pko.progress.passport_workspace import REFS, IDS, TEXT, digest, tool_schema

CONNECTION_ASPECTS = ("input", "output", "dependencies", "recovery")
CONNECTION_SCHEMA = tool_schema(
    "submit_connection_review",
    "Проверить необходимые связи одного процесса, включая отсутствующие на схеме: вход, получатель результата, зависимости, восстановление. "
    "Передай полный checks по четырём аспектам. Это исследование связей, не оценка готовности; выводы проверяются независимо.",
    {"process": TEXT, "checks": {"type": "array", "minItems": 4, "maxItems": 4, "items": {
        "type": "object", "properties": {
            "aspect": {"type": "string", "enum": list(CONNECTION_ASPECTS)},
            "result": {"type": "string", "enum": ["supported", "finding", "unknown", "not_applicable"]},
            "detail": {"type": "string", "minLength": 30, "maxLength": 2000},
            "nodes": {**IDS, "maxItems": 32}, "relations": {**IDS, "maxItems": 32},
            "evidence": {**REFS, "maxItems": 12}, "finding_ids": {**IDS, "maxItems": 16}},
        "required": ["aspect", "result", "detail", "nodes", "relations", "evidence"]}}},
    ["process", "checks"],
)


def _relation_id(row):
    return "relation:" + ":".join(str(row[k]) for k in ("from", "to", "kind"))


def submit_connection_review(state, args):
    prefix = "submit_connection_review отклонён: "
    if state.research_basis != "code":
        return prefix + "инструмент доступен только для исследования по коду."
    pid, checks = args.get("process"), args.get("checks")
    if not isinstance(pid, str) or pid not in state.nodes or not pid.startswith("process-") or not state.nodes[pid].filled:
        return prefix + "process — заполненный бизнес-процесс."
    if not isinstance(checks, list) or len(checks) != len(CONNECTION_ASPECTS):
        return prefix + "checks покрывает input, output, dependencies, recovery ровно по одному разу."
    relations = {_relation_id(r): r for r in state.relations}
    flaws = getattr(state.system_research_state, "records", {})
    defects = {"defect:" + str(row.get("id")) for row in state.defects}
    seen, normalized = set(), []
    for row in checks:
        if not isinstance(row, dict):
            return prefix + "каждая проверка — объект."
        aspect, result = row.get("aspect"), row.get("result")
        if not isinstance(aspect, str) or aspect not in CONNECTION_ASPECTS or aspect in seen:
            return prefix + "неизвестный или повторный аспект."
        seen.add(aspect)
        if result not in ("supported", "finding", "unknown", "not_applicable"):
            return prefix + "неизвестный результат проверки."
        detail = row.get("detail")
        if not isinstance(detail, str) or not 30 <= len(detail.strip()) <= 2000:
            return prefix + "detail объясняет механизм, источник/получателя и границу проверки (30–2000 символов)."
        nodes, links, refs = row.get("nodes"), row.get("relations"), row.get("evidence")
        if not isinstance(nodes, list) or len(nodes) > 32 or any(not isinstance(n, str) or n not in state.nodes for n in nodes):
            return prefix + "nodes содержит только действующие узлы."
        if not isinstance(links, list) or len(links) > 32 or any(not isinstance(r, str) or r not in relations for r in links):
            return prefix + "relations содержит только действующие ID relation:<from>:<to>:<kind>."
        for rid in links:
            edge = relations[rid]
            if not {edge["from"], edge["to"]} <= set(nodes) | {pid}:
                return prefix + "укажи оба конца проверяемой связи в nodes (процесс включён автоматически)."
        if state.evidence_corpus is None:
            return prefix + "нужен корпус прочитанных оснований."
        if not isinstance(refs, list) or len(refs) > 12:
            return prefix + "evidence — не более 12 точных цитат на аспект."
        errors = state.evidence_corpus.citations(refs, code=True, required=result != "unknown")
        if errors:
            return prefix + "; ".join(errors)
        finding_ids = row.get("finding_ids", [])
        if not isinstance(finding_ids, list) or len(finding_ids) > 16 or any(not isinstance(fid, str) or fid not in defects and
                not (fid.startswith("system:flaw-") and fid in flaws) for fid in finding_ids):
            return prefix + "finding_ids — сохранённые defect:<id> или system:flaw-N."
        if result == "finding" and not finding_ids:
            return prefix + "находку сначала сохрани через submit_defect/submit_flaw и укажи finding_ids."
        normalized.append({"aspect": aspect, "result": result, "detail": detail.strip(),
                           "nodes": list(dict.fromkeys(nodes)), "relations": list(dict.fromkeys(links)),
                           "evidence": deepcopy(refs), "finding_ids": list(dict.fromkeys(finding_ids))})
    value = {"process": pid, "checks": sorted(normalized, key=lambda row: CONNECTION_ASPECTS.index(row["aspect"]))}
    if state.connection_review.get(pid) != value:
        state.workspace.event("connection_review", previous=state.connection_review.get(pid), value=value)
        state.connection_review[pid] = value
        state.risk_reviewed = False
    return "Проверка необходимых связей сохранена; нужна независимая проверка текущей версии."


def sync_connection_objects(state):
    if state.research_basis != "code":
        return set()
    live = set()
    # All connections can reveal an omitted supplier/consumer, so the whole
    # bounded graph is a dependency. Hash raw state to avoid reviewer cycles.
    graph = {"nodes": {nid: {"data": n.data, "parents": n.parents, "children": n.children}
                       for nid, n in state.nodes.items()}, "relations": state.relations,
             "scenarios": state.scenarios, "scenario_context": state.scenario_context,
             "defects": state.defects,
             "traces": {oid: obj["revision"] for oid, obj in state.workspace.objects.items()
                        if oid.startswith(("scenario:", "trace:"))},
             "system_findings": getattr(state.system_research_state, "records", {})}
    revision = digest(graph)
    for pid, row in state.connection_review.items():
        oid = "connection-review:" + pid
        live.add(oid)
        neighbours = {n for check in row["checks"] for n in check["nodes"]} | {pid}
        checks = [{**check, "evidence": [{"id": ref["id"]} for ref in check["evidence"]]}
                  for check in row["checks"]]
        finding_ids = {fid for check in row["checks"] for fid in check["finding_ids"]}
        defects = {"defect:" + str(d.get("id")): d for d in state.defects}
        defects.update({fid: record.get("value", {}) for fid, record in
                        getattr(state.system_research_state, "records", {}).items() if fid.startswith("system:flaw-")})
        # The receipt depends on the full graph. Its display context is explicitly
        # bounded; literal conclusions/quotes remain in the research ledger and
        # the reviewer must inspect sources, not infer completeness from a preview.
        node_ids = list(dict.fromkeys([pid, *sorted(neighbours), *state.nodes]))
        node_ids = [n for n in node_ids if n in state.nodes][:80]
        selected_links = {rid for check in row["checks"] for rid in check["relations"]}
        edges = sorted(state.relations, key=lambda r: (_relation_id(r) not in selected_links, _relation_id(r)))[:120]
        selected_findings = sorted(finding_ids)[:8]
        state.workspace.put(oid, "claim", {"process": pid, "checks": checks,
            "submission_revision": digest(row), "research_basis": "code", "graph_revision": revision,
            "context_scope": {"kind": "bounded_preview", "nodes_total": len(state.nodes),
                              "nodes_shown": len(node_ids), "relations_total": len(state.relations),
                              "relations_shown": len(edges), "findings_total": len(finding_ids),
                              "findings_shown": len(selected_findings),
                              "note": "Названия до 120, описание изъяна до 400 символов; это подсказки, не полные выводы. Проверь источники самостоятельно."},
            "findings_context": {fid: {k: str(defects.get(fid, {}).get(k) or "")[:400] for k in
                                 ("title", "kind", "detail", "where")} for fid in selected_findings},
            "graph_nodes": [{"id": n, "name": state.nodes[n].name[:120], "parents": state.nodes[n].parents[:16]} for n in node_ids],
            "graph_relations": [{k: r.get(k) for k in ("from", "to", "kind")} for r in edges]})
    return live


def connection_blockers(state):
    if state.research_basis != "code":
        return []
    errors = [f"{node.id}: нет проверки необходимых связей (submit_connection_review)"
              for node in state.of_type("process") if node.id not in state.connection_review]
    nodes, relations = set(state.nodes), {_relation_id(r) for r in state.relations}
    findings = {"defect:" + str(row.get("id")) for row in state.defects}
    findings.update(getattr(state.system_research_state, "records", {}))
    for pid, row in state.connection_review.items():
        if pid not in nodes:
            errors.append(f"проверка связей {pid}: процесс отозван; пересмотри исследование")
        for check in row["checks"]:
            if (set(check["nodes"]) - nodes or set(check["relations"]) - relations
                    or set(check["finding_ids"]) - findings):
                errors.append(f"проверка связей {pid}/{check['aspect']}: есть отозванные ссылки; пересмотри проверку")
    return errors
