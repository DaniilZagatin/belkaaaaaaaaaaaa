"""Source-path policy shared by passport preparation and the evidence broker.

The frozen reviewer keeps its own reader. Passport preparation must not bypass
the stricter broker policy before that broker has been constructed.
"""
from typing import Any

from pko.extractors.base import is_vendor
from pko.progress.agent_tools import _is_blocked


def safe_source_path(path: Any) -> bool:
    return (isinstance(path, str) and 0 < len(path) <= 512 and path == path.strip()
            and not any(ord(char) < 32 or ord(char) == 127 for char in path)
            and not any(char in path for char in "\\:")
            and not path.startswith("/")
            and all(part not in {"", ".", ".."} for part in path.split("/")))


def allowed_source_path(path: Any) -> bool:
    return (safe_source_path(path) and not is_vendor(path)
            and not any(_is_blocked(part) for part in path.split("/")))


def available_source_path(tree: Any, path: Any) -> bool:
    return (allowed_source_path(path)
            and path in getattr(tree, "files_set", getattr(tree, "files", ())))
