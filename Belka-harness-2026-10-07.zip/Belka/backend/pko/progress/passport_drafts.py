"""Versioned node proposals: amend a field, then revalidate the whole proposal.

Drafts are not accepted nodes and never establish a status or a citation.
"""
from __future__ import annotations

from copy import deepcopy
import json
from typing import Any, Callable

from pko.progress.passport_workspace import digest


def _node_revision(node: Any) -> str:
    return digest({'name': node.name, 'basis': node.basis, 'data': node.data,
                   'parents': node.parents, 'children': node.children,
                   'branching': node.branching, 'before_fork': node.before_fork})


def _object(value: Any) -> Any:
    if isinstance(value, str):
        try:
            return json.loads(value)
        except ValueError:
            return value
    return value


def _merge(previous: dict, patch: dict) -> dict:
    result = deepcopy(previous)
    for key, value in patch.items():
        if key in ('patch', 'draft_revision', 'draft', 'field_contract', 'filled', 'type'):
            continue
        if key == 'fields':
            cells = _object(value)
            before = _object(result.get(key))
            result[key] = {**before, **deepcopy(cells)} if isinstance(cells, dict) and isinstance(before, dict) else deepcopy(cells)
        elif key == 'fact_check':
            audit, before = _object(value), _object(result.get(key))
            if isinstance(audit, dict) and isinstance(before, dict):
                merged = {**before, **deepcopy(audit)}
                if isinstance(audit.get('fields'), dict) and isinstance(before.get('fields'), dict):
                    merged['fields'] = {**before['fields'], **deepcopy(audit['fields'])}
                result[key] = merged
            else:
                result[key] = deepcopy(audit)
        else:
            result[key] = deepcopy(value)
    return result


def submit(state: Any, args: dict, validate: Callable[[Any, dict], str]) -> str:
    nid = str(args.get('id') or '').strip()
    if nid not in state.nodes:
        return validate(state, args)
    previous = state.node_drafts.get(nid)
    if 'patch' in args and type(args['patch']) is not bool:
        return 'submit_node отклонён: patch должен быть true или false.'
    if args.get('patch'):
        version = args.get('draft_revision')
        if not previous or type(version) is not int or version != previous['revision']:
            return f'{nid} отклонён: правка требует актуальный draft_revision; прочитай read_node(id).'
        if previous.get('base_node_revision') != _node_revision(state.nodes[nid]):
            return (f'{nid} отклонён: узел изменён другим инструментом после этой заявки. '
                    'Прочитай read_node(id) и отправь новую полную заявку по текущему узлу, '
                    'учитывая ещё не принятые исправления; прежние привязки автоматически не возвращаются.')
        proposal = _merge(previous['proposal'], args)
    else:
        proposal = {key: deepcopy(value) for key, value in args.items()
                    if key not in ('patch', 'draft_revision', 'draft', 'field_contract', 'filled', 'type')}
    # Save before validation: a rejected draft remains available after context
    # compaction, and changing one field cannot discard unrelated obligations.
    revision = (previous['revision'] if previous else 0) + 1
    draft = {'revision': revision, 'proposal': deepcopy(proposal), 'accepted': False, 'feedback': ''}
    state.node_drafts[nid] = draft
    feedback = validate(state, proposal)
    accepted = feedback.startswith(f'{nid} «') and 'принят.' in feedback.split('\n', 1)[0]
    draft['accepted'] = accepted
    draft['base_node_revision'] = _node_revision(state.nodes[nid])
    if accepted:
        node = state.nodes[nid]
        # Keep the canonical version so generated links and independently
        # established metadata are not lost on a later small edit.
        draft['proposal'] = {'id': nid, 'name': node.name, 'basis': node.basis, **deepcopy(node.data)}
    draft['feedback'] = feedback.split('\n{', 1)[0][:2000]
    return feedback + (f'\nВерсия заявки: {revision}. Для точечной правки: '
                       f'submit_node(id="{nid}", patch=true, draft_revision={revision}, '
                       'fields={только исправленные поля}, fact_check={их проверка}). '
                       'Полная заявка и замечания доступны через read_node(id); все основания проверяются заново.')
