"""Tools for a model-directed passport loop. None can write to the target tree."""
from __future__ import annotations

import json
import time
from copy import deepcopy

from pko.progress.passport_evidence import claim_citation_errors
from pko.progress.passport_workspace import sync_objects


def _json(value):
    return json.dumps(value, ensure_ascii=False)


def summary(state):
    sync_objects(state)
    ws = state.workspace
    return _json({"mode": "agentic", "nodes": [{"id": n.id, "name": n.name,
        "filled": n.filled, "parents": n.parents, "children": n.children} for n in list(state.nodes.values())[:16]],
        "nodes_total": len(state.nodes), "nodes_next_offset": 16 if len(state.nodes) > 16 else None,
        "open_findings": ws.unresolved()[:16], "open_findings_total": len(ws.unresolved()),
        "pending_reviews": ws.pending_reviews()[:16], "pending_reviews_total": len(ws.pending_reviews()),
        "risk_analysis_current": state.risk_reviewed,
        **({"research_mode": "code_reconstruction" if state.research_basis == "code" else "integrated",
            "research_basis": state.research_basis, "scenarios_total": len(state.scenarios),
            "research_sections": ["scenarios", "connectivity", "system"]} if state.research_enabled else {}),
        "instruction": "Выбирай следующий шаг: исследуй, меняй план/структуру/поля, проверяй гипотезы. "
                       "Для деталей — research_state. finish проверяет полноту, повтор не снимает замечания."})


def read_state(state, args):
    ws = state.workspace
    section = args.get("section", "summary")
    if section == "summary":
        return summary(state)
    sync_objects(state)
    if section in ("scenarios", "connectivity", "system"):
        if not state.research_enabled:
            return "research_state отклонён: интегрированное исследование не включено для этого вызова."
        from pko.progress.passport_agent import _research_data
        data = _research_data(state)
        if section == "system":
            return _json({"integrity": data["integrity"], "objects": {
                oid: obj for oid, obj in ws.objects.items() if oid.startswith("system:")}})
        try:
            offset = max(0, int(args.get("offset", 0)))
        except (TypeError, ValueError):
            return "research_state отклонён: offset должен быть числом."
        rows = (data["connectivity"] or {}).get("scenarios", [])
        if section == "scenarios":
            rows = [{**{k: v for k, v in row.items() if k != "handoffs"},
                     "research_object": ws.objects.get("scenario:" + row["id"])} for row in rows]
        return _json({"items": rows[offset:offset + 4], "total": len(rows),
                      "next_offset": offset + 4 if offset + 4 < len(rows) else None,
                      "trace_objects": {"trace:" + row["id"]: ws.objects.get("trace:" + row["id"])
                                        for row in rows[offset:offset + 4]} if section == "connectivity" else {}})
    if section == "object":
        return _json(ws.objects.get(str(args.get("id")), {"error": "Объект не найден"}))
    if section == "risk_catalog":
        from pko.progress.risk_catalog import render_index
        return render_index()
    if section == "risk_context":
        from pko.progress.passport_agent import _risk_exposure_digest, _RISK_GUIDE_PATH
        from pko.progress.passport_facts import exposure_digest
        guide = _RISK_GUIDE_PATH.read_text(encoding="utf-8") if _RISK_GUIDE_PATH.exists() else "Памятка недоступна."
        return "\n\n".join((_risk_exposure_digest(state), exposure_digest(state.exposures), guide))
    if section == "scope":
        return _json({"decisions": ws.scope, "exclusions": ws.exclusions,
                      "inventory": state.evidence_broker.inventory() if state.evidence_broker else {}})
    if section == "nodes":
        try:
            offset = max(0, int(args.get("offset", 0)))
        except (ValueError, TypeError):
            return "research_state отклонён: offset должен быть числом."
        return _json({"items": [{"id": n.id, "name": n.name, "filled": n.filled,
                                "parents": n.parents, "children": n.children}
                               for n in list(state.nodes.values())[offset:offset + 16]],
                      "total": len(state.nodes),
                      "next_offset": offset + 16 if offset + 16 < len(state.nodes) else None})
    if section == "capabilities":
        try:
            offset = max(0, int(args.get("offset", 0)))
        except (TypeError, ValueError):
            return "research_state отклонён: offset должен быть числом."
        mapped, dismissed, _ = state.capability_state()
        return _json({"items": [{"id": c.id, "description": c.describe(),
                                "nodes": mapped.get(c.id, []), "dismissal": dismissed.get(c.id)}
                               for c in state.capabilities[offset:offset + 16]],
                      "total": state.capabilities_total,
                      "next_offset": offset + 16 if offset + 16 < len(state.capabilities) else None})
    rows = {"connections": list(state.connection_review.values()),
            "plan": ws.plan, "findings": list(ws.findings.values()),
            "candidates": list(ws.risk_candidates.values()), "reviews": list(ws.reviews.values())}.get(section)
    if rows is None:
        return "research_state отклонён: неизвестный раздел."
    try:
        offset = max(0, int(args.get("offset", 0)))
    except (TypeError, ValueError):
        return "research_state отклонён: offset должен быть числом."
    return _json({"items": rows[offset:offset + 8], "total": len(rows),
                  "next_offset": offset + 8 if offset + 8 < len(rows) else None})


def update_plan(state, args):
    tasks = args.get("tasks")
    if not isinstance(tasks, list) or len(tasks) > 30:
        return "update_research_plan отклонён: нужен массив до 30 задач."
    seen = set()
    for task in tasks:
        if (not isinstance(task, dict) or not isinstance(task.get("id"), str)
                or not task["id"].strip() or task["id"] in seen
                or not isinstance(task.get("task"), str) or not 5 <= len(task["task"]) <= 1200
                or task.get("state") not in ("open", "doing", "done")):
            return "update_research_plan отклонён: каждой задаче нужны уникальный id, task и state=open/doing/done."
        seen.add(task["id"])
    if state.workspace.plan != tasks:
        state.workspace.event("plan_updated", previous=state.workspace.plan, tasks=tasks)
        state.workspace.plan = deepcopy(tasks)
    return "План сохранён. Следующее действие выбираешь самостоятельно."


def request_evidence(state, args):
    if state.evidence_broker is None:
        return "request_passport_evidence отклонён: исходный снимок недоступен."
    result = state.evidence_broker.request(args)
    state.known_paths.update(state.evidence_corpus.included)
    return _json(result)


def review(state, args):
    sync_objects(state)
    ids = args.get("ids")
    if not isinstance(ids, list) or not 1 <= len(ids) <= 8 or any(not isinstance(x, str) for x in ids):
        return "review_passport отклонён: передай 1–8 id объектов из research_state."
    ids = list(dict.fromkeys(ids))
    if any(x not in state.workspace.objects for x in ids):
        return "review_passport отклонён: неизвестные id; проверь research_state."
    if state.reviewer is None:
        return "review_passport отклонён: проверяющий недоступен; результат останется неполным."
    if state.workspace.review_calls >= state.max_review_calls:
        return "review_passport отклонён: бюджет независимых проверок исчерпан."
    if state.deadline and time.monotonic() >= state.deadline:
        return "review_passport отклонён: время паспортного анализа исчерпано."
    objects = [deepcopy(state.workspace.objects[x]) for x in ids]
    reviewed_findings = {}
    review_keys = {}
    corpus_revision = len(state.evidence_corpus.records) if state.evidence_corpus else 0
    for obj in objects:
        retirement = state.workspace.retirements.get(obj["id"], {})
        finding_keys = state.workspace.review_keys(obj["id"])
        for retired_id in retirement.get("retired_object_ids", []):
            finding_keys.update(state.workspace.review_keys(retired_id))
        if retirement.get("object_id"):
            finding_keys.update(state.workspace.review_keys(retirement["object_id"]))
        prior = [deepcopy(f) for f in state.workspace.findings.values()
                 if f.get("key") in finding_keys and f["state"] in ("open", "open_question")]
        if any(f.get("key") == "review:" + obj["id"] and f.get("proposal", {}).get("revision") == obj["revision"]
               and f.get("proposal", {}).get("corpus_revision") == corpus_revision for f in prior):
            return "review_passport отклонён: прежний контрпример не устранён; измени вывод или запроси новые основания."
        if prior:
            obj["prior_findings"] = prior
        reviewed_findings[obj["id"]] = {f["id"] for f in prior}
        review_keys[obj["id"]] = finding_keys
    state.workspace.review_calls += 1
    result = state.reviewer(objects)
    accepted = []
    for finding in result.get("findings", []):
        oid = finding.get("object_id")
        obj = state.workspace.objects.get(oid)
        if oid not in ids or not obj or obj["revision"] != finding.get("revision"):
            continue
        if finding.get("result") not in ("supported", "contradicted", "insufficient"):
            continue
        state.workspace.reviews[oid] = deepcopy(finding)
        state.workspace.event("independent_review", finding=finding)
        if finding["result"] in ("contradicted", "insufficient"):
            state.workspace.reject("review:" + oid,
                {**finding, "tool": "independent_review", "corpus_revision": len(state.evidence_corpus.records) if state.evidence_corpus else 0},
                finding.get("reason", ""))
        else:
            # A receipt can resolve only counterexamples actually sent to this
            # reviewer, never a new negative result from the same response batch.
            for key in review_keys[oid]:
                state.workspace.accepted(key, finding_ids=reviewed_findings[oid])
        accepted.append(oid)
    state.workspace.event("review_completed", objects=ids, reviewed=accepted,
                          reads=result.get("reviewer_reads", []), notes=result.get("notes", []))
    return _json(result)


def resolve(state, args):
    ws = state.workspace
    fid = str(args.get("id") or "")
    row = ws.findings.get(fid) or ws.risk_candidates.get(fid)
    resolution, reason = args.get("resolution"), str(args.get("reason") or "").strip()
    if row is None or resolution not in ("withdrawn", "refuted", "open_question") or len(reason) < 30:
        return "resolve_finding отклонён: нужен существующий id, resolution и конкретная причина (от 30 символов)."
    if row.get("proposal", {}).get("tool") == "independent_review":
        return "resolve_finding отклонён: вывод независимой проверки закрывается новой проверкой исправленной версии или новых оснований."
    refs = args.get("evidence", [])
    if state.evidence_corpus is not None:
        errors = state.evidence_corpus.citations(refs, required=resolution == "refuted" or fid in ws.risk_candidates,
                                                code=fid in ws.risk_candidates)
        if errors:
            return "resolve_finding отклонён: " + "; ".join(errors)
    previous = deepcopy(row)
    row.update(state=resolution, resolution_reason=reason, resolution_evidence=deepcopy(refs))
    ws.event("finding_resolved", previous=previous, finding=row)
    if fid in ws.risk_candidates:
        state.risk_reviewed = False
    # A withdrawn rejected relation is not evidence of a missing real connection.
    proposal = row.get("proposal", {})
    key = tuple(str(proposal.get(k, "")) for k in ("from", "to", "kind"))
    if resolution != "open_question":
        state.unresolved_relations.pop(key, None)
    return "Решение сохранено вместе с исходной находкой и причиной."


def scope(state, args):
    target = str(args.get("target") or "").strip()
    disposition, reason = args.get("disposition"), str(args.get("reason") or "").strip()
    refs = args.get("evidence", [])
    if not target or disposition not in ("reviewed", "excluded", "unknown") or len(reason) < 30:
        return "record_scope отклонён: нужны target, disposition и конкретная граница проверки."
    # Explicit keys for requirements/steps; component names come from broker inventory.
    component_inventory = None
    if target.startswith("step:"):
        parts = target.split(":")
        if len(parts) != 3 or parts[1] not in state.scenarios or not parts[2].isdigit() or int(parts[2]) >= len(state.scenarios[parts[1]]):
            return "record_scope отклонён: неизвестный шаг; формат step:scenario-N:0."
    elif target.startswith("bullet:"):
        value = target[7:]
        if not value.isdigit() or not 0 <= int(value) < len(state.plan_bullets):
            return "record_scope отклонён: неизвестный пункт; формат bullet:0."
    elif not target.startswith("component:"):
        return "record_scope отклонён: target — component:<имя>, step:scenario-N:0 или bullet:0."
    elif state.evidence_broker is not None:
        components = state.evidence_broker.inventory().get("components", [])
        known = {str(c.get("path", "")) for c in components if isinstance(c, dict)}
        known.update(str(c.get("name", "")) for c in components if isinstance(c, dict))
        if target[10:] not in known:
            return "record_scope отклонён: компонент не найден в inventory; прочитай research_state(section=scope)."
        component_inventory = next((deepcopy(c) for c in components if c.get("path", c.get("name")) == target[10:]), None)
    document_scope = (state.research_basis == "code" and disposition == "excluded"
                      and component_inventory is not None and component_inventory.get("code_files") == 0)
    if state.evidence_corpus is not None:
        errors = state.evidence_corpus.citations(refs, required=disposition != "unknown",
                                                code=disposition == "reviewed" or state.research_basis == "code" and not document_scope)
        if document_scope:
            for ref in refs if isinstance(refs, list) else []:
                record = state.evidence_corpus.records.get(str(ref.get("id")), {}) if isinstance(ref, dict) else {}
                if record.get("kind") != "document":
                    errors.append("Исключение документального компонента требует документа из этого компонента, не ОР/сводки.")
        if errors:
            return "record_scope отклонён: " + "; ".join(errors)
    target_text = target
    if target.startswith("bullet:"):
        target_text = state.plan_bullets[int(target[7:])]
    elif target.startswith("step:"):
        _, sid, step = target.split(":")
        target_text = state.scenarios[sid][int(step)]
    elif (disposition == "reviewed" or state.research_basis == "code" and disposition == "excluded") and state.evidence_corpus is not None:
        component = target[10:]
        paths = [str(state.evidence_corpus.records[r["id"]]["label"]).rsplit(":", 1)[0] for r in refs]
        if not any(("/" not in p if component == "." else p.startswith(component + "/")) for p in paths):
            return "record_scope отклонён: цитаты не относятся к указанному компоненту."
    row = {"target": target, "target_text": target_text, "disposition": disposition,
           "reason": reason, "evidence": deepcopy(refs)}
    if state.research_basis == "code":
        row.update(research_basis="code", source_scope=document_scope, component_inventory=component_inventory)
    store = state.workspace.scope if target.startswith("component:") else state.workspace.exclusions
    if store.get(target) != row:
        state.workspace.event("scope_decision", previous=store.get(target), decision=row)
        store[target] = row
    return "Граница рассмотрения сохранена; неизвестное не считается отсутствующей реализацией."


def claim(state, args):
    row = {k: deepcopy(args.get(k)) for k in ("kind", "text", "conditions", "limits", "nodes", "evidence")}
    if row["kind"] not in ("intent", "implementation", "reachability", "condition", "effect", "observed_outcome"):
        return "submit_claim отклонён: неизвестный вид утверждения."
    if any(not isinstance(row[k], str) or not row[k].strip() for k in ("text", "conditions", "limits")):
        return "submit_claim отклонён: укажи утверждение, условия и границу доказательства."
    if not isinstance(row["nodes"], list) or not row["nodes"] or any(n not in state.nodes for n in row["nodes"]):
        return "submit_claim отклонён: нужны существующие связанные узлы."
    if state.evidence_corpus is None:
        return "submit_claim отклонён: корпус недоступен."
    errors = state.evidence_corpus.citations(row["evidence"], code=row["kind"] not in ("intent", "observed_outcome"))
    if row["kind"] == "observed_outcome":
        kinds = {state.evidence_corpus.records.get(r.get("id"), {}).get("kind") for r in row["evidence"] if isinstance(r, dict)} if isinstance(row["evidence"], list) else set()
        if not kinds or not kinds <= {"document"}:
            errors.append("наблюдаемый эффект требует документированной проверки; код/намерение его не подтверждают")
    if not errors and row["kind"] not in ("intent", "observed_outcome"):
        errors.extend(claim_citation_errors(state.evidence_corpus, row["text"], row["evidence"]))
    if errors:
        return "submit_claim отклонён: " + "; ".join(errors)
    cid = str(args.get("id") or "")
    if cid and cid not in state.workspace.claims:
        return "submit_claim отклонён: неизвестный id; для нового утверждения не передавай id."
    if not cid:
        from pko.progress.passport_agent import _record_id
        cid = _record_id(state, "claim", [{"id": key} for key in state.workspace.claims])
    state.workspace.claims[cid] = row
    sync_objects(state)
    return f"Утверждение {cid} сохранено. Смысл проверяется review_passport, буквальная цитата сама его не доказывает."


def structure(state, args):
    from pko.progress.passport_gate import node_type, parent_link_problem, check_relation, PassportCheck
    nid = str(args.get("id") or "")
    node = state.nodes.get(nid)
    reason = str(args.get("reason") or "").strip()
    if node is None or node_type(nid) == "journey" or len(reason) < 20:
        return "revise_structure отклонён: нужен существующий узел ниже пути и причина от 20 символов."
    if args.get("action") == "retire":
        references = [r for r in state.relations if nid in (r["from"], r["to"])]
        references += [r for r in state.risks if nid in r.get("linked_nodes", []) or r.get("primary_node") == nid]
        references += [d for d in state.defects if nid in d.get("nodes", [])]
        references += [g for g in state.guardrails if nid in g.get("targets", [])]
        references += [c for c in state.workspace.claims.values() if nid in c.get("nodes", [])]
        references += [check for pid, review in state.connection_review.items() if pid != nid
                       for check in review["checks"] if nid in check["nodes"]]
        if node.children or references or node.data.get("scenario_steps") or any(nid in ns for ns in state.capability_bound.values()):
            return "revise_structure отклонён: сначала перенеси детей, привязки и связи; удаление не должно терять факты."
        for parent in node.parents:
            state.nodes[parent].children.remove(nid)
        state.workspace.event("node_retired", node_id=nid, previous=node.data, reason=reason)
        if node.filled:
            state.workspace.retirements["retirement:" + nid] = {"object_id": nid, "previous": deepcopy(node.data), "reason": reason}
        if nid in state.connection_review:
            state.workspace.retirements["retirement:" + nid].update({
                "connection_review": state.connection_review.pop(nid),
                "retired_object_ids": ["connection-review:" + nid]})
        del state.nodes[nid]
    elif args.get("action") == "move":
        parents = args.get("parents")
        if not isinstance(parents, list) or not parents or len(set(parents)) != len(parents):
            return "revise_structure отклонён: parents должен содержать уникальных родителей."
        errors = []
        for parent in parents:
            if parent not in state.nodes or state.nodes[parent].planned:
                errors.append(f"родитель {parent} отсутствует или планируемый")
            else:
                issue = parent_link_problem(nid, parent, set(state.nodes), before_fork=node.before_fork)
                if issue:
                    errors.append(issue)
        if node.before_fork and len(parents) != 1:
            errors.append("узлу до развилки нужен ровно один родитель")
        proposed = state.relation_context()
        proposed[nid]["parents"] = parents
        for relation in state.relations:
            if relation["kind"] == "includes" and relation["to"] == nid and relation["from"] not in parents:
                errors.append("сначала удали прежнюю связь includes через revise_relation")
            check = PassportCheck()
            check_relation(check, relation, set(state.nodes), set(), proposed)
            errors.extend(check.errors)
        if errors:
            return "revise_structure отклонён: " + "; ".join(errors)
        old = list(node.parents)
        for parent in old:
            state.nodes[parent].children.remove(nid)
        node.parents = list(parents)
        for parent in parents:
            if nid not in state.nodes[parent].children:
                state.nodes[parent].children.append(nid)
        state.workspace.event("node_moved", node_id=nid, previous_parents=old, parents=parents, reason=reason)
        from pko.progress.passport_agent import _fill_linked_fields
        _fill_linked_fields(state, nid, node_type(nid), node.data.setdefault("fields", {}))
    else:
        return "revise_structure отклонён: action=move или retire."
    state.risk_reviewed = False
    return "Структура изменена; проверь связанные утверждения и анализ рисков.\n" + summary(state)


def relation(state, args):
    key = tuple(str(args.get(k) or "") for k in ("from", "to", "kind"))
    reason = str(args.get("reason") or "").strip()
    found = next((r for r in state.relations if tuple(str(r[k]) for k in ("from", "to", "kind")) == key), None)
    if found is None or len(reason) < 20:
        return "revise_relation отклонён: нужна существующая связь и причина от 20 символов."
    if found["kind"] == "includes":
        child = state.nodes[found["to"]]
        if len(child.parents) < 2:
            return "revise_relation отклонён: нельзя удалить единственного родителя."
        child.parents.remove(found["from"])
        state.nodes[found["from"]].children.remove(found["to"])
    state.relations.remove(found)
    state.workspace.event("relation_retired", previous=found, reason=reason)
    state.workspace.retirements["retirement:relation:" + ":".join(key)] = {
        "object_id": "relation:" + ":".join(key), "previous": deepcopy(found), "reason": reason}
    state.risk_reviewed = False
    return "Связь удалена с сохранением истории. Исправленную связь передай link_nodes."


def retire_record(state, args):
    kind, rid = args.get("kind"), str(args.get("id") or "")
    reason = str(args.get("reason") or "").strip()
    if kind not in ("claim", "defect", "guardrail") or len(reason) < 30:
        return "retire_record отклонён: нужен kind, существующий id и конкретная причина от 30 символов."
    rows = state.workspace.claims if kind == "claim" else state.defects if kind == "defect" else state.guardrails
    found = rows.get(rid) if isinstance(rows, dict) else next((r for r in rows if r.get("id") == rid), None)
    if found is None:
        return "retire_record отклонён: запись не найдена."
    if kind == "guardrail" and any(rid in r.get("guardrails", []) for r in state.risks):
        return "retire_record отклонён: сначала пересмотри связанные риски."
    if state.evidence_corpus is None:
        return "retire_record отклонён: корпус оснований недоступен."
    errors = state.evidence_corpus.citations(args.get("evidence"), code=True)
    if errors:
        return "retire_record отклонён: " + "; ".join(errors)
    decision = {"object_id": rid if kind == "claim" else kind + ":" + rid,
                "previous": deepcopy(found), "reason": reason, "evidence": deepcopy(args["evidence"])}
    state.workspace.retirements["retirement:" + kind + ":" + rid] = decision
    state.workspace.event("record_retired", kind=kind, record_id=rid, decision=decision)
    if isinstance(rows, dict):
        del rows[rid]
    else:
        rows.remove(found)
    state.risk_reviewed = False
    return "Запись отозвана с сохранением истории; решение требует независимой проверки."


HANDLERS = {"research_state": read_state, "update_research_plan": update_plan,
            "request_passport_evidence": request_evidence, "review_passport": review,
            "resolve_finding": resolve, "record_scope": scope, "submit_claim": claim,
            "revise_structure": structure, "revise_relation": relation, "retire_record": retire_record}
