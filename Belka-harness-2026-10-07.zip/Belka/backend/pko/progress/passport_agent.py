"""Паспортный агент v2: модель выбирает инструменты, код проверяет результат.

Штатная сессия использует EvidenceBroker и ResearchWorkspace: чтение,
изменение графа и независимая проверка доступны в цикле по выбору модели.
finish требует актуальных проверок и не ослабляется после повторов.
Подробности нового контракта — docs/passport-agent-v2.md.

Ниже описан сохранённый совместимый протокол прямых вызовов agentic=False.

Сессия оценки (`matcher.run_agent`) заканчивается вердиктом. Паспорт
клиентского пути собирает **вторая сессия** — без инструментов репозитория:
по коду она не ходит, а работает на том, что уже собрала первая — карте
возможностей, вердиктах с доказательствами и сжатом следе прочитанного.

Дерево строится **итеративно**, и очередь ведёт код, а не модель:

    journey-1  ← submit_node: поля пути
               ← declare_children: процессы (название + basis) и узлы до
                  развилки — BBB с before_fork (классификатор, права):
                  они выполняются до выбора процесса и в процессы не входят
    process-1  ← submit_node: поля процесса
               ← declare_children: BBB — новые {name, basis} или уже
                  объявленные {ref: "bbb-2"} (общий блок, второй родитель)
    bbb-1      ← submit_node
               ← declare_children: операции
    operation-1 ← submit_node          (лист — детей нет)
    operation-2 ← submit_node
    bbb-2 …    (обход в глубину, пока очередь не пуста)
    link_nodes(from, to, kind, basis, field)   связи поверх дерева
    bind_scenario_step(scenario, step, nodes)  шаги сценариев без узла
    submit_defect(title, kind, nodes, scenarios, where, blocking)  дефекты
    submit_need(name, purpose, source)                потребность клиента
    submit_guardrail(name, invariant, condition, effect, targets, source)
    read_risk_patterns(ids)                          библиотека гипотез
    submit_risks(risks)                               операционные риски
    finish

Каждый узел проверяется гейтом отдельно (`passport_gate`), отклонение стоит
одного шага, а не всего паспорта. У промежуточных узлов дети обязательны:
объявление без единого ребёнка не принимается. Идентификаторы выдаёт код,
реестр и `object-id` строит `normalize_passport` — модель присылает только
названия, основания, поля и связи. В каждом ответе модель получает карту
уже построенного дерева — из истории ей ничего вспоминать не нужно.

Сценарии из ревизии связности привязываются к узлам по шагам
(`scenario_steps` в `submit_node`, `bind_scenario_step` после дерева).
Шаг без узла код не пропускает молча: после дерева он перечисляет такие
шаги, а первый `finish` при них отклоняет.

Что модель не заполняет, потому что код это знает сам: название пути в
«Связанном КП» процесса, название родительского блока в «Связанном BBB»
операции, версию объекта (коммит). Одно имя — из одного места.

Узел, которого в коде нет, модель помечает `planned`: код оставляет ему
бизнес-смысл, владельца и «чего не хватает», остальные поля отбрасывает,
детей не спрашивает (одна карточка вместо поддерева пустых), а если
привязанный пункт ОР оценён как работающий — отклоняет: заявка «в коде
нет» спорит с оценкой. Дефекты — отдельные сущности (`submit_defect`),
а не проза, размазанная по четырём узлам; разрывы стыков и обещания без
реализации код добавляет в реестр дефектов сам.
"""

from __future__ import annotations

import json
import math
import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from pko.errors import LlmError, ValidationError
from pko.extractors.runner import Extraction
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.llm.tracing import _NoopSpan, trace_span, trace_tool_call
from pko.progress.connectivity import match_bullets
from pko.progress.loop_guard import cycle_text, repeating_cycle
from pko.progress.matcher import _signature, _strip_cjk, max_tokens_for
from pko.progress.risk_review import CHECKS as RISK_CHECKS, RESULTS as RISK_REVIEW_RESULTS, validate_review
from pko.progress.passport_evidence import (
    EvidenceCorpus, READ_SCHEMA, SEARCH_SCHEMA, NODE_AUDIT_SCHEMA,
    RELATION_PROOF_SCHEMA, CONTROL_REVIEW_SCHEMA,
    NODE_FIELDS, GENERATED_FIELDS,
    check_node_audit, check_relation_proof, check_control_review, claim_citation_errors, entry_note,
)
from pko.progress.passport_facts import (
    CAPABILITY_KIND_LABEL, DISMISS_REASONS, Capability, auto_mapped, exposure_digest,
)
from pko.progress.passport_fields import apply_management_unknowns, field_contract, fields_schema
from pko.progress.passport_gate import (
    BEFORE_FORK_TYPES,
    BRANCHING_HINT,
    BRANCHING_KINDS,
    CHILD_TYPE,
    DECISION_BOUNDARIES,
    DEFECT_KIND_HINT,
    DEFECT_KINDS,
    GUARDRAIL_EFFECT_LABEL,
    GUARDRAIL_EFFECTS,
    MAX_GUARDRAILS,
    MAX_NEEDS,
    MAX_RISKS,
    _AUDIENCE_RE,
    MAX_DEFECTS,
    PLANNED_FIELDS,
    RELATION_HINT,
    RELATION_KINDS,
    RELATION_LABEL,
    RISK_CONFIDENCE,
    RISK_CONFIDENCE_LABEL,
    RISK_SCOPES,
    RISK_SCOPE_LABEL,
    TYPE_LABEL,
    PassportCheck,
    check_defect,
    check_guardrail,
    check_need,
    check_node_fields,
    check_relation,
    check_risk,
    check_router_present,
    collapsed_level_message,
    duplicate_name_message,
    journey_name_of,
    node_type,
    norm_name,
    normalize_passport,
    parent_link_problem,
)
from pko.progress.schema import (
    ConnectivityReview, IntegrityReview, ItemVerdict, PlanItem, ProjectSummary,
    CRITERION_STATUSES, POC_WEIGHT, STATUS_LABEL, SCENARIO_STATUS_LABEL, CHECK_RESULT_LABEL,
    HANDOFF_CHECK_LABEL, capability_coverage, contains_code,
)
from pko.progress.risk_catalog import MAX_PATTERNS_PER_CALL, read_patterns, render_index
from pko.progress.passport_workspace import ResearchWorkspace, WORKSPACE_SCHEMAS, sync_objects, digest

_PROMPT_PATH = Path(__file__).parent / "passport_system.md"
_RISK_GUIDE_PATH = Path(__file__).parent / "risk_hypothesis_guide.md"

# Бюджет шагов паспортной сессии: узел — шаг, объявление детей — шаг.
# Дерево на 20 узлов со связями и привязкой сценариев — около 35 шагов;
# запас на отклонения гейта. `PKO_PASSPORT_MAX_STEPS`.
DEFAULT_PASSPORT_MAX_STEPS = 128
# Потолок времени паспортной сессии, `PKO_PASSPORT_MAX_SECONDS`; 0 — без предела.
DEFAULT_PASSPORT_SECONDS = 1200
# The integrated cycle also owns scenario discovery and system research.
DEFAULT_RESEARCH_MAX_STEPS = 192
MAX_PASSPORT_TOOL_CALLS = 512
DEFAULT_RESEARCH_SECONDS = 1800
# Сколько раз один узел отклоняется, прежде чем принять его с нарушениями.
MAX_NODE_REJECTIONS = 2
# У процесса меньше двух BBB — замечание: обычно процесс описан одним куском.
MIN_BBB_PER_PROCESS = 2
# Сколько ошибок подряд без вызова инструмента останавливают сессию.
_MAX_MALFORMED = 3
# `finish` при шагах сценариев без узла отклоняется столько раз: модель
# обязана либо привязать шаг, либо сознательно оставить его вне схемы.
MAX_FINISH_REJECTIONS = 1
# Шагов подряд, после которых в паспорте ничего не принято (узел, дети, связь,
# дефект, риски, привязка): на первом пороге модели напоминают отправить
# ожидаемое, на втором сессия останавливается. Нормальная пауза на чтение
# оснований в живых прогонах — до 9 шагов; зациклившийся агент листал корпус
# больше ста шагов, меняя только offset, и одинаковых вызовов подряд не делал.
IDLE_STEPS_NUDGE = 12
IDLE_STEPS_STOP = 24
# Спор паспорта со статусом оценки: потолок числа и минимальная длина довода.
MAX_STATUS_DISPUTES = 10
MIN_DISPUTE_CHARS = 40
# Сколько непривязанных возможностей показывать в одном ответе модели.
_MAX_UNMAPPED_SHOWN = 12

# Узлы, которые выполняют шаги сценариев: путь и процесс — контейнеры.
SCENARIO_NODE_TYPES = ("bbb", "operation")

# Поля, которые заполняет код по дереву: одно имя — из одного места.
_LINKED_JOURNEY_FIELD = "4.3.2"   # процесс → связанный клиентский путь
_LINKED_BBB_FIELD = "4.5.2"       # операция → связанный BBB
# Статусы пунктов ОР, при которых «в коде нет» спорит с оценкой.
_WORKING_STATUSES = ("done", "limited", "unused")
# Ссылки на узлы в контракте входа: «профиль из bbb-4» — bbb-4 обязан
# входить в процесс, где стоит ссылающийся узел, либо передавать данные.
_NODE_REF_RE = re.compile(r"\b(?:bbb|operation)-\d+\b")
_INPUT_CONTRACT_FIELDS = {"bbb": "4.4.2", "operation": "4.5.5"}
_EMPTY_JOURNEY_NAME = re.compile(
    r"^(?:клиентский\s+)?путь$|как\s+его\s+назвал|название\s+(?:клиентского\s+)?пути|"
    r"назван\w*\s+моделью",
    re.IGNORECASE,
)
# Пути файлов в следе оценки — по ним проверяется «место в коде» у дефекта.
_PATH_RE = re.compile(r"[\w./\\-]+\.[A-Za-z]{1,6}\b")


# Сколько символов сжатого следа оценки уходит в первое сообщение.
_MAX_KNOWLEDGE_CHARS = 30_000
# При корпусе след в брифе — оглавлением: строка на запись и её evidence-N.
# Полные записи лежат в корпусе как «След оценки N», и бриф, уходящий на
# каждом шаге, не должен нести их второй раз.
_KNOWLEDGE_HEAD_CHARS = 110
_MAX_KNOWLEDGE_INDEX_CHARS = 12_000
_MAX_PROOF_CHARS = 300


def _env_number(name: str, default: float) -> float:
    raw = (os.environ.get(name) or "").strip()
    try:
        value = float(raw) if raw else default
        return max(0.0, value) if math.isfinite(value) else default
    except ValueError:
        return default


def passport_enabled() -> bool:
    """`PKO_PASSPORT`: выключить паспортную сессию можно только явно."""
    raw = (os.environ.get("PKO_PASSPORT") or "").strip().lower()
    return raw not in ("0", "false", "no", "off")


# --- схемы инструментов --------------------------------------------------------

_SUBMIT_NODE_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_node",
        "description": (
            "Заполнить один узел паспорта — тот, который код назвал в "
            "последнем ответе. Передай его id, название (name), basis — одну "
            "фразу, почему узел существует как объект управления и чем "
            "отличается от соседей, — и fields: по каждому полю раздела "
            "{value, source}. source начинается с уровня: Установлено: / "
            "Выведено: / Гипотеза: / Требует подтверждения владельца: / "
            "Не установлено:. Для journey дополнительно decision_boundary "
            "(END_TO_END_PROCESS | COMPONENT_BBB). Код проверит узел и скажет, что дальше."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "id": {"type": "string", "description": "id узла из ответа кода: journey-1, process-2, bbb-3, operation-4"},
                "name": {"type": "string", "description": "Название узла на языке бизнеса"},
                "basis": {"type": "string", "description": "Почему узел существует как объект управления и чем отличается от соседей — одна фраза"},
                "explanation": {"type": "string", "description": "Обоснование структуры: роль узла, выбор родителя и шага сценария, подтверждающие факты и границы вывода. Короткие абзацы по 1–2 предложения; не копируй все поля и оценки, не назначай статус."},
                "fields": fields_schema(),
                "bullets": {
                    "type": "array", "items": {"type": "string"},
                    "description": "Пункты образа результата, которые этот узел реализует — дословно из задания. "
                                   "По ним код считает готовность узла и красит его на схеме. Для узлов дерева "
                                   "(process, bbb, operation) обязательно старайся указать; пункт может принадлежать нескольким узлам.",
                },
                "scenario_steps": {
                    "type": "array",
                    "items": {"type": "object", "properties": {
                        "scenario": {"type": "string", "description": "id целевого сценария из задания: scenario-1 …"},
                        "step": {"type": "integer", "description": "номер шага сценария (с нуля), который выполняет этот узел"},
                    }, "required": ["scenario", "step"]},
                    "description": "В каких шагах целевых сценариев участвует узел. По ним код рисует путь сценария "
                                   "поверх схемы и показывает разрывы на стыках. Только для bbb и operation.",
                },
                "scenario": {
                    "type": "string",
                    "description": "Только для process: ровно один id целевого сценария (scenario-N), который и является этим процессом. Один сценарий — один процесс.",
                },
                "decision_boundary": {"type": "string", "description": "Только для journey: END_TO_END_PROCESS или COMPONENT_BBB"},
                "planned": {
                    "type": "boolean",
                    "description": "true — узла в коде нет, он обещан образом результата. Код оставит "
                                   "бизнес-смысл, владельца, целевые условия/шаги сценария с пометкой «План» "
                                   "и «чего не хватает» (версия и изменения), "
                                   "остальные поля отбросит: режимы, fallback, handoff и компенсацию "
                                   "несуществующему коду не назначают.",
                },
            },
            "required": ["id", "name", "basis", "fields"],
        },
    },
}

_DECLARE_CHILDREN_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "declare_children",
        "description": (
            "Объявить дочерние узлы только что заполненного узла: для journey "
            "— процессы, для process — BBB, для bbb — атомарные операции. "
            "Новый ребёнок — {name, basis}; уже объявленный узел того же уровня, "
            "который входит и сюда (общий BBB или общая операция), — {ref: id}: "
            "у него появится второй родитель, заполнять его повторно не нужно. "
            "У journey дети с before_fork: true — BBB до развилки (определение "
            "сценария обращения, проверка прав): они выполняются до выбора процесса, "
            "в процессы не входят и связываются с ними triggers. "
            "Поля каждого нового ребёнка ты заполнишь, когда код его назовёт. "
            "Дети обязательны: journey без процессов, процесс без BBB и BBB без "
            "операций не принимаются. Дроби по бизнес-действиям: ориентир 3–6 BBB "
            "на процесс, 1–3 операции на BBB."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "parent": {"type": "string", "description": "id узла-родителя из ответа кода"},
                "branching": {
                    "type": "string", "enum": list(BRANCHING_KINDS),
                    "description": "Как дети складываются в результат родителя: "
                                   + "; ".join(f"{k} — {BRANCHING_HINT[k]}" for k in BRANCHING_KINDS),
                },
                "children": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "basis": {"type": "string", "description": "Почему это отдельный объект и чем отличается от соседей"},
                            "ref": {"type": "string", "description": "id уже объявленного узла того же уровня, который входит и в этот родитель"},
                            "before_fork": {"type": "boolean", "description": "Только у детей journey: BBB до развилки — выполняется до выбора процесса и выбирает или разрешает его"},
                        },
                    },
                },
            },
            "required": ["parent", "children"],
        },
    },
}

_LINK_NODES_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "link_nodes",
        "description": (
            "Объявить связь между двумя узлами поверх дерева. Виды: "
            + "; ".join(f"{k} — {RELATION_HINT[k]}" for k in RELATION_KINDS)
            + ". basis — одна фраза, какой факт кода или образа результата "
            "показывает связь. Дерево (родитель → ребёнок) связью не дублируй."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "from": {"type": "string", "description": "id узла-источника"},
                "to": {"type": "string", "description": "id узла-приёмника"},
                "kind": {"type": "string", "enum": list(RELATION_KINDS)},
                "basis": {"type": "string"},
                "field": {"type": "string", "description": "Для feeds: конкретное имя поля состояния, которое источник записывает, а приёмник читает (например portfolio_items), а не «состояние графа»"},
            },
            "required": ["from", "to", "kind", "basis"],
        },
    },
}

_BIND_SCENARIO_STEP_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "bind_scenario_step",
        "description": (
            "Привязать шаг целевого сценария к узлам, которые его выполняют "
            "(bbb или operation). Нужен для шагов, которые не были указаны в "
            "scenario_steps при заполнении узлов: код перечисляет их после дерева."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "scenario": {"type": "string", "description": "id сценария: scenario-1 …"},
                "step": {"type": "integer", "description": "номер шага с нуля"},
                "nodes": {"type": "array", "items": {"type": "string"}, "description": "id узлов bbb/operation"},
            },
            "required": ["scenario", "step", "nodes"],
        },
    },
}

_SUBMIT_DEFECT_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_defect",
        "description": (
            "Зафиксировать один дефект как отдельный объект — вместо пересказа в полях "
            "нескольких узлов. Виды: "
            + "; ".join(f"{k} — {DEFECT_KIND_HINT[k]}" for k in DEFECT_KINDS)
            + ". Один дефект — один вызов, даже если он объясняет несколько узлов и сценариев. "
            "Разрывы стыков из ревизии связности и обещания образа результата без реализации "
            "код добавляет в реестр сам — их повторять не нужно."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Что не так и чем грозит клиенту — словами, без кода"},
                "kind": {"type": "string", "enum": list(DEFECT_KINDS)},
                "nodes": {"type": "array", "items": {"type": "string"}, "description": "Затронутые узлы"},
                "scenarios": {"type": "array", "items": {"type": "string"}, "description": "Сценарии из задания, которые дефект блокирует или искажает"},
                "where": {"type": "string", "description": "Место в коде: путь и строка из материалов оценки"},
                "blocking": {"type": "boolean", "description": "true — сценарий с этим дефектом до результата не доходит (деньги списаны, продукт не открыт)"},
            },
            "required": ["title", "kind"],
        },
    },
}

_SUBMIT_NEED_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_need",
        "description": (
            "Сформулировать потребность клиента — задачу человека, существующую до продукта, "
            "которую закрывает клиентский путь. Аудитория («все клиенты приложения») потребностью "
            "не является. Кодом потребность не устанавливается: source — «Выведено: …» из образа "
            "результата или «Требует подтверждения владельца: …». Обычно одна-две на путь."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Короткое предметное название потребности"},
                "purpose": {"type": "string", "description": "Какую задачу хочет решить человек и какой результат ему нужен — 1–2 предложения. Это потребность, не утверждение о текущей реализации агентом."},
                "source": {"type": "string", "description": "Уровень и привязка: из какого текста образа результата следует"},
            },
            "required": ["name", "purpose", "source"],
        },
    },
}

_SUBMIT_GUARDRAIL_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_guardrail",
        "description": (
            "Сформулировать ограничение исполнения: защищаемый инвариант + условие срабатывания + "
            "ограничивающий эффект. Эффекты: "
            + ", ".join(f"{e} — {GUARDRAIL_EFFECT_LABEL[e]}" for e in GUARDRAIL_EFFECTS)
            + ". targets — узлы, которые ограничение защищает (процесс, BBB, операция, путь). "
            "Константа или лимит без места применения ограничение не доказывают; обязательная "
            "защита из образа результата может быть «Требует подтверждения владельца», если реализации нет."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "invariant": {"type": "string", "description": "Что защищаем — какое состояние не должно нарушаться"},
                "condition": {"type": "string", "description": "Когда срабатывает"},
                "effect": {"type": "string", "enum": list(GUARDRAIL_EFFECTS)},
                "targets": {"type": "array", "items": {"type": "string"}, "description": "id защищаемых узлов"},
                "source": {"type": "string", "description": "Префикс уровня, проверенный источник и конкретное действие защиты с условием срабатывания — 1–2 предложения. Сохраняй полный путь и строку; не повторяй название ограничения."},
            },
            "required": ["name", "invariant", "condition", "effect", "targets", "source"],
        },
    },
}

_SUBMIT_RISKS_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_risks",
        "description": (
            "Завершить отдельный анализ операционных рисков после дерева и guardrails. "
            "Передай весь дедуплицированный набор одним массивом (пустой массив допустим, "
            "если после локальной и сквозной проверки риски не обоснованы). Каждый риск — "
            "причина → негативное событие → бизнес-последствие; это не дефект, не отсутствие "
            "контроля само по себе и не новый уровень дерева. Риск не меняет статус узла."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "risks": {
                    "type": "array",
                    "maxItems": MAX_RISKS,
                    "items": {
                        "type": "object",
                        "properties": {
                            "title": {"type": "string", "description": "Краткое название негативного события, без слов «возможный риск»"},
                            "problem": {"type": "string", "description": "Для карточки руководителя: одно короткое понятное предложение, которое объединяет условие возникновения, негативное событие и конкретное бизнес-последствие. Без имён функций, вводных слов и повтора названия. Пример: «Если при нулевых остатках расчёт продолжится по обычному правилу, клиенту могут предложить портфель с неверными долями продуктов»"},
                            "scope": {"type": "string", "enum": list(RISK_SCOPES), "description": "local — внутри одного узла; cross_node — на стыке двух и более"},
                            "cause": {"type": "string", "description": "Отказ, ошибка, состояние данных, нарушение порядка, внешнее событие или недостаточный контроль"},
                            "negative_event": {"type": "string", "description": "Одно понятное руководителю предложение: что может пойти не так для клиента или операции; не повторяй причины и последствия"},
                            "consequences": {"type": "array", "items": {"type": "string"}, "description": "Влияние на клиента, банк, обязательство, деньги, данные, срок или бизнес-результат"},
                            "primary_node": {"type": "string", "description": "Основной id узла возникновения"},
                            "linked_nodes": {"type": "array", "items": {"type": "string"}, "description": "Все затронутые узлы, включая основной"},
                            "existing_controls": {
                                "type": "array",
                                "items": {"type": "object", "properties": {
                                    "description": {"type": "string"},
                                    "basis": {"type": "string", "description": "Где контроль обнаружен, при каком условии действует и что покрывает — 1–2 предложения со ссылкой. Не повторяй всю цепочку риска; неизвестное не выдавай за отсутствие защиты."},
                                }, "required": ["description", "basis"]},
                            },
                            "control_gap": {"type": "string", "description": "Конкретный пробел после problem: на каком понятном читателю этапе, перед каким действием и какая проверка/ветка/контроль не покрывает описанное условие. Не пиши внутренние ID вроде operation-28: они допустимы только в primary_node/linked_nodes. Если отсутствие не доказано, прямо напиши «не подтверждено», но назови конкретное правило. Не повторяй событие и последствия"},
                            "guardrails": {"type": "array", "items": {"type": "string"}, "description": "id связанных ограничений исполнения: guardrail-N"},
                            "evidence": {
                                "type": "array",
                                "items": {"type": "object", "properties": {
                                    "where": {"type": "string", "description": "Полный путь и строка либо точная ссылка на контракт/тест/иной прочитанный артефакт. Не сокращай путь: короткую подпись формирует интерфейс."},
                                    "basis": {"type": "string", "description": "Функция или обработчик, что конкретно обнаружено и как это подтверждает вывод — 1–2 предложения. Для риска назови проблемное условие; для проверки без находки — факт против гипотезы. Сохраняй границы проверки. Без повтора уровня доказательности и всего описания риска."},
                                }, "required": ["where", "basis"]},
                            },
                            "confidence": {"type": "string", "enum": list(RISK_CONFIDENCE)},
                            "confidence_note": {"type": "string", "description": "Кратко: какая часть подтверждена, какая является выводом и что неизвестно. Не повторяй название уровня, все evidence и всю причинную цепочку."},
                            "confirmation_needed": {"type": "string", "description": "Для requires_confirmation: что именно проверить"},
                        },
                        "required": ["title", "problem", "scope", "cause", "negative_event", "consequences",
                                     "primary_node", "linked_nodes", "existing_controls", "control_gap",
                                     "guardrails", "evidence", "confidence", "confidence_note"],
                    },
                },
            },
            "required": ["risks"],
        },
    },
}

# The full checklist is shown in the risk review, without safety scores.
_risk_parameters = _SUBMIT_RISKS_SCHEMA["function"]["parameters"]
_risk_parameters["required"].append("review")
_risk_parameters["required"].append("analysis")
_risk_parameters["properties"]["analysis"] = {
    "type": "string", "description": "Полное обоснование анализа с тематическими блоками, разделёнными пустыми строками: материалы и границы; проверенные гипотезы и шаблоны; подтверждённые и отклонённые риски с фактами за/против; найденные защиты; неизвестное и способы проверки. Внутри блока короткие пункты по 1–2 предложения. Не склеивай всё в один абзац и не сокращай весь анализ до трёх пунктов. Сохрани причины объединения дубликатов, наблюдаемые проверки и ограничения, без внутреннего монолога."
}
_risk_parameters["properties"]["review"] = {
    "type": "array", "description": "Внутренний чек-лист каждого процесса, включая его шаги и стыки",
    "items": {"type": "object", "required": ["node", "checks"], "properties": {
        "node": {"type": "string", "description": "process-N"},
        "checks": {"type": "array", "items": {"type": "object",
            "required": ["check", "result", "note", "evidence", "risk_titles"], "properties": {
                "check": {"type": "string", "enum": list(RISK_CHECKS), "description": str(RISK_CHECKS)},
                "result": {"type": "string", "enum": list(RISK_REVIEW_RESULTS)},
                "note": {"type": "string", "description": "Коротко: что проверено, результат и существенная граница, обычно 1–2 предложения на проверку; unknown — каких сведений нет. Факты и ссылки в evidence; отсутствие находки не означает безопасность."},
                "evidence": _risk_parameters["properties"]["risks"]["items"]["properties"]["evidence"],
                "risk_titles": {"type": "array", "items": {"type": "string"}},
                "exposures": {"type": "array", "items": {"type": "string"},
                              "description": "id фактов экспозиции (exposure-N), которые эта проверка рассмотрела; "
                                             "обязательные факты — в input или dependencies хотя бы одного процесса"},
            }}},
    }},
}
for _key, _description in {
    "trigger": "Конкретное условие возникновения события",
    "mechanism": "Как причина приводит к событию несмотря на найденные контроли; не выводи отсутствие защиты из молчания материалов",
    "recommendation": "Адресное действие для закрытия именно этого пробела",
    "closure_criterion": "Проверяемый результат теста/наблюдения, достаточный для закрытия пробела",
}.items():
    _item = _risk_parameters["properties"]["risks"]["items"]
    _item["properties"][_key] = {"type": "string", "description": _description}
    _item["required"].append(_key)

_READ_NODE_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "read_node",
        "description": (
            "Название, тип и точный контракт полей любого объявленного узла, даже ещё не заполненного. "
            "Для принятого узла также полные поля с основаниями и fact_check; читай перед исправлением."
        ),
        "parameters": {
            "type": "object",
            "properties": {"id": {"type": "string", "description": "id объявленного узла, например bbb-2"}},
            "required": ["id"],
        },
    },
}

_READ_RISK_PATTERNS_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "read_risk_patterns",
        "description": (
            "После построения дерева прочитать выбранные шаблоны из встроенной библиотеки рисков: "
            "условия применимости, факты для проверки, механизм, возможные контроли и опровержения. "
            "Выбирай ID из каталога по фактам узлов. Это гипотезы, не evidence проекта."
        ),
        "parameters": {
            "type": "object",
            "properties": {"ids": {"type": "array", "items": {"type": "string"},
                                   "minItems": 1, "maxItems": MAX_PATTERNS_PER_CALL}},
            "required": ["ids"],
            "additionalProperties": False,
        },
    },
}

_BIND_CAPABILITY_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "bind_capability",
        "description": (
            "Обратное сопоставление «код → паспорт»: указать узлы, которые описывают возможность "
            "системы (маршрут, задание, инструмент, узел графа) из списка cap-N после дерева. "
            "Нужен, когда узел описывает возможность, но код не распознал это по цитатам и основаниям."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "capability": {"type": "string", "description": "id возможности: cap-N"},
                "nodes": {"type": "array", "items": {"type": "string"}, "description": "id заполненных узлов"},
            },
            "required": ["capability", "nodes"],
        },
    },
}

_DISMISS_CAPABILITY_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "dismiss_capability",
        "description": (
            "Сознательно не включать возможность системы в паспорт. Причины: "
            + "; ".join(f"{k} — {v}" for k, v in DISMISS_REASONS.items())
            + ". basis — чем подтверждено (без кода в тексте). Возможность, которая участвует в "
            "результате клиента, отклонять нельзя: её нужно описать узлом."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "capability": {"type": "string", "description": "id возможности: cap-N"},
                "reason": {"type": "string", "enum": list(DISMISS_REASONS)},
                "basis": {"type": "string", "description": "Почему возможность не относится к клиентскому пути"},
            },
            "required": ["capability", "reason", "basis"],
        },
    },
}

_STATUS_DISPUTE_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_status_dispute",
        "description": (
            "Оспорить статус пункта образа результата, выставленный оценкой, если прочитанный код "
            "показывает ограничение или противоречие. Только понижение; статус, готовность и решение "
            "не меняются — спор попадает в замечания отчёта и карточку узла для ручной проверки."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "bullet": {"type": "string", "description": "Дословный текст пункта образа результата"},
                "suggested_status": {"type": "string", "enum": list(CRITERION_STATUSES),
                                     "description": "Статус, который следует из кода; строго ниже текущего"},
                "limitation": {"type": "string", "description": "Какое ограничение или противоречие найдено — "
                                                                "человеческим языком, без путей и имён функций"},
                "evidence": {"type": "array", "items": {"type": "object", "properties": {
                    "id": {"type": "string"}, "quote": {"type": "string", "minLength": 12}},
                    "required": ["id", "quote"]},
                    "description": "Дословные цитаты кода из read_passport_evidence"},
            },
            "required": ["bullet", "suggested_status", "limitation", "evidence"],
        },
    },
}

_FINISH_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "finish",
        "description": "Завершить паспорт: дерево построено, связи объявлены, шаги сценариев привязаны.",
        "parameters": {"type": "object", "properties": {}},
    },
}


# --- состояние сессии ------------------------------------------------------------

@dataclass
class _Node:
    id: str
    name: str
    basis: str
    # Первый родитель — место узла в дереве; остальные — общие включения.
    parents: list[str] = field(default_factory=list)
    # Как дети складываются в результат: из BRANCHING_KINDS, пусто — не задано.
    branching: str = ""
    # BBB до развилки: под клиентским путём, к процессам ведёт triggers.
    before_fork: bool = False
    # В коде нет: поля урезаны, статус на схеме — «не реализован».
    planned: bool = False
    filled: bool = False
    data: dict[str, Any] = field(default_factory=dict)
    children: list[str] = field(default_factory=list)

    @property
    def parent(self) -> str | None:
        return self.parents[0] if self.parents else None


@dataclass
class _PassportSession:
    # Production uses a model-directed loop; the legacy protocol remains readable.
    agentic: bool = False
    research_enabled: bool = False
    research_basis: str = "result_image"
    connection_review: dict[str, dict] = field(default_factory=dict)
    connectivity_state: Any = None
    system_research_state: Any = None
    research_source_digest: str = ""
    workspace: ResearchWorkspace = field(default_factory=ResearchWorkspace)
    evidence_broker: Any = None
    reviewer: Any = None
    max_review_calls: int = 16
    tool_calls: int = 0
    checkpoint_path: Path | None = None
    deadline: float = 0.0
    stop_reason: str = ""
    nodes: dict[str, _Node] = field(default_factory=dict)
    node_drafts: dict[str, dict] = field(default_factory=dict)
    research_focus: dict[str, Any] = field(default_factory=dict)
    harness_steps: int = 0
    harness_elapsed_seconds: float = 0.0
    harness_control: dict[str, Any] = field(default_factory=dict)
    counters: dict[str, int] = field(default_factory=dict)
    # Очередь заполнения — стек обхода в глубину.
    queue: list[str] = field(default_factory=list)
    # Узел, поля которого ждёт код, и узел, дети которого ждут объявления.
    current: str | None = None
    awaiting_children_of: str | None = None
    tree_done: bool = False
    attempts: dict[str, int] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)
    remarks: list[str] = field(default_factory=list)
    finished: bool = False
    decision_boundary: str = ""
    # Название инициативы — антипример для имени клиентского пути. Путь
    # должен описывать переход клиента к результату, а не продукт/проект.
    initiative_name: str = ""
    span: Any = field(default_factory=lambda: _NoopSpan())
    on_node: Callable[[str, str], None] | None = None
    # Пункты ОР (дословно) и целевые сценарии — для привязки узлов: по ним
    # код считает готовность узла и рисует путь сценария на схеме.
    plan_bullets: list[str] = field(default_factory=list)
    # Статус каждого пункта ОР после рецензента — сверка с «в коде нет».
    bullet_status: dict[str, str] = field(default_factory=dict)
    scenarios: dict[str, list[str]] = field(default_factory=dict)
    scenario_context: dict[str, dict[str, str]] = field(default_factory=dict)
    scenario_titles: dict[str, str] = field(default_factory=dict)
    # Связи поверх дерева: {from, to, kind, basis, field}.
    relations: list[dict[str, str]] = field(default_factory=list)
    # Дефекты — отдельные сущности.
    defects: list[dict[str, Any]] = field(default_factory=list)
    # Потребности клиента и ограничения исполнения — уровни графа.
    needs: list[dict[str, Any]] = field(default_factory=list)
    guardrails: list[dict[str, Any]] = field(default_factory=list)
    # Риски передаются одним финальным пакетом: так модель сначала видит всё
    # дерево, связи, контроли и может дедуплицировать локальные/сквозные записи.
    risks: list[dict[str, Any]] = field(default_factory=list)
    risk_reviewed: bool = False
    risk_review: list[dict[str, Any]] = field(default_factory=list)
    risk_analysis: str = ""
    # Пути файлов из материалов оценки — «место в коде» дефекта сверяется с ними.
    known_paths: set[str] = field(default_factory=set)
    evidence_corpus: EvidenceCorpus | None = None
    unresolved_relations: dict[tuple[str, str, str], str] = field(default_factory=dict)
    # Обратное сопоставление: возможности системы из кода и решения по ним.
    capabilities: list[Capability] = field(default_factory=list)
    capabilities_total: int = 0
    capability_bound: dict[str, list[str]] = field(default_factory=dict)
    capability_dismissed: dict[str, dict[str, str]] = field(default_factory=dict)
    # Факты экспозиции для чек-листа рисков и споры со статусами оценки.
    exposures: list[dict[str, Any]] = field(default_factory=list)
    status_disputes: list[dict[str, Any]] = field(default_factory=list)

    def capability_state(self) -> tuple[dict[str, list[str]], dict[str, dict[str, str]], list[Capability]]:
        """(привязанные → узлы, отклонённые, не рассмотренные) по заполненным узлам."""
        records = self.evidence_corpus.records if self.evidence_corpus is not None else {}
        filled = {nid: n.data for nid, n in self.nodes.items() if n.filled}
        mapped = auto_mapped(self.capabilities, filled, records)
        for cid, nodes in self.capability_bound.items():
            live = [n for n in nodes if n in filled]
            if live:
                mapped[cid] = list(dict.fromkeys(mapped.get(cid, []) + live))
        dismissed = {cid: d for cid, d in self.capability_dismissed.items() if cid not in mapped}
        unreviewed = [c for c in self.capabilities if c.id not in mapped and c.id not in dismissed]
        return mapped, dismissed, unreviewed

    def new_id(self, ntype: str) -> str:
        self.counters[ntype] = max(self.counters.get(ntype, 0),
            max((int(n.rsplit("-", 1)[1]) for n in self.nodes if node_type(n) == ntype), default=0)) + 1
        return f"{ntype}-{self.counters[ntype]}"

    def tree_ids(self) -> list[str]:
        return list(self.nodes)

    def of_type(self, ntype: str) -> list[_Node]:
        return [n for n in self.nodes.values() if node_type(n.id) == ntype]

    def relation_keys(self) -> set[tuple[str, str, str]]:
        return {(r["from"], r["to"], r["kind"]) for r in self.relations}

    def relation_context(self) -> dict[str, dict[str, Any]]:
        """Родители и признак «до развилки» — для контекстных проверок связи."""
        return {nid: {"parents": list(n.parents), "before_fork": n.before_fork}
                for nid, n in self.nodes.items()}

    def processes_of(self, nid: str) -> set[str]:
        """Процессы, в которые узел входит (через любого из родителей)."""
        out: set[str] = set()
        frontier = [nid]
        seen: set[str] = set()
        while frontier:
            current = frontier.pop()
            if current in seen or current not in self.nodes:
                continue
            seen.add(current)
            if node_type(current) == "process":
                out.add(current)
                continue
            frontier.extend(self.nodes[current].parents)
        return out

    def bound_steps(self) -> set[tuple[str, int]]:
        out: set[tuple[str, int]] = set()
        for node in self.nodes.values():
            if self.agentic and node.planned and node_type(node.id) == "process":
                for sid in node.data.get("scenarios", []):
                    out.update((sid, i) for i in range(len(self.scenarios.get(sid, []))))
            for entry in node.data.get("scenario_steps") or []:
                out.add((str(entry.get("scenario")), int(entry.get("step"))))
        return out

    def unbound_steps(self) -> list[tuple[str, int, str]]:
        """Шаги целевых сценариев, у которых нет ни одного узла."""
        bound = self.bound_steps()
        return [
            (sid, index, text)
            for sid, steps in self.scenarios.items()
            for index, text in enumerate(steps)
            if (sid, index) not in bound
        ]


# --- обработчики ----------------------------------------------------------------

def _handle_submit_node(state: _PassportSession, args: dict) -> str:
    if state.agentic:
        from pko.progress.passport_drafts import submit
        return submit(state, args, _validate_submit_node)
    return _validate_submit_node(state, args)


def _validate_submit_node(state: _PassportSession, args: dict) -> str:
    from copy import deepcopy
    nid = str(args.get("id") or "").strip()
    ntype = node_type(nid)
    expected = _expected_submit(state)
    if not ntype or nid not in expected:
        return (f"submit_node отклонён: сейчас ожидается {_expected_text(state)}, "
                f"а пришёл «{nid or '?'}».")
    name = _clean(args.get("name"))
    basis = _clean(args.get("basis"))
    fields = args.get("fields")
    if isinstance(fields, str):
        try:
            fields = json.loads(fields)
        except ValueError:
            fields = None
    if not isinstance(fields, dict):
        fields = {}
    fields = _clean_fields(fields)
    audit = deepcopy(args.get("fact_check"))
    node = state.nodes.get(nid)
    if node is not None and not name:
        name = node.name
    if node is not None and not basis:
        basis = node.basis
    # Клиентский путь формулирует агент: переход клиента из исходного
    # состояния к ценному результату. Аудитория путём не является.
    if ntype == "journey" and name and _AUDIENCE_RE.search(name) and len(name.split()) <= 5:
        return (f"{nid} отклонён:\n- «{name}» — аудитория, а не клиентский путь. Назови путь как "
                "переход клиента к результату: что человек получает в конце.")
    if (ntype == "journey" and name and state.initiative_name
            and norm_name(name) == norm_name(state.initiative_name)):
        return (
            f"{nid} отклонён:\n- «{name}» повторяет название инициативы. Название "
            "клиентского пути должно выражать общий результат для клиента и "
            "охватывать все процессы, например «Размещение сбережений»"
        )
    if ntype == "journey" and name and _EMPTY_JOURNEY_NAME.search(name):
        return (
            f"{nid} отклонён:\n- «{name}» не раскрывает суть пути. Назови действие "
            "клиента и конечный результат, без служебных слов о пути или модели"
        )

    payload: dict[str, Any] = {"name": name, "basis": basis, "fields": fields}
    if state.agentic:
        payload["agent_contract"] = 2
        if state.research_basis == "code":
            payload["research_basis"] = "code"
        if isinstance(audit, str):
            try:
                audit = json.loads(audit)
            except ValueError:
                return f"{nid} отклонён: fact_check должен быть JSON-объектом."
    if args.get("explanation"):
        payload["explanation"] = _clean(args["explanation"])
    planned = bool(args.get("planned")) and ntype != "journey"
    if state.research_basis == "code":
        if args.get("planned"):
            return f"{nid} отклонён: карта описывает текущую реализацию; planned-узлы в этом режиме недопустимы. Найденную заглушку опиши существующим узлом, а отсутствующее продолжение — разрывом или открытым вопросом."
        from pko.progress.passport_system_research import verified_corpus_evidence
        _, existence_errors = verified_corpus_evidence(state.evidence_corpus, args.get("existence_evidence"))
        if existence_errors:
            return f"{nid} отклонён (существование узла): " + "; ".join(existence_errors[:8])
        payload["existence_evidence"] = deepcopy(args["existence_evidence"])
    generated_fields = set(GENERATED_FIELDS.get(ntype, set()))
    if planned and ntype == "process" and state.scenarios:
        generated_fields.update(("4.3.4", "4.3.5"))
    if state.evidence_corpus is not None:
        # Canonical read_node data includes links generated from the tree. They
        # are recomputed, not model claims requiring fabricated source quotes.
        for fid in generated_fields:
            fields.pop(fid, None)
            if isinstance(audit, dict) and isinstance(audit.get("fields"), dict):
                audit["fields"].pop(fid, None)
        if isinstance(audit, dict):
            audit.pop("generated_fields", None)
        if state.research_basis == "code":
            auto_unknown = apply_management_unknowns(fields, audit, ntype)
            if auto_unknown:
                payload["auto_unknown_fields"] = auto_unknown
        errors = check_node_audit(state.evidence_corpus, audit, fields, planned=planned)
        expected_fields = (PLANNED_FIELDS[ntype] if planned else NODE_FIELDS[ntype]) - generated_fields
        missing_fields = expected_fields - set(fields)
        if missing_fields:
            errors.append("Не проверены поля: " + ", ".join(sorted(missing_fields))
                          + ". Заполни их или явно укажи, что именно неизвестно.")
        if set(fields) - NODE_FIELDS[ntype]:
            errors.append("Есть поля другого уровня или неизвестные номера полей.")
        for fid in expected_fields & set(fields):
            if not isinstance(fields[fid], dict) or not fields[fid].get("value") or not fields[fid].get("source"):
                errors.append(f"{fid}: нужны value и source, в том числе для неизвестного.")
        if errors:
            # Provenance must never pass through the legacy soft acceptance limit.
            state.span.add_event("node_evidence_rejected", count=len(errors))
            return f"{nid} отклонён (основания):\n" + "\n".join(f"- {e}" for e in errors[:12])
        payload["fact_check"] = audit
        note = entry_note(state.evidence_corpus, audit)
        if note:
            payload["entry_note"] = note
    if planned:
        payload["planned"] = True
    if node is not None and node.before_fork:
        payload["before_fork"] = True
    if node is not None and node.branching:
        payload["branching"] = node.branching
    _fill_linked_fields(state, nid, ntype, fields)
    check = PassportCheck()
    if not name:
        check.errors.append(f"{nid}: нет названия (name)")
    if payload.get("explanation"):
        from pko.report.guard import check_text
        check.errors.extend(v.render() for v in check_text(payload["explanation"], set(), state.known_paths))
    if not basis:
        check.errors.append(f"{nid}: нет basis — одной фразы, почему узел существует как объект управления")
    if not fields:
        check.errors.append(f"{nid}: fields пуст — заполни поля раздела, по каждому value и source")
    _check_name_unique(check, state, nid, name)
    if ntype == "process" and state.scenarios and state.agentic:
        scenario_ids = args.get("scenarios")
        if scenario_ids is None:
            scenario_ids = [args["scenario"]] if args.get("scenario") else (node.data.get("scenarios", []) if node else [])
        if (not isinstance(scenario_ids, list) or not scenario_ids
                or any(not isinstance(sid, str) or sid not in state.scenarios for sid in scenario_ids)):
            check.errors.append(f"{nid}: укажи scenarios — действующие сценарии, в которых участвует процесс")
        else:
            payload["scenarios"] = list(dict.fromkeys(scenario_ids))
            payload["scenario"] = scenario_ids[0]  # compatibility for saved v1 consumers
            if planned:
                contexts = [state.scenario_context[sid] for sid in scenario_ids if sid in state.scenario_context]
                source = ("Выведено: необходимое продолжение сценария по исследованному коду; реализация отсутствует в указанном месте"
                          if state.research_basis == "code" else "Выведено: целевые сценарии из образа результата; план, не поведение кода")
                fields["4.3.4"] = {"value": "План: " + "; ".join(c["entry"] for c in contexts), "source": source}
                fields["4.3.5"] = {"value": "План: " + "; ".join(c["outcome"] for c in contexts), "source": source}
    elif ntype == "process" and state.scenarios:
        scenario_id = str(args.get("scenario") or "").strip()
        if not scenario_id and node is not None and node.filled:
            scenario_id = str(node.data.get("scenario") or "").strip()
        claimed = {
            str(other.data.get("scenario") or "").strip()
            for other in state.of_type("process")
            if other.id != nid and other.filled
        }
        unclaimed = [sid for sid in state.scenarios if sid not in claimed]
        if not scenario_id and len(unclaimed) == 1:
            scenario_id = unclaimed[0]
        if scenario_id not in state.scenarios:
            check.errors.append(
                f"{nid}: process — это один целевой сценарий; укажи scenario из списка: "
                + ", ".join(state.scenarios)
            )
        elif scenario_id in claimed:
            check.errors.append(
                f"{nid}: сценарий {scenario_id} уже представлен другим процессом; "
                "один сценарий нельзя дублировать двумя процессами"
            )
        else:
            payload["scenario"] = scenario_id
            if planned and scenario_id in state.scenario_context:
                scenario = state.scenario_context[scenario_id]
                source = (f"Выведено: целевой сценарий «{state.scenario_titles.get(scenario_id, scenario_id)}» "
                          "из образа результата; план, не поведение кода")
                fields["4.3.4"] = {"value": "План: " + scenario["entry"], "source": source}
                fields["4.3.5"] = {"value": "План: " + " → ".join(state.scenarios[scenario_id])
                                   + ". Ожидаемый результат: " + scenario["outcome"], "source": source}
    if state.evidence_corpus is not None:
        generated = {fid: fields[fid]["source"] for fid in sorted(generated_fields) if fid in fields}
        if generated:
            payload["fact_check"]["generated_fields"] = generated
            for fid in generated:
                payload["fact_check"]["fields"].pop(fid, None)
    check_node_fields(check, nid, payload)
    if planned:
        payload["fields"] = {fid: f for fid, f in fields.items() if fid in PLANNED_FIELDS.get(ntype, set())}

    if ntype != "journey":
        _attach_links(state, check, nid, ntype, args, payload)
        if planned and state.research_basis != "code":
            _check_planned_against_verdicts(state, check, nid, payload.get("bullets") or [])

    if ntype == "journey":
        boundary = str(args.get("decision_boundary") or "").strip()
        if boundary not in DECISION_BOUNDARIES:
            check.errors.append(
                "journey: decision_boundary должен быть END_TO_END_PROCESS "
                "(путь покрывает триггер входа и результат после) или COMPONENT_BBB "
                "(диалог внутри агента от классификации до сообщения)"
            )
        else:
            payload["decision_boundary"] = boundary

    if check.errors:
        state.attempts[nid] = state.attempts.get(nid, 0) + 1
        state.span.add_event("node_rejected", node=nid, attempts=state.attempts[nid])
        if state.agentic or state.evidence_corpus is not None or state.attempts[nid] <= MAX_NODE_REJECTIONS:
            listed = "\n".join(f"- {e}" for e in check.errors[:10])
            return f"{nid} отклонён:\n{listed}\nИсправь и вызови submit_node({nid}) снова."
        state.notes.append(
            f"{nid} принят с нарушениями после {MAX_NODE_REJECTIONS} отклонений: "
            + "; ".join(check.errors[:6])
        )

    if node is None:
        node = _Node(id=nid, name=name, basis=basis)
        state.nodes[nid] = node
    previous_data = node.data
    node.name, node.basis = name, basis
    node.planned = planned
    # Повторная отправка после дерева (исправление по замечанию) не теряет
    # привязок сценариев, сделанных bind_scenario_step.
    if node.filled and not payload.get("scenario_steps"):
        payload["scenario_steps"] = list(node.data.get("scenario_steps") or [])
    node.data = payload
    node.filled = True
    if state.agentic:
        from pko.progress.passport_gate import _unique_object_id
        payload["object-id"] = previous_data.get("object-id") or _unique_object_id(
            ntype, name, {n.data["object-id"] for n in state.nodes.values() if n.data.get("object-id")})
        for other in state.nodes.values():
            if other.filled:
                _fill_linked_fields(state, other.id, node_type(other.id), other.data.setdefault("fields", {}))
        if previous_data != payload:
            state.risk_reviewed = False
        state.current = state.awaiting_children_of = None
        state.queue.clear()
    if ntype == "journey":
        state.decision_boundary = payload.get("decision_boundary", state.decision_boundary)
    state.remarks.extend(check.remarks)
    state.span.add_event(
        "node_accepted", node=nid, remarks=len(check.remarks),
        count=sum(1 for item in state.nodes.values() if item.filled),
    )
    if state.on_node is not None:
        state.on_node(nid, name)

    reply = [f"{nid} «{name}» принят."]
    if check.remarks:
        reply.append("Замечания (исправь при желании повторным submit_node, иначе продолжай):")
        reply.extend(f"- {r}" for r in check.remarks[:6])

    if state.agentic:
        reply.append(_advance(state))
        return "\n".join(reply)
    if state.tree_done:
        # Правка уже принятого узла после дерева: очередь не трогаем.
        reply.append(_after_tree_text(state))
        return "\n".join(reply)

    if planned and ntype in CHILD_TYPE:
        # Обещание без реализации — одна карточка и строка в реестре дефектов,
        # а не поддерево пустых карточек: детей у планируемого узла код не ждёт.
        reply.append("Узел планируемый: детей у него не заводим — обещание уйдёт в реестр дефектов как дефект полноты.")
        state.current = None
        reply.append(_advance(state))
        return "\n".join(reply)
    if ntype in CHILD_TYPE:
        state.current = None
        state.awaiting_children_of = nid
        child_label = TYPE_LABEL[CHILD_TYPE[ntype]]
        reply.append(
            f"Теперь объяви детей: declare_children(parent=\"{nid}\", children=[{{name, basis}} | {{ref}}, …]) "
            f"— {child_label.lower()} ({_children_hint(ntype)}). Дети обязательны."
        )
        return "\n".join(reply)

    state.current = None
    reply.append(_advance(state))
    return "\n".join(reply)


def _fill_linked_fields(state: _PassportSession, nid: str, ntype: str, fields: dict[str, Any]) -> None:
    """Связанный КП у процесса и связанный BBB у операции заполняет код:
    имя берётся из дерева, а не переписывается моделью в каждой карточке."""
    node = state.nodes.get(nid)
    parent = state.nodes.get(node.parent) if node is not None and node.parent else None
    if ntype == "process":
        root = next(iter(state.of_type("journey")), None)
        if root is not None:
            fields[_LINKED_JOURNEY_FIELD] = {
                "value": f"Клиентский путь «{root.name}».",
                "source": "Выведено: название пути сформулировано по исходному и целевому состоянию инициативы, узел journey-1",
            }
    elif ntype == "operation" and parent is not None:
        others = [state.nodes[p].name for p in node.parents[1:] if p in state.nodes]
        value = f"BBB «{parent.name}»" + (" (также в " + ", ".join(f"«{n}»" for n in others) + ")" if others else "") + "."
        fields[_LINKED_BBB_FIELD] = {
            "value": value,
            "source": f"Установлено: место операции в дереве паспорта — родитель {parent.id}",
        }


def _check_planned_against_verdicts(state: _PassportSession, check: PassportCheck,
                                    nid: str, bullets: list[str]) -> None:
    """«В коде нет» спорит с оценкой, если привязанный пункт ОР работает."""
    working = [b for b in bullets if state.bullet_status.get(b) in _WORKING_STATUSES]
    if working:
        check.errors.append(
            f"{nid}: узел объявлен планируемым, но его пункт ОР оценён как работающий: "
            + "; ".join(f"«{b[:60]}»" for b in working[:3])
            + ". Либо узел реализован (убери planned), либо пункт привязан не к тому узлу"
        )


def _attach_links(state: _PassportSession, check: PassportCheck, nid: str, ntype: str,
                  args: dict, payload: dict[str, Any]) -> None:
    """Привязка узла к пунктам ОР и шагам сценариев — модель предлагает,
    код сопоставляет. Несопоставленное отбрасывается с замечанием, а не
    с отклонением: карточка узла ценна и без раскраски."""
    raw_bullets = args.get("bullets")
    bullets = match_bullets(raw_bullets, state.plan_bullets) if state.plan_bullets and state.research_basis != "code" else []
    if state.research_basis == "code":
        pass  # OR is optional context, never a node coverage or status signal.
    elif isinstance(raw_bullets, list) and raw_bullets and not bullets:
        check.remarks.append(
            f"{nid}: ни один из названных пунктов ОР не сопоставлен — цитируй пункты "
            "дословно из задания"
        )
    elif ntype in SCENARIO_NODE_TYPES and not bullets and state.plan_bullets:
        check.remarks.append(
            f"{nid}: не привязан к пунктам ОР (bullets) — без этого готовность узла на "
            "схеме не считается"
        )
    payload["bullets"] = bullets

    steps_out: list[dict[str, Any]] = []
    raw_steps = args.get("scenario_steps")
    if isinstance(raw_steps, list):
        if ntype not in SCENARIO_NODE_TYPES and raw_steps:
            check.remarks.append(
                f"{nid}: шаги сценариев выполняют BBB и операции, а не {TYPE_LABEL[ntype].lower()} — "
                "привязка отброшена, укажи её у детей"
            )
        else:
            for item in raw_steps:
                if not isinstance(item, dict):
                    continue
                sid = str(item.get("scenario") or "").strip()
                try:
                    step = int(item.get("step"))
                except (TypeError, ValueError):
                    check.remarks.append(f"{nid}: у scenario_steps step должен быть числом")
                    continue
                problem = _scenario_step_problem(state, sid, step)
                if not problem and state.agentic:
                    problem = _scenario_node_problem(state, nid, sid)
                if problem:
                    (check.errors if state.agentic else check.remarks).append(f"{nid}: {problem}")
                    continue
                entry = {"scenario": sid, "step": step}
                if entry not in steps_out:
                    steps_out.append(entry)
    payload["scenario_steps"] = steps_out


def _scenario_step_problem(state: _PassportSession, sid: str, step: int) -> str:
    steps = state.scenarios.get(sid)
    if steps is None:
        if not state.scenarios:
            return "целевых сценариев в задании нет"
        return f"сценария {sid!r} нет — есть: " + ", ".join(state.scenarios)
    if not (0 <= step < len(steps)):
        return f"у {sid} шаги 0–{len(steps) - 1}, прислан {step}"
    return ""


def _scenario_node_problem(state: _PassportSession, nid: str, sid: str) -> str:
    if not state.agentic:
        return ""
    if any(sid in state.nodes[p].data.get("scenarios", []) for p in state.processes_of(nid)):
        return ""
    frontier, ancestors = [nid], set()
    while frontier:
        current = frontier.pop()
        if current in ancestors or current not in state.nodes:
            continue
        ancestors.add(current)
        frontier.extend(state.nodes[current].parents)
    before = {n for n in ancestors if state.nodes[n].before_fork}
    if any(r["kind"] == "triggers" and r["from"] in before
           and sid in state.nodes[r["to"]].data.get("scenarios", []) for r in state.relations):
        return ""
    return f"{nid} не входит в процесс сценария {sid}; для узла до развилки нужна подтверждённая triggers к такому процессу"


def _handle_declare_children(state: _PassportSession, args: dict) -> str:
    parent_id = str(args.get("parent") or "").strip()
    if state.agentic:
        if parent_id not in state.nodes or node_type(parent_id) not in CHILD_TYPE or state.nodes[parent_id].planned:
            return "declare_children отклонён: нужен существующий непланируемый контейнер."
    elif state.awaiting_children_of is None or parent_id != state.awaiting_children_of:
        return (f"declare_children отклонён: сейчас ожидается {_expected_text(state)}"
                + (f", а не объявление детей у «{parent_id}»" if parent_id else ""))
    parent = state.nodes[parent_id]
    ptype = node_type(parent_id)
    ctype = CHILD_TYPE[ptype]
    branching = str(args.get("branching") or "").strip()
    raw = args.get("children")
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            raw = None
    items = [c for c in (raw or []) if isinstance(c, dict)]
    new_children = [c for c in items if not str(c.get("ref") or "").strip() and str(c.get("name") or "").strip()]
    refs = [str(c.get("ref") or "").strip() for c in items if str(c.get("ref") or "").strip()]
    if state.agentic and len(state.nodes) + len(new_children) > 160:
        return "declare_children отклонён: лимит 160 узлов; сохрани существенные объекты и явные границы проверки."
    # Узлы до развилки объявляются у пути вместе с процессами и в дереве
    # стоят перед ними: они выполняются раньше любого процесса.
    gate_children = [c for c in new_children if ptype == "journey" and bool(c.get("before_fork"))]
    new_children = [c for c in gate_children] + [c for c in new_children if c not in gate_children]

    check = PassportCheck()
    if branching and branching not in BRANCHING_KINDS:
        check.errors.append(
            f"{parent_id}: тип ветвления «{branching}» не из списка: "
            + ", ".join(f"{k} ({BRANCHING_HINT[k]})" for k in BRANCHING_KINDS)
        )
    if not new_children and not refs:
        check.errors.append(
            f"{parent_id}: у {TYPE_LABEL[ptype].lower()} должен быть хотя бы один "
            f"{TYPE_LABEL[ctype].lower()} — {_children_hint(ptype)}"
        )
    if ptype == "journey" and new_children and len(gate_children) == len(new_children) and not refs:
        check.errors.append(
            f"{parent_id}: объявлены только узлы до развилки — у клиентского пути должен "
            "быть хотя бы один процесс"
        )
    if ptype != "journey" and any(bool(c.get("before_fork")) for c in new_children):
        check.errors.append(
            f"{parent_id}: before_fork допустим только у детей клиентского пути — "
            "узел до развилки стоит перед процессами, а не внутри"
        )
    seen: set[str] = set()
    for child in new_children:
        cname = _clean(child.get("name"))
        cbasis = _clean(child.get("basis"))
        key = norm_name(cname)
        child_type = "bbb" if child in gate_children else ctype
        if not cbasis:
            check.errors.append(f"«{cname}»: нет basis")
        if key in seen:
            check.errors.append(f"«{cname}» объявлен дважды")
        seen.add(key)
        if key == norm_name(parent.name):
            check.errors.append(duplicate_name_message(f"{child_type}-?", parent_id, cname))
        else:
            _check_name_unique(check, state, f"{child_type}-?", cname)
    # Ссылка на уже объявленный узел — общий ребёнок: второй родитель того же
    # уровня, а не новый узел. Существование и тип проверяет гейт.
    shared: list[str] = []
    for ref in refs:
        if ref in shared:
            check.errors.append(f"{ref} указан дважды")
            continue
        problem = parent_link_problem(ref, parent_id, set(state.nodes)) if ref in state.nodes else f"{ref}: узла нет"
        if not problem and state.nodes[ref].before_fork:
            problem = (f"{ref}: узел до развилки выполняется до выбора процесса и в процессы "
                       "не входит; если процесс им запускается — link_nodes(kind=triggers)")
        if problem:
            check.errors.append(f"ref {problem}")
            continue
        if parent_id in state.nodes[ref].parents:
            check.errors.append(f"{ref} уже ребёнок {parent_id}")
            continue
        shared.append(ref)
    total = len(new_children) + len(shared)
    if (not state.agentic and ptype == "process" and len(new_children) == 1 and not shared
            and norm_name(new_children[0].get("basis")) == norm_name(parent.basis)):
        check.errors.append(collapsed_level_message(parent_id, f"{ctype}-?"))
    if (not state.agentic and ptype == "bbb" and len(new_children) == 1 and not shared
            and norm_name(new_children[0].get("basis")) == norm_name(parent.basis)):
        check.errors.append(
            f"{parent_id} и operation-?: единственная операция повторяет основание BBB. "
            "Операция должна называть конкретный вызов, вход, выход и собственную точку "
            "отказа; если отдельной точки отказа нет, не создавай формальный уровень"
        )

    if check.errors:
        key = f"children:{parent_id}"
        state.attempts[key] = state.attempts.get(key, 0) + 1
        state.span.add_event("children_rejected", node=parent_id, attempts=state.attempts[key])
        if state.agentic or state.attempts[key] <= MAX_NODE_REJECTIONS or not total:
            listed = "\n".join(f"- {e}" for e in check.errors[:10])
            return (f"дети {parent_id} отклонены:\n{listed}\n"
                    f"Исправь и вызови declare_children(parent=\"{parent_id}\") снова.")
        state.notes.append(
            f"дети {parent_id} приняты с нарушениями: " + "; ".join(check.errors[:6])
        )

    if not state.agentic and ptype == "process" and total < MIN_BBB_PER_PROCESS:
        state.remarks.append(
            f"{parent_id}: один BBB на процесс — проверь по признакам дробления "
            "(разные входы/результаты, внешние системы, расчёт vs генерация, "
            "режим полномочий); обычно процесс описан одним куском"
        )

    if branching in BRANCHING_KINDS:
        parent.branching = branching
        parent.data["branching"] = branching
    elif ptype != "journey" and len(new_children) + len(shared) > 1:
        state.remarks.append(
            f"{parent_id}: у узла несколько веток, а тип ветвления не назван — укажи branching "
            "(mandatory_parallel / alternative / optional / sequence): для обязательных "
            "параллельных веток результат родителя требует всех"
        )
    ids: list[str] = []
    for child in new_children:
        is_gate = child in gate_children
        cid = state.new_id("bbb" if is_gate else ctype)
        state.nodes[cid] = _Node(
            id=cid, name=_clean(child.get("name")),
            basis=_clean(child.get("basis")), parents=[parent_id],
            before_fork=is_gate,
        )
        parent.children.append(cid)
        ids.append(cid)
    for ref in shared:
        state.nodes[ref].parents.append(parent_id)
        parent.children.append(ref)
    # Обход в глубину: первый новый ребёнок заполняется следующим, остальные ждут.
    state.queue[0:0] = ids
    state.awaiting_children_of = None
    state.span.add_event("children_declared", node=parent_id, count=total)

    parts = [f"{cid} «{state.nodes[cid].name}»" + (" (до развилки)" if state.nodes[cid].before_fork else "")
             for cid in ids]
    parts += [f"{ref} «{state.nodes[ref].name}» (общий, уже заполнен)" for ref in shared]
    reply = [f"{parent_id}: объявлено {total} — " + ", ".join(parts) + "."]
    if not state.agentic and ptype == "process" and total < MIN_BBB_PER_PROCESS:
        reply.append("Замечание: " + state.remarks[-1])
    elif not branching and ptype != "journey" and total > 1:
        reply.append("Замечание: " + state.remarks[-1])
    reply.append(_advance(state))
    return "\n".join(reply)


def _handle_link_nodes(state: _PassportSession, args: dict) -> str:
    if not state.agentic and (state.awaiting_children_of or state.current):
        return (f"link_nodes отклонён: сначала {_expected_text(state)}; связи объявляй "
                "между уже объявленными узлами, лучше после дерева.")
    rel = {
        "from": str(args.get("from") or "").strip(),
        "to": str(args.get("to") or "").strip(),
        "kind": str(args.get("kind") or "").strip(),
        "basis": _clean(args.get("basis")),
        "field": _clean(args.get("field")),
    }
    check = PassportCheck()
    key = (rel["from"], rel["to"], rel["kind"])
    if state.evidence_corpus is not None:
        check.errors.extend(check_relation_proof(state.evidence_corpus, args.get("proof"), rel["kind"], rel["field"]))
        if not check.errors:
            rel["proof"] = args["proof"]
    check_relation(check, rel, set(state.nodes), state.relation_keys(), state.relation_context())
    if rel["kind"] == "includes" and rel["to"] in state.nodes and rel["from"] in state.nodes[rel["to"]].parents:
        check.errors.append(f"связь {rel['from']} → {rel['to']}: {rel['from']} уже родитель {rel['to']} — дерево связью не дублируй")
    if check.errors:
        if state.evidence_corpus is not None:
            state.unresolved_relations[key] = "; ".join(check.errors[:6])
        state.span.add_event("relation_rejected", count=len(check.errors))
        return "связь отклонена:\n" + "\n".join(f"- {e}" for e in check.errors[:6])
    state.relations.append(rel)
    if state.agentic:
        state.risk_reviewed = False
    state.unresolved_relations.pop(key, None)
    if rel["kind"] == "includes":
        state.nodes[rel["to"]].parents.append(rel["from"])
        state.nodes[rel["from"]].children.append(rel["to"])
    state.remarks.extend(check.remarks)
    state.span.add_event("relation_accepted", kind=rel["kind"])
    reply = [f"связь принята: {rel['from']} {RELATION_LABEL[rel['kind']]} {rel['to']}."]
    reply.extend(f"Замечание: {r}" for r in check.remarks[:3])
    if state.tree_done:
        reply.append(_after_tree_text(state))
    else:
        reply.append(_advance(state))
    return "\n".join(reply)


def _handle_bind_scenario_step(state: _PassportSession, args: dict) -> str:
    if not state.agentic and (state.awaiting_children_of or state.current):
        return f"bind_scenario_step отклонён: сначала {_expected_text(state)}."
    sid = str(args.get("scenario") or "").strip()
    try:
        step = int(args.get("step"))
    except (TypeError, ValueError):
        return "bind_scenario_step отклонён: step должен быть числом."
    problem = _scenario_step_problem(state, sid, step)
    if problem:
        return f"bind_scenario_step отклонён: {problem}."
    raw = args.get("nodes")
    if isinstance(raw, str):
        raw = [raw]
    ids = [str(x).strip() for x in (raw or []) if str(x).strip()]
    errors: list[str] = []
    accepted: list[str] = []
    for nid in ids:
        node = state.nodes.get(nid)
        if node is None:
            errors.append(f"узла {nid} нет")
        elif node_type(nid) not in SCENARIO_NODE_TYPES:
            errors.append(f"{nid}: шаги сценариев выполняют BBB и операции, а не {TYPE_LABEL[node_type(nid)].lower()}")
        elif problem := _scenario_node_problem(state, nid, sid):
            errors.append(problem)
        else:
            accepted.append(nid)
    replace = state.agentic and args.get("replace") is True
    if errors and state.agentic:
        return "bind_scenario_step отклонён: " + "; ".join(errors)
    if not accepted and not replace:
        return "bind_scenario_step отклонён:\n" + "\n".join(f"- {e}" for e in (errors or ["nodes пуст"]))
    if replace:
        for node in state.nodes.values():
            node.data["scenario_steps"] = [x for x in node.data.get("scenario_steps", [])
                                          if not (x.get("scenario") == sid and x.get("step") == step)]
        state.workspace.event("step_rebound", scenario=sid, step=step, nodes=accepted)
    for nid in accepted:
        node = state.nodes[nid]
        steps = list(node.data.get("scenario_steps") or [])
        entry = {"scenario": sid, "step": step}
        if entry not in steps:
            steps.append(entry)
        node.data["scenario_steps"] = steps
    reply = [f"{sid} шаг {step} «{state.scenarios[sid][step]}» — привязан к " + ", ".join(accepted) + "."]
    if errors:
        reply.append("Отброшено: " + "; ".join(errors))
    reply.append(_after_tree_text(state) if state.tree_done else _advance(state))
    return "\n".join(reply)


def _handle_submit_defect(state: _PassportSession, args: dict) -> str:
    if not state.agentic and (state.awaiting_children_of or state.current):
        return f"submit_defect отклонён: сначала {_expected_text(state)}; дефекты — после дерева."
    replace_id = str(args.get("id") or "") if state.agentic else ""
    previous = next((d for d in state.defects if d.get("id") == replace_id), None) if replace_id else None
    if replace_id and previous is None:
        return "submit_defect отклонён: неизвестный id; для новой записи не передавай id."
    if len(state.defects) >= MAX_DEFECTS and previous is None:
        return f"submit_defect отклонён: реестр дефектов полон ({MAX_DEFECTS})."
    defect = {
        "title": _clean(args.get("title")),
        "kind": str(args.get("kind") or "").strip(),
        "nodes": [str(x).strip() for x in (args.get("nodes") or []) if str(x).strip()] if isinstance(args.get("nodes"), list) else [],
        "scenarios": [str(x).strip() for x in (args.get("scenarios") or []) if str(x).strip()] if isinstance(args.get("scenarios"), list) else [],
        "where": _clean(args.get("where")),
        "blocking": bool(args.get("blocking")),
    }
    check = PassportCheck()
    if state.agentic:
        defect["id"] = replace_id or _record_id(state, "defect", state.defects)
        defect["evidence"] = args.get("evidence", [])
        check.errors.extend(state.evidence_corpus.citations(defect["evidence"], code=True)
                            if state.evidence_corpus is not None else ["нужен корпус оснований"])
        if not check.errors:
            check.errors.extend(claim_citation_errors(state.evidence_corpus, defect["where"], defect["evidence"]))
    check_defect(check, defect, set(state.nodes), set(state.scenarios), state.known_paths or None)
    if any(d is not previous and norm_name(d["title"]) == norm_name(defect["title"]) for d in state.defects):
        check.errors.append(f"дефект «{defect['title'][:30]}» уже заведён — один дефект, одна строка")
    if check.errors:
        state.span.add_event("defect_rejected", count=len(check.errors))
        return "дефект отклонён:\n" + "\n".join(f"- {e}" for e in check.errors[:6])
    if previous is not None:
        state.defects[state.defects.index(previous)] = defect
    else:
        state.defects.append(defect)
    state.remarks.extend(check.remarks)
    state.span.add_event("defect_accepted", kind=defect["kind"])
    reply = [f"дефект принят ({len(state.defects)}): {defect['title'][:80]}."]
    reply.extend(f"Замечание: {r}" for r in check.remarks[:2])
    reply.append(_after_tree_text(state) if state.tree_done else _advance(state))
    return "\n".join(reply)


def _record_id(state: _PassportSession, kind: str, rows: list[dict]) -> str:
    largest = max((int(str(r["id"]).rsplit("-", 1)[1]) for r in rows
                   if str(r.get("id", "")).startswith(kind + "-")
                   and str(r["id"]).rsplit("-", 1)[1].isdigit()), default=0)
    state.counters[kind] = max(state.counters.get(kind, 0), largest) + 1
    return f"{kind}-{state.counters[kind]}"


def _handle_submit_need(state: _PassportSession, args: dict) -> str:
    if not state.agentic and (state.awaiting_children_of or state.current):
        return f"submit_need отклонён: сначала {_expected_text(state)}."
    if len(state.needs) >= MAX_NEEDS:
        return f"submit_need отклонён: потребностей уже {MAX_NEEDS}."
    need = {"name": _clean(args.get("name")), "purpose": _clean(args.get("purpose")), "source": _clean(args.get("source"))}
    check = PassportCheck()
    check_need(check, need)
    if any(norm_name(n["name"]) == norm_name(need["name"]) for n in state.needs):
        check.errors.append(f"потребность «{need['name'][:30]}» уже сформулирована")
    if check.errors:
        return "потребность отклонена:\n" + "\n".join(f"- {e}" for e in check.errors[:6])
    state.needs.append(need)
    state.span.add_event("need_accepted")
    return f"потребность принята ({len(state.needs)}): {need['name']}.\n" + (_after_tree_text(state) if state.tree_done else _advance(state))


def _handle_submit_guardrail(state: _PassportSession, args: dict) -> str:
    if not state.agentic and (state.awaiting_children_of or state.current):
        return f"submit_guardrail отклонён: сначала {_expected_text(state)}."
    replace_id = str(args.get("id") or "") if state.agentic else ""
    previous = next((g for g in state.guardrails if g.get("id") == replace_id), None) if replace_id else None
    if replace_id and previous is None:
        return "submit_guardrail отклонён: неизвестный id; для новой записи не передавай id."
    if len(state.guardrails) >= MAX_GUARDRAILS and previous is None:
        return f"submit_guardrail отклонён: ограничений уже {MAX_GUARDRAILS}."
    raw_targets = args.get("targets")
    guardrail = {
        "id": f"guardrail-{len(state.guardrails) + 1}",
        "name": _clean(args.get("name")), "invariant": _clean(args.get("invariant")),
        "condition": _clean(args.get("condition")), "effect": str(args.get("effect") or "").strip().upper(),
        "targets": [str(x).strip() for x in raw_targets if str(x).strip()] if isinstance(raw_targets, list) else [str(raw_targets or "").strip()],
        "source": _clean(args.get("source")),
    }
    check = PassportCheck()
    if state.agentic:
        guardrail["id"] = replace_id or _record_id(state, "guardrail", state.guardrails)
        guardrail["evidence"] = args.get("evidence", [])
        check.errors.extend(state.evidence_corpus.citations(guardrail["evidence"], code=True)
                            if state.evidence_corpus is not None else ["нужен корпус оснований"])
        if not check.errors:
            check.errors.extend(claim_citation_errors(state.evidence_corpus,
                guardrail["source"] + "\n" + guardrail["invariant"], guardrail["evidence"]))
    check_guardrail(check, guardrail, set(state.nodes))
    if any(g is not previous and norm_name(g["name"]) == norm_name(guardrail["name"]) for g in state.guardrails):
        check.errors.append(f"ограничение «{guardrail['name'][:30]}» уже сформулировано")
    if check.errors:
        return "ограничение отклонено:\n" + "\n".join(f"- {e}" for e in check.errors[:6])
    if previous is not None:
        state.guardrails[state.guardrails.index(previous)] = guardrail
    else:
        state.guardrails.append(guardrail)
    state.span.add_event("guardrail_accepted", effect=guardrail["effect"])
    return f"ограничение {guardrail['id']} принято ({len(state.guardrails)}): {guardrail['name']}.\n" + (_after_tree_text(state) if state.tree_done else _advance(state))


def _handle_submit_risks(state: _PassportSession, args: dict) -> str:
    if not state.agentic and (state.awaiting_children_of or state.current or not state.tree_done):
        return f"submit_risks отклонён: сначала {_expected_text(state)}; риски финализируются после дерева."
    raw = args.get("risks")
    if not isinstance(raw, list):
        return "submit_risks отклонён: risks должен быть массивом; передай [] после выполненного анализа, если обоснованных рисков нет."
    if len(raw) > MAX_RISKS:
        return f"submit_risks отклонён: рисков больше лимита {MAX_RISKS}; дедуплицируй одинаковые события и последствия."
    candidate_ids = [state.workspace.candidate(item) for item in raw if isinstance(item, dict)] if state.agentic else []

    candidates: list[dict[str, Any]] = []
    errors: list[str] = []
    remarks: list[str] = []
    seen: dict[str, int] = {}
    seen_titles: set[str] = set()
    known_guardrails = {str(g.get("id") or "") for g in state.guardrails}
    for index, item in enumerate(raw, 1):
        if not isinstance(item, dict):
            errors.append(f"риск {index}: ожидается объект")
            continue
        controls = []
        for control in item.get("existing_controls") or []:
            if isinstance(control, dict):
                controls.append({"description": _clean(control.get("description")),
                                 "basis": _clean(control.get("basis"))})
            else:
                controls.append(control)
        evidence = []
        for ev in item.get("evidence") or []:
            if isinstance(ev, dict):
                evidence.append({"where": _clean(ev.get("where")), "basis": _clean(ev.get("basis"))})
            else:
                evidence.append(ev)
        risk = {
            "title": _clean(item.get("title")),
            "problem": _clean(item.get("problem")),
            "scope": str(item.get("scope") or "").strip(),
            "cause": _clean(item.get("cause")),
            "negative_event": _clean(item.get("negative_event")),
            "consequences": [_clean(x) for x in item.get("consequences") or [] if _clean(x)]
                            if isinstance(item.get("consequences"), list) else [],
            "primary_node": str(item.get("primary_node") or "").strip(),
            "linked_nodes": [str(x).strip() for x in item.get("linked_nodes") or [] if str(x).strip()]
                            if isinstance(item.get("linked_nodes"), list) else [],
            "existing_controls": controls,
            "control_gap": _clean(item.get("control_gap")),
            "guardrails": [str(x).strip() for x in item.get("guardrails") or [] if str(x).strip()]
                          if isinstance(item.get("guardrails"), list) else [],
            "evidence": evidence,
            "confidence": str(item.get("confidence") or "").strip(),
            "confidence_note": _clean(item.get("confidence_note")),
            "confirmation_needed": _clean(item.get("confirmation_needed")),
        }
        if state.agentic:
            risk["id"] = state.workspace.candidate(item).replace("candidate-", "risk-", 1)
        check = PassportCheck()
        for key in ("trigger", "mechanism", "recommendation", "closure_criterion"):
            risk[key] = _clean(item.get(key))
            if len(risk[key]) < 20:
                check.errors.append(f"{key}: нужно конкретное объяснение, не короче 20 символов")
        if state.evidence_corpus is not None:
            check.errors.extend(check_control_review(state.evidence_corpus, item.get("control_review")))
            risk["control_review"] = item.get("control_review")
        check_risk(check, risk, set(state.nodes), known_guardrails, state.known_paths, strict=True)
        signature = norm_name(risk["negative_event"]) + "|" + risk["primary_node"]
        if signature and signature in seen:
            check.errors.append(
                f"дублирует риск {seen[signature]} — объедини причины, последствия, узлы и основания без потери"
            )
        if norm_name(risk["title"]) in seen_titles:
            check.errors.append("название риска повторяется — объедини дубликаты или уточни разные события")
        if check.errors:
            errors.extend(f"риск {index}: {message}" for message in check.errors[:8])
        else:
            seen[signature] = index
            seen_titles.add(norm_name(risk["title"]))
            candidates.append(risk)
            remarks.extend(check.remarks)
    review = args.get("review")
    analysis = _clean(args.get("analysis"))
    if len(analysis) < 80:
        errors.append("analysis: нужно подробное общее обоснование проверок, результатов и ограничений (не короче 80 символов)")
    from pko.report.guard import check_text
    errors.extend(v.render() for v in check_text(analysis, set(), state.known_paths))
    exposures = {e["id"]: bool(e.get("required")) for e in state.exposures} if state.exposures else None
    errors.extend(validate_review(review, {n.id for n in state.of_type("process")}, candidates,
                                  state.known_paths, exposures=exposures))
    if errors:
        state.span.add_event("risks_rejected", count=len(errors))
        return "submit_risks отклонён:\n" + "\n".join(f"- {e}" for e in errors[:16])

    if state.agentic:
        incoming = set(candidate_ids)
        missing = [r["id"] for r in state.workspace.risk_candidates.values()
                   if r["id"] not in incoming and r["state"] in ("proposed", "accepted")]
        if missing:
            return ("submit_risks отклонён: прежние находки не исчезают при новой отправке: "
                    + ", ".join(missing) + ". Верни их либо resolve_finding с основанием пересмотра.")
        for cid in candidate_ids:
            state.workspace.risk_candidates[cid]["state"] = "accepted"
            state.workspace.event("risk_accepted", candidate_id=cid)
    state.risks = candidates
    state.risk_review = review
    state.risk_analysis = analysis
    state.risk_reviewed = True
    state.remarks.extend(remarks)
    state.span.add_event("risks_accepted", count=len(candidates))
    reply = [f"анализ операционных рисков принят: {len(candidates)}."]
    reply.extend(f"Замечание: {r}" for r in remarks[:3])
    reply.append(_after_tree_text(state))
    return "\n".join(reply)


def _handle_finish(state: _PassportSession, args: dict) -> str:
    if state.agentic:
        errors = _agentic_blockers(state)
        if errors:
            return "finish отклонён: " + "; ".join(errors[:16]) + ". Исправь основания или сохрани явную границу проверки; повтор не снимает ошибки."
        state.finished = True
        state.stop_reason = "completed"
        return "Паспорт завершён: обязательные проверки выполнены. Это статический анализ, не доказательство эксплуатации."
    missing = _unfinished(state)
    if missing:
        return "finish отклонён: " + "; ".join(missing) + ". " + _expected_text(state)
    if not state.risk_reviewed:
        return (
            "finish отклонён: операционные риски не проанализированы. После локальной проверки "
            "BBB/операций и сквозной проверки стыков вызови submit_risks(risks=[…]); если "
            "полных причинных цепочек нет — submit_risks(risks=[])."
        )
    scenario_issues = _process_scenario_issues(state)
    if scenario_issues:
        state.attempts["process_scenarios"] = state.attempts.get("process_scenarios", 0) + 1
        if state.attempts["process_scenarios"] <= MAX_FINISH_REJECTIONS:
            return (
                "finish отклонён: process должен совпадать с целевым сценарием один к одному — "
                + "; ".join(scenario_issues)
                + ". Исправь process повторным submit_node(id, scenario=\"scenario-N\")."
            )
        state.remarks.append("несовпадение процессов и сценариев: " + "; ".join(scenario_issues))
    unbound = state.unbound_steps()
    if unbound:
        state.attempts["finish"] = state.attempts.get("finish", 0) + 1
        if state.attempts["finish"] <= MAX_FINISH_REJECTIONS:
            return ("finish отклонён: шаги сценариев без узла — "
                    + _unbound_text(unbound)
                    + ". Привяжи их bind_scenario_step(scenario, step, nodes) к BBB или операции, "
                    "которые их выполняют; если шаг лежит вне схемы паспорта — вызови finish ещё раз, "
                    "и он останется в замечаниях.")
        state.remarks.append("шаги сценариев без узла на схеме: " + _unbound_text(unbound))
    _, _, unreviewed = state.capability_state()
    if unreviewed:
        state.attempts["capabilities"] = state.attempts.get("capabilities", 0) + 1
        if state.attempts["capabilities"] <= MAX_FINISH_REJECTIONS:
            return ("finish отклонён: возможности системы не рассмотрены паспортом — "
                    + _capability_text(unreviewed)
                    + ". Опиши их узлами или привяжи bind_capability(capability, nodes); если возможность "
                    "не относится к клиентскому пути — dismiss_capability(capability, reason, basis). "
                    "Повторный finish оставит остаток в замечаниях.")
        state.remarks.append("возможности системы без узла и без решения: " + _capability_text(unreviewed))
    state.finished = True
    return "паспорт завершён"


def _unbound_text(unbound: list[tuple[str, int, str]]) -> str:
    return "; ".join(f"{sid} шаг {index} «{text[:60]}»" for sid, index, text in unbound[:8]) + (
        f" … и ещё {len(unbound) - 8}" if len(unbound) > 8 else "")


def _process_scenario_issues(state: _PassportSession) -> list[str]:
    """Покрытие сценариев процессами: many-to-many в новом режиме, 1:1 в старом."""
    if not state.scenarios:
        return []
    if state.agentic:
        represented = {sid for node in state.of_type("process") for sid in node.data.get("scenarios", [])}
        issues = [f"сценарий {sid} не представлен процессом" for sid in state.scenarios if sid not in represented]
        if state.research_enabled:
            for node in state.of_type("process"):
                ids = node.data.get("scenarios", [])
                if not ids or any(sid not in state.scenarios for sid in ids):
                    issues.append(f"{node.id}: пересмотри scenarios — процесс не связан с действующими сценариями")
        return issues
    by_scenario: dict[str, list[str]] = {sid: [] for sid in state.scenarios}
    unmapped: list[str] = []
    for node in state.of_type("process"):
        sid = str(node.data.get("scenario") or "").strip()
        if sid in by_scenario:
            by_scenario[sid].append(node.id)
        else:
            unmapped.append(node.id)
    issues: list[str] = []
    if unmapped:
        issues.append("без scenario: " + ", ".join(unmapped))
    missing = [sid for sid, nodes in by_scenario.items() if not nodes]
    if missing:
        issues.append("без process: " + ", ".join(missing))
    duplicate = [f"{sid} → {', '.join(nodes)}" for sid, nodes in by_scenario.items() if len(nodes) > 1]
    if duplicate:
        issues.append("дубли: " + "; ".join(duplicate))
    return issues


def _clean(value: Any) -> str:
    """Текст от модели в паспорт — через ту же чистку иероглифов, что и у
    трёх других проходов: GLM-5.2 вставляет CJK-символы в русский текст."""
    return _strip_cjk(str(value or "")).strip()


def _clean_fields(fields: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for fid, cell in fields.items():
        if isinstance(cell, dict):
            out[fid] = {**cell, "value": _clean(cell.get("value")),
                        "source": _clean(cell.get("source"))}
        else:
            out[fid] = cell
    return out


def _handle_read_node(state: _PassportSession, args: dict) -> str:
    nid = str(args.get("id") or "").strip()
    node = state.nodes.get(nid)
    if not state.agentic and (node is None or not node.filled):
        accepted = ", ".join(key for key, item in state.nodes.items() if item.filled)
        return f"узел {nid or '—'} не принят. Принятые узлы: {accepted or 'пока нет'}"
    if node is None:
        declared = ", ".join(state.nodes)
        return f"узел {nid or '—'} не объявлен. Объявленные узлы: {declared or 'пока нет'}"
    return json.dumps({**node.data, "id": nid, "name": node.name, "basis": node.basis,
                       "type": node_type(nid), "filled": node.filled,
                       **({"draft": state.node_drafts.get(nid)} if state.agentic else {}),
                       "field_contract": field_contract(node_type(nid), state.research_basis)},
                      ensure_ascii=False, default=str)


def _handle_read_risk_patterns(state: _PassportSession, args: dict) -> str:
    if not state.agentic and not state.tree_done:
        return "Сначала построй дерево: выбор гипотез опирается на факты узлов и стыков."
    if set(args) != {"ids"}:
        return "read_risk_patterns принимает только ids — список ID из каталога."
    try:
        return read_patterns(args.get("ids"))
    except ValidationError as exc:
        return exc.render()


def _handle_evidence_read(state: _PassportSession, args: dict) -> str:
    if state.evidence_corpus is None:
        return "Корпус буквальных оснований не передан."
    return json.dumps(state.evidence_corpus.read(args.get("ids")), ensure_ascii=False)


def _handle_evidence_search(state: _PassportSession, args: dict) -> str:
    if state.evidence_corpus is None:
        return "Корпус буквальных оснований не передан."
    try:
        offset = int(args.get("offset", 0))
    except (ValueError, TypeError):
        return "offset должен быть целым числом."
    return json.dumps(state.evidence_corpus.index(str(args.get("query") or ""), offset), ensure_ascii=False)


def _capability_text(caps: list[Capability]) -> str:
    shown = "; ".join(c.describe() for c in caps[:_MAX_UNMAPPED_SHOWN])
    return shown + (f" … и ещё {len(caps) - _MAX_UNMAPPED_SHOWN}" if len(caps) > _MAX_UNMAPPED_SHOWN else "")


def _find_capability(state: _PassportSession, cid: Any) -> Capability | None:
    return next((c for c in state.capabilities if c.id == str(cid or "").strip()), None)


def _handle_bind_capability(state: _PassportSession, args: dict) -> str:
    if not state.agentic and not state.tree_done:
        return f"bind_capability отклонён: сначала {_expected_text(state)}."
    cap = _find_capability(state, args.get("capability"))
    if cap is None:
        return "bind_capability отклонён: неизвестная возможность — передай id cap-N из списка."
    nodes = args.get("nodes")
    nodes = [str(n).strip() for n in nodes] if isinstance(nodes, list) else []
    bad = [n for n in nodes if n not in state.nodes or not state.nodes[n].filled or node_type(n) == "journey"]
    if not nodes or bad:
        return ("bind_capability отклонён: nodes — заполненные узлы process/bbb/operation"
                + (f"; не подходят: {', '.join(bad)}" if bad else ""))
    prior = [] if state.agentic and args.get("replace") is True else state.capability_bound.get(cap.id, [])
    state.capability_bound[cap.id] = list(dict.fromkeys(prior + nodes))
    state.capability_dismissed.pop(cap.id, None)
    _, _, unreviewed = state.capability_state()
    return (f"{cap.id} привязана к {', '.join(nodes)}. "
            + (f"Не рассмотрено возможностей: {len(unreviewed)}." if unreviewed else "Все возможности рассмотрены."))


def _handle_dismiss_capability(state: _PassportSession, args: dict) -> str:
    if not state.agentic and not state.tree_done:
        return f"dismiss_capability отклонён: сначала {_expected_text(state)}."
    cap = _find_capability(state, args.get("capability"))
    if cap is None:
        return "dismiss_capability отклонён: неизвестная возможность — передай id cap-N из списка."
    reason = str(args.get("reason") or "").strip()
    basis = _clean(args.get("basis"))
    errors: list[str] = []
    if reason not in DISMISS_REASONS:
        errors.append("reason: " + ", ".join(DISMISS_REASONS))
    if len(basis) < 20:
        errors.append("basis: объясни, почему возможность не относится к клиентскому пути (не короче 20 символов)")
    code = contains_code(basis)
    if code:
        errors.append(f"basis: без кода в тексте («{code}»)")
    from pko.report.guard import check_text
    errors.extend(v.render() for v in check_text(basis, set(), state.known_paths))
    if state.agentic:
        if state.evidence_corpus is None:
            errors.append("для исключения возможности нужен корпус оснований")
        else:
            errors.extend(state.evidence_corpus.citations(args.get("evidence"), code=state.research_basis == "code"))
    mapped, _, _ = state.capability_state()
    if cap.id in mapped:
        replacing = state.agentic and args.get("replace") is True
        records = state.evidence_corpus.records if state.evidence_corpus is not None else {}
        automatic = auto_mapped([cap], {nid: node.data for nid, node in state.nodes.items() if node.filled}, records)
        if not replacing:
            errors.append(f"{cap.id} уже описана узлами {', '.join(mapped[cap.id])} — "
                          + ("для пересмотра явной привязки передай replace=true" if state.agentic else "отклонять её нельзя"))
        elif cap.id in automatic:
            errors.append(f"{cap.id} подтверждена основаниями узлов; сначала исправь их, исключение не отменяет прочитанный код")
    usage = state.evidence_corpus.route_usage if state.evidence_corpus is not None else None
    route = usage.route_at(cap.path, cap.line) if usage is not None and cap.kind == "ROUTE" else None
    if route is not None and route.called and reason == "legacy":
        errors.append("интерфейс вызывает этот маршрут (" + ", ".join(f"{c['path']}:{c['line']}" for c in route.calls[:2])
                      + ") — «не вызывается» противоречит коду")
    if errors:
        return "dismiss_capability отклонён:\n" + "\n".join(f"- {e}" for e in errors)
    if state.agentic and cap.id in state.capability_bound:
        previous = state.capability_bound.pop(cap.id)
        state.workspace.link_review_obligations("binding:" + cap.id, "dismissal:" + cap.id)
        state.workspace.event("capability_binding_replaced", capability=cap.id, previous=previous,
                              reason=reason, basis=basis)
    state.capability_dismissed[cap.id] = {"reason": reason, "basis": basis}
    if state.agentic:
        state.capability_dismissed[cap.id]["evidence"] = args.get("evidence", [])
    _, _, unreviewed = state.capability_state()
    return (f"{cap.id} отмечена как «{DISMISS_REASONS[reason]}». "
            + (f"Не рассмотрено возможностей: {len(unreviewed)}." if unreviewed else "Все возможности рассмотрены."))


def _handle_status_dispute(state: _PassportSession, args: dict) -> str:
    if state.evidence_corpus is None:
        return "submit_status_dispute недоступен: без корпуса буквальных оснований спор не проверить."
    if not state.tree_done:
        return f"submit_status_dispute отклонён: сначала {_expected_text(state)}."
    matched = match_bullets([str(args.get("bullet") or "")], state.plan_bullets) if state.plan_bullets else []
    if not matched:
        return "submit_status_dispute отклонён: пункт не найден в образе результата — передай его дословно."
    bullet = matched[0]
    current = state.bullet_status.get(bullet)
    suggested = str(args.get("suggested_status") or "").strip()
    errors: list[str] = []
    if not current:
        errors.append("у пункта нет оценки — оспаривать нечего")
    elif suggested not in POC_WEIGHT:
        errors.append("suggested_status: " + ", ".join(CRITERION_STATUSES))
    elif POC_WEIGHT[suggested] >= POC_WEIGHT[current]:
        errors.append(f"спор допускает только понижение: сейчас «{STATUS_LABEL.get(current, current)}», "
                      f"предложено «{STATUS_LABEL.get(suggested, suggested)}»")
    limitation = _clean(args.get("limitation"))
    if len(limitation) < MIN_DISPUTE_CHARS:
        errors.append(f"limitation: опиши ограничение конкретно (не короче {MIN_DISPUTE_CHARS} символов)")
    code = contains_code(limitation)
    if code:
        errors.append(f"limitation: без кода в тексте («{code}») — место в коде передаётся цитатой")
    from pko.report.guard import check_text
    errors.extend(v.render() for v in check_text(limitation, set(), state.known_paths))
    provenance = state.evidence_corpus.citations(args.get("evidence"), code=True)
    errors.extend(provenance)
    if not provenance:
        errors.extend(claim_citation_errors(state.evidence_corpus, limitation, args.get("evidence"),
                                            numbers_from=limitation))
    if any(d["bullet"] == bullet for d in state.status_disputes):
        errors.append("по этому пункту спор уже принят")
    if len(state.status_disputes) >= MAX_STATUS_DISPUTES:
        errors.append(f"принято максимум споров ({MAX_STATUS_DISPUTES})")
    if errors:
        state.span.add_event("status_dispute_rejected", count=len(errors))
        return "submit_status_dispute отклонён:\n" + "\n".join(f"- {e}" for e in errors[:8])
    nodes = [nid for nid, n in state.nodes.items() if n.filled and bullet in (n.data.get("bullets") or [])]
    state.status_disputes.append({
        "bullet": bullet, "status": current, "status_label": STATUS_LABEL.get(current, current),
        "suggested_status": suggested, "suggested_label": STATUS_LABEL.get(suggested, suggested),
        "limitation": limitation, "evidence": list(args.get("evidence") or []), "nodes": nodes,
    })
    state.span.add_event("status_dispute_accepted")
    return ("спор принят: статус оценки не меняется, спор уйдёт в замечания отчёта и карточки узлов "
            + (", ".join(nodes) if nodes else "(узлов с этим пунктом нет)") + ".")


_HANDLERS: dict[str, Callable[[_PassportSession, dict], str]] = {
    "read_passport_evidence": _handle_evidence_read,
    "search_passport_evidence": _handle_evidence_search,
    "bind_capability": _handle_bind_capability,
    "dismiss_capability": _handle_dismiss_capability,
    "submit_status_dispute": _handle_status_dispute,
    "submit_node": _handle_submit_node,
    "declare_children": _handle_declare_children,
    "link_nodes": _handle_link_nodes,
    "bind_scenario_step": _handle_bind_scenario_step,
    "submit_defect": _handle_submit_defect,
    "submit_need": _handle_submit_need,
    "submit_guardrail": _handle_submit_guardrail,
    "submit_risks": _handle_submit_risks,
    "read_risk_patterns": _handle_read_risk_patterns,
    "read_node": _handle_read_node,
    "finish": _handle_finish,
}
_TOOL_NAMES = ", ".join(_HANDLERS)


def _unfinished(state: _PassportSession) -> list[str]:
    if state.agentic:
        out = []
        for node in state.nodes.values():
            if not node.filled:
                out.append(f"не заполнен {node.id}")
            if node_type(node.id) in CHILD_TYPE and not node.planned and not node.children:
                out.append(f"не объявлены дети {node.id}")
            if node.planned and node.children:
                out.append(f"планируемый {node.id} содержит реализуемое поддерево; уточни структуру")
        return out
    out: list[str] = []
    if state.awaiting_children_of:
        out.append(f"не объявлены дети {state.awaiting_children_of}")
    if state.current:
        out.append(f"не заполнен {state.current}")
    if state.queue:
        out.append(f"в очереди {len(state.queue)} узлов: " + ", ".join(state.queue[:5]))
    return out


def _agentic_blockers(state: _PassportSession) -> list[str]:
    """Completion gate for research, independent of readiness and GO/PIVOT."""
    sync_objects(state)
    errors = _unfinished(state) + _process_scenario_issues(state)
    if state.research_basis == "code":
        from pko.progress.passport_connections import connection_blockers
        errors.extend(connection_blockers(state))
        errors.extend(f"{n.id}: существование узла не подтверждено кодом" for n in state.nodes.values()
                      if n.filled and not n.data.get("existence_evidence"))
    if state.research_enabled:
        from pko.progress.passport_connectivity import connectivity_blockers
        from pko.progress.passport_system_research import system_research_blockers
        errors.extend(connectivity_blockers(state))
        errors.extend(system_research_blockers(state))
    for nid, node in state.nodes.items():
        for step in node.data.get("scenario_steps", []):
            problem = _scenario_node_problem(state, nid, str(step.get("scenario")))
            if problem:
                errors.append(problem)
    if state.evidence_corpus is None:
        errors.append("нет корпуса проверяемых оснований")
    if not state.risk_reviewed:
        errors.append("анализ рисков не представлен для текущей структуры")
    def excluded(key: str) -> bool:
        return state.workspace.exclusions.get(key, {}).get("disposition") == "excluded"
    unbound = [row for row in state.unbound_steps() if not excluded(f"step:{row[0]}:{row[1]}")]
    if unbound:
        errors.append("шаги без узла: " + _unbound_text(unbound))
    linked = {b for n in state.nodes.values() if n.filled for b in n.data.get("bullets", [])}
    missing = [str(i) for i, b in enumerate(state.plan_bullets) if b not in linked and not excluded(f"bullet:{i}")]
    if missing and state.research_basis != "code":
        errors.append("пункты ОР без узла/обоснованного исключения: " + ", ".join(missing))
    _, _, caps = state.capability_state()
    if caps or state.capabilities_total > len(state.capabilities):
        errors.append("возможности без решения: " + _capability_text(caps)
                      + ("; часть каталога не загружена" if state.capabilities_total > len(state.capabilities) else ""))
    if state.evidence_broker is not None:
        inventory = state.evidence_broker.inventory()
        unknown = [c["path"] for c in inventory.get("components", [])
                   if state.workspace.scope.get("component:" + c["path"], {}).get("disposition") not in ("reviewed", "excluded")]
        if unknown:
            errors.append("компоненты без границы проверки: " + ", ".join(unknown[:12]))
        if inventory.get("components_total", 0) > len(inventory.get("components", [])):
            errors.append("инвентаризация компонентов неполна")
    if state.unresolved_relations:
        errors.append("не разобраны отклонённые связи")
    unresolved = state.workspace.unresolved()
    if unresolved:
        errors.append("открытые находки: " + ", ".join(unresolved[:12]))
    pending = state.workspace.pending_reviews()
    if pending:
        errors.append("не подтверждены независимой проверкой текущие версии: " + ", ".join(pending[:12]))
    if any(r.get("disposition") == "unknown" for r in state.workspace.exclusions.values()):
        errors.append("остались неизвестные границы охвата")
    return errors


def _advance(state: _PassportSession) -> str:
    """Следующий шаг протокола: очередной узел дерева или переход к связям."""
    if state.agentic:
        from pko.progress.passport_tools import summary
        state.queue.clear()
        state.current = state.awaiting_children_of = None
        state.tree_done = not _unfinished(state)
        return summary(state)
    if state.queue:
        nid = state.queue.pop(0)
        state.current = nid
        node = state.nodes[nid]
        parent = state.nodes[node.parent] if node.parent else None
        lines = [_tree_map(state), f"Заполни {nid} «{node.name}» ({TYPE_LABEL[node_type(nid)]}) — basis: {node.basis}."]
        if parent is not None:
            lines.append(f"Родитель {parent.id} «{parent.name}»: {_node_digest(parent)}")
        siblings = [state.nodes[c] for c in (parent.children if parent else []) if c != nid]
        if siblings:
            lines.append("Соседи: " + "; ".join(f"{s.id} «{s.name}»" for s in siblings))
        if node_type(nid) == "process" and state.scenarios:
            available = [
                f"{sid} «{state.scenario_titles.get(sid, sid)}»"
                for sid in state.scenarios
                if not any(
                    other.id != nid and other.data.get("scenario") == sid
                    for other in state.of_type("process")
                )
            ]
            lines.append(
                "Process равен одному целевому сценарию. Передай scenario; доступны: "
                + ", ".join(available)
            )
        lines.append(f"Вызови submit_node(id=\"{nid}\") с полями раздела.")
        return "\n".join(lines)
    if not state.tree_done:
        state.tree_done = True
        return "\n".join([_tree_map(state), "Дерево построено.", _after_tree_text(state)])
    return _after_tree_text(state)


def _after_tree_text(state: _PassportSession) -> str:
    """Что делать после дерева: связи, привязка шагов сценариев, finish."""
    if state.agentic:
        from pko.progress.passport_tools import summary
        return summary(state)
    lines = [
        "Дальше: связи поверх дерева — link_nodes(from, to, kind, basis), виды: "
        + ", ".join(f"{k} ({RELATION_LABEL[k]})" for k in RELATION_KINDS)
        + "; общий BBB или операция, входящие в несколько процессов/блоков — kind=includes."
    ]
    unbound = state.unbound_steps()
    if unbound:
        lines.append(
            "Шаги сценариев без узла: " + _unbound_text(unbound)
            + ". Привяжи bind_scenario_step(scenario, step, nodes=[bbb-N | operation-N])."
        )
    elif state.scenarios:
        lines.append("Все шаги целевых сценариев привязаны к узлам.")
    if state.capabilities:
        mapped, dismissed, unreviewed = state.capability_state()
        if unreviewed:
            lines.append(
                f"Обратное сопоставление «код → паспорт»: рассмотрено {len(mapped) + len(dismissed)} из "
                f"{len(state.capabilities)} возможностей системы. Не рассмотрены: " + _capability_text(unreviewed)
                + ". Опиши их узлами (повторный submit_node с цитатой кода возможности), привяжи "
                "bind_capability(capability, nodes) или отклони dismiss_capability(capability, reason, basis)."
            )
        else:
            lines.append(f"Все {len(state.capabilities)} возможностей системы рассмотрены паспортом.")
    if state.evidence_corpus is not None and state.bullet_status:
        lines.append(
            "Если прочитанный код показывает, что пункт образа результата работает хуже, чем в оценке, — "
            "submit_status_dispute(bullet, suggested_status, limitation, evidence): только понижение, статус "
            "не меняется, спор уходит в замечания." + (f" Принято споров: {len(state.status_disputes)}." if state.status_disputes else "")
        )
    scenario_issues = _process_scenario_issues(state)
    if scenario_issues:
        lines.append(
            "Процессы должны совпадать со сценариями один к одному: "
            + "; ".join(scenario_issues)
            + ". Исправь process повторным submit_node(id, scenario=\"scenario-N\")."
        )
    gaps = _input_contract_gaps(state)
    if gaps:
        lines.append("Контракт входа ссылается на узел вне процесса: " + "; ".join(gaps[:6])
                     + ". Если узел выполняется внутри процесса — link_nodes(kind=includes) от процесса; "
                     "если только передаёт данные — kind=feeds.")
    lines.append(
        "Дефекты — submit_defect(title, kind, nodes, scenarios, where, blocking): один дефект — один вызов "
        "(отключённый расчёт, нет компенсации при частичном исполнении, повторное нажатие, две реализации, "
        "деградация на запасном пути). Разрывы стыков и обещания без реализации код добавит сам."
        + (f" Заведено дефектов: {len(state.defects)}." if state.defects else "")
    )
    lines.append(
        "Потребность клиента — submit_need(name, purpose, source); ограничения исполнения — "
        "submit_guardrail(name, invariant, condition, effect, targets, source)."
        + (f" Потребностей: {len(state.needs)}, ограничений: {len(state.guardrails)}." if state.needs or state.guardrails else " Пока ни одной.")
    )
    lines.append(
        "Операционные риски финализируй одним submit_risks(risks=[…], review=[…]) после guardrails: "
        "по каждому процессу обязателен чек-лист input/decision/execution/persistence/dependencies/detection/recovery, "
        "даже при пустом наборе рисков. Сначала "
        "локально проверь BBB и операции, затем стыки всей цепочки; каждый риск — причина → "
        "негативное событие → бизнес-последствие. Риск не равен дефекту или отсутствию контроля и "
        "не меняет статус узла. "
        + (f"Анализ принят, рисков: {len(state.risks)}." if state.risk_reviewed else "Анализ ещё не отправлен.")
    )
    if not state.risk_reviewed:
        lines.append(_risk_exposure_digest(state))
        if state.exposures:
            lines.append(exposure_digest(state.exposures))
        try:
            lines.append(_RISK_GUIDE_PATH.read_text(encoding="utf-8").strip())
        except OSError:
            note = "Памятка гипотез операционного риска не найдена: risk_hypothesis_guide.md"
            if note not in state.notes:
                state.notes.append(note)
        try:
            lines.append(render_index())
        except ValidationError as exc:
            note = exc.render()
            lines.append(note + " Продолжи проверку по семи областям; не считай библиотеку проверенной.")
            if note not in state.notes:
                state.notes.append(note)
    lines.append("Исправить принятый узел можно повторным submit_node(id). Когда всё — finish.")
    return "\n".join(lines)


_RISK_FOCUS_FIELDS = {
    "process": ("4.3.4", "4.3.6", "4.3.7"),
    "bbb": ("4.4.2", "4.4.4", "4.4.5"),
    "operation": ("4.5.4", "4.5.5", "4.5.6"),
}


def _risk_exposure_digest(state: _PassportSession, limit: int = 7000) -> str:
    """Напомнить модели принятые узлы и факты об экспозиции после сборки дерева.

    Это навигация по заполненному паспорту, не источник доказательств сам по
    себе: в evidence всё равно требуется исходный прочитанный материал.
    """
    lines = [
        "Опорные факты для поиска рисков (утверждения узлов, не доказательства риска; "
        "сверяй каждую гипотезу с исходным прочитанным источником):"
    ]
    used = len(lines[0])
    omitted = 0
    for node in state.nodes.values():
        ntype = node_type(node.id)
        if ntype == "journey":
            continue
        fields = node.data.get("fields") or {}
        parts = [f"{node.id} «{node.name[:90]}»"]
        if node.planned:
            parts.append("планируется; не считай отсутствие реализации действующим отказом")
        if ntype == "process":
            parts.append(f"сценарий {node.data.get('scenario') or 'не привязан'}")
        else:
            parts.append("родители: " + ", ".join(node.parents))
        first_source = ""
        for fid in _RISK_FOCUS_FIELDS.get(ntype, ()):
            field_data = fields.get(fid) or {}
            value = str(field_data.get("value") or "").strip()
            if value:
                parts.append(f"{fid}: {value[:110]}")
                source = str(field_data.get("source") or "").strip()
                if source and not first_source:
                    first_source = source[:140]
        if first_source:
            parts.append("источник поля: " + first_source)
        if node.data.get("scenario_steps"):
            parts.append("шаги: " + str(node.data["scenario_steps"])[:90])
        line = "; ".join(parts)
        if used + len(line) + 1 > limit:
            omitted += 1
            continue
        lines.append(line)
        used += len(line) + 1
    if omitted:
        lines.append(f"Ещё {omitted} узлов не вошли в краткую сводку; используй карту дерева выше.")
    if state.relations:
        relations = "; ".join(
            f"{r['from']} {r['kind']} {r['to']}" for r in state.relations
        )
        lines.append("Принятые связи: " + relations[:1200])
    return "\n".join(lines)


def _input_contract_gaps(state: _PassportSession) -> list[str]:
    """Узел X упомянут в контракте входа узла Y, но не входит ни в один
    процесс Y и не связан с ним: реестр расходится с карточкой."""
    fed: set[tuple[str, str]] = {(r["from"], r["to"]) for r in state.relations if r["kind"] in ("feeds", "precedes", "triggers", "depends_on")}
    out: list[str] = []
    for nid, node in state.nodes.items():
        if not node.filled:
            continue
        fid = _INPUT_CONTRACT_FIELDS.get(node_type(nid))
        if not fid:
            continue
        cell = (node.data.get("fields") or {}).get(fid) or {}
        text = " ".join(str(cell.get(k) or "") for k in ("value", "source"))
        y_processes = state.processes_of(nid)
        for ref in dict.fromkeys(_NODE_REF_RE.findall(text)):
            other = state.nodes.get(ref)
            if other is None or ref == nid or other.before_fork:
                continue
            if (ref, nid) in fed or (nid, ref) in fed:
                continue
            if state.processes_of(ref) & y_processes:
                continue
            out.append(f"{ref} упомянут в контракте входа {nid}, но не входит в "
                       + ", ".join(sorted(y_processes)) if y_processes else f"{ref} упомянут в контракте входа {nid}")
    return out


def _expected_submit(state: _PassportSession) -> set[str]:
    if state.agentic:
        return set(state.nodes)
    if state.awaiting_children_of:
        return set()
    if state.current:
        return {state.current}
    if not state.tree_done:
        return set()
    # После дерева — повторная отправка уже принятого узла (исправление по замечанию).
    return {n.id for n in state.nodes.values() if n.filled}


def _progress_mark(state: _PassportSession) -> tuple:
    """Activity marker: v2 includes new evidence; legacy counts accepted changes.

    The independent research focus tracks whether evidence becomes an outcome.
    New reads alone must not hide a long stretch without saved conclusions.
    """
    if state.agentic:
        return (digest({nid: {"data": n.data, "parents": n.parents, "children": n.children}
                        for nid, n in state.nodes.items()}),
                digest(state.workspace.reviews),
                # Rewording a rejected proposal is not new research progress.
                # A new objection or an explicit change of its state still is.
                digest({fid: f["state"] for fid, f in state.workspace.findings.items()}),
                digest(state.workspace.risk_candidates), digest(state.workspace.claims),
                digest(state.workspace.scope), digest(state.workspace.exclusions),
                digest(state.capability_bound), digest(state.capability_dismissed),
                digest(state.workspace.plan), digest(state.status_disputes), digest(state.needs),
                digest(state.workspace.retirements),
                digest({oid: obj["revision"] for oid, obj in state.workspace.objects.items()}),
                digest(state.relations), digest(state.defects), digest(state.guardrails),
                len(state.evidence_corpus.shown) if state.evidence_corpus else 0,
                len(state.evidence_corpus.records) if state.evidence_corpus else 0,
                state.risk_reviewed, state.finished)
    return (
        tuple((nid, node.filled, repr(node.data)) for nid, node in state.nodes.items()),
        len(state.relations), len(state.defects), len(state.needs), len(state.guardrails),
        len(state.risks), state.risk_reviewed, len(state.status_disputes),
        sum(len(nodes) for nodes in state.capability_bound.values()),
        len(state.capability_dismissed), state.finished,
    )


def _idle_nudge(state: _PassportSession, idle: int) -> str:
    if state.agentic:
        return (f"За {idle} шагов нет новых прочитанных материалов или изменений исследования. "
                "Останови повтор прежних поисков. Зафиксируй уже установленные по прочитанному коду факты: "
                "выбери узел, сценарий, системный вывод или submit_claim; конкретный пробел сохрани как неизвестное. "
                "Если для вывода ещё нет основания, укажи в плане точный вопрос и нужный новый источник. "
                "Исчерпанный лимит запросов уточнением не восстановить. Не придумывай доказательства и не удаляй "
                "факты ради принятия формы; незавершённое сохранится как черновик.")
    return (f"Уже {idle} шагов подряд в паспорт ничего не принято. Хватит читать и искать: "
            f"отправь {_expected_text(state)}. Чего нет в корпусе — запиши как «Не установлено: …» "
            f"и понизь уровень основания. Ещё {IDLE_STEPS_STOP - IDLE_STEPS_NUDGE} шагов без "
            "принятого результата — и сессия остановится.")


def _expected_text(state: _PassportSession) -> str:
    if state.agentic:
        return "самостоятельно выбрать инструмент исследования, изменения паспорта или проверки; research_state показывает открытые задачи"
    if state.awaiting_children_of:
        return f"declare_children(parent=\"{state.awaiting_children_of}\")"
    if state.current:
        return f"submit_node(id=\"{state.current}\")"
    if state.tree_done:
        return ("link_nodes, bind_scenario_step, bind_capability, dismiss_capability, submit_status_dispute, "
                "read_risk_patterns, submit_risks, повторный submit_node принятого узла или finish")
    return "ничего: дерево не начато"


def _check_name_unique(check: PassportCheck, state: _PassportSession, nid: str, name: str) -> None:
    key = norm_name(name)
    if not key:
        return
    for other in state.nodes.values():
        if other.id != nid and norm_name(other.name) == key:
            check.errors.append(duplicate_name_message(nid, other.id, name))
            return


def _children_hint(ptype: str) -> str:
    return {
        "journey": "по одному на сценарий с собственными условиями запуска и завершением; "
                   "узел, который выбирает или разрешает процесс (определение сценария, проверка прав), "
                   "— BBB с before_fork: true, перед процессами",
        "process": "одно бизнес-действие с одним ответом «что получили»; 3–6 на процесс, "
                   "включая определение сценария, получение данных, подбор, предложение, "
                   "объяснение, подтверждение, исполнение; общий с другим процессом блок — {ref: id}",
        "bbb": "шаг с наблюдаемым снаружи результатом, который может отказать отдельно; "
               "1–3 на BBB, обычно по способам исполнения; общая с другим блоком операция — {ref: id}",
    }[ptype]


def _node_digest(node: _Node, limit: int = 220) -> str:
    fields = node.data.get("fields") or {}
    parts = []
    for fid in sorted(fields):
        value = str((fields.get(fid) or {}).get("value") or "").strip()
        if value:
            parts.append(f"{fid}: {value[:limit]}")
        if len(parts) >= 3:
            break
    return " · ".join(parts) or "поля не заполнены"


def _tree_map(state: _PassportSession) -> str:
    """Карта построенного: id · название — basis, с отступами по уровням.
    Общий узел показан под каждым родителем, но раскрыт только под первым."""
    lines = ["Построено:"]

    def visit(nid: str, depth: int, via: str | None) -> None:
        node = state.nodes[nid]
        mark = "✓" if node.filled else "…"
        shared = via is not None and node.parent != via
        extra = ""
        if len(node.parents) > 1:
            extra = " (также в " + ", ".join(p for p in node.parents if p != via) + ")"
        if node.before_fork:
            extra += " (до развилки)"
        if node.planned:
            extra += " (планируется)"
        lines.append(f"{'  ' * depth}{mark} {nid} «{node.name}» — {node.basis[:100]}{extra}")
        if shared:
            return
        for cid in node.children:
            visit(cid, depth + 1, nid)

    for root in state.of_type("journey"):
        visit(root.id, 0, None)
    business = [f"{r['from']} {RELATION_LABEL[r['kind']]} {r['to']}"
                for r in state.relations if r["kind"] != "includes"]
    if business:
        lines.append("Связи: " + "; ".join(business))
    return "\n".join(lines)


# --- сборка результата --------------------------------------------------------------

def _build_passport_data(state: _PassportSession, scope: str, date: str, commit: str = "") -> dict[str, Any]:
    visible = set(state.nodes)
    if state.research_basis == "code":
        visible = set()
        def include(nid):
            node = state.nodes[nid]
            if nid in visible or not node.filled or not node.data.get("existence_evidence"):
                return
            visible.add(nid)
            for child in node.children:
                if state.nodes[child].parent == nid:
                    include(child)
        for root in state.of_type("journey"):
            include(root.id)
    def rebuild(nid: str) -> dict[str, Any]:
        node = state.nodes[nid]
        out: dict[str, Any] = {"id": nid, "type": node_type(nid)}
        if node.children or node_type(nid) != "operation":
            # Под второстепенным родителем общий узел в дереве не повторяется:
            # его место — под первым; остальные связи живут в `parents`.
            out["children"] = [rebuild(c) for c in node.children if c in visible and state.nodes[c].parent == nid]
        return out

    # Версия объекта — состояние кода, по которому выставлены статусы: один
    # текст на все узлы, без «Не установлена» рядом с «Не установлено по…».
    version = f"коммит {commit[:8]}" if commit else "Не установлено: источник без git-истории (архив)"
    nodes: dict[str, Any] = {}
    for nid, node in state.nodes.items():
        if nid not in visible:
            continue
        entry: dict[str, Any] = {"name": node.name, "basis": node.basis, "fields": {},
                                 "parents": [p for p in node.parents if p in visible], "before_fork": node.before_fork,
                                 "planned": node.planned, "object-version": version}
        if node.filled:
            entry.update({k: v for k, v in node.data.items() if k not in ("name", "basis")})
        else:
            entry["object-version"] = "Не заполнено: сессия прервана до этого узла"
        nodes[nid] = entry
    data = {
        "agent_filled": bool(visible) if state.research_basis == "code" else any(node.filled for node in state.nodes.values()),
        "analysis-scope": scope,
        "decision-boundary": state.decision_boundary,
        "analysis-date": date,
        "tree": [rebuild(n.id) for n in state.of_type("journey") if n.id in visible],
        "nodes": nodes,
        "relations": [dict(r) for r in state.relations if r["from"] in visible and r["to"] in visible],
        "defects": [dict(d) for d in state.defects],
        "needs": [dict(n) for n in state.needs],
        "guardrails": [dict(g) for g in state.guardrails],
        "risks": [dict(r) for r in state.risks],
        "risk_review": {"complete": state.risk_reviewed, "summary": state.risk_analysis, "processes": state.risk_review},
        "status_disputes": [dict(d) for d in state.status_disputes],
        "exposures": [{k: v for k, v in e.items() if k != "anchors"} for e in state.exposures],
    }
    if state.capabilities:
        mapped, dismissed, unreviewed = state.capability_state()
        auto = auto_mapped(state.capabilities, {nid: n.data for nid, n in state.nodes.items() if n.filled},
                           state.evidence_corpus.records if state.evidence_corpus is not None else {})

        def row(cap: Capability) -> dict[str, Any]:
            return {"id": cap.id, "kind": cap.kind, "kind_label": CAPABILITY_KIND_LABEL.get(cap.kind, cap.kind),
                    "label": cap.label, "where": cap.where}

        data["capability_coverage"] = {
            **capability_coverage(state.capabilities_total or len(state.capabilities),
                                  len(state.capabilities), len(mapped), len(dismissed)),
            "mapped": [{**row(c), "nodes": mapped[c.id], "by": "code" if c.id in auto else "agent"}
                       for c in state.capabilities if c.id in mapped],
            "dismissed": [{**row(c), **dismissed[c.id], "reason_label": DISMISS_REASONS[dismissed[c.id]["reason"]]}
                          for c in state.capabilities if c.id in dismissed],
            "unreviewed": [row(c) for c in unreviewed],
        }
    if state.evidence_corpus is not None:
        usage = state.evidence_corpus.route_usage
        data["evidence_audit"] = {
            "mode": "literal_citations", "manifest": state.evidence_corpus.manifest(),
            "unreviewed_nodes": [nid for nid, node in state.nodes.items() if not node.filled],
            "unresolved_relations": [{"from": key[0], "to": key[1], "kind": key[2], "reason": reason}
                                     for key, reason in state.unresolved_relations.items()],
            "semantic_truth_verified": False,
            **({"route_usage": usage.to_dict()} if usage is not None else {}),
        }
        data["evidence_materials"] = state.evidence_corpus.records
    else:
        data["evidence_audit"] = {"mode": "legacy_unverified", "semantic_truth_verified": False}
    if state.agentic:
        from pko.progress.schema import passport_completion_state
        blockers = _agentic_blockers(state)
        data["schema_version"] = 2
        data["research"] = state.workspace.export()
        if state.research_enabled:
            data["research_mode"] = "code_reconstruction" if state.research_basis == "code" else "integrated"
            data["research_basis"] = state.research_basis
            if state.research_basis == "code":
                data["connection_review"] = list(state.connection_review.values())
                data["unpublished_nodes"] = [{"id": n.id, "name": n.name, "parents": n.parents,
                    "reason": "Узел или его контейнер не подтверждён прочитанным кодом; это рабочий кандидат, не текущая карта."}
                    for n in state.nodes.values() if n.id not in visible]
            data.update(_research_data(state))
        reason = state.stop_reason or "in_progress"
        labels = {"completed": "Проверки текущих версий завершены", "steps": "Исчерпан бюджет шагов",
                  "timeout": "Исчерпан бюджет времени", "idle": "Остановлено повторение без прогресса",
                  "cycle": "Обнаружено повторение действий", "error": "Сессия прервана ошибкой",
                  "malformed": "Модель не вызвала инструмент", "in_progress": "Исследование продолжается"}
        data["completion"] = {
            "state": passport_completion_state(blockers, reason, state.finished),
            "reason": labels.get(reason, reason), "stop_reason": reason, "blockers": blockers,
            "open_findings": state.workspace.unresolved(), "pending_reviews": state.workspace.pending_reviews(),
            "unfilled_nodes": [n.id for n in state.nodes.values() if not n.filled],
        }
        data["evidence_audit"]["mode"] = "agentic_review"
        data["evidence_audit"]["review_calls"] = state.workspace.review_calls
        if state.evidence_broker is not None:
            data["evidence_audit"]["source_inventory"] = state.evidence_broker.inventory()
    return normalize_passport(data)


@dataclass
class PassportAgentResult:
    passport_data: dict[str, Any] | None = None
    notes: list[str] = field(default_factory=list)
    steps: int = 0
    connectivity: ConnectivityReview | None = None
    integrity: IntegrityReview | None = None


# --- вход: сжатые знания сессии оценки -------------------------------------------------

def render_evaluation_digest(
    plan_items: list[PlanItem],
    verdicts: list[ItemVerdict],
    summary: ProjectSummary | None,
    knowledge: list[str],
    knowledge_ids: dict[int, str] | None = None,
) -> str:
    """Что узнала сессия оценки — единственный источник фактов для паспорта.

    `knowledge_ids` — номер записи следа → её id в корпусе. С ними след идёт
    оглавлением, полный текст записи — через read_passport_evidence.
    """
    by_id = {v.item_id: v for v in verdicts}
    lines: list[str] = []
    if summary is not None:
        lines.append(f"Верхнеуровневая оценка: {summary.match} — {summary.match_note}")
    lines.append("Оценка этапов образа результата (статус · проверка · как работает · ссылки):")
    for item in plan_items:
        lines.append(f"## {item.title}")
        verdict = by_id.get(item.id)
        for idx, text in enumerate(item.criteria):
            crit = verdict.criteria[idx] if verdict and idx < len(verdict.criteria) else None
            if crit is None:
                lines.append(f"- {text} — не оценено")
                continue
            lines.append(f"- Обещано: {text} — {STATUS_LABEL.get(crit.status, crit.status)}")
            if crit.proof:
                lines.append(f"  проверка: {crit.proof[:_MAX_PROOF_CHARS]}")
            if crit.how:
                lines.append(f"  как работает: {crit.how[:_MAX_PROOF_CHARS]}")
            for ev in crit.evidence:
                if getattr(ev, "verified", False):
                    lines.append(f"  · {ev.path}:{ev.line} — {ev.basis}" + (f" — {ev.note}" if getattr(ev, 'note', '') else ""))
    if knowledge and knowledge_ids:
        lines.append("")
        lines.append("Что сессия оценки читала в коде — оглавление следа; "
                     "полная запись — read_passport_evidence(ids=[id]):")
        total = 0
        for number, entry in enumerate(knowledge, 1):
            head = str(entry).split("\n", 1)[0]
            if len(head) > _KNOWLEDGE_HEAD_CHARS:
                head = head[:_KNOWLEDGE_HEAD_CHARS].rsplit(" ", 1)[0] + "…"
            line = f"{knowledge_ids.get(number, '—')}: {head}"
            total += len(line) + 1
            if total > _MAX_KNOWLEDGE_INDEX_CHARS:
                lines.append(f"… ещё записей: {len(knowledge) - number + 1}; "
                             "найти — search_passport_evidence(query=\"След оценки\")")
                break
            lines.append(line)
    elif knowledge:
        lines.append("")
        lines.append("Что сессия оценки читала в коде (сжатый след):")
        total = 0
        for entry in knowledge:
            total += len(entry) + 1
            if total > _MAX_KNOWLEDGE_CHARS:
                lines.append("… (след обрезан)")
                break
            lines.append(entry)
    return "\n".join(lines)


def render_scenarios_digest(connectivity: ConnectivityReview | None) -> str:
    """Целевые сценарии ревизии — для привязки узлов (`scenario_steps`)."""
    if connectivity is None or not connectivity.scenarios:
        return ""
    lines = ["Целевые сценарии (для scenario_steps: id сценария и номер шага с нуля; "
             "каждый шаг обязан получить узел bbb/operation, иначе finish попросит привязать):"]
    for scenario in connectivity.scenarios:
        status = scenario.status
        lines.append(f"{scenario.id} «{scenario.title}» — {SCENARIO_STATUS_LABEL.get(status, status)}"
                     + (", критический" if scenario.critical else ""))
        lines.append(f"  Целевой вход: {scenario.entry}")
        lines.append(f"  Проверяемый результат: {scenario.outcome}")
        lines.append("  Пункты ОР: " + "; ".join(scenario.bullets))
        for index, step in enumerate(scenario.steps):
            handoff = scenario.handoff_at(index)
            mark = ""
            if handoff is not None and index < scenario.transitions:
                mark = f" → стык после шага: {CHECK_RESULT_LABEL.get(handoff.result, handoff.result)}"
            lines.append(f"  {index}: {step}{mark}")
            if handoff is not None:
                for check in handoff.checks:
                    lines.append(f"    {HANDOFF_CHECK_LABEL.get(check.check, check.check)}: "
                                 f"{CHECK_RESULT_LABEL.get(check.result, check.result)} — {check.note}")
                    for ev in check.verified_evidence:
                        lines.append(f"      {ev.path}:{ev.line} — {ev.basis}; {ev.note}")
    return "\n".join(lines)


def run_passport_agent(
    plan_items: list[PlanItem],
    context: dict[str, str],
    verdicts: list[ItemVerdict],
    summary: ProjectSummary | None,
    spec: ModelSpec | None,
    client: ChatClient | None = None,
    capability_digest: str = "",
    knowledge: list[str] | None = None,
    source_text: str | None = None,
    repo_name: str = "",
    commit: str = "",
    max_steps: int | None = None,
    on_node: Callable[[str, str], None] | None = None,
    connectivity: ConnectivityReview | None = None,
    evidence_corpus: EvidenceCorpus | None = None,
    capabilities: list[Capability] | None = None,
    capabilities_total: int = 0,
    exposures: list[dict[str, Any]] | None = None,
    evidence_broker: Any = None,
    agentic: bool | None = None,
    checkpoint_path: Path | str | None = None,
    research_enabled: bool = False,
    source_digest: str = "",
    research_basis: str = "result_image",
    engine: str | None = None,
    resume_path: Path | str | None = None,
) -> PassportAgentResult:
    """Исследовать проект одним циклом; production включает research_enabled.

    `connectivity` — целевые сценарии ревизии: узлы привязываются к их шагам,
    и схема паспорта показывает путь сценария и разрывы на стыках.
    `capabilities` — возможности системы для обратного сопоставления,
    `exposures` — факты экспозиции для чек-листа рисков (`passport_facts`).
    """
    if research_basis not in ("result_image", "code"):
        raise ValueError("research_basis: result_image или code")
    if research_basis == "code" and not research_enabled:
        raise ValueError("Исследование по коду требует research_enabled=True")
    if research_basis == "code" and connectivity is not None:
        raise ValueError("Исследование по коду восстанавливает собственные сценарии; переданные целевые сценарии не импортируются")
    engine = engine or os.getenv("PKO_PASSPORT_ENGINE", "pydantic" if research_basis == "code" else "legacy")
    if engine not in ("pydantic", "legacy"):
        raise ValueError("PKO_PASSPORT_ENGINE: pydantic или legacy")
    use_harness = engine == "pydantic" and research_basis == "code"
    resume_path = resume_path or os.getenv("PKO_PASSPORT_RESUME") or None
    if resume_path is not None and not use_harness:
        raise ValueError("Возобновление поддерживает только новый паспортный цикл")
    if spec is None:
        return PassportAgentResult(notes=["Паспорт: matcher не настроен"])
    if max_steps is None:
        max_steps = int(_env_number("PKO_PASSPORT_MAX_STEPS",
                                   DEFAULT_RESEARCH_MAX_STEPS if research_enabled else DEFAULT_PASSPORT_MAX_STEPS))

    # Название пути — строго из образа результата; имя проекта и репозитория
    # только когда в тексте инициативы названия нет.
    journey_name = (repo_name or "Исследуемый проект") if research_basis == "code" else journey_name_of(context, repo_name)
    state = _PassportSession(
        agentic=evidence_broker is not None if agentic is None else agentic,
        research_enabled=research_enabled,
        research_basis=research_basis,
        research_source_digest=source_digest,
        evidence_broker=evidence_broker,
        checkpoint_path=Path(checkpoint_path) if checkpoint_path is not None else None,
        evidence_corpus=evidence_corpus,
        on_node=on_node,
        initiative_name="" if research_basis == "code" else (context.get("project_name") or "").strip(),
        plan_bullets=[] if research_basis == "code" else [str(text) for item in plan_items for text in item.criteria],
        bullet_status={} if research_basis == "code" else _bullet_statuses(plan_items, verdicts),
        scenarios={s.id: list(s.steps) for s in (connectivity.scenarios if connectivity else [])},
        scenario_context={s.id: {"entry": s.entry, "outcome": s.outcome}
                          for s in (connectivity.scenarios if connectivity else [])},
        scenario_titles={s.id: s.title for s in (connectivity.scenarios if connectivity else [])},
        capabilities=list(capabilities or []),
        capabilities_total=capabilities_total or len(capabilities or []),
        exposures=list(exposures or []),
    )
    if state.research_enabled and not state.agentic:
        raise ValueError("research_enabled требует agentic=True")
    root = state.new_id("journey")
    state.nodes[root] = _Node(id=root, name=journey_name, basis=("бизнес-схему требуется восстановить по коду"
                             if research_basis == "code" else "путь задан образом результата инициативы"))
    state.queue.append(root)
    state.known_paths = _known_paths(verdicts, knowledge or [])
    state.known_paths.update(ev.path for s in (connectivity.scenarios if connectivity else [])
                            for h in s.handoffs for c in h.checks for ev in c.verified_evidence)
    if state.agentic:
        from pko.audit import _CURRENT
        audit = _CURRENT.get()
        if state.checkpoint_path is None and audit is not None:
            state.checkpoint_path = audit.path.with_suffix(".passport.json")
        state.workspace.source_digest = digest({"commit": commit, "research_basis": research_basis,
                                               "intent": (source_text or "") if research_basis != "code" else "",
                                               "initial_corpus": evidence_corpus.manifest() if evidence_corpus else {}})
        if evidence_corpus is not None:
            state.known_paths.update(evidence_corpus.included)

    brief = [
        f"Рабочая подсказка для клиентского пути: {journey_name}. Название инициативы: "
        f"{context.get('project_name') or '—'}. Не повторяй название инициативы: "
        "сформулируй общий результат для клиента, охватывающий все процессы; "
        "не называй отдельный продукт, канал, способ подбора или шаг.",
        f"Было: {context.get('before') or '—'}. Стало: {context.get('after') or '—'}.",
    ]
    if research_basis == "code":
        brief = [f"Режим: восстановление бизнес-схемы проекта по коду (research_basis=code). Репозиторий: {repo_name or '—'}. "
                 "Восстанови точки входа, процессы, бизнес-результаты, необходимые передачи между узлами и операционные риски доступного снимка. "
                 "Сохраняй подтверждённые части по мере исследования; чтение всего проекта не является условием первой отправки. "
                 "Названия процессов и сценарии выводи из кода и контрактов. Образ результата и оценки прежнего ревьюера не задают состав, полноту или статусы схемы. "
                 "Найди границы проекта, в том числе возможности вне первоначальной инициативы. Дай корневому пути название по установленному назначению."]
    if source_text and source_text.strip() and research_basis != "code":
        brief.append("Дословный текст инициативы:\n" + source_text.strip()[:4000])
    # The evaluator's digest contains OR-specific instructions and a show_facts
    # tool absent from this session. Code research has its own capability catalog,
    # route digest and broker inventory below; do not import the old task wrapper.
    if capability_digest and research_basis != "code":
        brief.append(capability_digest)
    knowledge_ids: dict[int, str] = {}
    if evidence_corpus is not None:
        for key, row in evidence_corpus.records.items():
            label = str(row.get("label") or "")
            if label.startswith("След оценки ") and label[12:].isdigit():
                knowledge_ids.setdefault(int(label[12:]), key)
    if research_basis != "code":
        brief.append(render_evaluation_digest(plan_items, verdicts, summary, knowledge or [], knowledge_ids))
    scenarios_digest = render_scenarios_digest(connectivity)
    if scenarios_digest:
        brief.append(scenarios_digest)
    if state.research_enabled:
        brief.append("Единое исследование: сценарии и связность создаёшь и пересматриваешь сам "
                     "через submit_scenarios/submit_trace. Отдельного ревизора до этой сессии нет. "
                     "Вывод о системе — submit_system/submit_flow/submit_flaw/submit_integrity. "
                     "Порядок исследования, построения схемы, рисков и независимой проверки выбираешь сам. "
                     "Текущие данные доступны в research_state: scenarios, connectivity, system.")
    if evidence_corpus is not None:
        brief.append("Доступен корпус буквальных оснований: search_passport_evidence(query,offset), "
                     "read_passport_evidence(ids). В submit_node обязателен fact_check для каждого переданного поля; "
                     "в link_nodes — proof; у каждого риска — control_review. Сводки и ОР не доказывают реализацию. "
                     "Цитаты проверяются дословно по прочитанным фрагментам; нарушение не принимается после повторов.\n"
                     + json.dumps(evidence_corpus.index(), ensure_ascii=False))
        if evidence_corpus.route_usage is not None:
            route_digest = evidence_corpus.route_usage.digest()
            if route_digest:
                brief.append(route_digest)
    if state.capabilities:
        brief_caps = state.capabilities[:16] if state.agentic else state.capabilities
        brief.append(
            f"Возможности системы для обратного сопоставления (найдено {state.capabilities_total}, "
            f"показано {len(brief_caps)}): каждая должна быть описана узлом, "
            "привязана bind_capability или отклонена dismiss_capability с причиной. Код засчитывает "
            "возможность сам, если узел цитирует её код или называет обработчик/путь маршрута.\n"
            + "\n".join(c.describe() for c in brief_caps)
            + ("\nПолный каталог: research_state(section=capabilities, offset=0/16/32/…)." if state.agentic else "")
        )
    brief.append("")
    brief.append(_advance(state))
    user_brief = "\n\n".join(brief)

    try:
        prompt_path = _PROMPT_PATH.with_name("passport_agentic_system.md") if state.agentic else _PROMPT_PATH
        if research_basis == "code":
            prompt_path = _PROMPT_PATH.with_name("passport_code_system.md")
        system_prompt = prompt_path.read_text(encoding="utf-8")
    except OSError:
        system_prompt = "Ты заполняешь паспорт клиентского пути по знаниям сессии оценки."
        state.notes.append("Промпт паспортного агента не найден: passport_system.md")

    chat_client = client if client is not None else ChatClient(spec=spec)
    thinking_on = bool(
        spec.extra_body
        and spec.extra_body.get("chat_template_kwargs", {}).get("enable_thinking") is True
    )
    # Потолок ответа — тот же выбор, что у трёх других проходов: в режиме
    # рассуждения в него входит `reasoning_content`, и тесный бюджет даёт
    # пустой `content`.
    max_tokens = max_tokens_for(thinking_on)
    schemas = [_SUBMIT_NODE_SCHEMA, _DECLARE_CHILDREN_SCHEMA, _LINK_NODES_SCHEMA,
               _BIND_SCENARIO_STEP_SCHEMA, _SUBMIT_DEFECT_SCHEMA, _SUBMIT_NEED_SCHEMA,
               _SUBMIT_GUARDRAIL_SCHEMA, _SUBMIT_RISKS_SCHEMA, _READ_RISK_PATTERNS_SCHEMA,
               _READ_NODE_SCHEMA, _FINISH_SCHEMA]
    if evidence_corpus is not None:
        # Keep legacy persisted passports and direct callers compatible. The production
        # pipeline always supplies a corpus, even when it contains no source fragments.
        import copy
        schemas = copy.deepcopy(schemas)
        by_name = {s["function"]["name"]: s["function"]["parameters"] for s in schemas}
        for name, key, schema in (("submit_node", "fact_check", NODE_AUDIT_SCHEMA),
                                  ("link_nodes", "proof", RELATION_PROOF_SCHEMA)):
            by_name[name]["properties"][key] = schema
            by_name[name]["required"].append(key)
        risk_schema = by_name["submit_risks"]["properties"]["risks"]["items"]
        risk_schema["properties"]["control_review"] = CONTROL_REVIEW_SCHEMA
        risk_schema["required"].append("control_review")
        schemas.extend([READ_SCHEMA, SEARCH_SCHEMA])
        if state.bullet_status:
            schemas.append(_STATUS_DISPUTE_SCHEMA)
    if state.capabilities:
        schemas = [*schemas, _BIND_CAPABILITY_SCHEMA, _DISMISS_CAPABILITY_SCHEMA]
    if state.agentic:
        schemas = _agentic_schemas(schemas, state.evidence_broker is not None, research_basis)
    if state.research_enabled:
        from pko.progress.passport_connectivity import research_connectivity_schemas
        from pko.progress.passport_system_research import system_research_schemas
        schemas.extend(research_connectivity_schemas(research_basis) + system_research_schemas(research_basis))
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_brief},
    ]
    budget_seconds = _env_number("PKO_PASSPORT_MAX_SECONDS",
                                DEFAULT_RESEARCH_SECONDS if state.research_enabled else DEFAULT_PASSPORT_SECONDS)
    deadline = time.monotonic() + budget_seconds if budget_seconds else 0.0
    state.deadline = deadline
    if state.agentic:
        from pko.progress.passport_reviewer import review_passport_objects, _review_client
        state.max_review_calls = int(_env_number("PKO_PASSPORT_MAX_REVIEWS", 24 if state.research_enabled else 16))
        def independent_review(objects):
            remaining = max(0, state.deadline - time.monotonic()) if state.deadline else 120
            return review_passport_objects(objects, state.evidence_corpus, spec, client=chat_client,
                broker=state.evidence_broker, max_seconds=min(120, remaining))
        state.reviewer = independent_review
        if deadline and not use_harness:
            chat_client = _review_client(chat_client, spec, deadline)
    malformed = 0
    steps_done = 0
    recent_calls: list[tuple[tuple[str, str], ...]] = []
    last_mark: tuple | None = None
    idle = 0
    idle_calls: dict[str, int] = {}

    with trace_span("passport_session") as session_handle:
        state.span = session_handle
        session_handle.set_attribute("max_steps", max_steps)
        if use_harness:
            try:
                from pko.progress.passport_harness import run_harness_session
                steps_done = run_harness_session(state, client=chat_client, spec=spec, schemas=schemas,
                    system_prompt=system_prompt, user_brief=user_brief, max_steps=max_steps,
                    max_tokens=max_tokens, budget_seconds=budget_seconds, resume_path=resume_path)
            except ImportError:
                state.stop_reason = "error"
                state.notes.append("паспорт: библиотеки нового цикла недоступны; обновите зависимости из requirements.txt")
        else:
            for step in range(1, max(1, max_steps) + 1):
                steps_done = step
                if deadline and time.monotonic() > deadline:
                    state.stop_reason = "timeout"
                    state.notes.append(f"паспорт: время сессии исчерпано ({int(budget_seconds)} с) на шаге {step}")
                    break
                if state.agentic and state.tool_calls >= MAX_PASSPORT_TOOL_CALLS:
                    state.stop_reason = "tools"
                    state.notes.append(f"паспорт: бюджет вызовов инструментов исчерпан ({MAX_PASSPORT_TOOL_CALLS})")
                    break
                mark = _progress_mark(state)
                if mark != last_mark:
                    last_mark, idle = mark, 0
                    idle_calls.clear()
                else:
                    idle += 1
                if state.agentic:
                    from pko.progress.passport_focus import before_research_step
                    notice = before_research_step(state, step, max_steps,
                                                  max_tool_calls=MAX_PASSPORT_TOOL_CALLS)
                    if notice:
                        messages.append({"role": "user", "content": notice})
                if idle >= IDLE_STEPS_STOP:
                    state.stop_reason = "idle"
                    calls = ", ".join(f"{name} ×{count}" for name, count in
                                      sorted(idle_calls.items(), key=lambda kv: -kv[1])[:3])
                    state.notes.append(f"паспорт: остановлено — ни одного принятого результата, шагов подряд: {idle}"
                                       + (f" (вызовы: {calls})" if calls else ""))
                    break
                if idle == IDLE_STEPS_NUDGE:
                    messages.append({"role": "user", "content": _idle_nudge(state, idle)})
                # Шаг — ответ модели и все вызванные ею инструменты: в трейсе их
                # спаны дочерние к шагу.
                with trace_span("passport.step", step=step) as step_span:
                    try:
                        if state.agentic and deadline:
                            from pko.progress.passport_reviewer import _within_deadline
                            result = _within_deadline(lambda: chat_client.chat(messages, tools=schemas,
                                                                              max_tokens=max_tokens), deadline)
                        else:
                            result = chat_client.chat(messages, tools=schemas, max_tokens=max_tokens)
                    except LlmError as exc:
                        state.stop_reason = "error"
                        step_span.set_attribute("error", exc.message)
                        state.notes.append(f"паспорт: агент недоступен на шаге {step}: {exc.message} {exc.hint}".strip())
                        break
                    except TimeoutError:
                        state.stop_reason = "timeout"
                        state.notes.append("паспорт: время сессии исчерпано; запоздалый ответ модели не принимается")
                        break
                    except Exception as exc:
                        if not state.agentic:
                            raise
                        state.stop_reason = "error"
                        state.notes.append("паспорт: сессия прервана — " + type(exc).__name__)
                        break
                    if not result.tool_calls:
                        malformed += 1
                        if malformed >= _MAX_MALFORMED:
                            state.stop_reason = "malformed"
                            state.notes.append(f"паспорт: агент не вызвал инструмент {malformed} раз подряд — остановлено")
                            break
                        messages.append({"role": "assistant", "content": result.text})
                        messages.append({"role": "user", "content": "Нужно вызвать инструмент: " + _expected_text(state)})
                        if state.agentic:
                            _compact_agentic_history(messages, state)
                        continue
                    malformed = 0
                    for call in result.tool_calls:
                        name = str((call.get("function") or {}).get("name") or "")
                        idle_calls[name] = idle_calls.get(name, 0) + 1
                    if state.agentic and mark != (recent_calls[-1][0] if recent_calls else None):
                        recent_calls.clear()
                    signature = _signature(result.tool_calls)
                    recent_calls.append((mark, signature) if state.agentic else signature)
                    period = repeating_cycle(recent_calls)
                    if period:
                        state.stop_reason = "cycle"
                        state.notes.append(f"паспорт: остановлено — {cycle_text(period)}")
                        break
                    messages.append({
                        "role": "assistant", "content": result.text or None,
                        "tool_calls": result.tool_calls,
                        "reasoning_content": result.reasoning_content or None,
                    })
                    for call in result.tool_calls:
                        messages.append(trace_tool_call(_answer_call, state, call))
                    if state.agentic:
                        _compact_agentic_history(messages, state)
                    else:
                        _compact_history(messages)
                    if state.finished:
                        break
            else:
                state.stop_reason = "steps"
                state.notes.append(f"паспорт: бюджет шагов исчерпан ({max_steps})")
        session_handle.set_attribute("steps_done", steps_done)
        session_handle.set_attribute("nodes", len(state.nodes))
        session_handle.set_attribute("relations", len(state.relations))
        session_handle.set_attribute("defects", len(state.defects))
        session_handle.set_attribute("risks", len(state.risks))
        session_handle.set_attribute("risks_reviewed", state.risk_reviewed)
        session_handle.set_attribute("finished", state.finished)

    if not state.finished:
        missing = _unfinished(state)
        if missing:
            state.notes.append("паспорт не завершён: " + "; ".join(missing))
        elif not state.risk_reviewed:
            state.notes.append("паспорт не завершён: анализ операционных рисков не отправлен (submit_risks)")
        else:
            state.notes.append("паспорт не завершён: finish не принят до остановки сессии")
        unbound = state.unbound_steps()
        if unbound and state.scenarios:
            state.remarks.append("шаги сценариев без узла на схеме: " + _unbound_text(unbound))
    unfilled = [n.id for n in state.nodes.values() if not n.filled]
    if unfilled:
        state.notes.append("паспорт: узлы объявлены, но не заполнены: " + ", ".join(unfilled[:8]))
    if state.unresolved_relations:
        state.notes.append(f"паспорт: не подтверждено связей — {len(state.unresolved_relations)}; подробности в evidence_audit")
    for dispute in state.status_disputes:
        state.notes.append(
            f"паспорт оспаривает статус пункта «{dispute['bullet'][:120]}»: «{dispute['status_label']}» → "
            f"«{dispute['suggested_label']}» — {dispute['limitation']} Статус оценки не изменён, нужна ручная проверка."
        )
    if state.capabilities:
        _, _, unreviewed_caps = state.capability_state()
        if unreviewed_caps or state.capabilities_total > len(state.capabilities):
            state.notes.append(
                f"паспорт: возможностей системы без узла и без решения — {len(unreviewed_caps)} из "
                f"{len(state.capabilities)} показанных; найдено всего {state.capabilities_total}"
            )
    check = PassportCheck()
    check_router_present(check, {nid: n.data for nid, n in state.nodes.items() if n.filled})
    if state.finished and not state.needs:
        check.remarks.append("потребность клиента не сформулирована (submit_need) — на графе ряд потребностей пуст")
    state.remarks.extend(check.remarks)
    if state.remarks:
        state.notes.append("Замечания к паспорту: " + "; ".join(dict.fromkeys(state.remarks)))

    if state.plan_bullets and state.research_basis != "code":
        linked = {b for n in state.nodes.values() if n.filled for b in (n.data.get("bullets") or [])}
        unlinked = [b for b in state.plan_bullets if b not in linked]
        if unlinked:
            state.notes.append(
                f"паспорт: пунктов ОР без узла на схеме — {len(unlinked)} из {len(state.plan_bullets)}: "
                + "; ".join(f"«{b[:60]}»" for b in unlinked[:4])
            )
    filled_any = any(n.filled for n in state.nodes.values())
    scope = f"{repo_name} · коммит {commit[:8] if commit else '—'} · {context.get('project_name') or journey_name}"
    data = _build_passport_data(state, scope, time.strftime("%Y-%m-%d"), commit) if filled_any or evidence_corpus is not None else None
    if data is not None:
        data["runtime"] = {"engine": "pydantic-ai-harness" if use_harness else "legacy",
                           "version": "2.1" if use_harness else "2.0",
                           "harness_version": "0.54.0" if use_harness else None}
    if state.agentic:
        _checkpoint(state, data)
    research_connectivity, research_integrity = _research_results(state)
    return PassportAgentResult(passport_data=data, notes=state.notes, steps=steps_done,
                               connectivity=research_connectivity, integrity=research_integrity)


def _research_results(state: _PassportSession) -> tuple[ConnectivityReview | None, IntegrityReview | None]:
    if not state.research_enabled:
        return None, None
    from pko.progress.passport_connectivity import connectivity_review
    from pko.progress.passport_system_research import system_review
    return connectivity_review(state), system_review(state)


def _research_data(state: _PassportSession) -> dict[str, Any]:
    connectivity, integrity = _research_results(state)
    return {"connectivity": connectivity.to_dict() if connectivity else None,
            "integrity": integrity.to_dict() if integrity else None}


def _known_paths(verdicts: list[ItemVerdict], knowledge: list[str]) -> set[str]:
    """Пути, которые встречались в материалах оценки: ссылки вердиктов и
    след прочитанного. «Место в коде» у дефекта сверяется с ними."""
    out: set[str] = set()
    for verdict in verdicts:
        for crit in verdict.criteria:
            for ev in crit.evidence:
                if getattr(ev, "path", ""):
                    out.add(str(ev.path))
    for entry in knowledge:
        for match in _PATH_RE.findall(str(entry)):
            out.add(match)
    return out


def _bullet_statuses(plan_items: list[PlanItem], verdicts: list[ItemVerdict]) -> dict[str, str]:
    by_id = {v.item_id: v for v in verdicts}
    out: dict[str, str] = {}
    for item in plan_items:
        verdict = by_id.get(item.id)
        if verdict is None:
            continue
        for idx, text in enumerate(item.criteria):
            if idx < len(verdict.criteria) and verdict.criteria[idx].applicable:
                out[str(text)] = str(verdict.criteria[idx].status)
    return out


def _agentic_schemas(schemas: list[dict], broker_available: bool, research_basis: str = "result_image") -> list[dict]:
    from copy import deepcopy
    from pko.progress.passport_workspace import REFS
    result = deepcopy(schemas)
    by_name = {s["function"]["name"]: s["function"] for s in result}
    descriptions = {
        "submit_node": "Создать новую версию любого объявленного узла: name, basis, fields и fact_check. "
                       "Повторная отправка заменяет поля, сохраняет историю и отменяет прежнюю рецензию. "
                       "Поля своего уровня заполни либо явно укажи неизвестное; код проверяет основания.",
        "declare_children": "Добавить детей в любой существующий непланируемый контейнер. "
                            "Глубину задаёт смысл, квоты BBB нет. Общего ребёнка передай {ref:id}. "
                            "Узел до выбора процесса объяви before_fork у пути.",
        "bind_scenario_step": "Привязать шаг сценария к BBB/операциям. replace=true заменяет прежние привязки, "
                              "nodes=[] снимает их. Отсутствующие шаги видны при finish.",
        "submit_risks": "Передать текущий полный набор рисков, review и analysis. Можно пересматривать. "
                        "Отклонённые кандидаты сохраняются: исключать их нужно явно через resolve_finding с основанием.",
        "link_nodes": "Добавить доказанную связь между существующими узлами, в любой момент исследования. "
                      "Передавай proof, для feeds укажи конкретные передаваемые данные в field.",
        "finish": "Проверить завершённость исследования. Незакрытые находки, неполнота и неподтверждённые версии "
                  "блокируют завершение при любом числе повторов. Готовность кода и GO/PIVOT не изменяются.",
        "bind_capability": "Связать возможность с заполненными узлами. replace=true заменяет прежнюю привязку.",
        "dismiss_capability": "Обоснованно исключить возможность из пути. replace=true пересматривает явную привязку; "
                              "привязку по основаниям узлов сначала исправь в самих узлах. Нужны evidence и причина; "
                              "решение проходит независимую проверку, пустой поиск не доказывает legacy.",
    }
    for name, description in descriptions.items():
        if name in by_name:
            by_name[name]["description"] = description
    node_props = by_name["submit_node"]["parameters"]["properties"]
    node_props["scenarios"] = {"type": "array", "items": {"type": "string"},
                              "description": "У process — все сценарии, в которых участвует процесс; связь многие-ко-многим."}
    node_props.pop("scenario", None)
    node_props["bullets"]["description"] = "Дословные пункты ОР, к которым относится узел. Соответствие ОР и локальная реализация показываются раздельно."
    required = by_name["submit_node"]["parameters"].get("required", [])
    if "scenario" in required:
        required.remove("scenario")
    for name in ("bind_scenario_step", "bind_capability"):
        if name in by_name:
            by_name[name]["parameters"]["properties"]["replace"] = {"type": "boolean"}
    if "dismiss_capability" in by_name:
        params = by_name["dismiss_capability"]["parameters"]
        params["properties"]["evidence"] = deepcopy(REFS)
        params["properties"]["replace"] = {"type": "boolean"}
        params["required"].append("evidence")
    for name in ("submit_defect", "submit_guardrail"):
        params = by_name[name]["parameters"]
        params["properties"]["id"] = {"type": "string", "description": "Для изменения существующей записи; для новой не передавай."}
        params["properties"]["evidence"] = deepcopy(REFS)
        params["required"].append("evidence")
    result.extend(deepcopy(WORKSPACE_SCHEMAS))
    if research_basis == "code":
        from pko.progress.passport_connections import CONNECTION_SCHEMA
        result.append(deepcopy(CONNECTION_SCHEMA))
        node_props["fields"] = fields_schema("code")
        by_name["submit_node"]["description"] += (
            " Отсутствующие управленческие поля 4.2.3, 4.3.3, 4.3.9, 4.4.3, 4.4.7, 4.5.3 "
            "код отметит как Не установлено с auto_unknown_fields. Переданные значения и основания "
            "проверяются полностью; остальные смысловые поля и execution обязательны. "
            "Названия и назначение каждого поля доступны в fields и read_node."
        )
        node_props.pop("bullets", None)
        node_props["scenario_steps"]["items"]["properties"]["scenario"]["description"] = "ID сценария, восстановленного по коду: scenario-N."
        node_props.pop("planned", None)
        from pko.progress.passport_system_research import system_research_schemas
        code_refs = system_research_schemas("code")[0]["function"]["parameters"]["properties"]["evidence"]
        node_props["existence_evidence"] = {**deepcopy(code_refs), "description": "Обязательные прочитанные цитаты с path/line/basis, подтверждающие существование этого бизнес-узла или обоснованное объединение существующих действий. Желаемый отсутствующий блок не является узлом текущей карты."}
        by_name["submit_node"]["parameters"]["required"].append("existence_evidence")
        for schema in result:
            function = schema["function"]
            if function["name"] == "research_state":
                function["parameters"]["properties"]["section"]["enum"].append("connections")
            if function["name"] == "record_scope":
                function["description"] = "Зафиксировать исследование или обоснованное исключение component:<имя>/step:scenario-N:0. Нужны кодовые основания; отсутствие в ОР не исключает компонент проекта."
    if broker_available:
        from pko.progress.passport_broker import BROKER_SCHEMA
        result.append(deepcopy(BROKER_SCHEMA))
    node_schema = by_name["submit_node"]["parameters"]
    node_props["patch"] = {"type": "boolean", "description": "true — исправить только переданные поля последней заявки этого узла; весь объединённый узел проверяется заново."}
    node_props["draft_revision"] = {"type": "integer", "minimum": 1,
                                    "description": "Для patch=true: актуальная версия заявки из ответа submit_node или read_node.draft.revision."}
    full_required = list(node_schema.get("required", []))
    if research_basis == "code":
        # Existing declarations already carry name/basis. The domain gate merges
        # them before checking a submission; the transport schema must agree.
        full_required = [key for key in full_required if key not in ("name", "basis")]
    node_schema["required"] = ["id"]
    node_schema["anyOf"] = [
        {"required": full_required},
        {"required": ["id", "patch", "draft_revision"], "properties": {"patch": {"enum": [True]}}},
    ]
    if "fact_check" in node_props:
        node_props["fact_check"].pop("required", None)
        node_props["fact_check"]["description"] += (
            " При patch=true можно передать только fields с аудитом изменённых полей либо execution целиком; "
            "остальное сохраняется из актуальной заявки и проверяется заново.")
    by_name["submit_node"]["description"] += (
        " Для исправления ошибки не переписывай карточку целиком: patch=true, draft_revision из последнего ответа, "
        "fields — только исправленные поля (value и source), fact_check.fields — их проверка. "
        "Неизменённые данные и цитаты сохраняются; read_node показывает последнюю заявку даже после отказа.")
    return result


def _checkpoint(state: _PassportSession, draft: dict | None = None) -> None:
    if not state.agentic or state.checkpoint_path is None:
        return
    from dataclasses import asdict
    try:
        sync_objects(state)
        snapshot = {**draft, "node_drafts": state.node_drafts,
                    "research_focus": state.research_focus} if draft is not None else {
            "schema_version": 2, "research_basis": state.research_basis,
            "research_mode": "code_reconstruction" if state.research_basis == "code" else "integrated",
            "connection_review": list(state.connection_review.values()),
            "nodes": {nid: asdict(n) for nid, n in state.nodes.items()},
            "node_drafts": state.node_drafts,
            "research_focus": state.research_focus,
            "relations": state.relations, "risks": state.risks, "risk_review": state.risk_review,
            "risk_analysis": state.risk_analysis, "risk_reviewed": state.risk_reviewed,
            "defects": state.defects, "guardrails": state.guardrails,
            "capability_bound": state.capability_bound, "capability_dismissed": state.capability_dismissed,
            "evidence_audit": state.evidence_corpus.manifest() if state.evidence_corpus else {},
            "evidence_materials": state.evidence_corpus.records if state.evidence_corpus else {},
            "source_inventory": state.evidence_broker.inventory() if state.evidence_broker else {},
            "stop_reason": state.stop_reason, "finished": state.finished,
            **(_research_data(state) if state.research_enabled else {}),
        }
        state.workspace.checkpoint(state.checkpoint_path, draft=snapshot)
    except OSError as exc:
        note = "паспорт: контрольная копия не записана — " + type(exc).__name__
        if note not in state.notes:
            state.notes.append(note)


def _answer_call(state: _PassportSession, call: dict) -> dict[str, Any]:
    from pko.audit import record
    record("passport_tool_call", call=call)
    function = call.get("function") or {}
    name = str(function.get("name") or "")
    call_id = str(call.get("id") or "")
    try:
        args = json.loads(function.get("arguments") or "{}")
    except json.JSONDecodeError as exc:
        record("passport_tool_result", call_id=call_id, name=name, error="invalid_json")
        return {"role": "tool", "tool_call_id": call_id,
                "content": f"аргументы инструмента не являются валидным JSON: {exc}"}
    if not isinstance(args, dict):
        args = {}
    handlers = _HANDLERS
    if state.agentic:
        from pko.progress.passport_tools import HANDLERS
        handlers = {**handlers, **HANDLERS}
    if state.research_enabled:
        from pko.progress.passport_connectivity import RESEARCH_CONNECTIVITY_SCHEMAS, handle_research_connectivity
        from pko.progress.passport_system_research import SYSTEM_RESEARCH_SCHEMAS, handle_system_research
        handlers = {**handlers,
                    **{s["function"]["name"]: (lambda st, a, n=s["function"]["name"]: handle_research_connectivity(st, n, a))
                       for s in RESEARCH_CONNECTIVITY_SCHEMAS},
                    **{s["function"]["name"]: (lambda st, a, n=s["function"]["name"]: handle_system_research(st, n, a))
                       for s in SYSTEM_RESEARCH_SCHEMAS}}
    if state.research_basis == "code":
        from pko.progress.passport_connections import submit_connection_review
        handlers = {**handlers, "submit_connection_review": submit_connection_review}
        handlers.pop("submit_status_dispute", None)
    handler = handlers.get(name)
    if state.agentic and state.finished:
        content = "Паспорт уже завершён; последующие изменения в этом ответе не выполняются."
    elif state.agentic and (state.tool_calls >= MAX_PASSPORT_TOOL_CALLS or (state.deadline and time.monotonic() >= state.deadline)):
        content = "Инструмент не выполнен: бюджет паспортной сессии исчерпан; сохраняется неполный результат."
    elif handler is None:
        content = f"инструмента «{name}» нет. Доступны: {', '.join(handlers)}. " + _expected_text(state)
    else:
        state.tool_calls += 1
        before = digest({"nodes": {nid: {"data": n.data, "parents": n.parents, "children": n.children}
                                  for nid, n in state.nodes.items()},
                         "relations": state.relations, "defects": state.defects, "guardrails": state.guardrails}) if state.agentic else ""
        try:
            content = handler(state, args)
        except (ValueError, TypeError, KeyError, IndexError, AttributeError) as exc:
            if not state.agentic:
                raise
            content = f"{name} отклонён: некорректная структура аргументов ({type(exc).__name__}). Исправь по схеме инструмента."
        if state.agentic:
            key = name + ":" + str(args.get("id") or args.get("parent") or args.get("capability") or "")
            if name == "submit_trace":
                key = name + ":" + str(args.get("scenario_id") or "")
            if name == "submit_connection_review":
                key = name + ":" + str(args.get("process") or "")
            if name == "link_nodes":
                key = name + ":" + ":".join(str(args.get(k, "")) for k in ("from", "to", "kind"))
            # Only proposals can create findings. Read/search payloads contain
            # arbitrary source words, including "отклонён" and "error".
            # A finish refusal describes existing blockers, not a new finding.
            from pko.progress.passport_context import tool_rejected
            if name not in ("finish", "research_state", "resolve_finding", "review_passport",
                            "read_node", "read_passport_evidence", "search_passport_evidence",
                            "request_passport_evidence", "read_risk_patterns"):
                if tool_rejected(name, content):
                    fid = state.workspace.reject(key, {"tool": name, **args}, str(content))
                    content += f"\nНаходка сохранена: {fid}; исправленная отправка или resolve_finding сохранит решение."
                else:
                    state.workspace.accepted(key)
            after = digest({"nodes": {nid: {"data": n.data, "parents": n.parents, "children": n.children}
                                     for nid, n in state.nodes.items()},
                            "relations": state.relations, "defects": state.defects, "guardrails": state.guardrails})
            if before != after and name != "submit_risks":
                state.risk_reviewed = False
            if state.evidence_corpus is not None:
                state.known_paths.update(state.evidence_corpus.included)
            sync_objects(state)
            from pko.progress.passport_focus import observe_research_tool
            observe_research_tool(state, name, args, content)
            _checkpoint(state)
    record("passport_tool_result", call_id=call_id, name=name, content=content)
    return {"role": "tool", "tool_call_id": call_id, "content": content}


# Ответы после узлов несут карту дерева, а после дерева — памятку рисков.
# В истории нужны только последние ответы; старые ужимаются до первой строки.
_KEEP_RECENT_TOOL_REPLIES = 2


# Старые отправки паспорта. Аргументы submit_node и соседей — поля, цитаты,
# fact_check — оставались в истории навсегда и к концу сессии занимали четверть
# входа. После двух последних ответов модели от принятой отправки остаётся
# суть (имя, значения полей, ссылки evidence-N), а цитаты и разбор оснований
# уходят: их проверил гейт, и полные данные отдаёт read_node. Отклонённая
# отправка сворачивается до пометки — ответ гейта на неё остаётся в истории.
_KEEP_RECENT_CALLS = 2
_FOLDED_CALLS = frozenset({"submit_node", "link_nodes", "submit_risks", "submit_defect",
                           "submit_status_dispute"})
_AUDIT_KEYS = frozenset({"fact_check", "proof", "control_review", "explanation", "quote"})
_FOLD_MARK = "_свёрнуто"
_FOLDED_SOURCE_CHARS = 120
_EVIDENCE_ID = re.compile(r"evidence-\d+")


def _fold_old_calls(messages: list[dict[str, Any]]) -> None:
    from pko.progress.passport_context import tool_rejected
    replies = {m.get("tool_call_id"): str(m.get("content") or "")
               for m in messages if m.get("role") == "tool"}
    answers = [m for m in messages if m.get("role") == "assistant" and m.get("tool_calls")]
    for message in answers[:max(0, len(answers) - _KEEP_RECENT_CALLS)]:
        calls, changed = [], False
        for call in message["tool_calls"]:
            function = call.get("function") or {}
            name = function.get("name")
            try:
                args = json.loads(function.get("arguments") or "{}")
            except ValueError:
                args = None
            if name not in _FOLDED_CALLS or not isinstance(args, dict) or _FOLD_MARK in args:
                calls.append(call)
                continue
            rejected = tool_rejected(name, replies.get(call.get("id"), ""))
            folded = json.dumps(_folded_args(name, args, rejected), ensure_ascii=False)
            calls.append({**call, "function": {**function, "arguments": folded}})
            changed = True
        if changed:
            # Новый список, а не правка на месте: трассировка узнаёт изменённое
            # сообщение по тождеству списка вызовов.
            message["tool_calls"] = calls


def _folded_args(name: str, args: dict[str, Any], rejected: bool) -> dict[str, Any]:
    if rejected:
        keep = {k: args[k] for k in ("id", "name", "from", "to", "kind", "bullet", "title") if k in args}
        return {**keep, _FOLD_MARK: "отклонённая отправка; ответ гейта — в истории ниже"}
    ids: set[str] = set()
    slim = _without_audit(args, ids)
    if ids:
        slim["evidence_ids"] = sorted(ids, key=lambda x: int(x.split("-")[1]))
    slim[_FOLD_MARK] = ("принято; цитаты и разбор оснований свёрнуты"
                        + ("; полные данные — read_node(id)" if name == "submit_node" else ""))
    return slim


def _without_audit(value: Any, ids: set[str]) -> Any:
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for key, item in value.items():
            if key in _AUDIT_KEYS:
                ids.update(_EVIDENCE_ID.findall(json.dumps(item, ensure_ascii=False, default=str)))
            elif key == "source" and isinstance(item, str) and len(item) > _FOLDED_SOURCE_CHARS:
                out[key] = item[:_FOLDED_SOURCE_CHARS].rstrip() + "…"
            else:
                out[key] = _without_audit(item, ids)
        return out
    if isinstance(value, list):
        return [_without_audit(item, ids) for item in value]
    return value


def _compact_history(messages: list[dict[str, Any]]) -> None:
    evidence_chars = 0
    last_assistant = max((i for i, m in enumerate(messages) if m.get("role") == "assistant"), default=-1)
    for index in range(len(messages) - 1, -1, -1):
        message = messages[index]
        content = str(message.get("content") or "")
        if message.get("role") != "tool" or not content.startswith('{"records":') or '"text":' not in content:
            continue
        evidence_chars += len(content)
        # All replies from the latest batch must reach the model at least once.
        if index > last_assistant or evidence_chars <= 24_000:
            continue
        try:
            body = json.loads(content)
        except ValueError:
            continue
        records = [{k: v for k, v in row.items() if k != "text"} for row in body.get("records", [])]
        message["content"] = json.dumps({"records": records,
            "note": "Текст свёрнут для экономии контекста. Повторно прочитай нужные id через read_passport_evidence."}, ensure_ascii=False)
    _fold_old_calls(messages)
    tool_idx = [i for i, m in enumerate(messages) if m.get("role") == "tool"]
    for i in tool_idx[:-_KEEP_RECENT_TOOL_REPLIES]:
        content = str(messages[i].get("content") or "")
        if ("\nПостроено:" in content or content.startswith("Построено:")
                or "\nОпорные факты для поиска рисков (" in content):
            messages[i]["content"] = content.split("\n", 1)[0]


def _compact_agentic_history(messages: list[dict[str, Any]], state: _PassportSession | None = None) -> None:
    from pko.progress.passport_context import compact_context
    compact_context(messages, state)
