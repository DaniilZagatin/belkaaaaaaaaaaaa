"""Bounded, read-only extension of the passport's saved evidence corpus.

The broker introduces handles, not citations: a record is usable only after
EvidenceCorpus.read() has shown it. Search and call facts are discovery hints,
not evidence of absence, reachability, or semantic truth.
"""
from __future__ import annotations

import hashlib
import re
from collections import Counter
from copy import deepcopy
from typing import Any

from pko.progress.agent_tools import ToolBox, _mask_secrets
from pko.progress.passport_evidence import EvidenceCorpus
from pko.progress.passport_source import allowed_source_path as _allowed_path, safe_source_path as _safe_path


BROKER_SCHEMA = {
    "type": "function",
    "function": {
        "name": "request_passport_evidence",
        "description": (
            "Расширить сохранённый корпус из фиксированного снимка. file: path или id символа, "
            "line — центр окна; callers/callees: id символа из inventory/search; search: "
            "буквальный query, необязательный path файла или каталога. Ответ содержит только "
            "идентификаторы: затем обязательно read_passport_evidence. Точный повтор полного успешного "
            "запроса возвращает cached=true и прежние ID без нового расхода лимита. Это не чтение. "
            "При retryable=false не повторяй отказавший запрос: используй сохранённые материалы "
            "или зафиксируй границу исследования. Пустой поиск не доказывает отсутствие."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "kind": {"type": "string", "enum": ["file", "callers", "callees", "search"]},
                "path": {"type": "string", "maxLength": 512},
                "id": {"type": "string", "pattern": "^symbol-[1-9][0-9]*$"},
                "line": {"type": "integer", "minimum": 1},
                "query": {"type": "string", "minLength": 2, "maxLength": 160},
            },
            "required": ["kind"],
            "additionalProperties": False,
        },
    },
}

_SYMBOL_KINDS = {"FUNCTION", "CLASS_DEF", "TOOL", "SQL_PROC", "JAVA_METHOD",
                 "JAVA_CLASS", "ROUTE", "ENTRYPOINT", "GRAPH_NODE", "JAVA_JOB"}
_MAX_RESULTS = 8
_INVENTORY_ROWS = 200
_SCOPE = ("Только статический снимок: найденные вызовы приблизительны; отсутствие совпадений "
          "не доказывает отсутствие реализации или контроля. Выполнение не проверялось.")


class _SnapshotView:
    """Allowlisted, cached view; ToolBox is the only consumer of its text.

    Hashes describe decoded snapshot text before masking. The Tree protocol
    does not expose original bytes or ZIP provenance, so we never claim those.
    Even ToolBox.search cannot read blocked files through this view.
    """

    def __init__(self, tree: Any, files: list[str], max_files: int, max_chars: int):
        self._tree = tree
        self.files = files
        self._allowed = frozenset(files)
        self.cache: dict[str, str | None] = {}
        self.deferred: set[str] = set()
        self.hashes: dict[str, str] = {}
        self.failures: dict[str, str] = {}
        self.chars = 0
        self.max_files, self.max_chars = max_files, max_chars
        # Broad searches must not exhaust all source reads before the model can
        # inspect a concrete handler. Both paths still share the same hard cap.
        self.search_max_files = max(1, max_files - max(1, max_files // 4))
        self.search_max_chars = max(1, max_chars - max(1, max_chars // 4))
        self.refusals = 0
        self.search_refusals = 0

    @property
    def files_read(self) -> int:
        return len(self.cache) + len(self.deferred)

    def read(self, path: str, *, discovery: bool = False) -> str | None:
        if path not in self._allowed:
            self.refusals += 1
            return None
        if path in self.cache:
            return self.cache[path]
        if discovery and (path in self.deferred or self.files_read >= self.search_max_files or self.chars >= self.search_max_chars):
            self.refusals += 1
            self.search_refusals += 1
            return None
        if self.files_read - int(path in self.deferred) >= self.max_files or self.chars >= self.max_chars:
            self.refusals += 1
            return None
        try:
            text = self._tree.read(path)
        except Exception:  # Source error strings may contain credentials or host paths.
            text = None
        if not isinstance(text, str):
            self.deferred.discard(path)
            self.cache[path] = None
            self.failures[path] = "unreadable"
            return None
        if len(text) > self.max_chars - self.chars or "\x00" in text:
            self.deferred.discard(path)
            self.cache[path] = None
            self.failures[path] = "source_size_or_binary"
            self.refusals += 1
            return None
        if discovery and len(text) > self.search_max_chars - self.chars:
            self.deferred.add(path)
            self.refusals += 1
            self.search_refusals += 1
            return None  # Only an addressed read may retry within the hard cap.
        self.deferred.discard(path)
        self.cache[path] = text
        self.chars += len(text)
        self.hashes[path] = hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()
        return text


class _SearchSnapshotView:
    """Same snapshot and cache, with capacity reserved for addressed reads."""

    def __init__(self, snapshot: _SnapshotView):
        self.snapshot = snapshot
        self.files = snapshot.files

    def read(self, path: str) -> str | None:
        return self.snapshot.read(path, discovery=True)


class EvidenceBroker:
    """Session-owned broker. Constructor limits are host policy, never model input."""

    def __init__(self, tree: Any, extraction: Any, corpus: EvidenceCorpus, *,
                 max_requests: int = 40, max_new_files: int = 20, max_symbols: int = 80,
                 max_chars: int = 160_000, window_lines: int = 120,
                 max_source_files: int = 200, max_source_chars: int = 8_000_000):
        values = (max_requests, max_new_files, max_symbols, max_chars,
                  window_lines, max_source_files, max_source_chars)
        if any(type(value) is not int or value < 1 for value in values):
            raise ValueError("Broker limits must be positive integers")
        self.corpus = corpus
        self.limits = dict(zip(("requests", "new_files", "symbols", "chars", "window_lines",
                                "source_files", "source_chars"), values))
        self.limits["window_lines"] = min(window_lines, 200)
        self._files = sorted({p for p in tree.files if _allowed_path(p)})
        self._file_set = frozenset(self._files)
        self._snapshot = _SnapshotView(tree, self._files, max_source_files, max_source_chars)
        self._toolbox = ToolBox(self._snapshot, extraction)
        self._facts = tuple(f for f in getattr(extraction, "facts", ())
                            if f.path in self._file_set and type(f.line) is int and f.line > 0)
        definitions = sorted((f for f in self._facts if f.kind in _SYMBOL_KINDS),
                             key=lambda f: (f.path, f.line, f.kind, f.key))
        self._symbols: dict[str, dict] = {}
        self._symbol_names: dict[str, str] = {}
        seen = set()
        for fact in definitions:
            identity = (fact.path, fact.line, fact.key)
            if identity in seen:
                continue
            seen.add(identity)
            key = f"symbol-{len(self._symbols) + 1}"
            self._symbols[key] = {"id": key, "path": fact.path, "line": fact.line,
                                  "name": _mask_secrets(str(fact.key))[:160], "kind": fact.kind}
            self._symbol_names[key] = str(fact.key)
        self._initial_files = {row.get("label", "").rsplit(":", 1)[0]
                               for row in corpus.records.values() if row.get("kind") in {"code", "document"}}
        self._new_files: set[str] = set()
        self._used_symbols: set[str] = set()
        self._windows: dict[tuple[str, int], list[dict]] = {}
        # Only complete successful answers are immutable. A truncated search may
        # gain matches after addressed reads populate the shared snapshot cache.
        self._completed_requests: dict[tuple, dict] = {}
        self._request_calls = self._cache_hits = 0
        self._requests = self._chars = self._denied = 0
        self._audit: list[dict] = []
        self._events_omitted = 0
        self._source_kind = ("combined_snapshot" if hasattr(tree, "primary") and hasattr(tree, "overlay")
                             else "git_snapshot" if getattr(tree, "sha", "") else "file_snapshot")
        self._commit = str(getattr(tree, "sha", "") or corpus.commit)

    def _usage(self) -> dict:
        return {"requests": self._requests, "new_files": len(self._new_files),
                "request_calls": self._request_calls, "cache_hits": self._cache_hits,
                "symbols": len(self._used_symbols), "chars": self._chars,
                "source_files": self._snapshot.files_read, "source_chars": self._snapshot.chars,
                "source_deferred_files": len(self._snapshot.deferred),
                "source_refusals": self._snapshot.refusals,
                "search_source_refusals": self._snapshot.search_refusals,
                "denied": self._denied}

    def inventory(self) -> dict:
        """No source reads. Directory groups are never called original archives."""
        groups = Counter(path.split("/", 1)[0] if "/" in path else "." for path in self._files)
        docs = Counter(path.split("/", 1)[0] if "/" in path else "." for path in self._files
                       if path.lower().endswith((".md", ".rst", ".txt")))
        return {"source_kind": self._source_kind, "commit": self._commit,
                "components": [{"path": path, "files": count, "code_files": count - docs[path],
                                "document_files": docs[path], "basis": "top_level_directory"}
                               for path, count in sorted(groups.items())[:_INVENTORY_ROWS]],
                "components_total": len(groups),
                "archive_provenance": "unknown: the snapshot Tree does not expose original archive bytes/names",
                "files": self._files[:_INVENTORY_ROWS], "files_total": len(self._files),
                "symbols": deepcopy(list(self._symbols.values())[:self.limits["symbols"]]),
                "symbols_total": len(self._symbols),
                "limits": dict(self.limits), "usage": self._usage(),
                "source_hash_scope": "SHA-256 of complete decoded snapshot text encoded as UTF-8, before masking; not raw file or ZIP bytes",
                "source_hashes": [{"path": path, "sha256": digest}
                                  for path, digest in sorted(self._snapshot.hashes.items())],
                "source_hashes_complete": len(self._snapshot.hashes) == len(self._files),
                "source_failures": [{"path": path, "reason": reason}
                                    for path, reason in sorted(self._snapshot.failures.items())],
                "audit": deepcopy(self._audit), "audit_events_omitted": self._events_omitted,
                "scope": _SCOPE}

    def request(self, args: dict) -> dict:
        self._request_calls += 1
        kind = args.get("kind") if isinstance(args, dict) else None
        result: dict = {"ok": False, "records": [], "symbols": [], "truncated": False}
        error = self._validate(args)
        key = tuple(sorted(args.items())) if not error else None
        cached = key is not None and key in self._completed_requests
        if cached:
            result = deepcopy(self._completed_requests[key])
            self._cache_hits += 1
        else:
            self._requests += 1
            if self._requests > self.limits["requests"]:
                error = "request_budget"
            if error:
                result["error"] = error
            else:
                try:
                    result.update(self._dispatch(args))
                except Exception:  # Do not serialize arbitrary source/provider exceptions.
                    result["error"] = "source_error"
                if result["ok"] and not result["truncated"]:
                    self._completed_requests[key] = deepcopy(result)
        if not result["ok"]:
            self._denied += 1
        event = {"request": self._request_calls, "kind": kind if isinstance(kind, str) and kind in {"file", "search", "callers", "callees"} else "invalid",
                 "ok": result["ok"], "error": result.get("error", ""),
                 "cached": cached,
                 "records": [row["id"] for row in result["records"]],
                 "truncated": result["truncated"], "usage": self._usage(),
                 "omitted": deepcopy(result.get("omitted", []))}
        if isinstance(args, dict) and isinstance(args.get("query"), str):
            event["query_sha256"] = hashlib.sha256(args["query"].encode("utf-8", errors="replace")).hexdigest()
        if len(self._audit) < max(64, self.limits["requests"] * 2):
            self._audit.append(event)
        else:
            self._events_omitted += 1
        terminal_limit = result.get("error") in {
            "request_budget", "new_file_budget", "symbol_budget", "corpus_character_budget",
            "source_file_budget", "source_character_budget", "source_size_or_binary", "unreadable",
        }
        result.update({"limits": dict(self.limits), "usage": self._usage(), "scope": _SCOPE,
                       "cached": cached,
                       "availability": {"new_requests": self._requests < self.limits["requests"],
                                        "cached_requests": bool(self._completed_requests)},
                       "retryable": not terminal_limit,
                       "next_action": ("read_passport_evidence" if result["records"] else
                                       "use_existing_evidence_or_record_limit" if terminal_limit else "refine_request")})
        if terminal_limit:
            result["note"] = (
                "Этот запрос недоступен в текущей сессии; повтор или переформулировка не снимут указанный лимит. "
                "Продолжи с уже сохранённым корпусом через search_passport_evidence/read_passport_evidence, "
                "зафиксируй подтверждённые выводы и конкретную границу неизвестного. "
                "Лимит чтения не означает отсутствия функции и не запрещает отправить узел с известными основаниями."
            )
        return result

    def _validate(self, args: Any) -> str:
        if not isinstance(args, dict) or set(args) - {"kind", "path", "id", "line", "query"}:
            return "invalid_arguments"
        kind = args.get("kind")
        if not isinstance(kind, str) or kind not in {"file", "search", "callers", "callees"}:
            return "invalid_kind"
        if "path" in args and not _safe_path(args["path"]):
            return "invalid_path"
        if "line" in args and (type(args["line"]) is not int or args["line"] < 1):
            return "invalid_line"
        if "id" in args and (not isinstance(args["id"], str) or args["id"] not in self._symbols):
            return "unknown_symbol"
        if kind == "file":
            if ("path" in args) == ("id" in args) or "query" in args:
                return "file_requires_path_or_id"
        elif kind in {"callers", "callees"}:
            if set(args) != {"kind", "id"}:
                return "calls_require_symbol_id"
        elif (set(args) - {"kind", "path", "query"} or not isinstance(args.get("query"), str)
              or not 2 <= len(args["query"].strip()) <= 160):
            return "search_requires_literal_query"
        if "path" in args and args["path"] not in self._file_set:
            prefix = args["path"] + "/"
            if kind != "search" or not any(path.startswith(prefix) for path in self._files):
                return "path_not_available"
        return ""

    def _dispatch(self, args: dict) -> dict:
        kind = args["kind"]
        key = args.get("id")
        if key:
            if key not in self._used_symbols and len(self._used_symbols) >= self.limits["symbols"]:
                return {"error": "symbol_budget"}
            self._used_symbols.add(key)
        if kind == "file":
            symbol = self._symbols[key] if key else None
            path = symbol["path"] if symbol else args["path"]
            line = args.get("line", symbol["line"] if symbol else 1)
            return self._collect([(path, line)])
        if kind == "search":
            prefix = args.get("path", "")
            files = [path for path in self._files if not prefix or path == prefix or path.startswith(prefix + "/")]
            # The fixed view enforces secret-file and source-volume bounds even
            # though the historical ToolBox.search reader itself is permissive.
            toolbox = ToolBox(_SearchSnapshotView(self._snapshot))
            toolbox._files = files
            before = self._snapshot.refusals
            search_before = self._snapshot.search_refusals
            found = toolbox.search(re.escape(args["query"].strip()))
            spots = []
            for line in found.content.splitlines():
                match = re.match(r"^(.+?):(\d+): ", line)
                if match and match[1] in self._file_set:
                    spots.append((match[1], int(match[2])))
            symbols = [row for row in self._symbols.values()
                       if (not prefix or row["path"] == prefix or row["path"].startswith(prefix + "/"))
                       and args["query"].casefold() in (row["name"] + " " + row["path"]).casefold()]
            result = self._collect(spots)
            result.update({"symbols": deepcopy(symbols[:_MAX_RESULTS]), "matches_returned": len(spots),
                           "search_files_considered": found.meta.get("scanned", 0),
                           "unreadable_files": sum(path in self._snapshot.failures for path in files)})
            result["truncated"] |= (len(symbols) > _MAX_RESULTS or self._snapshot.refusals > before
                                    or bool(result["unreadable_files"])
                                    or "поиск остановлен" in found.content or "ещё совпадения" in found.content)
            if self._snapshot.search_refusals > search_before:
                result["search_limit"] = "Часть файлов не просмотрена: сохранён резерв для адресного чтения. Уточни path или запроси нужный файл/символ; пустой результат не доказывает отсутствие."
            return result
        symbol = self._symbols[key]
        name = self._symbol_names[key]
        edges = [fact for fact in self._facts
                 if (fact.kind == "CALLS" and isinstance(fact.value, dict)
                     and ((kind == "callers" and fact.value.get("callee") == name)
                          or (kind == "callees" and fact.path == symbol["path"] and fact.value.get("caller") == name)))
                 or (kind == "callers" and fact.kind == "SQL_CALL" and fact.key == name)]
        spots = [(fact.path, fact.line) for fact in edges]
        target_names = {fact.value.get("callee") for fact in edges} if kind == "callees" else set()
        targets = [row for sid, row in self._symbols.items() if self._symbol_names[sid] in target_names]
        spots.extend((row["path"], row["line"]) for row in targets)
        result = self._collect(spots)
        result.update({"symbols": deepcopy(targets[:_MAX_RESULTS]), "call_edges": len(edges),
                       "resolution": "approximate_name_match; same-name declarations and dynamic calls require inspection",
                       "call_facts_scope": "CALLS with named owner; SQL_CALL supports callers only because owner is not extracted"})
        result["truncated"] |= len(targets) > _MAX_RESULTS
        return result

    def _collect(self, spots: list[tuple[str, int]]) -> dict:
        unique = list(dict.fromkeys(spots))
        records, omissions = [], []
        for path, line in unique[:_MAX_RESULTS]:
            rows, error = self._window(path, line)
            records.extend(row for row in rows if row not in records)
            if error:
                omissions.append({"path": path, "line": line, "reason": error})
        return {"ok": bool(records) or not unique, "records": records,
                "truncated": bool(omissions) or len(unique) > _MAX_RESULTS,
                "omitted": omissions,
                **({"error": omissions[0]["reason"]} if omissions and not records else {})}

    def _window(self, path: str, line: int) -> tuple[list[dict], str]:
        width = self.limits["window_lines"]
        start = max(1, line - width // 2)
        key = (path, start)
        if key in self._windows:
            return deepcopy(self._windows[key]), ""
        if path not in self._initial_files | self._new_files and len(self._new_files) >= self.limits["new_files"]:
            return [], "new_file_budget"
        result = self._toolbox.read_file(path, offset=start, limit=width)
        if not result.ok:
            reason = self._snapshot.failures.get(path)
            if reason is None:
                reason = ("source_file_budget" if self._snapshot.files_read >= self._snapshot.max_files
                          else "source_character_budget" if self._snapshot.chars >= self._snapshot.max_chars
                          else "source_unavailable")
            return [], reason
        total = result.meta.get("total_lines", 0)
        if line > total:
            return [], "line_outside_file"
        text = result.content.split("\n... есть ещё строки", 1)[0]
        if self._chars + len(text) > self.limits["chars"]:
            return [], "corpus_character_budget"
        previous = set(self.corpus.records)
        kind = "document" if path.lower().endswith((".md", ".rst", ".txt")) else "code"
        self.corpus.add(kind, f"{path}:{start}", text)
        self.corpus.included.setdefault(path, "broker_request")
        rows = [{"id": eid, "path": path, "start_line": start,
                 "end_line": min(start + width - 1, total), "kind": kind}
                for eid in self.corpus.records if eid not in previous]
        self._chars += len(text)
        if path not in self._initial_files:
            self._new_files.add(path)
        self._windows[key] = rows
        return deepcopy(rows), ""
