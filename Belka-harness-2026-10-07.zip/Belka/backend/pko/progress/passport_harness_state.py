"""Atomic, source-bound resume points for the passport's Pydantic AI harness.

Only settled tool batches are resumable. The history and domain state are one
JSON transaction; the ordinary .passport.json remains a human audit artifact.
Source rehydration never grants citation access or replenishes a broker budget.
"""
from __future__ import annotations

from copy import copy, deepcopy
from dataclasses import fields, is_dataclass
import hashlib
import json
import os
from pathlib import Path
from time import monotonic
from typing import Any, Callable
from uuid import uuid4

from pydantic_ai.messages import ModelMessagesTypeAdapter, ThinkingPart
from pydantic_ai_harness.step_persistence import InMemoryStepStore, is_provider_valid

FORMAT = "belka-passport-harness"
VERSION = 1
MAX_CHECKPOINT_BYTES = 64 * 1024 * 1024
MAX_IDENTITY_FILES = 20_000
MAX_IDENTITY_CHARS = 128 * 1024 * 1024
MAX_SOURCE_SECONDS = 60.0
_RUNTIME = {"span", "reviewer", "on_node", "deadline", "checkpoint_path", "evidence_broker", "max_review_calls"}
_BROKER = ("_new_files", "_used_symbols", "_windows", "_completed_requests", "_request_calls",
           "_cache_hits", "_requests", "_chars", "_denied", "_audit", "_events_omitted")
_SNAPSHOT = ("deferred", "hashes", "failures", "chars", "refusals", "search_refusals")


class ResumeError(ValueError):
    """Invalid/incompatible local checkpoint; safe to show without source data."""


def _hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()


def _text_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()


def _classes() -> dict[str, type]:
    # Explicit constructors only: JSON cannot name/import an arbitrary class.
    from pko.progress.passport_agent import _Node
    from pko.progress.passport_connectivity import CodeScenario, ResearchConnectivityState
    from pko.progress.passport_context import _Memory
    from pko.progress.passport_evidence import EvidenceCorpus
    from pko.progress.passport_facts import Capability, RouteInfo, RouteUsage
    from pko.progress.passport_system_research import _SystemResearch
    from pko.progress.passport_workspace import ResearchWorkspace
    from pko.progress.schema import EvidenceRef, FlowTrace, Handoff, HandoffCheck, Scenario, SystemFlaw, SystemPurpose
    return {cls.__name__: cls for cls in (_Node, CodeScenario, ResearchConnectivityState, _Memory,
            EvidenceCorpus, Capability, RouteInfo, RouteUsage, _SystemResearch,
            ResearchWorkspace, EvidenceRef, FlowTrace, Handoff, HandoffCheck,
            Scenario, SystemFlaw, SystemPurpose)}


def _pack(value: Any) -> Any:
    if value is None or type(value) in (str, int, float, bool):
        return value
    if is_dataclass(value) and not isinstance(value, type):
        name = type(value).__name__
        if name not in _classes():
            raise ResumeError("Unsupported checkpoint data type")
        data = {f.name: getattr(value, f.name) for f in fields(value)
                if not (name == "ResearchConnectivityState" and f.name == "tree")}
        return {"type": name, "fields": _pack(data)}
    if isinstance(value, dict):
        return {"type": "dict", "items": [[_pack(k), _pack(v)] for k, v in value.items()]}
    if isinstance(value, (list, tuple, set)):
        items = [_pack(item) for item in value]
        if isinstance(value, set):
            items.sort(key=lambda item: json.dumps(item, sort_keys=True))
        return {"type": type(value).__name__, "items": items}
    raise ResumeError("Unsupported checkpoint data type")


def _unpack(value: Any) -> Any:
    if value is None or type(value) in (str, int, float, bool):
        return value
    if not isinstance(value, dict):
        raise ResumeError("Invalid checkpoint value")
    kind = value.get("type")
    if kind in ("dict", "list", "tuple", "set"):
        if set(value) != {"type", "items"} or not isinstance(value["items"], list):
            raise ResumeError("Invalid checkpoint collection")
        if kind == "dict":
            pairs = [(_unpack(k), _unpack(v)) for k, v in value["items"]]
            result = dict(pairs)
            if len(result) != len(pairs):
                raise ResumeError("Duplicate checkpoint key")
            return result
        return {"list": list, "tuple": tuple, "set": set}[kind](_unpack(v) for v in value["items"])
    cls = _classes().get(kind)
    if cls is None or set(value) != {"type", "fields"}:
        raise ResumeError("Unsupported checkpoint record")
    data = _unpack(value["fields"])
    expected = {f.name for f in fields(cls)}
    if kind == "ResearchConnectivityState":
        data["tree"] = None
    if set(data) != expected:
        raise ResumeError("Checkpoint record schema changed")
    return cls(**data)


def source_identity(broker: Any) -> dict:
    """Fingerprint the host-visible allowlisted snapshot, not the original ZIP.

    Git's immutable Tree needs no source reads. Local/overlay inputs are hashed
    through their trusted Tree; no texts enter the evidence corpus or model.
    Unreadable contents remain unavailable and are represented by a marker.
    """
    from pko.extractors.base import Tree
    from pko.progress.passport_source import available_source_path
    tree = broker._snapshot._tree
    paths = sorted(broker._files)
    if len(paths) > MAX_IDENTITY_FILES or any(not available_source_path(tree, p) for p in paths):
        raise ResumeError("Source identity exceeds safe snapshot scope")
    if type(tree) is Tree and tree.sha:
        return {"kind": "git", "sha": tree.sha, "paths": _hash(paths)}
    entries, chars, deadline = [], 0, monotonic() + MAX_SOURCE_SECONDS
    for path in paths:
        if monotonic() >= deadline:
            raise ResumeError("Source identity exceeded time limit")
        try:
            text = tree.read(path)
        except Exception:
            raise ResumeError("Cannot fingerprint source snapshot") from None
        if isinstance(text, str):
            chars += len(text)
            if chars > MAX_IDENTITY_CHARS:
                raise ResumeError("Source identity exceeds safe snapshot size")
            entries.append([path, _text_hash(text)])
        else:
            entries.append([path, None])
    if monotonic() >= deadline:
        raise ResumeError("Source identity exceeded time limit")
    return {"kind": "visible_text_snapshot", "sha256": _hash(entries), "files": len(paths)}


def build_identity(state: Any, configuration: dict) -> dict:
    if state.evidence_corpus is None or state.evidence_broker is None:
        raise ResumeError("Resume requires the evidence corpus and source broker")
    return {"source": source_identity(state.evidence_broker),
            "configuration": _hash(configuration),
            "seed": _hash(_pack({"corpus": state.evidence_corpus,
                "capabilities": state.capabilities, "exposures": state.exposures,
                "plan_bullets": state.plan_bullets, "bullet_status": state.bullet_status,
                "research_basis": state.research_basis, "research_enabled": state.research_enabled,
                "agentic": state.agentic, "limits": state.evidence_broker.limits}))}


def export_state(state: Any) -> dict:
    from pko.progress.passport_workspace import sync_objects
    sync_objects(state)
    broker = state.evidence_broker
    snapshot = broker._snapshot
    return {"session": _pack({f.name: getattr(state, f.name) for f in fields(state) if f.name not in _RUNTIME}),
            "context_memory": _pack(getattr(state, "_passport_context", None)),
            "broker": _pack({name: getattr(broker, name) for name in _BROKER}),
            "snapshot": _pack({**{name: getattr(snapshot, name) for name in _SNAPSHOT},
                               "cache": {path: text is not None for path, text in snapshot.cache.items()}})}


def restore_state(state: Any, data: dict) -> None:
    """Validate in a detached trial, then publish all restored references at once."""
    from pko.progress.agent_tools import ToolBox
    from pko.progress.passport_system_research import evidence_tree
    from pko.progress.passport_workspace import sync_objects
    session, saved_broker, saved_snapshot = (_unpack(data[k]) for k in ("session", "broker", "snapshot"))
    if set(session) != {f.name for f in fields(state) if f.name not in _RUNTIME}:
        raise ResumeError("Passport session schema changed")
    if set(saved_broker) != set(_BROKER) or set(saved_snapshot) != set(_SNAPSHOT) | {"cache"}:
        raise ResumeError("Broker checkpoint schema changed")
    trial = copy(state)
    for key, value in session.items():
        setattr(trial, key, value)
    corpus = trial.evidence_corpus
    if any(key not in corpus.records or not isinstance(windows, list)
           or any(not isinstance(text, str) or text not in corpus.records[key]["text"] for text in windows)
           for key, windows in corpus.shown.items()):
        raise ResumeError("Invalid shown-evidence checkpoint")
    memory = _unpack(data.get("context_memory"))
    if memory is not None:
        from pko.progress.passport_context import _Memory
        if not isinstance(memory, _Memory) or any(eid not in corpus.shown for eid in memory.evidence):
            raise ResumeError("Invalid context-evidence checkpoint")
        if any(not any(quote in text for text in corpus.shown.get(eid, [])) for eid, quote in memory.quotes):
            raise ResumeError("Invalid context-quotation checkpoint")
        trial._passport_context = memory
    broker, snapshot = copy(state.evidence_broker), copy(state.evidence_broker._snapshot)
    broker.corpus, broker._snapshot = corpus, snapshot
    cached, deadline = {}, monotonic() + MAX_SOURCE_SECONDS
    for path, present in saved_snapshot.pop("cache").items():
        if monotonic() >= deadline:
            raise ResumeError("Cached-source restoration exceeded time limit")
        if path not in broker._file_set:
            raise ResumeError("Cached source is outside the snapshot")
        if present:
            try:
                text = snapshot._tree.read(path)
            except Exception:
                raise ResumeError("Cannot restore cached source") from None
            if not isinstance(text, str) or _text_hash(text) != saved_snapshot["hashes"].get(path):
                raise ResumeError("Cached source changed")
            cached[path] = text
        else:
            cached[path] = None
    if monotonic() >= deadline:
        raise ResumeError("Cached-source restoration exceeded time limit")
    if set(saved_snapshot["hashes"]) != {p for p, t in cached.items() if t is not None}:
        raise ResumeError("Incomplete cached-source hashes")
    if sum(len(t) for t in cached.values() if t is not None) != saved_snapshot["chars"]:
        raise ResumeError("Invalid source-budget checkpoint")
    for name, value in saved_snapshot.items():
        setattr(snapshot, name, value)
    snapshot.cache = cached
    for name, value in saved_broker.items():
        setattr(broker, name, value)
    broker._toolbox = ToolBox(snapshot, state.evidence_broker._toolbox._extraction)
    trial.evidence_broker = broker
    if trial.connectivity_state is not None:
        trial.connectivity_state.tree = evidence_tree(corpus)
    previous = deepcopy(trial.workspace.objects)
    sync_objects(trial)
    if trial.workspace.objects != previous:
        raise ResumeError("Checkpoint object revisions do not match domain state")
    # A stopped turn can continue; previously accepted finish cannot be resumed.
    if trial.finished:
        raise ResumeError("Passport research already finished")
    trial.stop_reason = ""
    for key in session:
        setattr(state, key, getattr(trial, key))
    state.evidence_broker = broker
    if memory is not None:
        state._passport_context = memory


class PassportStepStore(InMemoryStepStore):
    """StepPersistence backend with an atomic history + domain checkpoint."""
    def __init__(self, state: Any, path: Path | str | None, identity: dict):
        super().__init__(max_snapshots_per_run=2)
        self.state, self.path, self.identity = state, Path(path) if path is not None else None, identity
        self.sequence = 0
        self._accepted: set[tuple[str, str]] = set()
        self._high_water: dict[str, int] = {}
        # Runtime callback: settle elapsed budget immediately before the atomic
        # save, including failures before after_node_run can update its clock.
        self.before_save: Callable[[], None] | None = None

    @staticmethod
    def _check_messages(messages: list) -> None:
        # The passport adapter keeps provider reasoning in memory only. Do not
        # silently strip protocol-required content and pretend it is resumable.
        for message in messages:
            if any(isinstance(part, ThinkingPart) for part in message.parts):
                raise ResumeError("Private provider reasoning cannot be checkpointed")
            if getattr(message, "provider_details", None):
                raise ResumeError("Private provider metadata cannot be checkpointed")

    async def save_snapshot(self, snapshot: Any) -> None:
        key = snapshot.idempotency_key
        identity = (snapshot.run_id, key) if key is not None else None
        try:
            order = int(key.partition(":")[0]) if key is not None else None
        except ValueError:
            order = None
        if identity in self._accepted or order is not None and order < self._high_water.get(snapshot.run_id, -1):
            return
        if snapshot.state != "complete" or not is_provider_valid(snapshot.messages):
            # Domain changes from an interrupted batch are not paired with the
            # previous settled history. Keep the previous atomic file intact.
            await super().save_snapshot(snapshot)
            return
        self._check_messages(snapshot.messages)
        if self.before_save is not None:
            self.before_save()
        messages = ModelMessagesTypeAdapter.dump_python(snapshot.messages, mode="json")
        payload = {"format": FORMAT, "version": VERSION, "identity": self.identity,
                   "sequence": self.sequence + 1, "run_id": snapshot.run_id,
                   "step_index": snapshot.step_index, "idempotency_key": key,
                   "messages": messages, "domain": export_state(self.state)}
        envelope = {**payload, "sha256": _hash(payload)}
        if self.path is not None:
            self._write(envelope)
        self.sequence += 1
        if identity is not None:
            self._accepted.add(identity)
        if order is not None:
            self._high_water[snapshot.run_id] = order
        await super().save_snapshot(snapshot)

    def _write(self, envelope: dict) -> None:
        from pko.util.paths import harden_file
        content = json.dumps(envelope, ensure_ascii=False, allow_nan=False)
        if len(content.encode("utf-8")) > MAX_CHECKPOINT_BYTES:
            raise ResumeError("Passport checkpoint exceeds safe size")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_name(self.path.name + "." + uuid4().hex + ".tmp")
        try:
            with temp.open("w", encoding="utf-8", newline="\n") as stream:
                harden_file(temp)
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp, self.path)
            harden_file(self.path)
        finally:
            temp.unlink(missing_ok=True)

    def restore(self, path: Path | str) -> list:
        try:
            if self.sequence or self._runs:
                raise ResumeError("Resume requires a fresh harness store")
            source = Path(path)
            if source.stat().st_size > MAX_CHECKPOINT_BYTES:
                raise ResumeError("Passport checkpoint exceeds safe size")
            data = json.loads(source.read_text(encoding="utf-8"))
            checksum = data.pop("sha256", None)
            if checksum != _hash(data) or data.get("format") != FORMAT or data.get("version") != VERSION:
                raise ResumeError("Invalid passport checkpoint version or checksum")
            if data.get("identity") != self.identity:
                raise ResumeError("Passport checkpoint belongs to different sources or settings")
            if type(data.get("sequence")) is not int or data["sequence"] < 1:
                raise ResumeError("Invalid passport checkpoint sequence")
            messages = ModelMessagesTypeAdapter.validate_python(data["messages"])
            if not is_provider_valid(messages):
                raise ResumeError("Passport checkpoint contains unsettled tool calls")
            self._check_messages(messages)
            restore_state(self.state, data["domain"])
            self.sequence = data["sequence"]
            key = data.get("idempotency_key")
            if key is not None:
                self._accepted.add((data["run_id"], key))
                try:
                    self._high_water[data["run_id"]] = int(key.partition(":")[0])
                except ValueError:
                    pass
            return messages
        except ResumeError:
            raise
        except Exception:
            raise ResumeError("Cannot read compatible passport checkpoint") from None


def prepare_store(state: Any, path: Path | str | None, *, configuration: dict,
                  resume_path: Path | str | None = None) -> tuple[PassportStepStore, list]:
    """Call on a freshly prepared session, before any model/tool action.

    Configuration must bind model and prompt/tool contracts. Broker limits are
    included automatically; runtime limits can increase while spent use remains.
    Only the configuration digest is persisted. Resume uses a new run identifier.
    Runtime callback/reviewer/deadline handles are supplied afresh by the caller.
    """
    store = PassportStepStore(state, path, build_identity(state, configuration))
    return store, store.restore(resume_path) if resume_path is not None else []
