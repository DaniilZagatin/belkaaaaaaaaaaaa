"""Pydantic AI owns the passport loop; Belka owns evidence and acceptance.

No observer model, second plan, shell, web, or filesystem tool is installed.
Capabilities operate on the same versioned ResearchWorkspace as the tools.
"""
from __future__ import annotations

import asyncio
import json
import time
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator
import pydantic_ai
from pydantic_ai import Agent, ModelRetry, RunContext, Tool, ToolOutput
from pydantic_ai.capabilities import AbstractCapability, ProcessHistory
from pydantic_ai.messages import ToolCallPart
from pydantic_ai.usage import UsageLimits
from pydantic_ai_harness.planning import Planning, PlanItem, TaskStatus
from pydantic_ai_harness.step_persistence import StepPersistence, InMemoryStepStore
from pydantic_ai_harness.system_reminders import SystemReminders

from pko.errors import LlmError
from pko.progress.passport_harness_model import PassportChatModel, from_chat_messages, to_chat_messages
from pko.progress.passport_harness_state import ResumeError, prepare_store
from pko.progress.passport_workspace import digest

HARNESS_VERSION = "0.54.0"
RUNTIME_VERSION = "2.1"
pydantic_ai.BANNER_ENABLED = False  # Belka owns its CLI output.


class PassportHalt(Exception):
    def __init__(self, reason: str, note: str):
        self.reason, self.note = reason, note
        super().__init__(note)


class WorkspacePlanStore:
    """Read-only projection; update_research_plan is the sole plan mutator."""
    def __init__(self, state: Any):
        self.state = state

    async def get_items(self):
        statuses = {"open": TaskStatus.pending, "doing": TaskStatus.in_progress, "done": TaskStatus.completed}
        return [PlanItem(id=row["id"], content=row["task"], status=statuses[row["state"]])
                for row in self.state.workspace.plan]

    async def get_item(self, item_id):
        return next((item for item in await self.get_items() if item.id == item_id), None)

    async def set_items(self, items):
        raise RuntimeError("Use update_research_plan")

    async def add_item(self, item):
        raise RuntimeError("Use update_research_plan")

    async def update_item(self, item_id, **kwargs):
        raise RuntimeError("Use update_research_plan")

    async def remove_item(self, item_id):
        raise RuntimeError("Use update_research_plan")


class ResearchControl(AbstractCapability):
    """Deterministic budgets and existing feedback, without another LLM."""
    def __init__(self, state, max_steps):
        self.state, self.max_steps = state, max(1, max_steps)
        self.notice = None
        self.started = time.monotonic()
        self.previous_elapsed = state.harness_elapsed_seconds
        self.pending_halt = None

    def update_elapsed(self):
        self.state.harness_elapsed_seconds = self.previous_elapsed + time.monotonic() - self.started

    async def wrap_model_request(self, ctx, *, request_context, handler):
        from pko.progress.passport_agent import (
            MAX_PASSPORT_TOOL_CALLS, IDLE_STEPS_NUDGE, IDLE_STEPS_STOP, _progress_mark, _idle_nudge,
        )
        from pko.progress.passport_focus import before_research_step
        state = self.state
        self.update_elapsed()
        if self.pending_halt:
            raise self.pending_halt
        if state.deadline and time.monotonic() >= state.deadline:
            raise PassportHalt("timeout", "паспорт: время сессии исчерпано")
        if state.harness_steps >= self.max_steps:
            raise PassportHalt("steps", f"паспорт: бюджет шагов исчерпан ({self.max_steps})")
        if state.tool_calls >= MAX_PASSPORT_TOOL_CALLS:
            raise PassportHalt("tools", f"паспорт: бюджет вызовов инструментов исчерпан ({MAX_PASSPORT_TOOL_CALLS})")
        memory = state.harness_control
        mark = digest(_progress_mark(state))
        if mark != memory.get("mark"):
            memory.update(mark=mark, idle=0, recent=[])
        else:
            memory["idle"] = memory.get("idle", 0) + 1
        if memory["idle"] >= IDLE_STEPS_STOP:
            raise PassportHalt("idle", f"паспорт: остановлено — нет изменений исследования {memory['idle']} шагов подряд")
        state.harness_steps += 1
        self.notice = before_research_step(state, state.harness_steps, self.max_steps,
                                          max_tool_calls=MAX_PASSPORT_TOOL_CALLS)
        if memory["idle"] == IDLE_STEPS_NUDGE:
            self.notice = "\n\n".join(filter(None, (self.notice, _idle_nudge(state, memory["idle"]))))
        return await handler(request_context)

    async def after_model_request(self, ctx, *, request_context, response):
        from pko.progress.loop_guard import repeating_cycle, cycle_text
        from pko.progress.passport_agent import _MAX_MALFORMED
        calls = [part for part in response.parts if isinstance(part, ToolCallPart)]
        memory = self.state.harness_control
        memory["malformed"] = 0 if calls else memory.get("malformed", 0) + 1
        if memory["malformed"] >= _MAX_MALFORMED:
            self.pending_halt = PassportHalt("malformed", "паспорт: агент повторно не вызвал инструмент — остановлено")
        if calls:
            signature = digest([(p.tool_name, p.args) for p in calls])
            recent = memory.setdefault("recent", [])
            recent.append(signature)
            del recent[:-24]
            period = repeating_cycle(recent)
            if period:
                self.pending_halt = PassportHalt("cycle", f"паспорт: остановлено — {cycle_text(period)}")
        return response

    async def after_node_run(self, ctx, *, node, result):
        self.update_elapsed()
        return result


class DurableHistory(AbstractCapability):
    """Compact before ephemeral plan/reminder wrappers, never persist their tail.

    In AI 2.54 before_model_request runs inside wrap_model_request. Calling the
    standard history processor here avoids saving injected reminders to history.
    """
    def __init__(self, processor):
        self.processor = ProcessHistory(processor)

    async def wrap_model_request(self, ctx, *, request_context, handler):
        request_context = await self.processor.before_model_request(ctx, request_context)
        return await handler(request_context)


def _tool(schema, state, control):
    from pko.progress.passport_agent import _answer_call
    from pko.llm.tracing import trace_tool_call
    function = schema["function"]
    name = function["name"]
    validator = Draft202012Validator(function["parameters"])

    async def invoke(ctx: RunContext[Any], **arguments):
        from pko.audit import record
        from pko.progress.passport_agent import MAX_PASSPORT_TOOL_CALLS
        call = {"id": ctx.tool_call_id, "type": "function", "function": {
            "name": name, "arguments": json.dumps(arguments, ensure_ascii=False)}}

        def checked(session, invocation):
            if (session.finished or session.tool_calls >= MAX_PASSPORT_TOOL_CALLS
                    or session.deadline and time.monotonic() >= session.deadline):
                return _answer_call(session, invocation)
            error = next(validator.iter_errors(arguments), None)
            if control.pending_halt:
                content = json.dumps({"ok": False, "error": control.pending_halt.note}, ensure_ascii=False)
            elif error is not None:
                # Return schema expectations, not potentially sensitive values.
                session.tool_calls += 1
                issues = []
                for issue in (error.context or [error])[:8]:
                    row = {"field": ".".join(map(str, issue.absolute_path)), "rule": issue.validator}
                    if issue.validator == "required" and isinstance(issue.instance, dict):
                        row["missing"] = [key for key in issue.validator_value if key not in issue.instance]
                    elif issue.validator in ("type", "enum"):
                        row["expected"] = issue.validator_value
                    issues.append(row)
                content = json.dumps({"ok": False, "error": "Аргументы не соответствуют схеме инструмента",
                                      "issues": issues}, ensure_ascii=False)
                # A malformed argument is not a factual finding. Keep its
                # sanitized proposal in the ledger without accepting a claim.
                session.workspace.event("tool_arguments_rejected", tool=name,
                                        proposal=arguments, issues=issues)
            else:
                return _answer_call(session, invocation)
            record("passport_tool_result", call_id=ctx.tool_call_id, name=name, content=content)
            return {"role": "tool", "tool_call_id": ctx.tool_call_id, "content": content}

        return trace_tool_call(checked, state, call)["content"]

    return Tool.from_schema(invoke, name=name, description=function.get("description", ""),
                            json_schema=function["parameters"], takes_ctx=True, sequential=True)


def run_harness_session(state, *, client, spec, schemas, system_prompt, user_brief,
                        max_steps, max_tokens, budget_seconds, resume_path=None):
    """One Agent run: model-directed tools, structured finish, settled checkpoints."""
    from pko.progress.passport_agent import _answer_call
    from pko.progress.passport_context import compact_context
    from pko.progress.passport_reviewer import _review_client
    from pko.llm.tracing import trace_tool_call, trace_span

    control = None
    try:
        configuration = {"runtime": RUNTIME_VERSION, "harness": HARNESS_VERSION,
                         "model": spec.model, "endpoint": spec.base_url,
                         "extra_body": spec.extra_body, "max_tokens": max_tokens,
                         "prompt": digest(system_prompt), "tools": digest(schemas)}
        path = (state.checkpoint_path.with_suffix(".harness.json") if state.checkpoint_path else None)
        if resume_path is not None and path is None:
            path = Path(resume_path)
        history = []
        if state.evidence_broker is not None:
            try:
                store, history = prepare_store(state, path, configuration=configuration, resume_path=resume_path)
            except ResumeError:
                if resume_path is not None:
                    raise
                state.notes.append("паспорт: снимок для возобновления недоступен; частичный паспорт сохраняется")
                store = InMemoryStepStore(max_snapshots_per_run=2)
        else:
            if resume_path is not None:
                raise ResumeError("Для возобновления нужен снимок EvidenceBroker")
            store = InMemoryStepStore(max_snapshots_per_run=2)

        if history:
            # Explicit continuation grants another attempt, not a new budget or
            # new proof. Do not immediately re-trigger the previous idle halt.
            state.harness_control = {}

        state.deadline = (time.monotonic() + max(0, budget_seconds - state.harness_elapsed_seconds)
                          if budget_seconds else 0.0)
        control = ResearchControl(state, max_steps)
        if hasattr(store, "before_save"):
            store.before_save = control.update_elapsed
        bounded_client = _review_client(client, spec, state.deadline) if state.deadline else client
        model = PassportChatModel(client=bounded_client, spec=spec, max_tokens=max_tokens, deadline=state.deadline)

        async def compact(messages):
            public = to_chat_messages(messages)
            compact_context(public, state)
            return from_chat_messages(public)

        async def reminder(ctx):
            return control.notice

        async def finish(ctx: RunContext[Any]) -> str:
            if control.pending_halt:
                raise ModelRetry(control.pending_halt.note)
            call = {"id": ctx.tool_call_id, "type": "function", "function": {"name": "finish", "arguments": "{}"}}
            reply = trace_tool_call(_answer_call, state, call)["content"]
            if not state.finished:
                raise ModelRetry(reply)
            return reply

        finish_schema = next(s["function"] for s in schemas if s["function"]["name"] == "finish")
        agent = Agent(model, deps_type=Any, system_prompt=system_prompt,
                      output_type=ToolOutput(finish, name="finish", description=finish_schema.get("description"),
                                             sequential=True, max_retries=max(1, max_steps)),
                      tools=[_tool(s, state, control) for s in schemas if s["function"]["name"] != "finish"],
                      retries=max(1, max_steps), end_strategy="graceful",
                      capabilities=[control, DurableHistory(compact),
                                    Planning(guidance="", tools=[], store=WorkspacePlanStore(state)),
                                    SystemReminders(dynamic_reminders=[reminder]),
                                    StepPersistence(store=store, capture_frontier=False)])
        async def traced_run():
            # Drive the official graph unchanged. The scope only groups its
            # request and tool nodes into Belka's established trace step.
            async with agent.iter(None if history else user_brief, deps=state,
                                  message_history=history or None,
                                  usage_limits=UsageLimits(
                                      request_limit=max(1, max_steps - state.harness_steps) + 1,
                                      tool_calls_limit=None)) as run:
                node = run.next_node
                while not Agent.is_end_node(node):
                    if Agent.is_model_request_node(node):
                        with trace_span("passport.step", step=state.harness_steps + 1):
                            node = await run.next(node)
                            if Agent.is_call_tools_node(node):
                                node = await run.next(node)
                    else:
                        node = await run.next(node)
            return run.result

        asyncio.run(traced_run())
    except PassportHalt as exc:
        state.stop_reason = exc.reason
        state.notes.append(exc.note)
    except ResumeError as exc:
        state.stop_reason = "error"
        state.notes.append("паспорт: не удалось продолжить сохранённое исследование: " + str(exc))
    except TimeoutError:
        state.stop_reason = "timeout"
        state.notes.append("паспорт: время сессии исчерпано; запоздалый ответ модели не принимается")
    except LlmError as exc:
        state.stop_reason = "error"
        state.notes.append(f"паспорт: агент недоступен: {exc.message} {exc.hint}".strip())
    except Exception as exc:
        state.stop_reason = "error"
        state.notes.append("паспорт: цикл Pydantic AI прерван — " + type(exc).__name__)
    finally:
        if control is not None:
            control.update_elapsed()
    return state.harness_steps
