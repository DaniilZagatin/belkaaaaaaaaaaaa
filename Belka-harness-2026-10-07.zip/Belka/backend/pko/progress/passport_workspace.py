"""Versioned working state for the passport agent, independent of its conversation.

The model chooses actions. This module preserves observations, rejected proposals,
and review receipts; it does not assign readiness or GO/PIVOT.
"""
from __future__ import annotations

import hashlib
import json
import os
from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


def digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     default=str).encode("utf-8")).hexdigest()


@dataclass
class ResearchWorkspace:
    plan: list[dict] = field(default_factory=list)
    objects: dict[str, dict] = field(default_factory=dict)
    history: list[dict] = field(default_factory=list)
    findings: dict[str, dict] = field(default_factory=dict)
    reviews: dict[str, dict] = field(default_factory=dict)
    risk_candidates: dict[str, dict] = field(default_factory=dict)
    scope: dict[str, dict] = field(default_factory=dict)
    exclusions: dict[str, dict] = field(default_factory=dict)
    claims: dict[str, dict] = field(default_factory=dict)
    retirements: dict[str, dict] = field(default_factory=dict)
    review_links: dict[str, list[str]] = field(default_factory=dict)
    review_calls: int = 0
    source_digest: str = ""

    def event(self, action: str, **data: Any) -> None:
        from pko.audit import record, sanitize
        entry = sanitize({"sequence": len(self.history) + 1, "action": action, **deepcopy(data)})
        self.history.append(entry)
        record("passport_research", **entry)

    def put(self, oid: str, kind: str, content: dict) -> None:
        revision = digest(content)
        previous = self.objects.get(oid)
        if previous and previous["revision"] == revision:
            return
        self.event("object_updated", object_id=oid, previous=previous,
                   revision=revision, content=content)
        self.objects[oid] = {"id": oid, "kind": kind, "revision": revision,
                             "content": deepcopy(content)}
        # A review belongs to the exact content, never to a reusable object name.
        self.reviews.pop(oid, None)

    def reject(self, key: str, proposal: dict, reason: str) -> str:
        # A new failed review does not establish that older counterexamples were
        # resolved. Keep every distinct conclusion until a supported review of
        # the current object (or its retirement) explicitly considers them all.
        # Repeating the same conclusion after corpus expansion stays idempotent.
        independent = proposal.get("tool") == "independent_review"
        conclusion = {k: v for k, v in proposal.items() if k != "corpus_revision"}
        existing = next((f for f in self.findings.values() if f["key"] == key and (
            not independent or f.get("reason") == reason and
            {k: v for k, v in f.get("proposal", {}).items() if k != "corpus_revision"} == conclusion)), None)
        fid = existing["id"] if existing else f"finding-{len(self.findings) + 1}"
        row = {"id": fid, "key": key, "state": "open", "proposal": deepcopy(proposal),
               "reason": reason}
        if existing != row:
            self.event("proposal_rejected", finding=row, previous=existing)
            self.findings[fid] = row
        return fid

    def accepted(self, key: str, *, finding_ids: set[str] | None = None) -> None:
        for row in self.findings.values():
            if (row["key"] == key and row["state"] in ("open", "open_question")
                    and (finding_ids is None or row["id"] in finding_ids)):
                row["state"] = "corrected"
                self.event("proposal_corrected", finding_id=row["id"], key=key)

    def link_review_obligations(self, first: str, second: str) -> None:
        """Alternative decisions about one fact inherit each other's objections."""
        for source, target in ((first, second), (second, first)):
            linked = self.review_links.setdefault(source, [])
            if target not in linked:
                linked.append(target)
                self.event("review_obligation_linked", object_id=source, related_object_id=target)

    def review_keys(self, oid: str) -> set[str]:
        pending, seen = [oid], set()
        while pending:
            current = pending.pop()
            if current in seen:
                continue
            seen.add(current)
            pending.extend(self.review_links.get(current, []))
        return {"review:" + current for current in seen}

    def candidate(self, item: dict) -> str:
        key = str(item.get("primary_node", "")) + "|" + str(item.get("title", "")).strip().casefold()
        old = next((r for r in self.risk_candidates.values() if r["key"] == key), None)
        rid = old["id"] if old else f"candidate-{len(self.risk_candidates) + 1}"
        row = {"id": rid, "key": key, "state": "proposed", "proposal": deepcopy(item)}
        if old and old.get("proposal") == item:
            return rid
        self.risk_candidates[rid] = row
        self.event("risk_proposed", candidate=row, previous=old)
        return rid

    def unresolved(self) -> list[str]:
        return [f["id"] for f in self.findings.values() if f["state"] in ("open", "open_question")] + [
            r["id"] for r in self.risk_candidates.values() if r["state"] in ("proposed", "open_question")]

    def pending_reviews(self) -> list[str]:
        return [oid for oid, obj in self.objects.items()
                if self.reviews.get(oid, {}).get("revision") != obj["revision"]
                or self.reviews.get(oid, {}).get("result") != "supported"]

    def export(self) -> dict:
        return deepcopy({"version": 1, "source_digest": self.source_digest,
                         "plan": self.plan, "objects": self.objects, "history": self.history,
                         "findings": self.findings, "reviews": self.reviews,
                         "risk_candidates": self.risk_candidates, "scope": self.scope,
                         "exclusions": self.exclusions, "claims": self.claims,
                         "retirements": self.retirements,
                         "review_links": self.review_links,
                         "review_calls": self.review_calls})

    def checkpoint(self, path: Path | None, *, draft: dict | None = None) -> None:
        if path is None:
            return
        from pko.audit import sanitize
        from pko.util.paths import harden_file
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_suffix(path.suffix + ".tmp")
        # No messages or provider reasoning are serialized.
        with temp.open("w", encoding="utf-8", newline="\n") as stream:
            harden_file(temp)
            json.dump(sanitize({"research": self.export(), "draft": draft}), stream,
                      ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        temp.replace(path)
        harden_file(path)


def sync_objects(state: Any) -> None:
    """Invalidate affected receipts when content or a linked neighbour changes."""
    ws = state.workspace
    live: set[str] = set()
    research_versions: dict[str, str] = {}
    if getattr(state, "research_enabled", False):
        from pko.progress.passport_connectivity import sync_connectivity_objects
        live.update(sync_connectivity_objects(state))
        research_versions = {oid: ws.objects[oid]["revision"] for oid in sorted(live)}

    def scenario_dependencies(node):
        ids = set(node.data.get("scenarios", []))
        if node.data.get("scenario"):
            ids.add(node.data["scenario"])
        ids.update(row.get("scenario") for row in node.data.get("scenario_steps", []))
        return {key: version for key, version in research_versions.items()
                if key.partition(":")[2] in ids}

    node_hashes = {nid: digest({"data": n.data, "parents": n.parents, "children": n.children})
                   for nid, n in state.nodes.items()}
    if research_versions:
        node_hashes = {nid: digest({"node": value, "scenarios": scenario_dependencies(state.nodes[nid])})
                       for nid, value in node_hashes.items()}
    base_hashes = dict(node_hashes)
    for nid, node in state.nodes.items():
        ancestors, frontier = set(), list(node.parents)
        while frontier:
            parent = frontier.pop()
            if parent in ancestors or parent not in state.nodes:
                continue
            ancestors.add(parent)
            frontier.extend(state.nodes[parent].parents)
        descendants, frontier = set(), list(node.children)
        while frontier:
            child = frontier.pop()
            if child in descendants or child not in state.nodes:
                continue
            descendants.add(child)
            frontier.extend(state.nodes[child].children)
        node_hashes[nid] = digest({"self": base_hashes[nid],
                                  "ancestors": {a: base_hashes[a] for a in sorted(ancestors)},
                                  "descendants": {d: base_hashes[d] for d in sorted(descendants)}})
    for nid, node in state.nodes.items():
        if not node.filled:
            continue
        live.add(nid)
        neighbours = list(dict.fromkeys(node.parents + node.children))
        content = {**node.data, "parents": node.parents, "children": node.children,
                   "lineage_revision": node_hashes[nid],
                   "neighbours": [{"id": x, "name": state.nodes[x].name,
                                    "revision": base_hashes[x]} for x in neighbours if x in state.nodes]}
        if research_versions:
            content["scenario_revisions"] = scenario_dependencies(node)
            scenario_ids = set(node.data.get("scenarios", []))
            scenario_ids.update(row.get("scenario") for row in node.data.get("scenario_steps", []))
            seen, frontier = set(), list(node.parents)
            while frontier:
                parent = frontier.pop()
                if parent in seen or parent not in state.nodes:
                    continue
                seen.add(parent)
                scenario_ids.update(state.nodes[parent].data.get("scenarios", []))
                frontier.extend(state.nodes[parent].parents)
            content["scenario_context"] = {sid: {"title": state.scenario_titles.get(sid, ""),
                **state.scenario_context.get(sid, {}), "steps": state.scenarios[sid]}
                for sid in sorted(scenario_ids) if sid in state.scenarios}
        ws.put(nid, "intent" if node.planned and state.research_basis != "code" else "node", content)
    for relation in state.relations:
        oid = "relation:" + ":".join(str(relation[k]) for k in ("from", "to", "kind"))
        live.add(oid)
        ws.put(oid, "relation", {**relation, "endpoints": {
            x: {"name": state.nodes[x].name, "revision": node_hashes[x]}
            for x in (relation["from"], relation["to"]) if x in state.nodes}})
    for risk in state.risks:
        oid = "risk:" + digest([risk.get("primary_node"), risk.get("title")])[:16]
        candidate_key = str(risk.get("primary_node", "")) + "|" + str(risk.get("title", "")).strip().casefold()
        candidate = ws.risk_candidates.get(str(risk.get("id", "")).replace("risk-", "candidate-", 1))
        if candidate is None:
            candidate = next((r for r in ws.risk_candidates.values() if r["key"] == candidate_key), None)
        if candidate:
            ws.link_review_obligations(oid, "resolution:" + candidate["id"])
        live.add(oid)
        ws.put(oid, "risk", {**risk, "linked_revisions": {
            n: node_hashes[n] for n in risk.get("linked_nodes", []) if n in node_hashes},
            "controls": state.guardrails})
    for cid, claim in ws.claims.items():
        live.add(cid)
        kind = claim.get("kind") if claim.get("kind") in ("intent", "observed_outcome") else "claim"
        ws.put(cid, kind, {**claim, "linked_revisions": {
            n: node_hashes[n] for n in claim.get("nodes", []) if n in node_hashes}})
    for kind, rows in (("defect", state.defects), ("guardrail", state.guardrails)):
        for row in rows:
            oid = kind + ":" + str(row.get("id", digest(row)[:12]))
            live.add(oid)
            ws.put(oid, "claim", {**row, "linked_revisions": {
                n: node_hashes[n] for n in row.get("nodes", row.get("targets", [])) if n in node_hashes}})
    for cid, nodes in state.capability_bound.items():
        oid = "binding:" + cid
        ws.link_review_obligations(oid, "dismissal:" + cid)
        live.add(oid)
        cap = next((c for c in state.capabilities if c.id == cid), None)
        ws.put(oid, "claim", {"capability": cap.describe() if cap else cid,
                             "nodes": {n: {"name": state.nodes[n].name, "revision": node_hashes[n]}
                                       for n in nodes if n in state.nodes}})
    for target, decision in {**ws.scope, **ws.exclusions}.items():
        if decision["disposition"] == "unknown":
            continue
        oid = "scope:" + target
        live.add(oid)
        content = decision
        if target.startswith("step:") and getattr(state, "research_enabled", False):
            sid = target.split(":")[1]
            scenario_object = ws.objects.get("scenario:" + sid)
            content = {**decision, "scenario_revision": scenario_object["revision"] if scenario_object else None,
                       "scenario": scenario_object["content"] if scenario_object else None}
        kind = "source_scope" if decision.get("source_scope") else (
            "intent" if decision["disposition"] == "excluded" and state.research_basis != "code" else "claim")
        ws.put(oid, kind, content)
    for rid, candidate in ws.risk_candidates.items():
        proposal = candidate["proposal"]
        ws.link_review_obligations("resolution:" + rid,
            "risk:" + digest([proposal.get("primary_node"), proposal.get("title")])[:16])
        if candidate["state"] not in ("withdrawn", "refuted"):
            continue
        oid = "resolution:" + rid
        live.add(oid)
        ws.put(oid, "claim", candidate)
    substantive = {"link_nodes", "submit_node", "submit_claim", "submit_defect",
                   "submit_guardrail", "submit_status_dispute", "submit_scenarios", "submit_trace",
                    "submit_system", "submit_flow", "submit_flaw", "submit_integrity",
                    "submit_connection_review"}
    for fid, finding in ws.findings.items():
        if finding["state"] not in ("withdrawn", "refuted") or finding.get("proposal", {}).get("tool") not in substantive:
            continue
        oid = "resolution:" + fid
        live.add(oid)
        ws.put(oid, "claim", finding)
    for rid, decision in ws.retirements.items():
        live.add(rid)
        ws.put(rid, "intent" if decision.get("kind") == "intent" else "claim", decision)
    for cid, dismissal in state.capability_dismissed.items():
        oid = "dismissal:" + cid
        live.add(oid)
        cap = next((c for c in state.capabilities if c.id == cid), None)
        ws.put(oid, "intent" if dismissal.get("reason") == "out_of_scope" and state.research_basis != "code" else "claim",
               {**dismissal, "capability": cap.describe() if cap else cid})
    if state.research_basis == "code":
        from pko.progress.passport_connections import sync_connection_objects
        live.update(sync_connection_objects(state))
    if state.risk_reviewed:
        live.add("risk-analysis")
        system_findings = {}
        if getattr(state, "research_enabled", False):
            research = getattr(state, "system_research_state", None)
            system_findings = {oid: {"revision": digest(record), "conclusion": record.get("value")}
                               for oid, record in getattr(research, "records", {}).items()
                               if oid != "system:integrity"}
        ws.put("risk-analysis", "claim", {"analysis": state.risk_analysis, "review": state.risk_review,
               **({"connection_reviews": {oid: ws.objects[oid]["revision"] for oid in sorted(live)
                                          if oid.startswith("connection-review:")}} if state.research_basis == "code" else {}),
               "risk_versions": {oid: ws.objects[oid]["revision"] for oid in sorted(live) if oid.startswith("risk:")},
               "nodes": node_hashes, **({"scenario_revisions": research_versions} if research_versions else {}),
               **({"system_findings": system_findings} if system_findings else {})})
    if getattr(state, "research_enabled", False):
        from pko.progress.passport_system_research import sync_system_research_objects
        live.update(sync_system_research_objects(state))
    for oid in list(ws.objects):
        if oid not in live:
            ws.event("object_retired", object=ws.objects.pop(oid))
            ws.reviews.pop(oid, None)


def tool_schema(name: str, description: str, properties: dict, required: list[str] = ()) -> dict:
    return {"type": "function", "function": {"name": name, "description": description,
            "parameters": {"type": "object", "properties": properties, "required": list(required)}}}


TEXT = {"type": "string"}
IDS = {"type": "array", "items": TEXT}
REFS = {"type": "array", "items": {"type": "object", "properties": {
    "id": TEXT, "quote": TEXT}, "required": ["id", "quote"]}}

WORKSPACE_SCHEMAS = [
    tool_schema("research_state", "Прочитать план, открытые вопросы и версии объектов; порядок действий выбираешь сам.",
                {"section": {"type": "string", "enum": ["summary", "nodes", "plan", "findings", "candidates", "reviews", "scope", "object", "capabilities", "risk_catalog", "risk_context", "scenarios", "connectivity", "system"]},
                 "id": TEXT, "offset": {"type": "integer"}}),
    tool_schema("update_research_plan", "Сохранить или изменить рабочий план исследования. План не заменяет факты.",
                {"tasks": {"type": "array", "maxItems": 30, "items": {"type": "object", "properties": {
                    "id": TEXT, "task": TEXT, "state": {"type": "string", "enum": ["open", "doing", "done"]}},
                    "required": ["id", "task", "state"]}}}, ["tasks"]),
    tool_schema("review_passport", "Независимый агент исследует версии объектов, ищет исключения и контрпримеры. После изменения нужна новая проверка.",
                {"ids": {"type": "array", "items": TEXT, "minItems": 1, "maxItems": 8}}, ["ids"]),
    tool_schema("resolve_finding", "Явно закрыть отвергнутое предложение/кандидата: отозвано, опровергнуто либо осталось открытым вопросом. История сохраняется.",
                {"id": TEXT, "resolution": {"type": "string", "enum": ["withdrawn", "refuted", "open_question"]},
                 "reason": TEXT, "evidence": REFS}, ["id", "resolution", "reason", "evidence"]),
    tool_schema("record_scope", "Учесть компонент источников или явную границу целевого сценария/пункта ОР. Не объявлять отсутствие реализации по пустому поиску.",
                {"target": TEXT, "disposition": {"type": "string", "enum": ["reviewed", "excluded", "unknown"]},
                 "reason": TEXT, "evidence": REFS}, ["target", "disposition", "reason", "evidence"]),
    tool_schema("submit_claim", "Зафиксировать проверяемое утверждение отдельно от карточки: условие, эффект, границы и источники. Повтор с id меняет версию.",
                {"id": TEXT, "kind": {"type": "string", "enum": ["intent", "implementation", "reachability", "condition", "effect", "observed_outcome"]},
                 "text": TEXT, "conditions": TEXT, "limits": TEXT, "nodes": IDS, "evidence": REFS},
                ["kind", "text", "conditions", "limits", "nodes", "evidence"]),
    tool_schema("revise_structure", "Перестроить модель: переместить узел (полный список parents) либо удалить пустой узел. Сначала перенеси его детей/ссылки; изменения сохраняются.",
                {"id": TEXT, "action": {"type": "string", "enum": ["move", "retire"]},
                 "parents": IDS, "reason": TEXT}, ["id", "action", "reason"]),
    tool_schema("revise_relation", "Удалить ошибочную связь с объяснением; исправленную отправь через link_nodes. Удалённое остаётся в истории.",
                {"from": TEXT, "to": TEXT, "kind": TEXT, "reason": TEXT}, ["from", "to", "kind", "reason"]),
    tool_schema("retire_record", "Отозвать ошибочное утверждение, дефект или контроль. Решение с прежними данными и цитатами проверит независимый агент.",
                {"kind": {"type": "string", "enum": ["claim", "defect", "guardrail"]}, "id": TEXT,
                 "reason": TEXT, "evidence": REFS}, ["kind", "id", "reason", "evidence"]),
]
