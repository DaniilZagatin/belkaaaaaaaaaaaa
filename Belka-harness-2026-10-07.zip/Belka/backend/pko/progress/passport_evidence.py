"""Bounded, masked source corpus for the passport, with checked literal citations.

The model can retrieve immutable records, never choose a repository path to read.
Citation validity is provenance, not a proof of the model's interpretation.
"""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from typing import Any

from pko.progress.agent_tools import ToolBox, _mask_secrets
from pko.progress.passport_source import available_source_path
from pko.progress.passport_fields import NODE_FIELDS, GENERATED_FIELDS
from pko.progress.verify import ANCHOR_WINDOW, MIN_ANCHOR, _DEFINITION, _SIGNATURE, _TOKEN

PAGE_CHARS = 6000
MAX_CODE_CHARS = 1_000_000
MAX_FILES = 80
MAX_LINES_PER_FILE = 1600
# Файлы расширения корпуса (точки входа, соседи по вызовам, места вызова
# маршрутов во фронтенде, факты экспозиции) читаются только окнами вокруг
# якорных строк — отдельный потолок, чтобы не вытеснять файлы оценки.
MAX_EXTRA_FILES = 60
REACHABILITY = ("connected", "endpoint_only", "definition_only", "disconnected", "unknown", "planned")
INCLUDE_REASON = {
    "anchor": "подтверждённая ссылка оценки или ревизии",
    "evaluation": "файл из следа оценки",
    "entrypoint": "точка входа системы",
    "ui_call": "место вызова маршрута во фронтенде",
    "exposure": "факт экспозиции",
    "neighbour": "сосед по графу вызовов",
}
def _hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


@dataclass
class EvidenceCorpus:
    records: dict[str, dict[str, str]] = field(default_factory=dict)
    omitted: list[str] = field(default_factory=list)
    commit: str = ""
    # Only text actually returned by read() can support a citation.
    shown: dict[str, list[str]] = field(default_factory=dict)
    # Почему файл попал в корпус: путь → ключ INCLUDE_REASON.
    included: dict[str, str] = field(default_factory=dict)
    # `passport_facts.RouteUsage`: вызовы маршрутов из фронтенда для гейта входа.
    route_usage: Any = None

    def add(self, kind: str, label: str, text: str) -> None:
        text = "\n".join(_mask_secrets(line) for line in text.splitlines())
        for offset in range(0, len(text), PAGE_CHARS):
            key = f"evidence-{len(self.records) + 1}"
            self.records[key] = {"kind": kind, "label": label,
                                 "part": str(offset // PAGE_CHARS + 1),
                                 "text": text[offset:offset + PAGE_CHARS]}

    def index(self, query: str = "", offset: int = 0) -> dict:
        query = str(query).casefold()
        rows = [{"id": key, **{k: row[k] for k in ("kind", "label", "part")},
                 "already_read": key in self.shown}
                for key, row in self.records.items()
                if not query or query in (row["label"] + "\n" + row["text"]).casefold()]
        offset = max(0, offset)
        page = rows[offset:offset + 30]
        result = {"records": page, "total": len(rows),
                  "next_offset": offset + 30 if offset + 30 < len(rows) else None,
                  "scope": "Поиск только в корпусе. Нет совпадений ≠ нет реализации/контроля.",
                  "read_state_scope": "already_read: этот фрагмент ранее показан в данной сессии чтения; это не гарантия сохранения текста в текущем контексте. Поиск сам по себе не является чтением."}
        if not page:
            # Живой агент сто шагов листал пустую выдачу, прибавляя к offset
            # по единице, и искал по полям ответа («"part": "1"»).
            result["note"] = (("Смещение за концом выдачи" if rows else "Совпадений нет")
                              + ": листать дальше нечего. Поиск идёт по тексту фрагментов, "
                              "а не по полям ответа (kind, part); пустой query — оглавление.")
        return result

    def read(self, ids: Any) -> dict:
        if not isinstance(ids, list) or not 1 <= len(ids) <= 2 or any(not isinstance(x, str) for x in ids):
            return {"error": "Нужен массив из 1–2 идентификаторов evidence-N."}
        out, new_ids, repeated_ids = [], [], []
        for key in ids:
            row = self.records.get(key)
            if row is None:
                out.append({"id": key, "error": "Нет такого фрагмента"})
            else:
                already_read = key in self.shown
                self.shown[key] = [row["text"]]
                out.append({"id": key, **row, "already_read": already_read})
                (repeated_ids if already_read else new_ids).append(key)
        return {"records": out, "newly_read_ids": new_ids, "already_read_ids": repeated_ids,
                "note": "Повторное чтение возвращает тот же буквальный материал. Если нужный текст уже есть в контексте, используй его для проверяемого вывода; новое чтение не усиливает основание."}

    def citations(self, refs: Any, *, code: bool = False, required: bool = True) -> list[str]:
        if not isinstance(refs, list) or (required and not refs):
            return ["Нужны цитаты evidence: [{id, quote}] из прочитанных фрагментов."]
        errors = []
        for ref in refs:
            if not isinstance(ref, dict):
                errors.append("Цитата должна содержать id и quote.")
                continue
            key, quote = ref.get("id"), ref.get("quote")
            row = self.records.get(key) if isinstance(key, str) else None
            if row is None:
                errors.append(f"Неизвестный id основания: {str(key)[:100]}.")
            elif not isinstance(quote, str) or not quote.strip():
                errors.append(f"{key}: отсутствует quote — нужна буквальная цитата из прочитанного фрагмента.")
            elif not re.sub(r"(?m)^\s*\d+: ?", "", quote).strip(".\u2026 \t\r\n"):
                errors.append(f"{key}: многоточие не является цитатой кода.")
            elif not any(quote in text for text in self.shown.get(key, [])):
                errors.append(f"{key}: цитата не найдена в показанном фрагменте; сначала прочитай его.")
            elif len(quote.strip()) < 12 and not self._short_code_line(key, quote):
                errors.append(f"{key}: слишком короткая цитата; нужны минимум 12 символов или полная короткая строка кода.")
            elif code and row["kind"] != "code":
                errors.append(f"{key}: сводка/образ результата не доказывает реализацию; нужен code.")
        return errors

    def _short_code_line(self, key: str, quote: str) -> bool:
        """A whole shown source line may be short (``if not rw:``, ``pass``).

        This checks provenance only; the normal mechanism and claim checks
        still decide whether that line supports the submitted interpretation.
        """
        if self.records[key]["kind"] != "code" or "\n" in quote.strip():
            return False
        plain = re.sub(r"^\s*\d+:\s?", "", quote).strip()
        if not re.search(r"\w", plain) or plain.startswith(("#", "//", "/*", "--")):
            return False
        return any(plain == re.sub(r"^\s*\d+:\s?", "", line).strip()
                   for text in self.shown.get(key, []) for line in text.splitlines())

    def manifest(self) -> dict:
        return {"version": 1, "commit": self.commit,
                "sha256": _hash(self.records), "hash_scope": "masked passport evidence corpus, not original archive",
                "records": [{"id": key, **{k: row[k] for k in ("kind", "label", "part")},
                             "sha256": _hash(row["text"]), "read": key in self.shown}
                            for key, row in self.records.items()],
                "omitted": self.omitted,
                "included": [{"path": path, "reason": reason, "reason_label": INCLUDE_REASON.get(reason, reason)}
                             for path, reason in self.included.items()],
                "limits": {"files": MAX_FILES, "extra_files": MAX_EXTRA_FILES,
                           "lines_per_file": MAX_LINES_PER_FILE, "code_chars": MAX_CODE_CHARS},
                "scope": "Файлы из следа оценки, точки входа, соседи по вызовам и места вызова маршрутов; "
                         "буквальные фрагменты подготовлены перед паспортным этапом. "
                         "Это не полный аудит репозитория и не проверка развёртывания."}


_EXTRA_ORDER = ("entrypoint", "ui_call", "exposure", "neighbour")


def _window_offsets(lines: set[int]) -> list[int]:
    return sorted({((line - 1) // 200) * 200 + 1 for line in lines if line > 0})


def build_corpus(tree: Any, paths: set[str], knowledge: list[str], source_text: str,
                 commit: str = "", anchors: dict[str, set[int]] | None = None,
                 extra: dict[str, tuple[str, set[int]]] | None = None,
                 summaries: list[tuple[str, str]] | None = None) -> EvidenceCorpus:
    """Корпус паспорта.

    `paths` — файлы следа оценки: читаются с начала (до `MAX_LINES_PER_FILE`),
    окна с подтверждёнными якорями — первыми. `extra` — расширение: путь →
    (причина из `INCLUDE_REASON`, якорные строки); такие файлы читаются только
    окнами вокруг якорей и под отдельным потолком `MAX_EXTRA_FILES`.
    `summaries` — сводки фактов (вид `summary`, не доказательство реализации);
    идут после кода, чтобы идентификаторы прежних фрагментов не менялись.
    """
    corpus = EvidenceCorpus(commit=commit)
    corpus.add("intent", "Исходный образ результата", source_text)
    for i, entry in enumerate(knowledge, 1):
        corpus.add("summary", f"След оценки {i}", str(entry))
    toolbox = ToolBox(tree)
    used = 0
    anchors = {path: set(lines) for path, lines in (anchors or {}).items()}
    extra = dict(extra or {})
    # Якоря расширения в файлах оценки тоже поднимают свои окна вперёд.
    for path in list(extra):
        if path in paths:
            anchors.setdefault(path, set()).update(extra.pop(path)[1])

    def read_windows(path: str, offsets: list[int], full: bool) -> None:
        nonlocal used
        covered: list[tuple[int, int]] = []
        total = 0
        for offset in offsets:
            if total and offset > total:
                continue
            try:
                result = toolbox.read_file(path, offset=offset, limit=200)
            except Exception:  # Source errors may include secrets or host paths.
                corpus.omitted.append(f"{path}: источник недоступен")
                return
            if not result.ok:
                corpus.omitted.append(f"{path}: {result.content}")
                return
            total = result.meta.get("total_lines", 0)
            if offset > total:
                continue
            # The reader's continuation marker is metadata, not source code.
            text = result.content.split("\n... есть ещё строки", 1)[0]
            if used + len(text) > MAX_CODE_CHARS:
                corpus.omitted.append(f"{path}:{offset}: лимит корпуса")
                break
            kind = "document" if path.lower().endswith((".md", ".rst", ".txt")) else "code"
            corpus.add(kind, f"{path}:{offset}", text)
            used += len(text)
            covered.append((offset, min(offset + 199, total)))
            # Do not stop after a high anchor: earlier windows may still be needed.
            if full and total <= 200:
                break
        next_line = 1
        for start, end in sorted(covered):
            if start > next_line and next_line <= total:
                corpus.omitted.append(f"{path}:{next_line}–{min(start - 1, total)}: вне выборки корпуса")
            next_line = max(next_line, end + 1)
        if next_line <= total:
            corpus.omitted.append(f"{path}:{next_line}–{total}: вне выборки корпуса")

    # Verified references take priority over lexicographic file heads.
    ordered_paths = sorted(paths, key=lambda path: (not bool(anchors.get(path)), path))
    selected_files = 0
    for path in ordered_paths:
        if not available_source_path(tree, path):
            corpus.omitted.append(f"{path}: путь запрещён или отсутствует в снимке")
            continue
        if selected_files >= MAX_FILES or used >= MAX_CODE_CHARS:
            corpus.omitted.append(f"{path}: лимит корпуса")
            continue
        corpus.included[path] = "anchor" if anchors.get(path) else "evaluation"
        selected_files += 1
        offsets = list(dict.fromkeys([*_window_offsets(anchors.get(path, set())),
                                      *range(1, MAX_LINES_PER_FILE + 1, 200)]))
        read_windows(path, offsets[:MAX_LINES_PER_FILE // 200], True)

    rank = {reason: index for index, reason in enumerate(_EXTRA_ORDER)}
    ordered_extra = sorted(extra.items(), key=lambda kv: (rank.get(kv[1][0], len(rank)), kv[0]))
    selected_extra = 0
    for path, (reason, lines) in ordered_extra:
        if not available_source_path(tree, path):
            corpus.omitted.append(f"{path}: путь запрещён или отсутствует в снимке")
            continue
        if selected_extra >= MAX_EXTRA_FILES or used >= MAX_CODE_CHARS:
            corpus.omitted.append(f"{path}: лимит расширения корпуса ({INCLUDE_REASON.get(reason, reason)})")
            continue
        offsets = _window_offsets(lines)[:MAX_LINES_PER_FILE // 200]
        if not offsets:
            continue
        corpus.included[path] = reason
        selected_extra += 1
        read_windows(path, offsets, False)

    for label, text in summaries or []:
        if text and text.strip():
            corpus.add("summary", label, text)
    return corpus


# --- привязка цитаты к утверждению ----------------------------------------------
# Происхождение цитаты (она взята из показанного фрагмента) ещё не значит, что
# она подтверждает именно это утверждение: строка `import logging` проходила
# как основание для «до трёх попыток, ошибка 400 или 500». Правило то же, что
# у ревьюера для evidence (`verify.py`), но строже по месту: имя из
# утверждения должно быть в самой цитате или в имени объявления, которому она
# принадлежит; файл и строка из основания — совпадать с процитированными;
# числа из значения — встречаться в цитатах.

_PATH_REF = re.compile(
    r"(?<![\w/.-])((?:[\w-]+/)*[\w.-]+\.(?:py|pyi|ts|tsx|js|jsx|mjs|java|kt|sql|go|rb|cs|vue|svelte|"
    r"yaml|yml|json|toml|md))(?::(\d+)(?:\s*[–-]\s*(\d+))?)?")
_STOP_TOKENS = {"http", "https", "json", "yaml", "html", "rest", "true", "false", "none", "null",
                "todo", "self", "with", "from", "this", "that", "when", "then"}
# Точка в конце фразы число не обрывает: «400 или 500.» — два числа.
_NUMBER_TAIL = r"(?!\w|[.,]\d)"
_NUMBER = re.compile(r"(?<![\w.])\d+(?:[.,]\d+)?" + _NUMBER_TAIL)
_FIELD_ID = re.compile(r"\b\d+\.\d+\.\d+\b")
# «Один/одна» в деловом тексте чаще значит «некий», чем число: не требуем.
_NUMBER_WORDS = {
    "два": "2", "две": "2", "двух": "2", "двум": "2", "двумя": "2",
    "три": "3", "трёх": "3", "трех": "3", "трём": "3", "трем": "3", "тремя": "3",
    "четыре": "4", "четырёх": "4", "четырех": "4", "пять": "5", "пяти": "5",
    "шесть": "6", "шести": "6", "семь": "7", "семи": "7", "восемь": "8", "восьми": "8",
    "девять": "9", "девяти": "9", "десять": "10", "десяти": "10",
}
_NUMBER_WORD_RE = re.compile(r"(?<![а-яё])(" + "|".join(sorted(_NUMBER_WORDS, key=len, reverse=True)) + r")(?![а-яё])",
                             re.IGNORECASE)


def _same_path(a: str, b: str) -> bool:
    return a == b or a.endswith("/" + b) or b.endswith("/" + a)


def _claim_tokens(text: str) -> set[str]:
    from pko.progress.passport_gate import EXECUTION_MODES
    vocabulary = {mode.lower() for mode in EXECUTION_MODES} | _STOP_TOKENS
    out: set[str] = set()
    for token in _TOKEN.findall(_PATH_REF.sub(" ", text or "")):
        for candidate in (token, *re.split(r"[^\w]+", token)):
            candidate = candidate.strip("._/-")
            if len(candidate) >= MIN_ANCHOR and candidate.lower() not in vocabulary and "/" not in candidate:
                out.add(candidate)
    return out


def _claim_numbers(text: str) -> list[str]:
    text = _FIELD_ID.sub(" ", _PATH_REF.sub(" ", text or ""))
    found = [n.replace(",", ".") for n in _NUMBER.findall(text)]
    found.extend(_NUMBER_WORDS[w.lower()] for w in _NUMBER_WORD_RE.findall(text))
    return list(dict.fromkeys(found))


def _enclosing_name(record: dict[str, str], quote: str) -> str:
    """Имя объявления, внутри которого стоит начало цитаты (в пределах фрагмента)."""
    text = record.get("text") or ""
    index = text.find(quote)
    if index < 0:
        return ""
    lines = text[:index].split("\n")
    current = text[index - len(lines[-1]):].split("\n", 1)[0]
    if str(record.get("label", "")).rsplit(":", 1)[0].lower().endswith((".py", ".pyi")):
        code_lines = [re.sub(r"^\d+: ", "", raw).expandtabs(8) for raw in [*lines[:-1], current]]
        for row in range(len(code_lines) - 1, -1, -1):
            declaration = re.match(r"^(\s*)(?:async\s+)?(?:def|class)\s+(\w+)\b", code_lines[row])
            if declaration is None:
                continue
            indent = len(declaration[1])
            # An earlier declaration is no longer an owner after a dedent.
            # Blank/comment lines and closing multiline delimiters do not end
            # its body; ambiguous fragments can cite the declaration itself.
            if all(not raw.strip() or raw.lstrip().startswith(("#", ")", "]", "}"))
                   or len(raw) - len(raw.lstrip()) > indent for raw in code_lines[row + 1:]):
                return declaration[2]
        return ""
    for raw in [current, *reversed(lines[:-1])]:
        code = re.sub(r"^\d+: ", "", raw)
        match = _DEFINITION.search(code) or _SIGNATURE.match(code)
        if match:
            return match.group("name")
    return ""


def claim_citation_errors(corpus: EvidenceCorpus, claim: str, refs: Any, *, numbers_from: str = "") -> list[str]:
    """Подтверждают ли цитаты кода именно это утверждение (место, имя, числа).

    Проверяются только цитаты вида `code`, уже прошедшие проверку
    происхождения; ошибки происхождения сообщает `citations`.
    """
    from pko.progress.passport_facts import _quote_lines
    cites: list[tuple[str, list[int], str, dict[str, str]]] = []
    for ref in refs if isinstance(refs, list) else []:
        if not isinstance(ref, dict):
            continue
        record = corpus.records.get(str(ref.get("id") or ""))
        quote = ref.get("quote")
        if record is None or record.get("kind") != "code" or not isinstance(quote, str):
            continue
        if not any(quote in text for text in corpus.shown.get(str(ref.get("id")), [])):
            continue
        path = str(record.get("label") or "").rsplit(":", 1)[0]
        cites.append((path, _quote_lines(record, quote), quote, record))
    if not cites:
        return []
    errors: list[str] = []
    named = [(m.group(1), m.group(2), m.group(3)) for m in _PATH_REF.finditer(claim or "")]
    uncited = list(dict.fromkeys(name for name, _, _ in named
                                if not any(_same_path(path, name) for path, *_ in cites)))
    if uncited:
        errors.append("основание называет " + ", ".join(uncited)
                      + ", а цитаты взяты из других файлов")
    for name, start, end in named:
        if start is None:
            continue
        low, high = int(start), int(end or start)
        own = [line for path, lines, _, _ in cites if _same_path(path, name) for line in lines]
        if own and not any(low - ANCHOR_WINDOW <= line <= high + ANCHOR_WINDOW for line in own):
            errors.append(f"{name}:{start}{'–' + end if end else ''} не совпадает с процитированными строками "
                          f"({', '.join(map(str, sorted(set(own))[:6]))}) — укажи строку, которую цитируешь")
    tokens = _claim_tokens(claim)
    if tokens:
        lowered = {t.lower() for t in tokens}
        anchored = any(
            any(t in quote.lower() for t in lowered)
            or _enclosing_name(record, quote).strip("_").lower() in lowered
            for _, _, quote, record in cites
        )
        if not anchored:
            errors.append("в цитатах нет ни одного имени из утверждения ("
                          + ", ".join(sorted(tokens)[:5])
                          + ") — процитируй строку, где это происходит, или понизь уровень основания")
    if numbers_from:
        code = re.sub(r"(?m)^\d+: ", "", "\n".join(quote for _, _, quote, _ in cites))
        missing = [n for n in _claim_numbers(numbers_from)
                   if not re.search(r"(?<![\w.])" + re.escape(n) + _NUMBER_TAIL, code)]
        if missing:
            errors.append("числа из утверждения не найдены в цитатах: " + ", ".join(missing)
                          + " — найди основание значения; если это вывод по нескольким фрагментам, "
                            "передай все основания и обозначь его как вывод, сохранив существенные условия")
    return errors


def check_node_audit(corpus: EvidenceCorpus, audit: Any, fields: dict, *, planned: bool = False) -> list[str]:
    if not isinstance(audit, dict):
        return ["Нужен fact_check: execution и проверка каждого переданного поля в fields."]
    errors = []
    execution = audit.get("execution")
    if not isinstance(execution, dict):
        errors.append("fact_check.execution: нужны reachability, entrypoint, conditions, outcome, limits, evidence.")
    else:
        reach = execution.get("reachability")
        if reach not in REACHABILITY:
            errors.append("reachability: " + " / ".join(REACHABILITY) + ".")
        if planned and reach != "planned":
            errors.append("Планируемому узлу нужна reachability=planned.")
        if not planned and reach == "planned":
            errors.append("reachability=planned допустим только для узла planned=true.")
        for key in ("entrypoint", "conditions", "outcome", "limits"):
            if not isinstance(execution.get(key), str) or not execution[key].strip():
                errors.append(f"execution.{key}: укажи факт или конкретную границу неизвестного.")
        effect_errors = corpus.citations(execution.get("evidence", []), code=True,
                                         required=reach in ("connected", "endpoint_only", "definition_only", "disconnected"))
        errors.extend(effect_errors)
        if not effect_errors:
            errors.extend("outcome: " + e for e in claim_citation_errors(
                corpus, str(execution.get("outcome") or ""), execution.get("evidence")))
        if reach == "connected":
            entry_errors = corpus.citations(execution.get("entry_evidence"), code=True)
            errors.extend("entrypoint: " + e for e in entry_errors)
            if not entry_errors:
                errors.extend("entrypoint: " + e for e in claim_citation_errors(
                    corpus, str(execution.get("entrypoint") or ""), execution.get("entry_evidence")))
                uncalled, other, _ = classify_entry(corpus, execution.get("entry_evidence"))
                usage = corpus.route_usage
                if usage is not None and usage.frontend_present and uncalled and not other:
                    errors.append(
                        "entrypoint: вход подтверждён только объявлением маршрута "
                        + ", ".join(r.key for r in uncalled)
                        + ", а во фронтенде вызова не найдено. Укажи reachability=endpoint_only "
                        "(маршрут есть, вызов из интерфейса не подтверждён) или процитируй место вызова: "
                        "фронтенд, задание, другой вызывающий код.")
    checks = audit.get("fields")
    if not isinstance(checks, dict) or set(checks) != set(fields):
        errors.append("fact_check.fields должен покрывать ровно все переданные fields, без пропусков.")
        return errors
    for fid, value in fields.items():
        row = checks[fid]
        if not isinstance(row, dict):
            errors.append(f"{fid}: нужна проверка support, evidence, limits.")
            continue
        support = row.get("support")
        mechanism = row.get("mechanism")
        if mechanism not in ("runtime", "prompt", "schema", "intent", "unknown"):
            errors.append(f"{fid}: mechanism = runtime / prompt / schema / intent / unknown.")
        source = str(value.get("source") or "") if isinstance(value, dict) else ""
        if support not in ("code", "inference", "intent", "unknown"):
            errors.append(f"{fid}: support = code / inference / intent / unknown.")
        if source.startswith("Установлено:") and support != "code":
            errors.append(f"{fid}: «Установлено» требует буквального основания в коде.")
        if source.startswith("Установлено:") and mechanism in ("prompt", "schema", "intent", "unknown"):
            errors.append(f"{fid}: инструкция/схема/намерение не доказывает фактическое выполнение; уточни уровень source.")
        if support == "unknown" and not source.startswith(("Не установлено:", "Требует подтверждения владельца:")):
            errors.append(f"{fid}: неизвестное должно быть явно обозначено в source.")
        if not isinstance(row.get("limits"), str) or not row["limits"].strip():
            errors.append(f"{fid}: нужны границы вывода (limits).")
        provenance = corpus.citations(row.get("evidence", []), code=support == "code",
                                      required=support != "unknown")
        errors.extend(f"{fid}: {e}" for e in provenance)
        if support == "code" and not provenance and isinstance(value, dict):
            claim_value = str(value.get("value") or "")
            errors.extend(f"{fid}: {e}" for e in claim_citation_errors(
                corpus, claim_value + "\n" + source, row.get("evidence"), numbers_from=claim_value))
    return errors


def classify_entry(corpus: EvidenceCorpus, refs: Any) -> tuple[list[Any], bool, bool]:
    """Что цитирует `entry_evidence`: (маршруты без вызова из фронтенда,
    есть ли иное место входа, есть ли объявления маршрутов вообще).

    Цитата фронтенд-файла, вызов из задания или другой функции — «иное место
    входа». Объявление маршрута, который интерфейс вызывает, — тоже иное: вызов
    найден. Без `route_usage` классификация не проводится.
    """
    usage = corpus.route_usage
    if usage is None or not isinstance(refs, list):
        return [], True, False
    from pko.progress.passport_facts import _quote_lines, is_frontend_file
    uncalled: list[Any] = []
    other = False
    routes_cited = False
    for ref in refs:
        if not isinstance(ref, dict):
            continue
        record = corpus.records.get(str(ref.get("id") or ""))
        if record is None:
            continue
        path = str(record.get("label") or "").rsplit(":", 1)[0]
        if is_frontend_file(path):
            other = True
            continue
        quote = str(ref.get("quote") or "")
        route = None
        for line in _quote_lines(record, quote):
            route = usage.route_at(path, line)
            if route is not None:
                break
        if route is None:
            route = next((r for r in usage.routes if r.decl_path == path and r.path in quote), None)
        if route is None:
            other = True
            continue
        routes_cited = True
        if route.called:
            other = True
        elif route not in uncalled:
            uncalled.append(route)
    return uncalled, other, routes_cited


def entry_note(corpus: EvidenceCorpus, audit: Any) -> str:
    """Пояснение к входу узла для карточки; пусто, если сказать нечего."""
    usage = corpus.route_usage
    if usage is None or not isinstance(audit, dict) or not isinstance(audit.get("execution"), dict):
        return ""
    execution = audit["execution"]
    reach = execution.get("reachability")
    if reach == "endpoint_only":
        return ("Маршрут объявлен, вызов из интерфейса не подтверждён: статический поиск во фронтенде "
                "его не нашёл или фронтенд не передан. Узел не описывает действующий шаг клиента.")
    if reach == "connected":
        uncalled, other, routes_cited = classify_entry(corpus, execution.get("entry_evidence"))
        if routes_cited and not other and not usage.frontend_present:
            return ("Точка входа — HTTP-маршрут; клиентский вызов в переданных материалах не проверялся "
                    "(фронтенда нет). Для внешних клиентов маршрут — законный вход.")
    return ""


def check_relation_proof(corpus: EvidenceCorpus, proof: Any, kind: str, data_field: str) -> list[str]:
    if not isinstance(proof, dict):
        return ["Нужен proof: direction, condition, mechanism, limits, evidence."]
    errors = []
    for key in ("direction", "condition", "mechanism", "limits"):
        if not isinstance(proof.get(key), str) or not proof[key].strip():
            errors.append(f"proof.{key}: опиши направление/условие/механизм/границу по источнику.")
    if kind == "feeds" and not data_field.strip():
        errors.append("feeds: укажи field — какие данные действительно передаются.")
    provenance = corpus.citations(proof.get("evidence"), code=kind != "includes")
    errors.extend(provenance)
    if not provenance:
        claim = "\n".join(str(proof.get(k) or "") for k in ("direction", "condition", "mechanism"))
        errors.extend(claim_citation_errors(corpus, claim, proof.get("evidence")))
        # Передача данных подтверждается цитатой, где видны именно эти данные.
        if kind == "feeds" and data_field.strip():
            errors.extend("field: " + e for e in claim_citation_errors(corpus, data_field, proof.get("evidence")))
    return errors


def check_control_review(corpus: EvidenceCorpus, review: Any) -> list[str]:
    if not isinstance(review, dict):
        return ["Нужен control_review: scope, checked_controls, conclusion, limits, evidence."]
    errors = []
    for key in ("scope", "checked_controls", "conclusion", "limits"):
        if not isinstance(review.get(key), str) or not review[key].strip():
            errors.append(f"control_review.{key}: опиши проверенные контроли и границы поиска.")
    provenance = corpus.citations(review.get("evidence"), code=True)
    errors.extend(provenance)
    if not provenance:
        controls = str(review.get("checked_controls") or "")
        errors.extend(claim_citation_errors(corpus, controls + "\n" + str(review.get("conclusion") or ""),
                                            review.get("evidence"), numbers_from=controls))
    return errors


READ_SCHEMA = {"type": "function", "function": {
    "name": "read_passport_evidence", "description": "Прочитать 1–2 сохранённых фрагмента по id. Только прочитанный буквальный текст можно цитировать.",
    "parameters": {"type": "object", "properties": {"ids": {"type": "array", "items": {"type": "string"}, "minItems": 1, "maxItems": 2}}, "required": ["ids"]}}}
SEARCH_SCHEMA = {"type": "function", "function": {
    "name": "search_passport_evidence", "description": "Поиск подстроки/пути в сохранённом корпусе; пустой query — оглавление. Отсутствие совпадения не доказывает отсутствие контроля.",
    "parameters": {"type": "object", "properties": {"query": {"type": "string"}, "offset": {"type": "integer"}}, "required": ["query"]}}}
NODE_AUDIT_SCHEMA = {"type": "object", "description":
    "Проверка каждого поля: {execution:{reachability:connected|endpoint_only|definition_only|unknown|planned,entrypoint,conditions,outcome,limits,evidence:[{id,quote}],entry_evidence:[{id,quote}]},"
    " fields:{тот_же_id_поля:{support:code|inference|intent|unknown,mechanism:runtime|prompt|schema|intent|unknown,limits,evidence:[{id,quote}]}}}. "
    "У connected entry_evidence обязательно цитирует вызов/маршрут/регистрацию, evidence — эффект. "
    "Если фронтенд передан, а маршрут в нём не вызывается, объявление маршрута не доказывает connected: "
    "это endpoint_only. Цитаты дословные из read_passport_evidence; у support=code цитата содержит имя из "
    "утверждения (или лежит внутри объявления с этим именем), совпадает с файлом:строкой из source и "
    "показывает числа из value."}
RELATION_PROOF_SCHEMA = {"type": "object", "description":
    "{direction,condition,mechanism,limits,evidence:[{id,quote}]}; для поведенческих связей цитируй код вызова/передачи/порядка, а не список функций или ОР."}
CONTROL_REVIEW_SCHEMA = {"type": "object", "description":
    "{scope,checked_controls,conclusion,limits,evidence:[{id,quote}]}; проверка повторов, дедупликации, транзакций, восстановления и иных применимых контролей по буквальному коду; учитывай факты против риска."}

_TEXT = {"type": "string", "minLength": 1}
_CITATIONS = {"type": "array", "items": {"type": "object",
    "properties": {"id": {"type": "string"}, "quote": {"type": "string", "minLength": 1,
        "description": "Буквальная цитата из прочитанного фрагмента: минимум 12 символов либо полная короткая строка кода. Пустота и многоточие недопустимы."}},
    "required": ["id", "quote"]}}
NODE_AUDIT_SCHEMA.update(properties={
    "execution": {"type": "object", "properties": {
        **{key: _TEXT for key in ("entrypoint", "conditions", "outcome", "limits")},
        "reachability": {"type": "string", "enum": list(REACHABILITY)},
        "evidence": _CITATIONS, "entry_evidence": _CITATIONS},
        "required": ["reachability", "entrypoint", "conditions", "outcome", "limits", "evidence"]},
    "fields": {"type": "object", "additionalProperties": {"type": "object", "properties": {
        "support": {"type": "string", "enum": ["code", "inference", "intent", "unknown"]},
        "mechanism": {"type": "string", "enum": ["runtime", "prompt", "schema", "intent", "unknown"]},
        "limits": _TEXT, "evidence": _CITATIONS}, "required": ["support", "mechanism", "limits", "evidence"]}},
}, required=["execution", "fields"])
for _schema, _keys in (
    (RELATION_PROOF_SCHEMA, ("direction", "condition", "mechanism", "limits")),
    (CONTROL_REVIEW_SCHEMA, ("scope", "checked_controls", "conclusion", "limits")),
):
    _schema.update(properties={**{key: _TEXT for key in _keys}, "evidence": _CITATIONS},
                   required=[*_keys, "evidence"])
