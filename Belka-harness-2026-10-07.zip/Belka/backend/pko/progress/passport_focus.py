"""Adaptive recovery from research loops, without prescribing an agent phase.

This is working memory and feedback, not an acceptance gate. Read materials,
plans and scope bookkeeping do not reset the substantive-progress counter.
The model still chooses its next hypothesis, object and tool.
"""
from __future__ import annotations

from copy import deepcopy
import json
import time
from typing import Any

from pko.progress.passport_workspace import digest


RECOVERY_INTERVAL = 8
FOCUS_MARKER = "Исследование без сохранённого содержательного результата:"
MAX_READ_INDEX = 512
MAX_RECENT_REQUESTS = 32
MAX_FOCUS_CHARS = 5_500
_READ_TOOLS = {"read_passport_evidence", "search_passport_evidence", "request_passport_evidence"}
_TERMINAL_LIMITS = {"request_budget", "new_file_budget", "symbol_budget", "corpus_character_budget"}


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, default=str)


def _focus(state: Any) -> dict:
    focus = getattr(state, "research_focus", None)
    if not isinstance(focus, dict):
        focus = {}
        state.research_focus = focus
    focus.setdefault("version", 1)
    focus.setdefault("reads", {})
    focus.setdefault("requests", [])
    focus.setdefault("broker", {})
    return focus


def _substantive_mark(state: Any) -> str:
    ws = state.workspace
    # Initial and unchanged accepted state is a baseline, not fresh progress.
    # Negative findings, review retries, source counts, drafts and cosmetic plan
    # edits do not prolong an exploration loop. Versions still govern review.
    return digest({
        "nodes": {nid: {"name": n.name, "parents": n.parents, "children": n.children,
                        "data": n.data if n.filled else None} for nid, n in state.nodes.items()},
        "objects": {oid: obj["revision"] for oid, obj in ws.objects.items()
                    if not oid.startswith("scope:")},
        "claims": ws.claims, "relations": state.relations, "risks": state.risks,
        "defects": state.defects, "guardrails": state.guardrails,
        "supported_reviews": {oid: row.get("revision") for oid, row in ws.reviews.items()
                              if row.get("result") == "supported"},
        "risk_analysis_current": state.risk_reviewed,
    })


def _remaining(state: Any, step: int, max_steps: int, max_tool_calls: int) -> dict:
    deadline = getattr(state, "deadline", 0)
    return {"steps": max(0, max_steps - step + 1),
            "tool_calls": max(0, max_tool_calls - getattr(state, "tool_calls", 0)),
            "seconds": max(0, int(deadline - time.monotonic())) if deadline else None}


def _reminder(state: Any, focus: dict) -> str:
    count = focus["steps_without_result"]
    total = len(getattr(getattr(state, "evidence_corpus", None), "shown", {}))
    budget = focus["remaining"]
    text = (f"{FOCUS_MARKER} {count} шагов. "
            f"Уже прочитано {total} фрагментов; чтение, поиски, план и учёт границ отдельно от результата. "
            f"Осталось шагов: {budget['steps']}, вызовов инструментов: {budget['tool_calls']}"
            + (f", времени: {budget['seconds']} с. " if budget["seconds"] is not None else ". "))
    if total:
        text += ("Выбери один текущий вопрос или объект. Зафиксируй узкое наблюдение через submit_claim "
                 "со связанным существующим узлом, условиями, границей и прочитанной цитатой; "
                 "либо уточни узел/связь/сценарий или проверь готовую гипотезу. "
                 "Это варианты следующего действия, порядок выбираешь самостоятельно. ")
    else:
        text += "Уточни один вопрос и адресно прочитай нужный фрагмент; без источника не придумывай факт. "
    text += ("Если оснований ещё недостаточно, назови конкретный недостающий факт и выполни адресный запрос. "
             "Не начинай общий обзор заново; ранее прочитанные ID и результаты поиска сохранены в рабочей памяти. "
             "Не выдумывай узлы и не ослабляй вывод ради принятия. ")
    terminal = focus.get("broker", {}).get("terminal_errors", [])
    if terminal:
        text += ("Лимиты расширения корпуса: " + ", ".join(terminal) + ". "
                 "Не повторяй отказавший запрос: используй уже сохранённые материалы или явно сохрани границу знания. ")
    if count >= 2 * RECOVERY_INTERVAL:
        text += ("Повторный поиск и перечитывание не заменяют сохранения результата. "
                 "Независимая проверка и finish сохраняют прежние требования; незавершённое останется черновиком.")
    return text.strip()


def before_research_step(state: Any, step: int, max_steps: int, *, max_tool_calls: int = 512) -> str | None:
    """Call before an idle-stop check. Step 1 starts at zero; step 9 can nudge.

    Returns a new, soft recovery message at 8/16/24… steps without a substantive
    result. The active message also lives in focus_snapshot, so compaction cannot
    erase it. This function never stops a run or disables a tool.
    """
    focus = _focus(state)
    mark = _substantive_mark(state)
    old_step = focus.get("step")
    if old_step is not None and step < old_step:
        # A newly started loop may restore durable read history; budgets restart.
        focus.pop("substantive_mark", None)
    if focus.get("substantive_mark") != mark:
        focus.update(substantive_mark=mark, last_result_step=step, last_notice_count=0,
                     steps_without_result=0, recovery=None)
    focus["step"] = step
    focus["remaining"] = _remaining(state, step, max_steps, max_tool_calls)
    count = max(0, step - focus["last_result_step"])
    focus["steps_without_result"] = count
    # Refresh budgets and counts in the persistent message without sending a new
    # user turn on every request or using new source reads as a counter reset.
    if count >= RECOVERY_INTERVAL:
        focus["recovery"] = _reminder(state, focus)
    if count < focus.get("last_notice_count", 0) + RECOVERY_INTERVAL:
        return None
    focus["last_notice_count"] = count
    from pko.audit import record
    record("passport_research_recovery", step=step, steps_without_result=count,
           read_records=len(getattr(getattr(state, "evidence_corpus", None), "shown", {})),
           remaining=focus["remaining"])
    return focus["recovery"]


def observe_research_tool(state: Any, name: str, args: dict, content: Any) -> None:
    """Remember actual tool observations, not assistant guesses or hidden reads."""
    if name not in _READ_TOOLS:
        return
    focus = _focus(state)
    try:
        body = json.loads(content) if isinstance(content, str) else content
    except (ValueError, TypeError):
        body = {}
    if not isinstance(body, dict):
        body = {}
    step = focus.get("step", 0)
    corpus = getattr(state, "evidence_corpus", None)
    records = body.get("records", [])
    records = records if isinstance(records, list) else []
    ids = [r["id"] for r in records if isinstance(r, dict) and isinstance(r.get("id"), str)]
    if name == "read_passport_evidence" and corpus is not None:
        for row in records:
            if not isinstance(row, dict) or not isinstance(row.get("id"), str):
                continue
            eid, text = row["id"], row.get("text")
            # Showing the same record again updates its counter, not provenance.
            if not isinstance(text, str) or text not in corpus.shown.get(eid, []):
                continue
            previous = focus["reads"].pop(eid, {})
            focus["reads"][eid] = {"id": eid, "label": str(row.get("label", ""))[:512],
                                    "kind": row.get("kind"), "part": row.get("part"),
                                    "count": previous.get("count", 0) + 1, "last_step": step}
        while len(focus["reads"]) > MAX_READ_INDEX:
            focus["reads"].pop(next(iter(focus["reads"])))
    if name == "request_passport_evidence":
        broker = focus["broker"]
        for key in ("usage", "limits"):
            if isinstance(body.get(key), dict):
                broker[key] = {k: v for k, v in body[key].items() if isinstance(v, (int, float, bool))}
        error = str(body.get("error", ""))[:100]
        if error in _TERMINAL_LIMITS or error and body.get("retryable") is False:
            errors = broker.setdefault("terminal_errors", [])
            if error not in errors:
                errors.append(error)
        broker["last_error"] = error or None
        broker["next_action"] = str(body.get("next_action", ""))[:160]
    # Identical search results remain known until the immutable corpus expands.
    signature = digest({"tool": name, "args": args})
    requests = focus["requests"]
    previous = next((row for row in requests if row["key"] == signature), {})
    requests[:] = [row for row in requests if row["key"] != signature]
    request = {"key": signature, "tool": name,
               "args": {k: (v[:512] if isinstance(v, str) else v[:8] if isinstance(v, list) else v)
                        for k, v in args.items() if k in ("kind", "query", "path", "id", "line", "offset", "ids")},
               "record_ids": ids[:16], "total": body.get("total", body.get("matches_returned")),
               "truncated": bool(body.get("truncated", False)), "next_offset": body.get("next_offset"),
               "error": str(body.get("error", ""))[:160] or None,
               "corpus_records": len(corpus.records) if corpus else 0,
               "count": previous.get("count", 0) + 1, "last_step": step}
    requests.append(request)
    del requests[:-MAX_RECENT_REQUESTS]


def focus_snapshot(state: Any) -> dict:
    """A bounded reminder/index; exact source text stays in the shown corpus."""
    focus = getattr(state, "research_focus", {})
    focus = focus if isinstance(focus, dict) else {}
    corpus = getattr(state, "evidence_corpus", None)
    shown = getattr(corpus, "shown", {})
    reads = focus.get("reads", {})
    # Handles remain discoverable even when their full pages leave the window.
    read_ids = list(shown)
    claims = getattr(getattr(state, "workspace", None), "claims", {})
    result = {
        "steps_without_result": focus.get("steps_without_result", 0),
        "remaining": deepcopy(focus.get("remaining", {})), "recovery": focus.get("recovery"),
        "read_total": len(read_ids), "read_ids": read_ids[-64:],
        "read_index": [{"id": eid, "label": str(corpus.records.get(eid, {}).get("label", ""))[:180],
                        "reads": reads.get(eid, {}).get("count", 1)}
                       for eid in list(reads)[-10:] if eid in shown],
        "recent_queries": [{k: deepcopy(v) for k, v in row.items() if k != "key"}
                           for row in focus.get("requests", []) if row["tool"] != "read_passport_evidence"][-5:],
        "broker": deepcopy(focus.get("broker", {})),
        "saved_observations": [{"id": cid, "text_excerpt": str(row.get("text", ""))[:320],
                                "limits_excerpt": str(row.get("limits", ""))[:180],
                                "evidence_ids": [r.get("id") for r in row.get("evidence", []) if isinstance(r, dict)][:8],
                                "meaning": "Сохранённое утверждение; статус проверки смотри в research_state."}
                               for cid, row in list(claims.items())[-4:]],
        "note": "Индекс не заменяет буквальную цитату и не доказывает смысл вывода. "
                "Поиск относится к указанному размеру корпуса; после расширения результат может измениться.",
    }
    while len(_json(result)) > MAX_FOCUS_CHARS:
        keys = [k for k, value in result.items() if isinstance(value, list) and value]
        if not keys:
            break
        key = max(keys, key=lambda k: len(_json(result[k])))
        # Keep the most recent observations/queries when the view is shortened.
        result[key].pop(0)
        result["index_truncated"] = True
    return result
