"""Pydantic AI model backed by Belka's existing, configured chat transport.

One Model.request means one ChatClient.chat call. Pydantic AI owns tool execution
and retries; this adapter neither executes tools nor runs another agent loop.
Provider reasoning stays in a private, per-adapter memory, never in Pydantic
message parts or checkpoint JSON. Existing transport/cache/trace policies apply.
"""
from __future__ import annotations

import asyncio
import json
from contextvars import copy_context
from copy import deepcopy
from threading import Thread
import time
from typing import Any, Callable, Sequence
from uuid import uuid4

from pydantic_ai.exceptions import UserError
from pydantic_ai.messages import (
    CachePoint, InstructionPart, ModelMessage, ModelRequest, ModelResponse, RetryPromptPart,
    SystemPromptPart, TextContent, TextPart, ThinkingPart, ToolCallPart, ToolReturnPart, UserPromptPart,
)
from pydantic_ai.models import Model, ModelRequestParameters, check_allow_model_requests
from pydantic_ai.settings import ModelSettings
from pydantic_ai.usage import RequestUsage

from pko.errors import LlmError
from pko.llm.client import DEFAULT_MAX_TOKENS
from pko.llm.registry import ModelSpec


_RESPONSE_ID = "_pko_response_id"
_PUBLIC_RESPONSE = "_pko_response"


def _user_content(content: Any) -> str:
    if isinstance(content, str):
        return content
    if not isinstance(content, (list, tuple)):
        raise UserError("PassportChatModel supports text messages, not binary or URL content.")
    parts = []
    for item in content:
        if isinstance(item, CachePoint):
            # Harness planning/reminders insert provider-specific cache hints.
            # Our existing transport owns caching; this is not visible content.
            continue
        if isinstance(item, TextContent):
            item = item.content
        if not isinstance(item, str):
            raise UserError("PassportChatModel supports only text parts in user messages.")
        parts.append(item)
    return "\n\n".join(parts)


def to_chat_messages(messages: Sequence[ModelMessage], *, instructions: str = "") -> list[dict[str, Any]]:
    """Convert text/tool history for compaction, without private reasoning.

    Opaque response IDs and public usage/cache metadata survive a round trip.
    Instructions are added only when explicitly supplied: the live Agent's
    instruction_parts are authoritative and must not accumulate in history.
    """
    result: list[dict[str, Any]] = []
    for message in messages:
        if isinstance(message, ModelRequest):
            for part in message.parts:
                if isinstance(part, SystemPromptPart):
                    result.append({"role": "system", "content": part.content})
                elif isinstance(part, UserPromptPart):
                    result.append({"role": "user", "content": _user_content(part.content)})
                elif isinstance(part, ToolReturnPart):
                    text, files = part.model_response_str_and_user_content()
                    if files:
                        raise UserError("Passport tools return text/JSON; file tool results are unsupported.")
                    result.append({"role": "tool", "tool_call_id": part.tool_call_id, "content": text})
                elif isinstance(part, RetryPromptPart):
                    row = {"role": "tool" if part.tool_name else "user", "content": part.model_response()}
                    if part.tool_name:
                        row["tool_call_id"] = part.tool_call_id
                    result.append(row)
                else:
                    raise UserError(f"PassportChatModel does not support request part {part.part_kind}.")
        elif isinstance(message, ModelResponse):
            text, calls = [], []
            for part in message.parts:
                if isinstance(part, TextPart):
                    text.append(part.content)
                elif isinstance(part, ToolCallPart):
                    calls.append({"id": part.tool_call_id, "type": "function", "function": {
                        "name": part.tool_name, "arguments": part.args_as_json_str()}})
                elif isinstance(part, ThinkingPart):
                    # Never turn imported private reasoning into public text.
                    continue
                else:
                    raise UserError(f"PassportChatModel does not support response part {part.part_kind}.")
            if not text and not calls:
                continue
            row = {"role": "assistant", "content": "".join(text) or None}
            if calls:
                row["tool_calls"] = calls
            if message.provider_response_id:
                row[_RESPONSE_ID] = message.provider_response_id
            row[_PUBLIC_RESPONSE] = {"model_name": message.model_name,
                "input_tokens": message.usage.input_tokens, "output_tokens": message.usage.output_tokens,
                "cache_read_tokens": message.usage.cache_read_tokens,
                "cache_write_tokens": message.usage.cache_write_tokens,
                "details": deepcopy(message.usage.details),
                "from_cache": bool((message.metadata or {}).get("from_cache", False))}
            result.append(row)
        else:
            raise UserError("PassportChatModel received an unsupported message.")
    if instructions:
        index = next((i for i, row in enumerate(result) if row["role"] != "system"), len(result))
        result.insert(index, {"role": "system", "content": instructions})
    return result


def from_chat_messages(messages: Sequence[dict[str, Any]]) -> list[ModelMessage]:
    """Rebuild typed history after compaction; hidden reasoning is discarded."""
    result: list[ModelMessage] = []
    parts: list[Any] = []
    names: dict[str, str] = {}

    def flush() -> None:
        if parts:
            result.append(ModelRequest(parts=list(parts)))
            parts.clear()

    for row in messages:
        role, content = row.get("role"), row.get("content")
        if role in ("system", "developer"):
            parts.append(SystemPromptPart(content=str(content or "")))
        elif role == "user":
            if isinstance(content, list):
                if any(not isinstance(p, dict) or p.get("type") != "text" or not isinstance(p.get("text"), str) for p in content):
                    raise UserError("Passport history contains a non-text user part.")
                content = [p["text"] for p in content]
            parts.append(UserPromptPart(content=content if content is not None else ""))
        elif role == "tool":
            cid = str(row.get("tool_call_id") or "")
            if not cid or cid not in names:
                raise UserError("Passport history has an orphaned tool result.")
            parts.append(ToolReturnPart(tool_name=names[cid], tool_call_id=cid,
                                        content=content if content is not None else ""))
        elif role == "assistant":
            flush()
            response_parts: list[Any] = [TextPart(content)] if isinstance(content, str) and content else []
            for call in row.get("tool_calls") or []:
                function = call.get("function") or {}
                cid, name = str(call.get("id") or ""), str(function.get("name") or "")
                if not cid or not name:
                    raise UserError("Passport history has a tool call without its ID or name.")
                names[cid] = name
                response_parts.append(ToolCallPart(name, function.get("arguments"), tool_call_id=cid))
            if not response_parts:
                continue
            public = row.get(_PUBLIC_RESPONSE) or {}
            usage = RequestUsage(**{k: public[k] for k in (
                "input_tokens", "output_tokens", "cache_read_tokens", "cache_write_tokens", "details") if k in public})
            result.append(ModelResponse(parts=response_parts, provider_response_id=row.get(_RESPONSE_ID),
                                        model_name=public.get("model_name"), usage=usage,
                                        metadata={"from_cache": bool(public.get("from_cache", False))}))
        else:
            raise UserError(f"Passport history contains unsupported role {role!r}.")
    flush()
    return result


async def _call_in_daemon(action: Callable[[], Any], deadline: float) -> Any:
    """Bound awaiting/cancellation without blocking asyncio's executor shutdown."""
    remaining = deadline - time.monotonic() if deadline else None
    if remaining is not None and remaining <= 0:
        raise TimeoutError("Passport model deadline expired before dispatch.")
    loop = asyncio.get_running_loop()
    future = loop.create_future()
    context = copy_context()

    def deliver(ok: bool, value: Any) -> None:
        if not future.done():
            future.set_result(value) if ok else future.set_exception(value)

    def worker() -> None:
        try:
            value, ok = context.run(action), True
        except BaseException as exc:
            value, ok = exc, False
        try:
            loop.call_soon_threadsafe(deliver, ok, value)
        except RuntimeError:
            pass  # A cancelled/expired caller has already closed its loop.

    Thread(target=worker, name="passport-harness-model", daemon=True).start()
    result = await asyncio.wait_for(future, remaining) if remaining is not None else await future
    if deadline and time.monotonic() >= deadline:
        raise TimeoutError("Passport model returned after its deadline.")
    return result


def _usage(usage: dict[str, Any]) -> RequestUsage:
    def number(value: Any) -> int:
        return max(0, int(value)) if isinstance(value, (int, float)) else 0
    prompt = usage.get("prompt_tokens_details") or {}
    completion = usage.get("completion_tokens_details") or {}
    details = {k: number(v) for k, v in usage.items() if isinstance(v, (int, float))}
    details.update({k: number(v) for k, v in completion.items() if isinstance(v, (int, float))})
    return RequestUsage(input_tokens=number(usage.get("prompt_tokens", usage.get("input_tokens", 0))),
                        output_tokens=number(usage.get("completion_tokens", usage.get("output_tokens", 0))),
                        cache_read_tokens=number(prompt.get("cached_tokens", usage.get("cache_read_tokens", 0))),
                        cache_write_tokens=number(usage.get("cache_write_tokens", 0)), details=details)


class PassportChatModel(Model):
    """The existing client supplies mTLS, cache, monitoring and tracing unchanged.

    Pass the already bounded client used by the passport session. The daemon
    bridge bounds caller wait; it cannot cancel an injected synchronous transport.
    Native HTTP cancellation/timeouts remain the configured client's responsibility.
    """

    def __init__(self, *, client: Any, spec: ModelSpec, max_tokens: int = DEFAULT_MAX_TOKENS,
                 deadline: float = 0.0):
        super().__init__(profile={"supports_tools": True, "supports_text_output": True,
                                  "supports_json_schema_output": False, "supported_native_tools": frozenset(),
                                  "supports_forced_tool_choice": False,
                                  "context_window": spec.context_window or None})
        self.client, self.spec = client, spec
        self.max_tokens, self.deadline = max_tokens, deadline
        self._reasoning: dict[str, str] = {}
        self._wire_responses: dict[str, dict[str, Any]] = {}
        # The existing tracer recognizes a session queue by list identity.
        # Its cursor needs rebasing when typed history drops old/ephemeral parts.
        self._wire_messages: list[dict[str, Any]] = []
        self._last_response_id: str | None = None
        self._public_messages: dict[str, dict[str, Any]] = {}
        self._wire_tools: list[dict[str, Any]] = []

    @property
    def model_name(self) -> str:
        return self.spec.model

    @property
    def system(self) -> str:
        return "openai"

    @property
    def base_url(self) -> str:
        return self.spec.base_url

    async def request(self, messages: list[ModelMessage], model_settings: ModelSettings | None,
                      model_request_parameters: ModelRequestParameters) -> ModelResponse:
        check_allow_model_requests()
        settings, params = self.prepare_request(model_settings, model_request_parameters)
        settings = settings or {}
        if params.native_tools:
            raise UserError("PassportChatModel supports function tools, not provider-native tools.")
        instruction_parts = self._get_instruction_parts(messages, params)
        instructions = InstructionPart.join(instruction_parts) if instruction_parts else ""
        wire = to_chat_messages(messages, instructions=instructions or "")
        previous_response = next((i for i, row in enumerate(wire)
                                  if self._last_response_id and row.get(_RESPONSE_ID) == self._last_response_id), None)
        live = {row[_RESPONSE_ID] for row in wire if row.get(_RESPONSE_ID)}
        self._reasoning = {key: value for key, value in self._reasoning.items() if key in live}
        self._wire_responses = {key: value for key, value in self._wire_responses.items() if key in live}
        public_messages = {}
        for index, row in enumerate(wire):
            response_id = row.pop(_RESPONSE_ID, None)
            row.pop(_PUBLIC_RESPONSE, None)
            if response_id:
                previous = self._wire_responses.get(response_id)
                if previous is not None:
                    # ReasoningWindowClient mutates these exact dictionaries and
                    # retains references for provider-requested rollback. Preserve
                    # the identity and any prior trimming across typed round trips.
                    if {key: value for key, value in previous.items() if key != "reasoning_content"} != row:
                        retained = ({"reasoning_content": previous["reasoning_content"]}
                                    if "reasoning_content" in previous else {})
                        previous.clear()
                        previous.update(row)
                        previous.update(retained)
                    wire[index] = previous
                else:
                    if response_id in self._reasoning:
                        row["reasoning_content"] = self._reasoning[response_id]
                    self._wire_responses[response_id] = row
            elif row.get("role") != "assistant":
                # Audit/tracing cache sanitized content by object identity.
                # Reuse only an exactly matching public message; changed text
                # gets a new object and remains visible to the existing audit.
                key = json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
                public_messages[key] = self._public_messages.get(key, row)
                wire[index] = public_messages[key]
        self._public_messages = public_messages  # evict history no longer sent
        self._wire_messages[:] = wire
        wire = self._wire_messages
        if previous_response is not None:
            from pko.llm.tracing import _SESSION
            session = _SESSION.get()
            if session is not None and session.messages is wire:
                # Everything after the last assistant response is new input.
                # +1 keeps the opening receipt intact even if a caller retained
                # only that response and its tool results after compaction.
                session.seen = previous_response + 1
        tools = []
        for tool in [*params.declared_function_tools, *params.output_tools]:
            function = {"name": tool.name, "description": tool.description or "",
                        "parameters": deepcopy(tool.parameters_json_schema)}
            if tool.strict is not None:
                function["strict"] = tool.strict
            tools.append({"type": "function", "function": function})
        if tools != self._wire_tools:
            self._wire_tools = tools
        tools = self._wire_tools
        # There is no adapter retry. Existing ChatClient policy and the Agent's
        # validation retry are independent and retain their original limits.
        result = await _call_in_daemon(lambda: self.client.chat(
            wire, tools=tools or None, temperature=settings.get("temperature", 0.0),
            max_tokens=settings.get("max_tokens", self.max_tokens)), self.deadline)
        parts: list[Any] = [TextPart(result.text)] if result.text else []
        for call in result.tool_calls or []:
            function = call.get("function") or {}
            name = str(function.get("name") or "")
            if call.get("type", "function") != "function" or not name:
                raise LlmError("Модель паспорта вернула некорректный вызов инструмента.")
            parts.append(ToolCallPart(name, function.get("arguments"),
                                      tool_call_id=str(call.get("id") or "call_" + uuid4().hex)))
        if not parts:
            raise LlmError("Модель паспорта вернула пустой ответ без вызова инструмента.")
        response_id = "passport_" + uuid4().hex
        self._last_response_id = response_id
        if result.reasoning_content:
            self._reasoning[response_id] = result.reasoning_content
        return ModelResponse(parts=parts, usage=_usage(result.usage or {}), model_name=self.model_name,
                             # The endpoint may contain credentials in userinfo or
                             # its query. It belongs to the configured transport,
                             # never to persisted public model messages.
                             provider_name=self.system, provider_url=None,
                             provider_response_id=response_id,
                             finish_reason="tool_call" if result.tool_calls else "stop",
                             metadata={"from_cache": bool(result.from_cache)})
