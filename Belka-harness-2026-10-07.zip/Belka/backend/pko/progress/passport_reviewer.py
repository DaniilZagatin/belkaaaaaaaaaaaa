"""Independent, bounded review of versioned passport objects.

The reviewer's context contains the objects, not the researcher's conversation.
Literal provenance is enforced here; semantic agreement remains a model judgment.
``complete`` means every requested version was reviewed, including insufficient ones.
"""
from __future__ import annotations

from contextvars import copy_context
from copy import deepcopy
from dataclasses import dataclass, field
import json
import math
from pathlib import Path
from queue import Empty, Queue
from threading import Thread
import time
from typing import Any, Callable

from pko.audit import AuditedClient, record
from pko.errors import LlmError
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.llm.tracing import TracedClient, trace_client, trace_span, trace_tool_call
from pko.progress.agent_tools import _mask_secrets
from pko.progress.context_window import ReasoningWindowClient
from pko.progress.matcher import _clip, max_tokens_for
from pko.progress.passport_evidence import EvidenceCorpus, READ_SCHEMA, SEARCH_SCHEMA
from pko.progress.passport_fields import field_contract

DEFAULT_MAX_SECONDS = 120.0
MAX_STEPS = 24
MAX_OBJECTS = 12
MAX_INPUT_CHARS = 80_000
MAX_TOOL_CALLS = 48
MAX_ARGUMENT_CHARS = 48_000
MAX_REASON_CHARS = 4000
MAX_EVIDENCE = 12
_PROMPT_PATH = Path(__file__).with_name("passport_reviewer_system.md")
_INTENT_KINDS = frozenset({"intent", "requirement", "scope"})
_PRIVATE_KEYS = frozenset({"reasoning", "reasoning_content", "chain_of_thought"})


def _is_native_create(method: Any) -> bool:
    """A late import must not mistake an already patched transport for native."""
    code = getattr(method, "__code__", None)
    return (getattr(method, "__module__", None) == "pko.llm.client"
            and getattr(method, "__qualname__", None) == "ChatClient._create"
            and code is not None
            and Path(code.co_filename).resolve() == Path(__file__).resolve().parents[1] / "llm" / "client.py")

SUBMIT_CHECKS_SCHEMA = {"type": "function", "function": {
    "name": "submit_checks",
    "description": "Принять результаты независимой проверки объектов. Можно отправлять частями; каждый id и revision проверяется ровно один раз.",
    "parameters": {"type": "object", "additionalProperties": False, "required": ["checks"], "properties": {
        "checks": {"type": "array", "minItems": 1, "maxItems": MAX_OBJECTS, "items": {
            "type": "object", "additionalProperties": False,
            "required": ["object_id", "revision", "result", "reason", "evidence"],
            "properties": {
                "object_id": {"type": "string"},
                "revision": {"anyOf": [{"type": "string", "minLength": 1}, {"type": "integer", "minimum": 1}]},
                "result": {"type": "string", "enum": ["supported", "contradicted", "insufficient"]},
                "reason": {"type": "string", "minLength": 20, "maxLength": MAX_REASON_CHARS},
                "evidence": {"type": "array", "maxItems": MAX_EVIDENCE, "items": {
                    "type": "object", "additionalProperties": False, "required": ["id", "quote"],
                    "properties": {"id": {"type": "string"}, "quote": {"type": "string", "minLength": 1,
                        "description": "Точная цитата из прочитанного фрагмента: минимум 12 символов либо полная короткая строка кода; не пустота или многоточие."}},
                }},
            },
        }},
    }},
}}


def _public_content(value: Any) -> Any:
    """Do not transfer hidden reasoning embedded in submitted object envelopes."""
    if isinstance(value, dict):
        return {key: _public_content(item) for key, item in value.items() if key not in _PRIVATE_KEYS}
    if isinstance(value, list):
        return [_public_content(item) for item in value]
    if isinstance(value, str):
        return "\n".join(_mask_secrets(line) for line in value.splitlines())
    return value


def _prepare_objects(objects: Any) -> tuple[dict[str, dict], list[str]]:
    if not isinstance(objects, list) or len(objects) > MAX_OBJECTS:
        return {}, [f"Проверка принимает массив не более {MAX_OBJECTS} объектов."]
    prepared: dict[str, dict] = {}
    for item in objects:
        if not isinstance(item, dict):
            return {}, ["Объект проверки должен содержать id, revision, kind и content."]
        oid, revision, kind = item.get("id"), item.get("revision"), item.get("kind")
        valid_revision = (type(revision) is int and revision > 0) or (isinstance(revision, str) and bool(revision.strip()))
        if not isinstance(oid, str) or not oid.strip() or oid in prepared or not valid_revision:
            return {}, ["Нужны уникальные непустые id и точные версии revision (строка или положительное целое)."]
        if not isinstance(kind, str) or not kind.strip() or "content" not in item:
            return {}, [f"Объект {oid}: нужны kind и content."]
        prepared[oid] = {"id": oid, "revision": revision, "kind": kind,
                         "content": _public_content(deepcopy(item["content"]))}
        if "prior_findings" in item:
            prior = item["prior_findings"]
            if not isinstance(prior, list) or any(not isinstance(row, dict) for row in prior):
                return {}, [f"Объект {oid}: prior_findings должен быть массивом прежних замечаний."]
            # Historical counterexamples inform the new review, but are neither
            # part of the object's version nor evidence read in this session.
            prepared[oid]["prior_findings"] = _public_content(deepcopy(prior))
    try:
        size = len(json.dumps(list(prepared.values()), ensure_ascii=False, allow_nan=False))
    except (TypeError, ValueError):
        return {}, ["Объекты проверки должны быть конечными JSON-значениями."]
    if size > MAX_INPUT_CHARS:
        return {}, [f"Объекты превышают лимит {MAX_INPUT_CHARS} символов; разделите проверку на меньшие пакеты."]
    return prepared, []


@dataclass
class _ReviewSession:
    objects: dict[str, dict]
    corpus: EvidenceCorpus
    deadline: float
    broker: Any = None
    findings: dict[str, dict] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)
    tool_calls: int = 0

    def pending(self) -> list[dict]:
        return [{"id": oid, "revision": obj["revision"]}
                for oid, obj in self.objects.items() if oid not in self.findings]


def _submit_checks(state: _ReviewSession, args: dict) -> dict:
    checks = args.get("checks")
    if not isinstance(checks, list) or not 1 <= len(checks) <= MAX_OBJECTS or set(args) != {"checks"}:
        return {"ok": False, "errors": [f"Нужен checks: массив из 1–{MAX_OBJECTS} результатов."]}
    accepted, errors = [], []
    for item in checks:
        if not isinstance(item, dict):
            errors.append("Результат должен быть объектом.")
            continue
        oid = item.get("object_id")
        target = state.objects.get(oid) if isinstance(oid, str) else None
        if target is None:
            errors.append("Неизвестный object_id; можно проверять только объекты из задания.")
            continue
        if oid in state.findings:
            errors.append(f"{oid}: результат этой версии уже принят; повтор не заменяет проверку.")
            continue
        if type(item.get("revision")) is not type(target["revision"]) or item["revision"] != target["revision"]:
            errors.append(f"{oid}: revision не совпадает с проверяемой версией.")
            continue
        result, reason, evidence = item.get("result"), item.get("reason"), item.get("evidence")
        if set(item) != {"object_id", "revision", "result", "reason", "evidence"}:
            errors.append(f"{oid}: нужны только object_id, revision, result, reason, evidence.")
            continue
        if result not in ("supported", "contradicted", "insufficient"):
            errors.append(f"{oid}: result — supported, contradicted или insufficient.")
            continue
        if not isinstance(reason, str) or not 20 <= len(reason.strip()) <= MAX_REASON_CHARS:
            errors.append(f"{oid}: объясните вывод и границу проверки (20–{MAX_REASON_CHARS} символов).")
            continue
        if not isinstance(evidence, list) or len(evidence) > MAX_EVIDENCE:
            errors.append(f"{oid}: evidence должен быть массивом не более {MAX_EVIDENCE} цитат.")
            continue
        decisive = result in ("supported", "contradicted")
        intent = target["kind"] in _INTENT_KINDS
        observed = target["kind"] == "observed_outcome"
        source_scope = target["kind"] == "source_scope"
        citation_errors = state.corpus.citations(evidence, code=decisive and not (intent or observed or source_scope), required=decisive)
        if (intent or observed or source_scope) and decisive:
            allowed = ("code", "document") if source_scope else (("document",) if observed else ("intent", "document"))
            for ref in evidence:
                row = state.corpus.records.get(str(ref.get("id"))) if isinstance(ref, dict) else None
                if row is not None and row.get("kind") not in allowed:
                    citation_errors.append("Граница исходного компонента требует его кода/документа, а не ОР или сводки." if source_scope else
                                           "Наблюдённый результат требует документа о выполненной проверке; код и намерение его не доказывают."
                                           if observed else "Обещание подтверждается исходным ОР/document, а не кодом или сводкой.")
        if citation_errors:
            errors.extend(f"{oid}: {error}" for error in citation_errors)
            continue
        clean_reason = _clip(_mask_secrets(reason), MAX_REASON_CHARS)
        if len(clean_reason) < 20:
            errors.append(f"{oid}: после очистки объяснение слишком короткое.")
            continue
        state.findings[oid] = {"object_id": oid, "revision": target["revision"], "result": result,
                               "reason": clean_reason,
                               "evidence": [{"id": ref["id"], "quote": ref["quote"]} for ref in evidence]}
        accepted.append(oid)
    return {"ok": not errors, "accepted": accepted, "errors": errors, "pending": state.pending()}


def _answer_call(state: _ReviewSession, call: dict) -> dict:
    """Every proposed call, including denied calls, gets its own tool result."""
    function = call.get("function") or {}
    name, raw = function.get("name"), function.get("arguments", "{}")
    state.tool_calls += 1
    record("passport_review_tool_call", call=call)
    try:
        if time.monotonic() >= state.deadline:
            result = {"ok": False, "error": "Бюджет времени проверки исчерпан."}
        elif state.tool_calls > MAX_TOOL_CALLS:
            result = {"ok": False, "error": "Бюджет вызовов инструментов проверки исчерпан."}
        elif not isinstance(raw, str) or len(raw) > MAX_ARGUMENT_CHARS:
            result = {"ok": False, "error": "Аргументы должны быть JSON-строкой ограниченного размера."}
        else:
            args = json.loads(raw)
            if not isinstance(args, dict):
                result = {"ok": False, "error": "Аргументы должны быть JSON-объектом."}
            elif name == "read_passport_evidence":
                result = state.corpus.read(args.get("ids"))
            elif name == "search_passport_evidence":
                query, offset = args.get("query"), args.get("offset", 0)
                if not isinstance(query, str) or len(query) > 500 or type(offset) is not int or offset < 0:
                    result = {"ok": False, "error": "Нужны query до 500 символов и целый offset ≥ 0."}
                else:
                    result = state.corpus.index(query, offset)
            elif name == "request_passport_evidence" and state.broker is not None:
                # A broker extends shared records, never this reviewer's shown ledger.
                result = state.broker.request(args)
            elif name == "submit_checks":
                result = _submit_checks(state, args)
            else:
                result = {"ok": False, "error": "Инструмент недоступен независимому проверяющему."}
    except (ValueError, TypeError, KeyError) as exc:
        result = {"ok": False, "error": "Некорректные аргументы инструмента: " + type(exc).__name__}
    except Exception as exc:  # broker failure is an observation, not a fabricated finding
        result = {"ok": False, "error": "Инструмент проверки недоступен: " + type(exc).__name__}
    record("passport_review_tool_result", name=name, result=result)
    return {"role": "tool", "tool_call_id": str(call.get("id") or ""),
            "content": json.dumps(result, ensure_ascii=False)}


class _DeadlineChatClient(ChatClient):
    """Reuse transport/cache settings, with no retries beyond the review budget."""

    def _create(self, payload: dict, extra_body: dict | None = None) -> Any:
        remaining = self._review_deadline - time.monotonic()
        if remaining <= 0:
            raise LlmError("Бюджет времени независимой проверки исчерпан.")
        kwargs = dict(payload)
        if extra_body:
            kwargs["extra_body"] = extra_body
        try:
            return self._client.with_options(timeout=remaining, max_retries=0).chat.completions.create(**kwargs)
        except Exception as exc:
            # Do not copy endpoint responses (which may contain source or secrets).
            raise LlmError("Модель независимой проверки недоступна.", type(exc).__name__) from exc


def _review_client(client: Any, spec: ModelSpec, deadline: float) -> Any:
    # Never reuse the researcher's removed-reasoning buffer or traced message cache.
    audited = False
    while isinstance(client, (ReasoningWindowClient, TracedClient, AuditedClient)):
        audited = audited or isinstance(client, AuditedClient)
        client = client.delegate
    if client is None:
        client = ChatClient(spec=spec, timeout=max(1, math.ceil(deadline - time.monotonic())))
    if not callable(getattr(client, "chat", None)):
        raise LlmError("Клиент не поддерживает chat с инструментами; независимая проверка не выполнена.")
    create_impl = getattr(getattr(client, "_create", None), "__func__", None)
    if type(client) in (ChatClient, _DeadlineChatClient) and (
            _is_native_create(create_impl) or create_impl is _DeadlineChatClient._create):
        local = object.__new__(_DeadlineChatClient)
        local.__dict__.update(client.__dict__)
        local._review_deadline = min(deadline, getattr(client, "_review_deadline", deadline))
        client = local
    if audited:
        client = AuditedClient(client)
    return trace_client(ReasoningWindowClient(client), spec)


def _within_deadline(action: Callable[[], Any], deadline: float) -> Any:
    """Bound caller wait even for transports without a total-request timeout.

    Only the LLM call runs in the worker. All tools and accepted findings stay on
    the caller thread. A late response is discarded and cannot change the review.
    The native transport has its own remaining-time timeout and retries disabled.
    """
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise TimeoutError
    queue: Queue = Queue(maxsize=1)
    context = copy_context()

    def run() -> None:
        try:
            queue.put((True, context.run(action)))
        except Exception as exc:
            queue.put((False, exc))

    Thread(target=run, name="passport-review-call", daemon=True).start()
    try:
        ok, value = queue.get(timeout=remaining)
    except Empty as exc:
        raise TimeoutError from exc
    if time.monotonic() >= deadline:
        raise TimeoutError
    if not ok:
        raise value
    return value


def review_passport_objects(
    objects: list[dict], corpus: EvidenceCorpus, spec: ModelSpec, *, client: Any = None,
    broker: Any = None, max_steps: int = 12, max_seconds: float = DEFAULT_MAX_SECONDS,
) -> dict:
    """Review a bounded packet of exact object versions in a fresh agent loop.

    ``broker.request(args)`` may add immutable records to ``corpus``; it must not
    mark them as read. ``max_seconds=0`` means no remaining budget, not unlimited.
    Unsupported clients, timeouts and malformed model output return partial data.
    """
    targets, notes = _prepare_objects(objects)
    output = {"complete": False, "findings": [], "notes": notes, "steps": 0,
              "reviewer_reads": [], "pending": [], "semantic_truth_verified": False}
    if notes:
        return output
    output["pending"] = [{"id": oid, "revision": obj["revision"]} for oid, obj in targets.items()]
    if not targets:
        output["complete"] = True
        return output
    if type(max_steps) is not int or not isinstance(max_seconds, (int, float)) or isinstance(max_seconds, bool) or not math.isfinite(max_seconds):
        notes.append("Бюджет проверки должен содержать целое число шагов и конечное время в секундах.")
        return output
    if max_steps <= 0 or max_seconds <= 0:
        notes.append("Бюджет независимой проверки исчерпан до запуска.")
        return output
    deadline = time.monotonic() + min(float(max_seconds), 300.0)
    local_corpus = EvidenceCorpus(records=corpus.records, omitted=corpus.omitted, commit=corpus.commit,
                                  included=corpus.included, route_usage=corpus.route_usage)
    state = _ReviewSession(targets, local_corpus, deadline, broker, notes=notes)
    try:
        system = _PROMPT_PATH.read_text(encoding="utf-8")
    except OSError:
        notes.append("Инструкции независимой проверки не найдены: passport_reviewer_system.md.")
        return output
    schemas = [READ_SCHEMA, SEARCH_SCHEMA, SUBMIT_CHECKS_SCHEMA]
    if broker is not None:
        try:
            from pko.progress.passport_broker import BROKER_SCHEMA
        except ImportError:
            notes.append("Инструмент расширения корпуса недоступен; проверка ограничена сохранёнными материалами.")
            state.broker = None
        else:
            schemas.append(BROKER_SCHEMA)
    # Reference meanings are shared once per packet, outside versioned claims.
    # They help distinguish (for example) a business owner from an output field.
    field_catalog = {}
    for obj in targets.values():
        if obj["kind"] not in ("node", "intent"):
            continue
        kind = obj["id"].split("-", 1)[0]
        for item in field_contract(kind)["fields"]:
            field_catalog[item["id"]] = {"label": item["label"], "purpose": item["purpose"]}
    messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": json.dumps({"objects": list(targets.values()),
          "field_catalog": field_catalog,
          "evidence_index": local_corpus.index(), "omitted": corpus.omitted[:30]}, ensure_ascii=False)},
    ]
    malformed = 0
    with trace_span("passport_review_session", objects=len(targets)) as span:
        try:
            chat_client = _review_client(client, spec, deadline)
            if not callable(getattr(chat_client, "chat", None)):
                notes.append("Клиент не поддерживает chat с инструментами; независимая проверка не выполнена.")
            else:
                thinking = bool(getattr(spec, "extra_body", None) and spec.extra_body.get("chat_template_kwargs", {}).get("enable_thinking"))
                for step in range(1, min(max_steps, MAX_STEPS) + 1):
                    if time.monotonic() >= deadline or state.tool_calls >= MAX_TOOL_CALLS:
                        notes.append("Бюджет времени или инструментов независимой проверки исчерпан.")
                        break
                    output["steps"] = step
                    with trace_span("passport_review.step", step=step):
                        result = _within_deadline(lambda: chat_client.chat(messages, tools=schemas,
                                                                         max_tokens=max_tokens_for(thinking)), deadline)
                        calls = getattr(result, "tool_calls", None)
                        if not isinstance(calls, list) or not calls:
                            malformed += 1
                            if malformed >= 3:
                                notes.append("Проверяющий трижды не вызвал инструмент; проверка остановлена.")
                                break
                            messages.append({"role": "user", "content": "Вызови инструмент чтения или submit_checks; текстовый ответ не завершает проверку."})
                            continue
                        if any(not isinstance(c, dict) or not isinstance(c.get("function"), dict) for c in calls):
                            notes.append("Модель вернула некорректный список вызовов инструментов.")
                            break
                        malformed = 0
                        messages.append({"role": "assistant", "content": getattr(result, "text", "") or None,
                                         "tool_calls": calls, "reasoning_content": getattr(result, "reasoning_content", "") or None})
                        for call in calls:
                            messages.append(trace_tool_call(_answer_call, state, call))
                    if not state.pending():
                        break
                else:
                    notes.append("Бюджет шагов независимой проверки исчерпан.")
        except TimeoutError:
            notes.append("Бюджет времени независимой проверки исчерпан; запоздалый ответ не принимается. Внешний запрос может завершиться позже.")
        except LlmError as exc:
            notes.append("Независимая проверка прервана: " + _clip(_mask_secrets(exc.message), 400))
        except Exception as exc:
            notes.append("Независимая проверка прервана: " + type(exc).__name__)
        output.update(complete=not state.pending(), findings=list(state.findings.values()),
                      pending=state.pending(), reviewer_reads=list(local_corpus.shown))
        span.set_attribute("complete", output["complete"])
        span.set_attribute("findings", len(state.findings))
        span.set_attribute("steps_done", output["steps"])
    return output
