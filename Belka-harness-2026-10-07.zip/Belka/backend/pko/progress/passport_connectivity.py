"""Scenario and handoff tools inside the passport's model-directed research loop.

The legacy connectivity gates and schema remain the only source of connectivity
statuses. This adapter adds source-specific references, read provenance, revisions,
and history without importing the passport agent or reading a repository.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field, replace
import json
import re
from typing import Any

from pko.progress.connectivity import (
    CONNECTIVITY_TOOL_SCHEMAS, ConnectivityState, _text_problem, handle_scenarios, handle_trace,
)
from pko.progress.passport_workspace import digest
from pko.progress.schema import (
    CHECK_CONFIDENCE, CHECK_RESULTS, CHECK_SUPPORTS, HANDOFF_CHECKS, HANDOFF_KINDS,
    MAX_SCENARIOS, RESULT_IMAGE_CHECKS, ConnectivityReview, Scenario,
)

MAX_CODE_SCENARIOS = 32

_REF_SCHEMA = {"type": "object", "properties": {
    "id": {"type": "string"}, "quote": {"type": "string", "minLength": 12}},
    "required": ["id", "quote"], "additionalProperties": False}
RESEARCH_CONNECTIVITY_SCHEMAS = deepcopy(CONNECTIVITY_TOOL_SCHEMAS)
_scenarios_tool, _trace_tool = [s["function"] for s in RESEARCH_CONNECTIVITY_SCHEMAS]
_scenarios_tool["description"] = (
    "Объявить или пересмотреть целевые сценарии из точных пунктов ОР. Это upsert: "
    "пропущенные сценарии сохраняются. Для изменения существующего передай id и "
    "его текущую целочисленную revision; новые id выдаёт код. evidence — прочитанный "
    "ОР/document. Изменение сбрасывает трассу; изменение шагов — их привязки."
)
_scenario_schema = _scenarios_tool["parameters"]["properties"]["scenarios"]
_scenario_schema.update(minItems=1, maxItems=MAX_SCENARIOS)
_scenario_schema["items"]["properties"].update({
    "id": {"type": "string", "description": "Существующий scenario-N; при создании не передавать."},
    "revision": {"type": "integer", "minimum": 1, "description": "Текущая версия сценария из ответа инструмента."},
    "evidence": {"type": "array", "minItems": 1, "maxItems": 12, "items": _REF_SCHEMA},
})
_scenario_schema["items"]["required"].append("evidence")
_scenario_schema["items"]["additionalProperties"] = False
_scenarios_tool["parameters"]["additionalProperties"] = False
_trace_tool["description"] = (
    "Заменить всю трассу текущей revision одного сценария. Для каждого перехода "
    "явно исследуй шесть HANDOFF_CHECKS; unknown с конкретной причиной допустим. "
    "ok/broken требуют реально прочитанную цитату и точные path/line/basis. "
    "ОР подтверждает только obligation с support=result_image, не исполнение. "
    "Повторный вызов заменяет текущую трассу, сохраняя историю."
)
_trace_tool["parameters"]["properties"]["revision"] = {
    "type": "integer", "minimum": 1, "description": "Текущая целочисленная версия определения сценария."}
_trace_tool["parameters"]["required"].append("revision")
_trace_tool["parameters"]["additionalProperties"] = False
_handoff_schema = _trace_tool["parameters"]["properties"]["handoffs"]
_handoff_schema.update(minItems=1, maxItems=6)
_handoff_schema["items"]["additionalProperties"] = False
_checks_schema = _handoff_schema["items"]["properties"]["checks"]
_checks_schema.update(minItems=1, maxItems=len(HANDOFF_CHECKS))
_check_schema = _checks_schema["items"]
_check_schema["additionalProperties"] = False
_check_schema["properties"]["evidence"]["maxItems"] = 12
_trace_ref_schema = _check_schema["properties"]["evidence"]["items"]
_trace_ref_schema["properties"].update(deepcopy(_REF_SCHEMA["properties"]))
_trace_ref_schema.update(required=["id", "quote"], additionalProperties=False)
_trace_ref_schema["properties"]["line"]["description"] = "Строка внутри именно этой цитаты; обязательна для code."
RESEARCH_CONNECTIVITY_SCHEMAS.append({"type": "function", "function": {
    "name": "retire_scenario",
    "description": "Отозвать ошибочный сценарий по ОР с сохранением истории. Привязки узлов снимаются; внешние изъяны/риски/утверждения нужно сначала пересмотреть. Решение проверяется независимо.",
    "parameters": {"type": "object", "additionalProperties": False,
        "properties": {"scenario_id": {"type": "string"}, "revision": {"type": "integer", "minimum": 1},
                       "reason": {"type": "string", "minLength": 30},
                       "evidence": {"type": "array", "minItems": 1, "maxItems": 12, "items": _REF_SCHEMA}},
        "required": ["scenario_id", "revision", "reason", "evidence"]}}})


def research_connectivity_schemas(research_basis: str = "result_image") -> list[dict]:
    """Return mode-specific tools without mutating either legacy schema catalog."""
    result = deepcopy(RESEARCH_CONNECTIVITY_SCHEMAS)
    if research_basis == "result_image":
        return result
    if research_basis != "code":
        raise ValueError("research_basis должен быть code или result_image")
    scenarios, trace, retire = [tool["function"] for tool in result]
    scenarios["description"] = (
        "Восстановить или пересмотреть бизнес-сценарии по прочитанному коду и его контрактам. "
        "ОР не определяет состав и не обязателен. Включай только реальные входы и шаги, "
        "существующие в прочитанном коде, в том числе явно объявленный контракт или заглушку. "
        "Не добавляй желаемые действия и идеальную цепочку. Разрыв текущей реализации "
        "сохраняй как находку: необработанный результат существующего вызова не создаёт "
        "новый воображаемый шаг. Ответ заглушки не доказывает исполнение её контракта. Не объявляй "
        "сценарий успешным из-за наличия части реализации: стыки проверяются submit_trace. "
        "Это upsert с устойчивыми ID; изменение требует id/current revision; "
        "пропущенные сценарии сохраняются. evidence — прочитанный code с path/line/basis."
    )
    array = scenarios["parameters"]["properties"]["scenarios"]
    array["maxItems"] = MAX_CODE_SCENARIOS
    item = array["items"]
    item["required"].remove("bullets")
    item["properties"]["bullets"]["description"] = (
        "Необязательные дословные пункты ОР для отдельного сопоставления; не основание сценария и не условие полноты.")
    item["properties"]["outcome"]["description"] = (
        "Результат существующего механизма или его явно объявленного в коде контракта. Укажи границу реализации; вызов не доказывает доставку.")
    item["properties"]["steps"]["description"] = (
        "Только существующие действия, вызовы, контракты или заглушки из прочитанного кода. Отсутствующий желаемый процесс не является шагом текущей карты.")
    item["properties"]["critical"]["description"] = (
        "true — без сценария не выполняется исследуемая бизнес-функция системы; обоснуй по коду/контракту, не по ОР.")
    code_ref = deepcopy(_trace_ref_schema)
    code_ref["required"] = ["id", "quote", "path", "line", "basis"]
    item["properties"]["evidence"]["items"] = deepcopy(code_ref)
    trace["description"] = (
        "Заменить трассу текущей revision бизнес-сценария. Явно исследуй каждый стык "
        "по шести HANDOFF_CHECKS; unknown с границей знания допустим. ok/broken требуют "
        "прочитанный code и точные path/line/basis. obligation — обязательство существующего "
        "механизма или явно объявленного в коде контракта. Исследуй оборванные переходы "
        "текущей реализации; не придумывай отсутствующие процессы, блоки или идеальные шаги. "
        "История прежних трасс сохраняется."
    )
    check = trace["parameters"]["properties"]["handoffs"]["items"]["properties"]["checks"]["items"]
    check["properties"]["support"]["enum"] = [s for s in CHECK_SUPPORTS if s != "result_image"]
    check["properties"]["support"]["description"] = "code — прочитанный механизм/контракт; inference — вывод с обозначенными границами. ОР не подтверждает стык."
    check["properties"]["confidence"]["description"] = "Уверенность вывода; high не отменяет обязательную прочитанную цитату для ok/broken."
    check["properties"]["evidence"]["items"] = deepcopy(code_ref)
    retire["description"] = (
        "Отозвать ошибочный бизнес-сценарий с причиной и прочитанными цитатами кода. "
        "Новый источник может опровергнуть прежнюю интерпретацию. Решение проверяется "
        "независимо; содержательные связанные факты нельзя удалить вместе со сценарием."
    )
    retire["parameters"]["properties"]["evidence"]["items"] = deepcopy(code_ref)
    return result


@dataclass(frozen=True)
class CodeScenario(Scenario):
    """Add provenance to serialization while inheriting all schema calculations."""
    origin: str = "code"

    def to_dict(self) -> dict[str, Any]:
        return {**super().to_dict(), "origin": self.origin}


@dataclass
class CodeConnectivityReview(ConnectivityReview):
    research_basis: str = "code"

    def to_dict(self) -> dict[str, Any]:
        return {**super().to_dict(), "research_basis": self.research_basis}


@dataclass
class ResearchConnectivityState(ConnectivityState):
    research_basis: str = "result_image"
    revisions: dict[str, int] = field(default_factory=dict)
    scenario_evidence: dict[str, list[dict]] = field(default_factory=dict)
    trace_versions: dict[str, int] = field(default_factory=dict)
    trace_submissions: dict[str, list[dict]] = field(default_factory=dict)
    next_id: int = 1


def _basis(state: Any) -> str:
    basis = getattr(state, "research_basis", "result_image")
    if basis not in ("code", "result_image"):
        raise ValueError("research_basis должен быть code или result_image")
    return basis


def _metadata(conn: ResearchConnectivityState) -> dict:
    return {"research_basis": "code", "origin": "code"} if conn.research_basis == "code" else {}


def _get_state(state: Any) -> ResearchConnectivityState:
    current = getattr(state, "connectivity_state", None)
    if current is not None:
        if current.research_basis != _basis(state):
            raise ValueError("основание исследования нельзя менять внутри сессии с прежними сценариями и рецензиями")
        return current
    corpus = getattr(state, "evidence_corpus", None)
    if corpus is None:
        raise ValueError("нужен корпус прочитанных оснований")
    from pko.progress.passport_system_research import evidence_tree
    current = ResearchConnectivityState(
        plan_bullets=list(state.plan_bullets), tree=evidence_tree(corpus),
        source_digest=getattr(state, "research_source_digest", ""),
        research_basis=_basis(state),
    )
    state.connectivity_state = current
    return current


def _definition(scenario: Scenario) -> dict:
    return {"title": scenario.title, "entry": scenario.entry, "outcome": scenario.outcome,
            "steps": list(scenario.steps), "critical": scenario.critical, "bullets": list(scenario.bullets)}


def _intent_refs(state: Any, refs: Any) -> list[str]:
    corpus = state.evidence_corpus
    errors = corpus.citations(refs)
    if isinstance(refs, list):
        for ref in refs:
            if not isinstance(ref, dict):
                continue
            row = corpus.records.get(ref.get("id")) if isinstance(ref.get("id"), str) else None
            if set(ref) != {"id", "quote"}:
                errors.append("основание обещания содержит только id и quote")
            if row is not None and row.get("kind") not in ("intent", "document"):
                errors.append("целевое обещание требует ОР/document, а не кода или сводки")
    return errors


def _scenario_refs(state: Any, conn: ResearchConnectivityState, refs: Any) -> list[str]:
    if conn.research_basis != "code":
        return _intent_refs(state, refs)
    if not isinstance(refs, list):
        return ["нужны прочитанные цитаты code"]
    for ref in refs:
        if not isinstance(ref, dict) or set(ref) - {"id", "quote", "path", "line", "basis", "note"}:
            return ["цитата кода содержит id, quote, path, line, basis и необязательный note"]
        for key in ("basis", "note"):
            if key in ref and (not isinstance(ref[key], str) or len(ref[key]) > 300):
                return [f"{key} основания: текст до 300 символов без скрытого обрезания"]
    from pko.progress.passport_system_research import verified_corpus_evidence
    _, errors = verified_corpus_evidence(state.evidence_corpus, refs)
    return errors


def _code_scenarios(candidates: list[dict], tree: Any) -> list[Scenario]:
    """Reuse text/duplicate restrictions without inventing OR bullets for the gate."""
    accepted, titles, signatures = [], set(), set()
    for index, item in enumerate(candidates, start=1):
        title = item["title"]
        if title.casefold() in titles:
            raise ValueError(f"сценарий «{title}» назван дважды")
        titles.add(title.casefold())
        signature = tuple(re.sub(r"\W+", "", item[key]).casefold() for key in ("entry", "outcome"))
        if signature in signatures:
            raise ValueError(f"сценарий «{title}» повторяет вход и результат другого сценария")
        signatures.add(signature)
        for label, text in ((key, item[key]) for key in ("title", "entry", "outcome")):
            problem = _text_problem(label, text, tree)
            if problem:
                raise ValueError(problem)
        for number, step in enumerate(item["steps"]):
            problem = _text_problem(f"шаг {number}", step, tree)
            if problem:
                raise ValueError(problem)
        accepted.append(CodeScenario(id=f"scenario-{index}", **deepcopy(item)))
    return accepted


def _reject(state: Any, name: str, args: Any, reason: str) -> str:
    state.workspace.event("connectivity_rejected", tool=name, proposal=args, reason=reason)
    return f"{name} отклонён: {reason}"


def _clear_step_bindings(state: Any, sid: str) -> list[dict]:
    removed_scopes = []
    for node in state.nodes.values():
        previous = node.data.get("scenario_steps", [])
        kept = [ref for ref in previous if ref.get("scenario") != sid]
        if previous != kept:
            state.workspace.event("scenario_step_bindings_reset", scenario_id=sid,
                                  node_id=node.id, previous=previous, current=kept)
            node.data["scenario_steps"] = kept
    for target in list(state.workspace.exclusions):
        if target.startswith(f"step:{sid}:"):
            previous = state.workspace.exclusions.pop(target)
            removed_scopes.append({"object_id": "scope:" + target, "decision": deepcopy(previous)})
            state.workspace.event("scenario_step_scope_reset", scenario_id=sid,
                                  previous=previous)
    return removed_scopes


def _refresh_views(state: Any, conn: ResearchConnectivityState) -> None:
    state.scenarios = {sid: list(conn.scenarios[sid].steps) for sid in conn.order}
    state.scenario_context = {sid: {"entry": conn.scenarios[sid].entry, "outcome": conn.scenarios[sid].outcome}
                              for sid in conn.order}
    state.scenario_titles = {sid: conn.scenarios[sid].title for sid in conn.order}


def _scenario_result(conn: ResearchConnectivityState) -> dict:
    return {"ok": True, **_metadata(conn), "scenarios": [
        {"id": sid, **_metadata(conn), "revision": conn.revisions[sid], "title": conn.scenarios[sid].title,
         "steps": list(conn.scenarios[sid].steps), "status": conn.scenarios[sid].status,
         "trace_current": conn.trace_versions.get(sid) == conn.revisions[sid]}
        for sid in conn.order]}


def _submit_scenarios(state: Any, args: dict) -> str:
    conn = _get_state(state)
    raw = args.get("scenarios")
    scenario_limit = MAX_CODE_SCENARIOS if conn.research_basis == "code" else MAX_SCENARIOS
    if set(args) != {"scenarios"} or not isinstance(raw, list) or not 1 <= len(raw) <= scenario_limit:
        raise ValueError(f"scenarios — непустой массив до {scenario_limit} объектов")
    candidates = {sid: _definition(conn.scenarios[sid]) for sid in conn.order}
    sources = deepcopy(conn.scenario_evidence)
    order, seen, next_id = list(conn.order), set(), conn.next_id
    for item in raw:
        allowed = {"id", "revision", "title", "entry", "outcome", "steps", "critical", "bullets", "evidence"}
        required = allowed - {"id", "revision"}
        if conn.research_basis == "code":
            required.discard("bullets")
        if not isinstance(item, dict) or set(item) - allowed or not required <= set(item):
            raise ValueError("нужны " + ", ".join(sorted(required)) + "; id/revision — для изменения")
        for name, limit in (("title", 80), ("entry", 160), ("outcome", 160)):
            if not isinstance(item[name], str) or not item[name].strip() or len(item[name]) > limit:
                raise ValueError(f"{name}: непустой текст до {limit} символов; не обрезай существенные условия")
        steps = item["steps"]
        if (not isinstance(steps, list) or not 2 <= len(steps) <= 7
                or any(not isinstance(s, str) or not s.strip() or len(s) > 160 for s in steps)):
            raise ValueError("steps: 2–7 непустых действий до 160 символов каждое")
        bullets = item.get("bullets", [])
        if (not isinstance(bullets, list) or (not bullets and conn.research_basis != "code")
                or any(not isinstance(b, str) or b not in state.plan_bullets for b in bullets)):
            raise ValueError("каждый bullet должен дословно совпадать с пунктом ОР; частичное совпадение не принимается")
        if type(item["critical"]) is not bool:
            raise ValueError("critical должен быть логическим значением")
        refs = item["evidence"]
        if not isinstance(refs, list) or len(refs) > 12:
            raise ValueError("evidence: до 12 прочитанных цитат основания сценария")
        errors = _scenario_refs(state, conn, refs)
        if errors:
            raise ValueError("; ".join(errors))
        sid = item.get("id")
        if sid is None:
            title = " ".join(item["title"].split()).casefold()
            sid = next((key for key, value in candidates.items() if value["title"].casefold() == title), None)
        elif not isinstance(sid, str) or sid not in conn.scenarios:
            raise ValueError("id должен обозначать существующий сценарий; новый ID выдаёт код")
        if sid is None:
            if "revision" in item:
                raise ValueError("у нового сценария ещё нет revision")
            sid = f"scenario-{next_id}"
            next_id += 1
            order.append(sid)
        if sid in seen:
            raise ValueError(f"{sid} передан дважды в одном пакете")
        seen.add(sid)
        definition = {key: deepcopy(item[key]) for key in required - {"evidence"}}
        definition["bullets"] = deepcopy(bullets)
        for key in ("title", "entry", "outcome"):
            definition[key] = " ".join(definition[key].split())
        definition["steps"] = [" ".join(step.split()) for step in definition["steps"]]
        definition["bullets"] = list(dict.fromkeys(definition["bullets"]))
        if sid in conn.scenarios:
            current = conn.revisions[sid]
            supplied = item.get("revision")
            if "revision" in item and (type(supplied) is not int or supplied != current):
                raise ValueError(f"{sid}: устаревшая revision; текущая — {current}")
            changed = definition != _definition(conn.scenarios[sid]) or refs != sources[sid]
            if changed and (item.get("id") != sid or supplied != current):
                raise ValueError(f"для изменения {sid} нужны его id и текущая revision={current}")
        candidates[sid], sources[sid] = definition, deepcopy(refs)
    if len(order) > scenario_limit:
        raise ValueError(f"после дополнения будет больше {scenario_limit} сценариев; пропущенные не удаляются")
    # Validate the complete resulting set with the existing duplicate/text gates.
    from pko.progress.passport_system_research import evidence_tree
    tree = evidence_tree(state.evidence_corpus)
    if conn.research_basis == "code":
        parsed_scenarios = _code_scenarios([candidates[sid] for sid in order], tree)
    else:
        trial = ConnectivityState(list(state.plan_bullets), tree)
        message = handle_scenarios(trial, {"scenarios": [candidates[sid] for sid in order]})
        if len(trial.order) != len(order):
            raise ValueError(message)
        parsed_scenarios = [trial.scenarios[key] for key in trial.order]
    changed_ids = []
    for sid, parsed in zip(order, parsed_scenarios):
        old = conn.scenarios.get(sid)
        new = replace(parsed, id=sid)
        if old is not None and _definition(old) == _definition(new) and sources[sid] == conn.scenario_evidence[sid]:
            continue
        previous_revision = conn.revisions.get(sid, 0)
        state.workspace.event("scenario_revised", scenario_id=sid, previous=old.to_dict() if old else None,
                              previous_revision=previous_revision, previous_evidence=conn.scenario_evidence.get(sid),
                              current=new.to_dict(), revision=previous_revision + 1, evidence=sources[sid],
                              previous_trace=conn.trace_submissions.get(sid))
        if old is not None and old.steps != new.steps:
            removed_scopes = _clear_step_bindings(state, sid)
            if removed_scopes:
                # An old negative review must not become impossible to resolve
                # merely because its positional step ID no longer exists.
                retirement_id = f"retirement:{sid}:steps:{previous_revision + 1}"
                decision = {"kind": "claim" if conn.research_basis == "code" else "intent",
                    **_metadata(conn), "object_id": removed_scopes[0]["object_id"],
                    "retired_object_ids": [row["object_id"] for row in removed_scopes],
                    "scenario_id": sid, "scenario_revision": previous_revision + 1,
                    "reason": "Шаги сценария пересмотрены; прежние решения об исключении по индексам больше не применяются. Новые шаги требуют новых привязок и проверки.",
                    "evidence": deepcopy(sources[sid]), "previous_scopes": removed_scopes,
                    "previous_scenario": _definition(old), "scenario": _definition(new)}
                state.workspace.retirements[retirement_id] = decision
                state.workspace.event("scenario_step_scope_retirement", retirement_id=retirement_id, decision=decision)
        conn.scenarios[sid] = new
        conn.revisions[sid] = previous_revision + 1
        conn.scenario_evidence[sid] = sources[sid]
        conn.trace_versions.pop(sid, None)
        conn.trace_submissions.pop(sid, None)
        conn.traced.discard(sid)
        changed_ids.append(sid)
    conn.order, conn.next_id = order, next_id
    _refresh_views(state, conn)
    if changed_ids:
        state.risk_reviewed = False
    sync_connectivity_objects(state)
    return json.dumps({**_scenario_result(conn), "changed": changed_ids}, ensure_ascii=False)


def _submit_trace(state: Any, args: dict) -> str:
    conn = _get_state(state)
    sid, revision = args.get("scenario_id"), args.get("revision")
    if set(args) != {"scenario_id", "revision", "handoffs"} or not isinstance(sid, str) or sid not in conn.scenarios:
        raise ValueError("нужны существующий scenario_id, его revision и handoffs")
    if type(revision) is not int or revision != conn.revisions[sid]:
        raise ValueError(f"{sid}: трасса относится к старой версии; текущая revision={conn.revisions[sid]}")
    raw = args["handoffs"]
    if not isinstance(raw, list) or not 1 <= len(raw) <= 6:
        raise ValueError("handoffs: непустой массив до 6 переходов")
    from pko.progress.passport_system_research import evidence_tree, verified_corpus_evidence
    prepared = deepcopy(raw)
    for handoff in prepared:
        if not isinstance(handoff, dict) or set(handoff) != {"step", "kind", "checks"}:
            raise ValueError("каждый переход содержит step, kind и checks")
        if type(handoff["step"]) is not int or handoff["kind"] not in HANDOFF_KINDS:
            raise ValueError("step должен быть целым номером; kind — видом стыка из схемы")
        checks = handoff["checks"]
        if not isinstance(checks, list) or not 1 <= len(checks) <= len(HANDOFF_CHECKS):
            raise ValueError("checks: непустой чек-лист HANDOFF_CHECKS")
        for check in checks:
            if (not isinstance(check, dict) or set(check) - {"check", "result", "note", "support", "confidence", "evidence"}
                    or check.get("check") not in HANDOFF_CHECKS or check.get("result") not in CHECK_RESULTS):
                raise ValueError("нужны известные check/result и поля проверки из схемы")
            if not isinstance(check.get("note", ""), str) or len(check.get("note", "")) > 300:
                raise ValueError("note: конкретное объяснение до 300 символов без обрезания условий")
            if check.get("support", "") not in ("", *CHECK_SUPPORTS) or check.get("confidence", "") not in ("", *CHECK_CONFIDENCE):
                raise ValueError("support/confidence должны соответствовать схеме")
            if conn.research_basis == "code" and check.get("support") == "result_image":
                raise ValueError("в исследовании по коду obligation и остальные стыки требуют кода/контракта; support=result_image недопустим")
            refs = check.get("evidence", [])
            if not isinstance(refs, list) or len(refs) > 12:
                raise ValueError("evidence: массив до 12 цитат")
            for ref in refs:
                if not isinstance(ref, dict) or set(ref) - {"id", "quote", "path", "line", "basis", "note"}:
                    raise ValueError("цитата содержит id, quote и при ссылке на код path, line, basis, note")
                for key in ("basis", "note"):
                    if key in ref and (not isinstance(ref[key], str) or len(ref[key]) > 300):
                        raise ValueError(f"{key} основания: текст до 300 символов без скрытого обрезания")
            decisive = check["result"] in ("ok", "broken")
            if decisive and not refs:
                raise ValueError("ok/broken требует прочитанную цитату; без основания укажи unknown и границу знания")
            if check.get("support") == "result_image":
                if check["check"] not in RESULT_IMAGE_CHECKS or check["result"] == "broken":
                    raise ValueError("образ результата подтверждает только обещание obligation, не выполнение или разрыв")
                errors = _intent_refs(state, refs) if refs else []
                # The legacy gate admits this explicitly limited intent check.
                check["evidence"] = []
            else:
                _, errors = verified_corpus_evidence(state.evidence_corpus, refs) if refs else ([], [])
                check["evidence"] = refs
            if errors:
                raise ValueError("; ".join(errors))
    trial = ConnectivityState(list(conn.plan_bullets), evidence_tree(state.evidence_corpus),
                              scenarios={sid: deepcopy(conn.scenarios[sid])}, order=[sid])
    message = handle_trace(trial, {"scenario_id": sid, "handoffs": prepared})
    if sid not in trial.traced:
        raise ValueError(message)
    updated = trial.scenarios[sid]
    if conn.research_basis == "code":
        updated = CodeScenario(id=updated.id, **_definition(updated), handoffs=updated.handoffs)
    if len(json.dumps(_trace_object(sid, revision, updated, raw), ensure_ascii=False)) > 79_000:
        raise ValueError("трасса слишком велика для независимой проверки; сократи повторяющиеся основания, сохраняя существенные утверждения")
    if conn.trace_versions.get(sid) != revision or conn.trace_submissions.get(sid) != raw:
        state.workspace.event("scenario_trace_revised", scenario_id=sid, revision=revision,
                              previous=conn.scenarios[sid].to_dict(), previous_submission=conn.trace_submissions.get(sid),
                              current=updated.to_dict(), submission=raw)
        conn.scenarios[sid] = updated
        conn.trace_submissions[sid] = deepcopy(raw)
        conn.trace_versions[sid] = revision
        conn.traced.add(sid)
        conn.downgraded += trial.downgraded
        state.risk_reviewed = False
    sync_connectivity_objects(state)
    return json.dumps({"ok": True, **_metadata(conn), "scenario_id": sid, "revision": revision,
                       "status": updated.status, "handoffs": len(updated.handoffs),
                       "transitions": updated.transitions, "blockers": connectivity_blockers(state)}, ensure_ascii=False)


def _contains_reference(value: Any, sid: str) -> bool:
    if isinstance(value, dict):
        return any(_contains_reference(v, sid) for v in value.values())
    if isinstance(value, list):
        return any(_contains_reference(v, sid) for v in value)
    return isinstance(value, str) and value == sid


def _retire_scenario(state: Any, args: dict) -> str:
    conn = _get_state(state)
    sid, revision, reason = args.get("scenario_id"), args.get("revision"), args.get("reason")
    if (set(args) != {"scenario_id", "revision", "reason", "evidence"}
            or not isinstance(sid, str) or sid not in conn.scenarios):
        raise ValueError("нужны существующий scenario_id, revision, reason и evidence")
    if type(revision) is not int or revision != conn.revisions[sid]:
        raise ValueError(f"{sid}: текущая revision={conn.revisions[sid]}")
    if not isinstance(reason, str) or not 30 <= len(reason.strip()) <= 2000:
        raise ValueError("reason: конкретное основание отзыва, 30–2000 символов")
    refs = args["evidence"]
    if not isinstance(refs, list) or len(refs) > 12:
        raise ValueError("evidence: до 12 прочитанных цитат основания отзыва")
    errors = _scenario_refs(state, conn, refs)
    if errors:
        raise ValueError("; ".join(errors))
    for name in ("defects", "risks", "guardrails", "status_disputes"):
        if _contains_reference(getattr(state, name, []), sid):
            raise ValueError(f"{sid} используется в {name}; сначала пересмотри эти ссылки, не удаляя установленных фактов")
    if _contains_reference(state.workspace.claims, sid):
        raise ValueError(f"{sid} используется в claims; сначала пересмотри связанные утверждения")
    decision = {"kind": "claim" if conn.research_basis == "code" else "intent",
                **_metadata(conn), "object_id": "scenario:" + sid,
                "retired_object_ids": ["scenario:" + sid, "trace:" + sid],
                "scenario_id": sid, "scenario_revision": revision,
                "reason": reason.strip(), "evidence": deepcopy(refs),
                "scenario": _definition(conn.scenarios[sid]),
                "trace": deepcopy(conn.trace_submissions.get(sid, []))}
    removed_scopes = _clear_step_bindings(state, sid)
    decision["previous_scopes"] = removed_scopes
    decision["retired_object_ids"].extend(row["object_id"] for row in removed_scopes)
    state.workspace.retirements["retirement:" + sid] = decision
    state.workspace.event("scenario_retired", decision=decision)
    for node in state.nodes.values():
        previous = deepcopy(node.data)
        if sid in node.data.get("scenarios", []):
            node.data["scenarios"] = [s for s in node.data["scenarios"] if s != sid]
        if node.data.get("scenario") == sid:
            node.data.pop("scenario", None)
        if node.data != previous:
            state.workspace.event("scenario_process_binding_reset", scenario_id=sid,
                                  node_id=node.id, previous=previous, current=node.data)
    conn.scenarios.pop(sid)
    conn.order.remove(sid)
    conn.revisions.pop(sid)
    conn.scenario_evidence.pop(sid)
    conn.trace_versions.pop(sid, None)
    conn.trace_submissions.pop(sid, None)
    conn.traced.discard(sid)
    state.risk_reviewed = False
    _refresh_views(state, conn)
    sync_connectivity_objects(state)
    return json.dumps({"ok": True, **_metadata(conn), "retired": sid, "retirement_object": "retirement:" + sid,
                       "blockers": connectivity_blockers(state)}, ensure_ascii=False)


def handle_research_connectivity(state: Any, name: str, args: dict) -> str:
    """Tool handler; rejections preserve prior accepted scenarios and traces."""
    if name not in ("submit_scenarios", "submit_trace", "retire_scenario"):
        return _reject(state, name, args, "неизвестный инструмент связности")
    if not isinstance(args, dict):
        return _reject(state, name, args, "нужен JSON-объект")
    try:
        if len(json.dumps(args, ensure_ascii=False, allow_nan=False)) > 80_000:
            raise ValueError("пакет превышает 80 000 символов")
        return {"submit_scenarios": _submit_scenarios, "submit_trace": _submit_trace,
                "retire_scenario": _retire_scenario}[name](state, args)
    except (ValueError, TypeError, KeyError) as exc:
        return _reject(state, name, args, str(exc))


def connectivity_review(state: Any) -> ConnectivityReview | None:
    conn = getattr(state, "connectivity_state", None)
    review = deepcopy(conn.review()) if conn is not None else None
    if review is not None and conn.research_basis == "code":
        return CodeConnectivityReview(scenarios=review.scenarios, source_digest=review.source_digest, basis=review.basis)
    return review


def connectivity_blockers(state: Any) -> list[str]:
    """Research completeness only: unknown/broken are valid disclosed results."""
    if not getattr(state, "research_enabled", False):
        return []
    conn = getattr(state, "connectivity_state", None)
    if conn is None or not conn.declared:
        if _basis(state) == "code":
            return ["Бизнес-сценарии не исследованы: вызови submit_scenarios по прочитанному коду и контрактам."]
        return ["Целевые сценарии не исследованы: вызови submit_scenarios по исходному ОР."]
    if conn.research_basis != _basis(state):
        return ["Основание исследования изменено; прежние сценарии и рецензии не подтверждают новый режим."]
    errors = []
    covered = {bullet for scenario in conn.scenarios.values() for bullet in scenario.bullets}
    for index, bullet in enumerate(state.plan_bullets):
        exclusion = state.workspace.exclusions.get(f"bullet:{index}", {})
        if conn.research_basis != "code" and bullet not in covered and exclusion.get("disposition") != "excluded":
            errors.append(f"Пункт ОР bullet:{index} не представлен целевым сценарием и не исключён с основанием.")
    for sid in conn.order:
        scenario = conn.scenarios[sid]
        if conn.trace_versions.get(sid) != conn.revisions[sid]:
            errors.append(f"{sid}: нет трассы текущей revision={conn.revisions[sid]}.")
            continue
        for step in range(scenario.transitions):
            handoff = scenario.handoff_at(step)
            present = {c.check for c in handoff.checks} if handoff is not None else set()
            missing = [check for check in HANDOFF_CHECKS if check not in present]
            if missing:
                errors.append(f"{sid}, переход {step}: явно не исследованы " + ", ".join(missing) + ".")
    return errors


def _trace_object(sid: str, revision: int, scenario: Scenario, submission: list[dict]) -> dict:
    # Review needs canonical conclusions and source addresses, not two copies of
    # long quotations. Exact originals remain in the ledger and immutable corpus.
    # A submission hash still invalidates a receipt when its quoted spans change.
    references = {(handoff["step"], check["check"]): check.get("evidence", [])
                  for handoff in submission for check in handoff["checks"]}
    metadata = {"origin": "code", "research_basis": "code"} if isinstance(scenario, CodeScenario) else {}
    return {"scenario_id": sid, **metadata, "scenario_revision": revision,
            "scenario": _definition(scenario), "submission_sha256": digest(submission),
            "handoffs": [{"step": h.step, "kind": h.kind, "basis": h.basis, "result": h.result,
                "checks": [{"check": c.check, "result": c.result, "note": c.note,
                    "support": c.support, "confidence": c.confidence,
                    "evidence": [{key: value for key, value in ref.items()
                                  if key in {"id", "path", "line", "basis", "note"}}
                                 for ref in references.get((h.step, c.check), [])]}
                           for c in h.checks]} for h in scenario.handoffs]}


def sync_connectivity_objects(state: Any) -> set[str]:
    """Return live IDs for workspace.sync_objects, without dependency cycles.

    The caller adds scenario/trace revisions to the hashes of linked passport
    nodes. This module never mutates their business content during synchronization.
    """
    conn = getattr(state, "connectivity_state", None)
    if conn is None:
        return set()
    live = set()
    for sid in conn.order:
        scenario = conn.scenarios[sid]
        oid = "scenario:" + sid
        live.add(oid)
        state.workspace.put(oid, "claim" if conn.research_basis == "code" else "intent",
                            {"scenario_id": sid, **_metadata(conn), "scenario_revision": conn.revisions[sid],
                                             **_definition(scenario), "evidence": conn.scenario_evidence[sid]})
        if conn.trace_versions.get(sid) == conn.revisions[sid]:
            oid = "trace:" + sid
            live.add(oid)
            state.workspace.put(oid, "claim", _trace_object(sid, conn.revisions[sid], scenario, conn.trace_submissions[sid]))
    for oid in list(state.workspace.objects):
        if oid.startswith(("scenario:", "trace:")) and oid not in live:
            state.workspace.event("object_retired", object=state.workspace.objects.pop(oid))
            state.workspace.reviews.pop(oid, None)
    return live
