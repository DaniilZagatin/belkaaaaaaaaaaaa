"""Детерминированные факты для паспорта поверх фактов экстракторов.

Считаются в паспортном этапе, после ранней выдачи дашборда: входы ревьюера
(факты, карта возможностей, инструменты) не меняются.

* **Вызовы маршрутов из интерфейса.** Фронтенд Белка не разбирает, поэтому
  объявленный backend-маршрут выглядел «достижимым», даже когда интерфейс
  его не вызывает. Здесь маршруты сопоставляются с HTTP-вызовами во
  фронтенд-файлах; локальные константы и простые шаблоны URL разрешаются
  статически, без исполнения кода.
* **Возможности системы** — маршруты, задания, инструменты, узлы графа: по
  ним код проверяет, что паспорт рассмотрел всё, что система умеет
  (обратное сопоставление «код → паспорт»).
* **Факты экспозиции** — вызовы модели и внешних систем, значения по
  умолчанию настроек контура, предупреждения пользователю: без них чек-лист
  рисков не видит, куда уходят данные.

Всё это сигналы, а не приговоры: URL, собранный динамически, вызов через
реестр или конфигурацию статический поиск не видит. «Не найден» — повод
проверить, а не доказательство отсутствия.
"""

from __future__ import annotations

import re
from bisect import bisect_left
from dataclasses import dataclass, field
from typing import Any, Iterable

from pko.progress.passport_source import allowed_source_path, available_source_path

FRONTEND_SUFFIXES = (".js", ".jsx", ".ts", ".tsx", ".vue", ".svelte", ".mjs", ".cjs")
_FRONTEND_SKIP_PARTS = ("node_modules/", "/dist/", "/build/", "/.next/", "/coverage/",
                        "/vendor/", "/__tests__/", "/__mocks__/", "/e2e/", "/cypress/")
_FRONTEND_TEST_RE = re.compile(r"\.(test|spec|stories)\.[jt]sx?$|\.min\.[jt]s$")
# Потолки обхода: сигнал должен считаться за секунды и на большом монорепо.
MAX_FRONTEND_FILES = 3000
MAX_FILE_CHARS = 1_500_000
MAX_CALLS_PER_ROUTE = 5
# Сколько возможностей код предъявляет паспортному агенту для обратного
# сопоставления: остальные учитываются в счётчике, но не в списке.
MAX_CAPABILITIES = 40
# Виды фактов-возможностей по убыванию приоритета.
CAPABILITY_KINDS = ("ROUTE", "JAVA_JOB", "ENTRYPOINT", "TOOL", "GRAPH_NODE")
CAPABILITY_KIND_LABEL = {
    "ROUTE": "HTTP-маршрут",
    "JAVA_JOB": "задание по расписанию",
    "ENTRYPOINT": "точка входа",
    "TOOL": "инструмент агента",
    "GRAPH_NODE": "узел графа исполнения",
}
# Причины, по которым возможность сознательно не входит в паспорт.
DISMISS_REASONS = {
    "auxiliary": "вспомогательная или техническая",
    "admin": "администрирование и сопровождение",
    "legacy": "устаревшая или не вызывается",
    "out_of_scope": "вне результата инициативы",
    "duplicate": "дублирует другую возможность",
}
MAX_EXPOSURES = 40
# Сколько фактов внешнего вызова обязаны получить ссылку в чек-листе рисков.
MAX_REQUIRED_EXPOSURES = 8
_REQUIRED_EXTERNAL_MECHANISMS = ("llm", "http_client")

_JS_TOKEN_RE = re.compile(
    r"//[^\n]*|/\*[\s\S]*?\*/|<!--[^>]*-->|"
    r"'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\"|`(?:\\.|[^`\\])*`|"
    r"[A-Za-z_$][\w$]*|\d+(?:\.\d+)?|=>|\.\.\.|\S"
)
_HTTP_METHODS = frozenset({"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"})
_HTTP_CLIENT_RE = re.compile(r"(?:axios|api|client|http|request)", re.I)
_HTTP_WRAPPER_RE = re.compile(r"(?:fetch|request)$", re.I)
_JS_IDENTIFIER_RE = re.compile(r"^[A-Za-z_$][\w$]*$")
_PARAM_RE = re.compile(r"^(\{[^}]*\}|<[^>]*>|:\w+|\*)$")
_PY_DEF_RE = re.compile(r"^(\s*)(?:async\s+)?def\s+(\w+)")
_JAVA_DEF_RE = re.compile(r"^(\s*)(?:public|private|protected)\s[\w<>\[\],.\s]*?(\w+)\s*\(")
_ENV_DEFAULT_RE = re.compile(
    r"""os\.(?:getenv|environ\.get)\(\s*['"]([A-Z][A-Z0-9_]{2,60})['"]\s*,\s*([^)\n]{1,80})\)""")
_ENV_INTERESTING = re.compile(
    r"ENV|DEPLOY|CONTOUR|CIRCUIT|BASE_URL|_URL|ENDPOINT|HOST|PROVIDER|MODEL|RETR|TIMEOUT|MTLS|TLS|"
    r"INTERNAL|EXTERNAL|REGION|LLM|OPENAI|ROUTER|PROXY")
_ENV_SECRET = re.compile(r"KEY|TOKEN|SECRET|PASSWORD|PASSWD|PASS\b|CREDENTIAL|PRIVATE")
_UI_WARNING_RE = re.compile(
    r"конфиденциальн|персональн\w* данн|не загружайте|коммерческ\w* тайн|confidential|sensitive data|"
    r"do not upload|personal data", re.IGNORECASE)
_DOC_MARKER_RE = re.compile(
    r"внешн\w*\s+контур|внутренн\w*\s+контур|DEPLOYMENT_ENV|внешн\w*\s+провайдер|external\s+provider",
    re.IGNORECASE)
MAX_UI_WARNINGS = 10
MAX_DOC_MARKERS = 8
MAX_ENV_DEFAULTS = 30


# --- общие утилиты ---------------------------------------------------------------

def is_frontend_file(path: str) -> bool:
    if not allowed_source_path(path):
        return False
    low = "/" + path.lower()
    if not low.endswith(FRONTEND_SUFFIXES):
        return False
    if any(part in low for part in _FRONTEND_SKIP_PARTS):
        return False
    return not _FRONTEND_TEST_RE.search(low)


def _is_vendor(path: str) -> bool:
    try:
        from pko.extractors.base import is_vendor
    except ImportError:  # pragma: no cover — экстракторы поставляются вместе
        return False
    return is_vendor(path)


def _read(tree: Any, path: str) -> str:
    if not available_source_path(tree, path):
        return ""
    try:
        text = tree.read(path)
    except Exception:  # noqa: BLE001 — нечитаемый файл просто не даёт сигнала
        return ""
    if not isinstance(text, str) or len(text) > MAX_FILE_CHARS:
        return ""
    return text


def _mask(text: str) -> str:
    from pko.progress.agent_tools import _mask_secrets
    return _mask_secrets(text)


def _segments(path: str) -> list[str]:
    path = re.sub(r"^[a-z]+://[^/]+", "", str(path).strip(), flags=re.IGNORECASE)
    path = path.split("?", 1)[0].split("#", 1)[0]
    return [s for s in path.strip("/").split("/") if s]


def _is_param(segment: str) -> bool:
    return bool(_PARAM_RE.match(segment)) or "${" in segment or "{" in segment


def _static(segments: list[str]) -> list[str]:
    return [s for s in segments if not _is_param(s)]


def _same(route: list[str], literal: list[str]) -> bool:
    if len(route) != len(literal):
        return False
    shared_static = 0
    for a, b in zip(route, literal):
        if _is_param(a):
            continue
        # A dynamic frontend segment cannot establish a specific static route.
        if _is_param(b):
            return False
        if a != b:
            return False
        shared_static += 1
    return shared_static > 0


def _line_of(text: str, index: int) -> int:
    return text.count("\n", 0, index) + 1


def _declaration_span(text: str, line: int, path: str = "") -> tuple[int, int, str]:
    """Строки объявления, начинающегося у `line` (декоратор допустим), и имя.

    Конец — последняя строка перед кодом с отступом не больше, чем у `def`.
    Разбор приблизительный: он нужен, чтобы понять, цитирует ли узел код
    именно этой возможности, а не соседней.
    """
    lines = text.splitlines()
    if not 1 <= line <= len(lines):
        return line, line, ""
    pattern = _JAVA_DEF_RE if path.endswith((".java", ".kt")) else _PY_DEF_RE
    start = line
    def_index, indent, name = None, 0, ""
    for index in range(line - 1, min(len(lines), line + 6)):
        match = pattern.match(lines[index])
        if match:
            def_index = index
            indent = len(match.group(1) or "")
            name = match.group(2) or ""
            break
    if def_index is None:
        return start, start, ""
    end = def_index + 1
    for index in range(def_index + 1, min(len(lines), def_index + 400)):
        raw = lines[index]
        stripped = raw.strip()
        if not stripped or stripped.startswith(("#", "//", "*")):
            continue
        if len(raw) - len(raw.lstrip()) <= indent and not stripped.startswith((")", "}", "]")):
            break
        end = index + 1
    return start, max(start, end), name


# --- вызовы маршрутов из интерфейса ------------------------------------------------

@dataclass(frozen=True)
class _JsToken:
    text: str
    start: int
    scope: tuple[int, ...]


class _FrontendCalls:
    """Small conservative JS/TS reader, not a JavaScript evaluator.

    Only URL expressions passed to recognizable HTTP calls are considered.
    Comments and string contents are never searched for calls. Bindings stay
    within their lexical scope; mutable or unresolved prefixes stay unknown.
    Imported configuration and arbitrary helper execution are deliberately not
    inferred. A call site is evidence of a static call, not runtime execution.
    """

    def __init__(self, text: str):
        self.text = text
        self.tokens: list[_JsToken] = []
        scopes: list[int] = []
        self.bindings: dict[str, list[tuple[int, int, int, bool]]] = {}
        self.parameter_spans: dict[str, list[tuple[int, int]]] = {}
        self.pairs: dict[int, int] = {}
        opened: list[int] = []
        for match in _JS_TOKEN_RE.finditer(text):
            value = match.group()
            if value.startswith(("//", "/*", "<!--")):
                continue
            if value == "}" and scopes:
                scopes.pop()
            index = len(self.tokens)
            self.tokens.append(_JsToken(value, match.start(), tuple(scopes)))
            if value in ("(", "[", "{"):
                opened.append(index)
            elif value in (")", "]", "}") and opened:
                left = opened.pop()
                if self.tokens[left].text == {")": "(", "]": "[", "}": "{"}[value]:
                    self.pairs[left] = index
            if value == "{":
                scopes.append(match.start())
        for index, token in enumerate(self.tokens[:-2]):
            if token.text not in ("const", "let", "var"):
                continue
            name = self.tokens[index + 1].text
            if not _JS_IDENTIFIER_RE.fullmatch(name):
                continue
            start = index + 2
            # Optional TypeScript annotation on a simple local binding.
            if self.tokens[start].text == ":":
                while start < len(self.tokens) and self.tokens[start].text not in ("=", ";", "{"):
                    start += 1
            if start >= len(self.tokens) or self.tokens[start].text != "=":
                continue
            start += 1
            end = self._expression_end(start)
            self.bindings.setdefault(name, []).append((index, start, end, token.text == "const"))
        # Function parameters shadow outer constants. Do not resolve a global
        # API prefix through a parameter of the same name.
        for left, right in self.pairs.items():
            if self.tokens[left].text != "(" or right + 1 >= len(self.tokens):
                continue
            body = right + 2 if self.tokens[right + 1].text == "=>" else right + 1
            if body + 1 >= len(self.tokens):
                continue
            if left and self.tokens[left - 1].text in ("if", "while", "switch", "for", "with"):
                continue
            arrow_expression = self.tokens[right + 1].text == "=>" and self.tokens[body].text != "{"
            if self.tokens[body].text != "{" and not arrow_expression:
                continue
            for first, last in self._split(left + 1, right):
                name = self.tokens[first].text
                if _JS_IDENTIFIER_RE.fullmatch(name):
                    if arrow_expression:
                        self.parameter_spans.setdefault(name, []).append((body, self._expression_end(body)))
                    else:
                        self.bindings.setdefault(name, []).append((body + 1, first, last, False))
        for index in range(1, len(self.tokens) - 1):
            if self.tokens[index].text == "=>" and _JS_IDENTIFIER_RE.fullmatch(self.tokens[index - 1].text):
                name = self.tokens[index - 1].text
                body = index + 1
                if self.tokens[body].text == "{" and body + 1 < len(self.tokens):
                    self.bindings.setdefault(name, []).append((body + 1, index - 1, index, False))
                else:
                    self.parameter_spans.setdefault(name, []).append((body, self._expression_end(body)))

    def _expression_end(self, start: int) -> int:
        index = start
        while index < min(len(self.tokens), start + 1000):
            token = self.tokens[index]
            if token.text in (";", ",", "}"):
                break
            if index > start:
                previous = self.tokens[index - 1]
                gap = self.text[previous.start + len(previous.text):token.start]
                if "\n" in gap and previous.text not in ("+", "=", ".", "?") and token.text not in ("+", ".", "?", "("):
                    break
            if index in self.pairs:
                index = self.pairs[index] + 1
            else:
                index += 1
        return index

    def _binding(self, name: str, at: int) -> tuple[int, int, int, bool] | None:
        if any(start <= at < end for start, end in self.parameter_spans.get(name, [])):
            return None
        scope = self.tokens[at].scope
        visible = [row for row in self.bindings.get(name, [])
                   if row[0] <= at and scope[:len(self.tokens[row[0]].scope)] == self.tokens[row[0]].scope]
        return max(visible, key=lambda row: (len(self.tokens[row[0]].scope), row[0])) if visible else None

    def _split(self, start: int, end: int, separator: str = ",") -> list[tuple[int, int]]:
        spans = []
        left = index = start
        while index < end:
            if self.tokens[index].text == separator:
                spans.append((left, index))
                left = index + 1
            if index in self.pairs:
                index = self.pairs[index] + 1
            else:
                index += 1
        if left < end:
            spans.append((left, end))
        return spans

    def value(self, start: int, end: int, at: int, depth: int = 0) -> str | None:
        if depth > 8 or start >= end:
            return None
        while self.tokens[start].text == "(" and self.pairs.get(start) == end - 1:
            start, end = start + 1, end - 1
        pieces = self._split(start, end, "+")
        if len(pieces) > 1:
            values = [self.value(a, b, at, depth + 1) for a, b in pieces]
            return "".join(values) if all(v is not None for v in values) else None
        if end - start != 1:
            # A URL parameter encoded by the caller is still a parameter, not a
            # guessed constant. Unknown arbitrary expressions stay unresolved.
            if self.tokens[start].text == "encodeURIComponent" and self.pairs.get(start + 1) == end - 1:
                return "{param}"
            return None
        token = self.tokens[start].text
        if token.startswith(("'", '"', "`")):
            raw = token[1:-1]
            raw = re.sub(r"\\([\\/'\"`])", r"\1", raw)
            if token.startswith("`"):
                def substitute(match: re.Match) -> str:
                    name = match.group(1).strip()
                    if _JS_IDENTIFIER_RE.fullmatch(name):
                        binding = self._binding(name, at)
                        if binding and binding[3]:
                            resolved = self.value(binding[1], binding[2], binding[0], depth + 1)
                            if resolved is not None:
                                return resolved
                    return "{param}"
                raw = re.sub(r"\$\{([^{}]*)\}", substitute, raw)
                if "${" in raw:
                    return None
            return raw
        if _JS_IDENTIFIER_RE.fullmatch(token):
            binding = self._binding(token, at)
            if binding and binding[3]:
                return self.value(binding[1], binding[2], binding[0], depth + 1)
            return "{param}"
        return token if token.isdigit() else None

    def property(self, start: int, end: int, name: str, at: int, depth: int = 0) -> tuple[str | None, bool]:
        """Return value and whether the option was explicitly present."""
        if depth > 8:
            return None, True
        if end - start == 1:
            binding = self._binding(self.tokens[start].text, at)
            if binding and binding[3]:
                return self.property(binding[1], binding[2], name, binding[0], depth + 1)
        if start >= end or self.tokens[start].text != "{" or self.pairs.get(start) != end - 1:
            return None, True  # Unknown options may override method or base URL.
        result: tuple[str | None, bool] = (None, False)
        for left, right in self._split(start + 1, end - 1):
            key = self.tokens[left].text.strip("'\"")
            if key == "...":
                result = (None, True)
            elif key == name and left + 1 < right and self.tokens[left + 1].text == ":":
                result = (self.value(left + 2, right, at), True)
            elif key == name and left + 1 == right:
                result = (self.value(left, right, at), True)
        return result

    def _client_base(self, receiver: str, at: int) -> str | None:
        binding = self._binding(receiver, at)
        if not binding or not binding[3]:
            return None
        start, end = binding[1:3]
        # axios.create({baseURL: API}); no project-wide prefix guessing.
        if start + 4 < end and [t.text for t in self.tokens[start:start + 4]] == ["axios", ".", "create", "("]:
            close = self.pairs.get(start + 3)
            if close is not None:
                base, _ = self.property(start + 4, close, "baseURL", binding[0])
                return base
        return None

    def calls(self) -> Iterable[tuple[int, str | None, str | None]]:
        for index, token in enumerate(self.tokens):
            if not _JS_IDENTIFIER_RE.fullmatch(token.text):
                continue
            if index and self.tokens[index - 1].text in (".", "function", "new"):
                continue
            cursor = index + 1
            names = [token.text]
            while cursor + 1 < len(self.tokens) and self.tokens[cursor].text == ".":
                names.append(self.tokens[cursor + 1].text)
                cursor += 2
            if cursor not in self.pairs or self.tokens[cursor].text != "(":
                continue
            args = self._split(cursor + 1, self.pairs[cursor])
            if not args:
                continue
            leaf, receiver = names[-1], names[0]
            base = self._client_base(receiver, index)
            client_method = (leaf.upper() in _HTTP_METHODS and len(names) > 1
                             and (base is not None or _HTTP_CLIENT_RE.search(".".join(names[:-1]))))
            direct = (leaf in ("fetch", "$fetch", "axios", "api") or _HTTP_WRAPPER_RE.search(leaf))
            if not client_method and not direct:
                continue
            method: str | None = leaf.upper() if client_method else None
            if self.tokens[args[0][0]].text == "{":
                url, _ = self.property(*args[0], "url", index)
                option_method, present = self.property(*args[0], "method", index)
                method = option_method.upper() if option_method and option_method.upper() in _HTTP_METHODS else None
                if not present and leaf == "axios":
                    method = "GET"
            else:
                url = self.value(*args[0], index)
                # request('POST', '/path') is a common thin client wrapper.
                if url in _HTTP_METHODS and len(args) > 1:
                    method, url = url, self.value(*args[1], index)
                elif not client_method:
                    option_method, present = self.property(*args[1], "method", index) if len(args) > 1 else (None, False)
                    method = option_method.upper() if option_method and option_method.upper() in _HTTP_METHODS else None
                    if not present and (leaf == "axios" or leaf == "fetch" and
                                        (len(names) == 1 or receiver in ("window", "globalThis"))):
                        method = "GET"
            if url and base and url.startswith("/") and not url.startswith("//"):
                url = base.rstrip("/") + url
            if not url or not re.match(r"^(?:https?://[^/]+)?/", url) or "{param}" in url.split("/", 3)[0]:
                yield token.start, None, method
            else:
                yield token.start, url, method


def _route_prefix(text: str, line: int) -> str:
    """Resolve a local Python APIRouter prefix without changing extractors."""
    lines = text.splitlines()
    decorator = lines[line - 1] if 0 < line <= len(lines) else ""
    match = re.search(r"@([A-Za-z_]\w*)\.(?:get|post|put|patch|delete|head|options)\(", decorator)
    if not match:
        return ""
    assignment = re.search(r"(?m)^\s*" + re.escape(match.group(1)) + r"\s*=\s*APIRouter\(([^)]*)\)", text)
    if not assignment:
        return ""
    prefix = re.search(r"\bprefix\s*=\s*(['\"])(/[^'\"]*)\1", assignment.group(1))
    return prefix.group(2).rstrip("/") if prefix else ""


@dataclass
class RouteInfo:
    key: str
    method: str
    path: str
    decl_path: str
    decl_line: int
    handler: str = ""
    calls: list[dict[str, Any]] = field(default_factory=list)

    @property
    def called(self) -> bool:
        return bool(self.calls)


@dataclass
class RouteUsage:
    frontend_files: int = 0
    scanned_files: int = 0
    truncated: bool = False
    routes: list[RouteInfo] = field(default_factory=list)
    unresolved_calls: int = 0
    skipped_files: list[str] = field(default_factory=list)

    @property
    def frontend_present(self) -> bool:
        return self.frontend_files > 0

    def route_at(self, path: str, line: int, window: int = 2) -> RouteInfo | None:
        for route in self.routes:
            if route.decl_path == path and abs(route.decl_line - line) <= window:
                return route
        return None

    def digest(self, limit: int = 60) -> str:
        if not self.routes:
            return ""
        if not self.frontend_present:
            return ("Вызовы маршрутов из интерфейса: фронтенд в переданных материалах не найден — "
                    "клиентский вызов маршрутов не проверялся; маршрут остаётся точкой входа для внешних клиентов.")
        called = sum(1 for r in self.routes if r.called)
        lines = [f"Вызовы маршрутов из интерфейса (статический разбор HTTP-вызовов в {self.scanned_files} "
                 f"фронтенд-файлах; «не найден» — сигнал, не доказательство): найдено {called} из {len(self.routes)}."]
        for route in self.routes[:limit]:
            if route.called:
                where = ", ".join(f"{c['path']}:{c['line']}" for c in route.calls[:3])
                lines.append(f"- {route.key} → вызывается: {where}")
            else:
                lines.append(f"- {route.key} → во фронтенде не найден")
        if len(self.routes) > limit:
            lines.append(f"… ещё {len(self.routes) - limit} маршрутов")
        if self.unresolved_calls or self.skipped_files or self.truncated:
            lines.append(f"Границы поиска: URL не разрешён у {self.unresolved_calls} вызовов; "
                         f"не прочитано файлов — {len(self.skipped_files)}; "
                         f"лимит обхода {'достигнут' if self.truncated else 'не достигнут'}.")
        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        return {
            "frontend_files": self.frontend_files,
            "scanned_files": self.scanned_files,
            "truncated": self.truncated,
            "unresolved_calls": self.unresolved_calls,
            "skipped_files": self.skipped_files,
            "routes_total": len(self.routes),
            "routes_called": sum(1 for r in self.routes if r.called),
            "routes": [{"key": r.key, "declared": f"{r.decl_path}:{r.decl_line}",
                        "called": r.called, "calls": [f"{c['path']}:{c['line']}" for c in r.calls],
                        "call_details": r.calls}
                       for r in self.routes],
            "scope": ("Статический разбор HTTP-вызовов, локальных const и шаблонов URL. "
                      "Неизвестные выражения, импорты и достижимость самих вызывающих функций не доказаны."),
        }


def route_usage(tree: Any, facts: Iterable[Any]) -> RouteUsage:
    """Сопоставить backend-маршруты с URL и методом статических HTTP-вызовов."""
    usage = RouteUsage()
    seen: set[tuple[str, str, int]] = set()
    route_segments: list[tuple[RouteInfo, list[str]]] = []
    for fact in facts:
        if getattr(fact, "kind", "") != "ROUTE" or not available_source_path(tree, getattr(fact, "path", "")):
            continue
        value = fact.value if isinstance(fact.value, dict) else {}
        path = str(value.get("path") or fact.key.split(" ", 1)[-1] or "")
        method = str(value.get("method") or fact.key.split(" ", 1)[0] or "")
        line = int(fact.line or 0)
        marker = (fact.path, path, line)
        if marker in seen or not _static(_segments(path)):
            continue
        seen.add(marker)
        text = _read(tree, fact.path)
        _, _, handler = _declaration_span(text, line, fact.path) if text and line else (0, 0, "")
        route = RouteInfo(key=f"{method} {path}".strip(), method=method.upper(), path=path,
                          decl_path=fact.path, decl_line=line, handler=handler)
        usage.routes.append(route)
        prefix = _route_prefix(text, line)
        route_segments.append((route, _segments(prefix + path)))
    files = [p for p in getattr(tree, "files", []) if is_frontend_file(p)]
    usage.frontend_files = len(files)
    if not usage.routes or not files:
        return usage
    if len(files) > MAX_FRONTEND_FILES:
        usage.truncated = True
        files = files[:MAX_FRONTEND_FILES]
    calls: list[tuple[str, int, list[str], str | None, str, str]] = []
    for path in files:
        text = _read(tree, path)
        if not text:
            usage.skipped_files.append(path)
            continue
        # Бандл без переносов строк — сборка, а не исходник.
        if len(text) > 20000 and text.count("\n") < len(text) / 2000:
            usage.skipped_files.append(path)
            continue
        usage.scanned_files += 1
        source_lines = text.splitlines()
        breaks = [i for i, ch in enumerate(text) if ch == "\n"]
        for start, url, method in _FrontendCalls(text).calls():
            if url is None:
                usage.unresolved_calls += 1
                continue
            segments = _segments(url)
            if not segments or not _static(segments):
                continue
            line = bisect_left(breaks, start) + 1
            snippet = source_lines[line - 1].strip()[:160] if line <= len(source_lines) else ""
            calls.append((path, line, segments, method, _mask(snippet), _mask(url)))
    # Индекс по статическим сегментам: маршрут сравнивается только с
    # литералами, где встречается его последний статический сегмент.
    by_segment: dict[str, list[int]] = {}
    for index, (_, _, segs, _, _, _) in enumerate(calls):
        for segment in set(_static(segs)):
            by_segment.setdefault(segment, []).append(index)
    for route, segs in route_segments:
        for index in by_segment.get(_static(segs)[-1], []):
            path, line, lit, method, snippet, url = calls[index]
            if len(route.calls) >= MAX_CALLS_PER_ROUTE:
                break
            if method is not None and route.method in _HTTP_METHODS and method != route.method:
                continue
            if _same(segs, lit):
                route.calls.append({"path": path, "line": line, "snippet": snippet,
                                    "url": url, "method": method})
    return usage


# --- возможности системы для обратного сопоставления --------------------------------

@dataclass
class Capability:
    id: str
    kind: str
    label: str
    path: str
    line: int
    span: tuple[int, int]
    names: list[str] = field(default_factory=list)

    @property
    def where(self) -> str:
        return f"{self.path}:{self.line}"

    def describe(self) -> str:
        return f"{self.id} · {CAPABILITY_KIND_LABEL.get(self.kind, self.kind)} «{self.label}» · {self.where}"


def capabilities(tree: Any, facts: Iterable[Any], limit: int | None = MAX_CAPABILITIES,
                 *, offset: int = 0) -> tuple[list[Capability], int]:
    """Страница возможностей, стабильные ID по всему списку и общее количество.

    Старый вызов возвращает первые MAX_CAPABILITIES. Для следующей страницы
    передайте offset; limit=None возвращает весь оставшийся список. Порядок и
    ID не зависят от размера страницы, так что рассмотренные узлы не теряются.
    """
    if offset < 0 or limit is not None and limit < 0:
        raise ValueError("offset и limit возможностей должны быть неотрицательными")
    order = {kind: index for index, kind in enumerate(CAPABILITY_KINDS)}
    picked = []
    seen: set[tuple[str, str, int]] = set()
    for fact in facts:
        kind = getattr(fact, "kind", "")
        if kind not in order or not available_source_path(tree, getattr(fact, "path", "")):
            continue
        marker = (kind, fact.path, int(fact.line or 0))
        if marker in seen:
            continue
        seen.add(marker)
        picked.append(fact)
    picked.sort(key=lambda f: (order[f.kind], f.path, int(f.line or 0)))
    total = len(picked)
    out: list[Capability] = []
    texts: dict[str, str] = {}
    for number, fact in enumerate(picked[offset:None if limit is None else offset + limit], offset + 1):
        line = int(fact.line or 0)
        if fact.path not in texts:
            texts[fact.path] = _read(tree, fact.path)
        start, end, handler = _declaration_span(texts[fact.path], line, fact.path) if line else (line, line, "")
        names = [n for n in (handler, str(fact.key)) if n]
        if fact.kind == "ROUTE":
            value = fact.value if isinstance(fact.value, dict) else {}
            if value.get("path"):
                names.append(str(value["path"]))
        if fact.kind == "GRAPH_NODE":
            start = end = line
        out.append(Capability(id=f"cap-{number}", kind=fact.kind, label=str(fact.key),
                              path=fact.path, line=line, span=(start, end),
                              names=list(dict.fromkeys(names))))
    return out, total


def _quote_lines(record: dict[str, str], quote: str) -> list[int]:
    """Номера строк исходника, которые покрывает дословная цитата фрагмента."""
    text = record.get("text") or ""
    index = text.find(quote) if quote else -1
    if index < 0:
        return []
    first = text.rfind("\n", 0, index) + 1
    lines = text[first:index + len(quote)].splitlines() or [""]
    out = []
    for raw in lines:
        match = re.match(r"^(\d+): ", raw)
        if match:
            out.append(int(match.group(1)))
    return out


def _citations(fact_check: Any) -> list[dict[str, Any]]:
    if not isinstance(fact_check, dict):
        return []
    refs: list[Any] = []
    execution = fact_check.get("execution")
    if isinstance(execution, dict):
        refs.extend(execution.get("evidence") or [])
        refs.extend(execution.get("entry_evidence") or [])
    for row in (fact_check.get("fields") or {}).values():
        if isinstance(row, dict):
            refs.extend(row.get("evidence") or [])
    return [r for r in refs if isinstance(r, dict)]


def _node_texts(data: dict[str, Any]) -> str:
    parts: list[str] = []
    for cell in (data.get("fields") or {}).values():
        if isinstance(cell, dict):
            parts.append(str(cell.get("source") or ""))
            parts.append(str(cell.get("value") or ""))
    audit = data.get("fact_check")
    if isinstance(audit, dict) and isinstance(audit.get("execution"), dict):
        parts.extend(str(audit["execution"].get(k) or "") for k in ("entrypoint", "limits", "outcome"))
    return "\n".join(parts)


def auto_mapped(caps: list[Capability], nodes: dict[str, dict[str, Any]],
                records: dict[str, dict[str, str]]) -> dict[str, list[str]]:
    """Возможность → узлы, которые на неё опираются: цитата кода в пределах её
    объявления, `путь:строка` внутри него или имя обработчика/путь маршрута в
    основаниях полей. Упоминание файла без строки не считается: в одном файле
    живут десятки маршрутов."""
    out: dict[str, list[str]] = {}
    for nid, data in nodes.items():
        cited: dict[str, set[int]] = {}
        for ref in _citations(data.get("fact_check")):
            record = records.get(str(ref.get("id") or ""))
            if not record or record.get("kind") != "code":
                continue
            path = str(record.get("label") or "").rsplit(":", 1)[0]
            cited.setdefault(path, set()).update(_quote_lines(record, str(ref.get("quote") or "")))
        text = _node_texts(data)
        for cap in caps:
            start, end = cap.span
            hit = any(start <= n <= end for n in cited.get(cap.path, ()))
            if not hit:
                for match in re.finditer(re.escape(cap.path) + r":(\d+)", text):
                    if start <= int(match.group(1)) <= end:
                        hit = True
                        break
            if not hit:
                for name in cap.names:
                    # Путь маршрута — целиком: «/tasks» не засчитывается по «/tasks/{task_id}».
                    if len(name) >= 4 and re.search(r"(?<![\w/])" + re.escape(name) + r"(?![\w/{-])", text):
                        hit = True
                        break
            if hit:
                out.setdefault(cap.id, []).append(nid)
    return out


# --- факты экспозиции --------------------------------------------------------------

def exposure_facts(tree: Any, facts: Iterable[Any]) -> list[dict[str, Any]]:
    """Куда система отправляет данные и в каком контуре работает — по коду.

    `required` — вызов модели или внешнего HTTP-сервиса: чек-лист рисков
    обязан на него сослаться (с любым результатом, включая «неизвестно»).
    """
    facts = [fact for fact in facts if available_source_path(tree, getattr(fact, "path", ""))]
    out: list[dict[str, Any]] = []

    def add(kind: str, label: str, detail: str, where: list[tuple[str, int]], required: bool) -> None:
        if len(out) >= MAX_EXPOSURES:
            return
        out.append({"id": f"exposure-{len(out) + 1}", "kind": kind, "label": label,
                    "detail": _mask(detail)[:200], "where": [f"{p}:{n}" for p, n in where[:3]],
                    "anchors": [[p, n] for p, n in where[:3]], "required": required})

    llm_by_file: dict[str, list[int]] = {}
    for fact in facts:
        if getattr(fact, "kind", "") == "LLM_CALL" and fact.path and not _is_vendor(fact.path):
            llm_by_file.setdefault(fact.path, []).append(int(fact.line or 0))
    for path, lines in sorted(llm_by_file.items()):
        add("llm_call", "Вызов языковой модели", f"{len(lines)} вызов(ов) в файле", [(path, n) for n in sorted(lines)], True)

    external: dict[str, list[Any]] = {}
    for fact in facts:
        if getattr(fact, "kind", "") == "EXTERNAL" and fact.path and not _is_vendor(fact.path):
            external.setdefault(str(fact.key), []).append(fact)
    for system, items in sorted(external.items()):
        mechanism = str(getattr(items[0], "mechanism", "") or "")
        add("external", f"Внешняя система: {system}", f"механизм {mechanism or 'не указан'}; мест: {len(items)}",
            [(f.path, int(f.line or 0)) for f in items], mechanism in _REQUIRED_EXTERNAL_MECHANISMS)

    files = [path for path in getattr(tree, "files", []) if allowed_source_path(path)]
    env_rows = 0
    for path in files:
        if env_rows >= MAX_ENV_DEFAULTS or not path.endswith(".py") or _is_vendor(path) or "/tests/" in "/" + path:
            continue
        text = _read(tree, path)
        if "getenv" not in text and "environ.get" not in text:
            continue
        for match in _ENV_DEFAULT_RE.finditer(text):
            name, default = match.group(1), match.group(2).strip()
            if _ENV_SECRET.search(name) or not _ENV_INTERESTING.search(name):
                continue
            add("env_default", f"Настройка {name}", f"значение по умолчанию: {default}",
                [(path, _line_of(text, match.start()))], False)
            env_rows += 1
            if env_rows >= MAX_ENV_DEFAULTS:
                break

    warnings = 0
    for path in files:
        if warnings >= MAX_UI_WARNINGS or not is_frontend_file(path):
            continue
        text = _read(tree, path)
        for match in _UI_WARNING_RE.finditer(text):
            line = _line_of(text, match.start())
            snippet = text.splitlines()[line - 1].strip()
            add("ui_warning", "Предупреждение пользователю в интерфейсе", snippet, [(path, line)], False)
            warnings += 1
            break

    markers = 0
    for path in files:
        if markers >= MAX_DOC_MARKERS or not path.lower().endswith((".md", ".rst", ".txt")) or _is_vendor(path):
            continue
        text = _read(tree, path)
        match = _DOC_MARKER_RE.search(text)
        if match:
            line = _line_of(text, match.start())
            add("doc_marker", "Документация о контуре развёртывания", text.splitlines()[line - 1].strip(),
                [(path, line)], False)
            markers += 1

    required = [row for row in out if row["required"]]
    for row in required[MAX_REQUIRED_EXPOSURES:]:
        row["required"] = False
    return out


def exposure_digest(exposures: list[dict[str, Any]]) -> str:
    if not exposures:
        return ""
    lines = ["Факты экспозиции (детерминированно из кода и документации; основание — строка кода, "
             "а не вывод о риске). Факты с пометкой «обязательно» сошли на них в чек-листе рисков "
             "полем exposures у проверки input или dependencies хотя бы одного процесса — результат "
             "может быть finding, no_finding или unknown с объяснением; конфигурация развёртывания "
             "без фактов остаётся неизвестной:"]
    for row in exposures:
        mark = " · обязательно" if row["required"] else ""
        lines.append(f"- {row['id']}{mark}: {row['label']} — {row['detail']} ({', '.join(row['where'])})")
    return "\n".join(lines)


# --- расширение корпуса ------------------------------------------------------------

def neighbour_anchors(facts: Iterable[Any], known: set[str]) -> dict[str, set[int]]:
    """Соседи по графу вызовов на один шаг от уже известных файлов.

    Вызывающие: факт `CALLS` в другом файле, чей вызываемый объявлен в
    известном. Вызываемые: объявление в другом файле, которое вызывает
    известный. Имя, объявленное больше одного раза, пропускается: к какому
    файлу оно относится, по имени не понять.
    """
    facts = [fact for fact in facts if allowed_source_path(getattr(fact, "path", ""))]
    declared: dict[str, list[tuple[str, int]]] = {}
    for fact in facts:
        if getattr(fact, "kind", "") in ("FUNCTION", "CLASS_DEF", "TOOL", "JAVA_METHOD") and fact.path:
            declared.setdefault(str(fact.key), []).append((fact.path, int(fact.line or 0)))
    unique = {name: spots[0] for name, spots in declared.items() if len(spots) == 1}
    out: dict[str, set[int]] = {}
    for fact in facts:
        if getattr(fact, "kind", "") != "CALLS" or not isinstance(fact.value, dict):
            continue
        callee = unique.get(str(fact.value.get("callee") or ""))
        if callee is None:
            continue
        caller_path, callee_path = fact.path, callee[0]
        if caller_path == callee_path:
            continue
        if callee_path in known and caller_path not in known and fact.line:
            out.setdefault(caller_path, set()).add(int(fact.line))
        if caller_path in known and callee_path not in known and callee[1]:
            out.setdefault(callee_path, set()).add(callee[1])
    return out
