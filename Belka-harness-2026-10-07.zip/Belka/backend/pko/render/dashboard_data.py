"""Данные CLI-отчётов из ProgressModel.

Готовность, решение и шкала вычисляются в progress/schema.py.
Рендер dashboard_html оставляет только поля эталонного отчёта готовности.
Расширенные данные связности и паспорта доступны отдельно потребителям модели.
"""

from __future__ import annotations

from typing import Any

from pko.progress.schema import (
    MATCH_LABEL,
    READY_THRESHOLD,
    STATUS_LABEL,
    ProgressModel,
    limit_groups,
    scale_rows,
)


def build_review_dashboard_data(model: ProgressModel) -> dict[str, Any]:
    """Собрать контракт дашборда — не полный `ProgressModel.to_dict()`.

    Читатель дашборда — первое лицо, не разработчик: пути к материалам и
    `unclaimed` сюда осознанно не попадают.

    Ссылки на код доезжают, но **только подтверждённые** и в отдельную
    шторку: отчёт читается без них, а тому, кто захочет проверить, они под
    рукой. Неподтверждённая ссылка не показывается вовсе — она ничего не
    доказывает, а рядом со статусом выглядит доказательством. В модели
    (`progress_model.json`) остаются обе: там нужен полный след проверки.

    Только данные оценки: связность и карта паспорта здесь не строятся.
    """
    # Группы сводятся к MAX_GROUPS до отдачи на экран: одного указания в
    # промпте мало — на живом прогоне модель выдала 11 групп на 12 буллитов.
    # Неприменимые пункты тоже попадают в группировку: они видны в отчёте, и
    # без своей группы уезжали в отдельный блок «Функционал» — пятый при
    # лимите в четыре.
    group_map = limit_groups([
        criterion.group
        for verdict in model.verdicts
        for criterion in verdict.criteria
    ])

    items = []
    for verdict in model.verdicts:
        item = model.items.get(verdict.item_id)
        if item is None:
            continue
        assessment = [
            _assessment_row(text, criterion, group_map)
            for text, criterion in zip(item.criteria, verdict.criteria)
        ]
        stage: dict[str, Any] = {
            "title": item.title,
            "description": item.description,
            "percent": verdict.percent(),
            "assessment": assessment,
        }
        if verdict.applicable:
            stage["applicable"] = True
        items.append(stage)

    result: dict[str, Any] = {
        "meta": _meta(model),
        # Две готовности из одних и тех же статусов: прототип (главное число,
        # по нему решение) и промышленное решение (строгие веса).
        "readiness": model.readiness,
        "readiness_prod": model.readiness_prod,
        "items": items,
    }
    if model.summary is not None:
        summary = model.summary.to_dict()
        # Решение показывается рядом с оценкой кода (`meta.decision`), в
        # блоке вывода оно было бы вторым бейджем о том же самом.
        summary.pop("decision", None)
        result["summary"] = summary
    return result


def build_dashboard_data(model: ProgressModel) -> dict[str, Any]:
    """Расширенный контракт для программных потребителей: ревью и паспорт.

    HTML-дашборд CLI использует build_review_dashboard_data независимо от
    наличия и работоспособности паспортной карты.
    """
    result = build_review_dashboard_data(model)
    group_map = limit_groups([
        criterion.group
        for verdict in model.verdicts
        for criterion in verdict.criteria
    ])
    merged_groups = sorted({old for old, new in group_map.items() if old != new})
    result["gaps"] = (list(model.gaps) + _match_conflict(model) + _integrity_conflict(model)
                      + _connectivity_conflict(model) + ([
        "Тематических групп было больше четырёх — мелкие сведены в «Прочее»: "
        + ", ".join(merged_groups[:6])
    ] if merged_groups else []))
    if model.integrity is not None:
        result["integrity"] = model.integrity.to_dict()
    # Сквозная связность — отдельная цифра: доля целевых сценариев,
    # собранных до результата. Основной GO/PIVOT она пока не меняет.
    if model.connectivity is not None:
        result["connectivity"] = model.connectivity.to_dict()
    # Паспорт клиентского пути — отдельный файл, в карточку не рисуется.
    # Расширенный контракт сохраняет карту для программных потребителей.
    result["passport"] = _passport_summary(model)
    return result


def _passport_summary(model: ProgressModel) -> dict[str, Any]:
    from pko.render.passport_map import build_passport_map

    data = model.passport_data or {}
    nodes = data.get("nodes") if isinstance(data, dict) else None
    count = len(nodes) if isinstance(nodes, dict) else 0
    # `tree`, `relations` и `paths` — схема с оценкой: узлы с
    # готовностью по пунктам ОР, всеми родителями и проблемами, связи
    # поверх дерева, пути целевых сценариев со стыками. Считает
    # `passport_map.build_passport_map`; карточки полей остаются в файле паспорта.
    schema = build_passport_map(model)
    return {"filled_by_agent": count > 0, "nodes": count,
            **({"research_basis": data["research_basis"], "research_mode": data.get("research_mode", "")}
               if data.get("research_basis") else {}),
            "tree": schema["nodes"], "relations": schema["relations"],
            "paths": schema["paths"], "risks": schema["risks"],
            "summary": schema["summary"]}


def _connectivity_conflict(model: ProgressModel) -> list[str]:
    """Спор связности сценариев с решением — в замечания прогона.

    Пока оценка схемы выпускается отдельной функцией и не меняет основной
    GO/PIVOT. Поэтому резкое расхождение остаётся явным замечанием.
    """
    if (model.passport_data or {}).get("research_basis") == "code":
        return []
    review = model.connectivity
    if review is None or not review.scenarios:
        return []
    out: list[str] = []
    blocked = review.blocked()
    if blocked and model.summary is not None and model.summary.decision == "GO":
        names = ", ".join(f"«{s.title}»" for s in blocked[:4])
        out.append(
            f"Сквозная связность: решение GO при разорванных критических сценариях "
            f"({len(blocked)}: {names}) — обещанные результаты заблокированы, "
            "проверьте список сценариев перед тем, как опираться на решение."
        )
    percent = review.percent() or 0
    if percent == 0 and model.readiness >= READY_THRESHOLD and review.counts()["broken"]:
        out.append(
            f"Сквозная связность: ни один целевой сценарий не собран при готовности "
            f"{model.readiness}% — пункты закрыты по отдельности, а до результата путь "
            "не доходит. Процент готовности считается по буллитам и связность не учитывает."
        )
    return out


def _integrity_conflict(model: ProgressModel) -> list[str]:
    """Спор связности с процентом — в замечания прогона.

    Высокий процент при несобранном решении — это ровно тот случай, ради
    которого ревизия и заведена: пункты закрыты, а система не работает как
    целое. Читателю карточки это видно по блоку связности, а тому, кто прогон
    запускал, нужно в явном виде.
    """
    if (model.passport_data or {}).get("research_basis") == "code":
        return []
    review = model.integrity
    if review is None or not review.level:
        return []
    blockers = review.severity_counts().get("blocker", 0)
    if review.level == "disconnected" and model.readiness >= READY_THRESHOLD:
        return [
            f"Ревизия связности: решение не собрано при готовности {model.readiness}% — "
            "пункты закрыты по отдельности, но сквозного пути нет. Процент считается "
            "по буллитам и связность не учитывает."
        ]
    if blockers and model.summary is not None and model.summary.decision == "GO":
        return [
            f"Ревизия связности: решение GO при изъянах, блокирующих замысел ({blockers}) — "
            "проверьте блок связности перед тем, как опираться на решение."
        ]
    return []


def _match_conflict(model: ProgressModel) -> list[str]:
    """Расхождение верхнеуровневой оценки с расчётом — в замечания.

    Оценку целого даёт модель, проценты считает код. Разойтись они могут
    законно (буллиты формальные, а суть сделана — и наоборот), но резкое
    расхождение читатель должен видеть, а не гадать, какому числу верить.
    """
    summary = model.summary
    if summary is None or not summary.match:
        return []
    if summary.match == "mismatch" and model.readiness >= READY_THRESHOLD:
        return [
            f"Верхнеуровневая оценка «{MATCH_LABEL['mismatch'].lower()}» "
            f"расходится с расчётом по буллитам ({model.readiness}%): "
            "проверьте, тот ли код анализировался."
        ]
    if summary.match in ("matches", "mostly") and model.readiness < READY_THRESHOLD:
        # На девяти живых прогонах модель поставила «в основном соответствует»
        # девять раз из девяти — включая прогоны на 25% и 31%, где в её же
        # пояснении сказано, что главного в коде нет. Средняя оценка стала
        # значением по умолчанию, и расхождение с расчётом надо показывать.
        label = MATCH_LABEL.get(summary.match, summary.match).lower()
        return [
            f"Верхнеуровневая оценка «{label}» расходится с расчётом по буллитам "
            f"({model.readiness}%, порог {READY_THRESHOLD}%): большая часть пунктов "
            "не подтверждена кодом."
        ]
    return []


def _assessment_row(text: str, criterion, group_map: dict[str, str]) -> dict[str, Any]:
    """Одна строка отчёта: текст буллита из плана + оценка из вердикта."""
    row: dict[str, Any] = {
        "text": text,
        "group": group_map.get(criterion.group, criterion.group),
    }
    if not criterion.applicable:
        # Неприменимый пункт показывается серым и в расчёт не входит: статуса
        # у него нет, и додумывать его шаблону нечем. Но причина исключения
        # обязана быть видна — иначе пункт молча пропадает из знаменателя.
        if criterion.na_reason:
            row["na_reason"] = criterion.na_reason
        return row
    row["applicable"] = True
    row["status"] = criterion.status
    row["status_label"] = STATUS_LABEL.get(criterion.status, criterion.status)
    # Раскрытие пункта — два буллита: «Проверка» и «Как работает».
    row["proof"] = criterion.proof_text
    row["how"] = criterion.how_text
    # Ссылки — в шторку, и только подтверждённые: отклонённая ссылка ничего
    # не доказывает, а на экране читается как доказательство.
    links = [
        {"path": e.path, "line": e.line, "basis": e.basis, "note": e.note}
        for e in criterion.evidence if e.verified
    ]
    if links:
        row["links"] = links
    return row


def _meta(model: ProgressModel) -> dict[str, Any]:
    """Шапка отчёта: контекст пути плюс всё посчитанное бэкендом."""
    meta = dict(model.meta)
    # Шкала печатается в отчёте с весами: читатель должен уметь пересчитать
    # процент сам, не заглядывая в документацию.
    meta["scale"] = scale_rows()
    meta["closed_share"] = model.closed_share()
    meta["counts"] = model.criterion_counts()
    meta["not_applicable"] = model.not_applicable_count()
    if model.summary is not None:
        meta["decision"] = model.summary.decision
        # Верхнеуровневая оценка целого: постатейный разбор считает буллиты,
        # а это ответ на вопрос, делает ли система то, ради чего затевалась.
        meta["match"] = model.summary.match
        meta["match_label"] = MATCH_LABEL.get(model.summary.match, "")
        meta["match_note"] = model.summary.match_note
    # Строка расчёта («71% ≥ 40%») в шапку не идёт: два числа готовности
    # рядом с бейджем говорят то же самое и читаются лучше. В модели
    # (`summary.reason`) и в выводе CLI она остаётся — там это след, а не
    # элемент отчёта.
    return meta
