"""Transport regressions: no model, network, or target code is executed."""
from __future__ import annotations

import asyncio
from contextvars import ContextVar
from copy import deepcopy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Event, Thread
import time
import unittest
from unittest.mock import patch

from pydantic_ai import Agent, ToolOutput
from pydantic_ai.exceptions import UserError
from pydantic_ai.messages import (
    CachePoint, ImageUrl, InstructionPart, ModelMessagesTypeAdapter, ModelRequest, ModelResponse,
    RetryPromptPart, SystemPromptPart, TextContent, TextPart, ThinkingPart,
    ToolCallPart, ToolReturnPart, UserPromptPart,
)
from pydantic_ai.models import ModelRequestParameters, override_allow_model_requests
from pydantic_ai.tools import ToolDefinition

from pko.errors import LlmError
from pko.llm.client import ChatClient, ChatResult
from pko.llm.registry import ModelSpec
from pko.progress.passport_harness_model import (
    PassportChatModel, from_chat_messages, to_chat_messages,
)


SPEC = ModelSpec("passport", "https://transport.invalid/v1", "glm-demo", "fixture-key",
                 extra_body={"thinking": {"type": "enabled"}}, context_window=300000,
                 client_cert="fixture-cert", client_key="fixture-key-path")


def call(name="inspect", arguments='{"id":"evidence-1"}', cid="call-1"):
    return {"id": cid, "type": "function", "function": {"name": name, "arguments": arguments}}


class Client:
    """An injected existing transport, including its configured provider identity."""
    spec = SPEC

    def __init__(self, *responses):
        self.responses = list(responses)
        self.calls = []

    def chat(self, messages, **kwargs):
        self.calls.append((deepcopy(messages), deepcopy(kwargs)))
        result = self.responses.pop(0)
        if isinstance(result, BaseException):
            raise result
        return result


class MessageConversionTests(unittest.TestCase):
    def test_multipart_tool_batch_retry_and_ids_round_trip(self):
        original = [
            ModelRequest(parts=[SystemPromptPart("protocol"),
                                UserPromptPart(["first", TextContent("second")])],
                         instructions="live instructions are not history"),
            ModelResponse(parts=[TextPart("before"), TextPart(" after"),
                                 ToolCallPart("read", {"id": "e-1"}, tool_call_id="a"),
                                 ToolCallPart("search", '{"query":"orders"}', tool_call_id="b")],
                          provider_response_id="private-cache-key"),
            ModelRequest(parts=[ToolReturnPart("read", {"ok": True}, tool_call_id="a"),
                                RetryPromptPart("Invalid search", tool_name="search", tool_call_id="b")]),
        ]
        wire = to_chat_messages(original)
        self.assertEqual(wire[1]["content"], "first\n\nsecond")
        self.assertEqual(wire[2]["content"], "before after")
        self.assertEqual([r["tool_call_id"] for r in wire[3:]], ["a", "b"])
        self.assertIn("Invalid search", wire[4]["content"])
        self.assertNotIn("live instructions", json.dumps(wire))
        rebuilt = from_chat_messages(wire)
        self.assertEqual(to_chat_messages(rebuilt), wire)
        self.assertEqual(rebuilt[1].provider_response_id, "private-cache-key")

    def test_private_reasoning_is_never_imported_into_public_history(self):
        messages = [ModelResponse(parts=[ThinkingPart("private-one"), TextPart("public")])]
        wire = to_chat_messages(messages)
        wire[0]["reasoning_content"] = "private-two"
        rebuilt = from_chat_messages(wire)
        persisted = ModelMessagesTypeAdapter.dump_json(rebuilt)
        self.assertNotIn(b"private-one", persisted)
        self.assertNotIn(b"private-two", persisted)
        self.assertIn(b"public", persisted)

    def test_cache_hints_are_not_user_content(self):
        wire = to_chat_messages([ModelRequest(parts=[
            UserPromptPart(["task", CachePoint(ttl="5m")]),
            UserPromptPart([CachePoint(ttl="5m"), "FOCUS: save current evidence"]),
        ])])
        self.assertEqual(wire, [{"role": "user", "content": "task"},
                                {"role": "user", "content": "FOCUS: save current evidence"}])

    def test_orphan_results_and_non_text_content_fail_explicitly(self):
        with self.assertRaisesRegex(UserError, "orphaned"):
            from_chat_messages([{"role": "tool", "tool_call_id": "missing", "content": "okay"}])
        with self.assertRaisesRegex(UserError, "text parts"):
            to_chat_messages([ModelRequest(parts=[UserPromptPart([ImageUrl("https://image.invalid/a.png")])])])
        with self.assertRaisesRegex(UserError, "non-text"):
            from_chat_messages([{"role": "user", "content": [{"type": "image_url"}]}])

    def test_falsy_structured_tool_return_is_not_erased(self):
        rows = [{"role": "assistant", "tool_calls": [call(cid="one")]},
                {"role": "tool", "tool_call_id": "one", "content": False}]
        self.assertIs(from_chat_messages(rows)[1].parts[0].content, False)


class ModelTransportTests(unittest.IsolatedAsyncioTestCase):
    async def test_unchanged_wire_objects_reuse_audit_cache_but_changed_text_is_recorded(self):
        from pko.audit import AuditedClient

        class RecordingClient(Client):
            def __init__(self):
                super().__init__(ChatResult("", {}, tool_calls=[call(cid="first")]),
                                 ChatResult("", {}, tool_calls=[call(cid="second")]),
                                 ChatResult("finished", {}))
                self.message_objects, self.tool_objects = [], []

            def chat(self, messages, **kwargs):
                self.message_objects.append(list(messages))
                self.tool_objects.append(kwargs["tools"])
                return super().chat(messages, **kwargs)

        client = RecordingClient()
        model = PassportChatModel(client=AuditedClient(client), spec=SPEC)
        params = ModelRequestParameters(function_tools=[ToolDefinition(
            name="inspect", parameters_json_schema={"type": "object", "properties": {"id": {"type": "string"}}})])
        events = []
        def record(event, **fields):
            events.append((event, deepcopy(fields)))
        opening = ModelRequest(parts=[SystemPromptPart("protocol"), UserPromptPart("original")])
        with patch("pko.audit.record", side_effect=record):
            first = await model.request([opening], None, params)
            history = [opening, first, ModelRequest(parts=[ToolReturnPart("inspect", "read-one", "first")])]
            second = await model.request(history, None, params)
            # A rebuilt typed request changes one existing message, keeping the
            # same assistant and tool-return values alongside a new result.
            changed = ModelRequest(parts=[SystemPromptPart("protocol"), UserPromptPart("updated")])
            await model.request([changed, *history[1:], second,
                                 ModelRequest(parts=[ToolReturnPart("inspect", "read-two", "second")])], None, params)

        first_wire, second_wire, third_wire = client.message_objects
        self.assertIs(first_wire[0], second_wire[0])
        self.assertIs(first_wire[1], second_wire[1])
        self.assertIs(second_wire[0], third_wire[0])
        self.assertIsNot(second_wire[1], third_wire[1])
        self.assertIs(second_wire[2], third_wire[2])
        self.assertIs(second_wire[2]["tool_calls"], third_wire[2]["tool_calls"])
        self.assertIs(second_wire[3], third_wire[3])
        self.assertTrue(all(tools is client.tool_objects[0] for tools in client.tool_objects))
        self.assertTrue(all(tools[0] is client.tool_objects[0][0] for tools in client.tool_objects))
        recorded = [fields["message"] for event, fields in events if event == "context_message"]
        self.assertEqual([m["content"] for m in recorded if m["role"] == "system"], ["protocol"])
        self.assertEqual([m["content"] for m in recorded if m["role"] == "user"], ["original", "updated"])
        self.assertFalse(any(row.get("content") == "original" for row in model._public_messages.values()))

    async def test_trace_queue_is_stable_and_new_tail_survives_compaction(self):
        try:
            from opentelemetry.sdk.trace import TracerProvider
            from opentelemetry.sdk.trace.export import SimpleSpanProcessor
            from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
        except ImportError:
            self.skipTest("optional OpenTelemetry SDK is not installed")
        from pko.llm import tracing

        exporter = InMemorySpanExporter()
        provider = TracerProvider(span_limits=tracing.span_limits())
        provider.add_span_processor(SimpleSpanProcessor(exporter))
        self.addCleanup(provider.shutdown)
        client = Client(ChatResult("", {}, tool_calls=[call(cid="first")]),
                        ChatResult("", {}, tool_calls=[call(cid="second")]),
                        ChatResult("finished", {}))
        opening = ModelRequest(parts=[SystemPromptPart("protocol"), UserPromptPart("task")])
        with patch.object(tracing, "_tracer", provider.get_tracer("passport-model-test")):
            model = PassportChatModel(client=tracing.trace_client(client, SPEC), spec=SPEC)
            with tracing.trace_span("passport_session"):
                # Real capabilities add temporary user parts to the wire only.
                initial = ModelRequest(parts=[*opening.parts, UserPromptPart("REMINDER_1")])
                with tracing.trace_span("passport.step", step=1):
                    first = await model.request([initial], None, ModelRequestParameters())
                queue = model._wire_messages
                returned_first = ModelRequest(parts=[ToolReturnPart("inspect", "read-one", "first")])
                with tracing.trace_span("passport.step", step=2):
                    second = await model.request([opening, first, returned_first], None, ModelRequestParameters())
                self.assertIs(model._wire_messages, queue)
                # Drop the old complete batch and add the current reminder.
                returned_second = ModelRequest(parts=[ToolReturnPart("inspect", "read-two", "second"),
                                                      UserPromptPart("REMINDER_3")])
                with tracing.trace_span("passport.step", step=3):
                    await model.request([opening, second, returned_second], None, ModelRequestParameters())
                self.assertIs(model._wire_messages, queue)

        spans = exporter.get_finished_spans()
        session = next(s for s in spans if s.attributes.get("pko.span") == "passport_session")
        initial_input = json.loads(session.attributes["input.value"])
        self.assertEqual([m["role"] for m in initial_input], ["system", "user", "user"])
        self.assertEqual(initial_input[-1]["content"], "REMINDER_1")
        steps = {int(s.name.split()[1]): s for s in spans
                 if s.attributes.get("pko.span") == "passport.step"}
        second_input = json.loads(steps[2].attributes["input.value"])
        self.assertEqual([(m["role"], m.get("tool_call_id")) for m in second_input], [("tool", "first")])
        third_input = json.loads(steps[3].attributes["input.value"])
        self.assertEqual([(m["role"], m.get("tool_call_id")) for m in third_input],
                         [("tool", "second"), ("user", None)])
        self.assertEqual(third_input[-1]["content"], "REMINDER_3")

    async def test_existing_transport_schemas_settings_and_usage(self):
        client = Client(ChatResult("", {"prompt_tokens": 100, "completion_tokens": 20,
                                       "prompt_tokens_details": {"cached_tokens": 60},
                                       "completion_tokens_details": {"reasoning_tokens": 8}},
                                   tool_calls=[call()], reasoning_content="private-reasoning"))
        model = PassportChatModel(client=client, spec=SPEC, max_tokens=1000)
        schema = {"type": "object", "properties": {"id": {"type": "string"}}, "required": ["id"]}
        params = ModelRequestParameters(
            output_mode="tool",
            function_tools=[ToolDefinition(name="inspect", parameters_json_schema=schema,
                                           description="Read material", strict=False)],
            output_tools=[ToolDefinition(name="finish", parameters_json_schema={"type": "object"}, kind="output")],
            instruction_parts=[InstructionPart("active instructions")])
        response = await model.request([ModelRequest(parts=[UserPromptPart("start")], instructions="stale")],
                                       {"temperature": 0.2, "max_tokens": 1234}, params)
        self.assertIs(model.client, client)
        self.assertIs(model.spec, SPEC)
        self.assertEqual(model.profile["context_window"], 300000)
        messages, args = client.calls[0]
        self.assertEqual(messages[0], {"role": "system", "content": "active instructions"})
        self.assertNotIn("stale", json.dumps(messages))
        self.assertEqual(args["max_tokens"], 1234)
        self.assertEqual(args["temperature"], 0.2)
        self.assertEqual([t["function"]["name"] for t in args["tools"]], ["inspect", "finish"])
        self.assertEqual(args["tools"][0]["function"]["parameters"], schema)
        self.assertFalse(args["tools"][0]["function"]["strict"])
        self.assertEqual(response.parts[0].tool_call_id, "call-1")
        self.assertEqual(response.usage.input_tokens, 100)
        self.assertEqual(response.usage.output_tokens, 20)
        self.assertEqual(response.usage.cache_read_tokens, 60)
        self.assertEqual(response.usage.details["reasoning_tokens"], 8)
        self.assertEqual(response.finish_reason, "tool_call")
        self.assertNotIn(b"private-reasoning", ModelMessagesTypeAdapter.dump_json([response]))

    async def test_reasoning_round_trip_is_private_and_old_entries_expire(self):
        client = Client(ChatResult("", {}, tool_calls=[call()], reasoning_content="secret-turn-1"),
                        ChatResult("same", {}, from_cache=True, reasoning_content="secret-turn-2"),
                        ChatResult("same", {}, from_cache=True))
        model = PassportChatModel(client=client, spec=SPEC)
        initial = ModelRequest(parts=[UserPromptPart("start")])
        first = await model.request([initial], None, ModelRequestParameters())
        original = [initial, first, ModelRequest(parts=[ToolReturnPart("inspect", "read", tool_call_id="call-1")])]
        compacted = from_chat_messages(to_chat_messages(original))
        second = await model.request(compacted, None, ModelRequestParameters())
        wire = client.calls[1][0]
        self.assertEqual(wire[1]["reasoning_content"], "secret-turn-1")
        self.assertTrue(all(not any(k.startswith("_pko") for k in row) for row in wire))
        public = ModelMessagesTypeAdapter.dump_json(compacted + [second])
        self.assertNotIn(b"secret-turn", public)
        self.assertTrue(second.metadata["from_cache"])
        self.assertEqual(second.usage.total_tokens, 0)
        self.assertTrue(from_chat_messages(to_chat_messages([second]))[0].metadata["from_cache"])
        third = await model.request([initial], None, ModelRequestParameters())
        self.assertNotEqual(second.provider_response_id, third.provider_response_id)
        self.assertEqual(model._reasoning, {})

    async def test_instruction_fallback_and_explicit_empty_instructions(self):
        client = Client(ChatResult("ok", {}), ChatResult("ok", {}))
        model = PassportChatModel(client=client, spec=SPEC)
        messages = [ModelRequest(parts=[UserPromptPart("go")], instructions="fallback")]
        await model.request(messages, None, ModelRequestParameters())
        await model.request(messages, None, ModelRequestParameters(instruction_parts=[]))
        self.assertEqual(client.calls[0][0][0]["content"], "fallback")
        self.assertEqual(client.calls[1][0], [{"role": "user", "content": "go"}])

    async def test_reasoning_window_retains_trimming_and_rolls_back_current_history(self):
        from pko.progress.context_window import ReasoningWindowClient
        client = Client(ChatResult("one", {}, reasoning_content="reason-1"),
                        ChatResult("two", {}, reasoning_content="reason-2"),
                        ChatResult("three", {}, reasoning_content="reason-3"),
                        LlmError("reasoning required"), ChatResult("four", {}))
        window = ReasoningWindowClient(client, keep=1)
        model = PassportChatModel(client=window, spec=SPEC)
        history = [ModelRequest(parts=[UserPromptPart("start")])]
        for _ in range(3):
            response = await model.request(history, None, ModelRequestParameters())
            history = from_chat_messages(to_chat_messages([
                *history, response, ModelRequest(parts=[UserPromptPart("next")])]))
        self.assertEqual(len(window._removed), 1)
        await model.request(history, None, ModelRequestParameters())
        self.assertFalse(window.enabled)
        self.assertEqual(len(client.calls), 5)
        assistants = [row for row in client.calls[-1][0] if row["role"] == "assistant"]
        self.assertEqual([row["reasoning_content"] for row in assistants], ["reason-1", "reason-2", "reason-3"])
        self.assertNotIn(b"reason-", ModelMessagesTypeAdapter.dump_json(history))

    async def test_transport_exception_is_not_retried(self):
        client = Client(LlmError("fixture unavailable"))
        model = PassportChatModel(client=client, spec=SPEC)
        with self.assertRaisesRegex(LlmError, "fixture unavailable"):
            await model.request([ModelRequest(parts=[UserPromptPart("go")])], None, ModelRequestParameters())
        self.assertEqual(len(client.calls), 1)

    async def test_endpoint_credentials_do_not_enter_persisted_message_metadata(self):
        spec = ModelSpec("passport", "https://user:fixture-secret@example.invalid/v1?api_key=query-secret",
                         "fixture", "api-secret")
        client = Client(ChatResult("public", {}))
        model = PassportChatModel(client=client, spec=spec)
        response = await model.request([], None, ModelRequestParameters())
        persisted = ModelMessagesTypeAdapter.dump_json([response])
        self.assertIsNone(response.provider_url)
        self.assertNotIn(b"fixture-secret", persisted)
        self.assertNotIn(b"query-secret", persisted)
        self.assertNotIn(b"api-secret", persisted)
        self.assertEqual(model.base_url, spec.base_url)

    async def test_framework_request_kill_switch_prevents_dispatch(self):
        client = Client()
        model = PassportChatModel(client=client, spec=SPEC)
        with override_allow_model_requests(False):
            with self.assertRaisesRegex(RuntimeError, "Model requests are not allowed"):
                await model.request([], None, ModelRequestParameters())
        self.assertEqual(client.calls, [])

    async def test_missing_provider_tool_id_gets_stable_id_for_next_return(self):
        client = Client(ChatResult("", {}, tool_calls=[call(cid=None)]))
        model = PassportChatModel(client=client, spec=SPEC)
        response = await model.request([], None, ModelRequestParameters())
        cid = response.parts[0].tool_call_id
        self.assertTrue(cid.startswith("call_"))
        history = [response, ModelRequest(parts=[ToolReturnPart("inspect", "ok", tool_call_id=cid)])]
        self.assertEqual(from_chat_messages(to_chat_messages(history))[0].parts[0].tool_call_id, cid)

    async def test_copy_context_preserves_active_trace(self):
        trace = ContextVar("transport-test-trace", default="absent")
        token = trace.set("active-trace")
        class TraceClient:
            def chat(self, messages, **kwargs):
                return ChatResult(trace.get(), {})
        try:
            model = PassportChatModel(client=TraceClient(), spec=SPEC)
            result = await model.request([], None, ModelRequestParameters())
            self.assertEqual(result.parts[0].content, "active-trace")
        finally:
            trace.reset(token)

    async def test_expired_deadline_does_not_dispatch(self):
        client = Client()
        model = PassportChatModel(client=client, spec=SPEC, deadline=time.monotonic() - 1)
        with self.assertRaises(TimeoutError):
            await model.request([], None, ModelRequestParameters())
        self.assertEqual(client.calls, [])

    async def test_timeout_does_not_wait_for_synchronous_transport_or_store_late_reasoning(self):
        entered, release, returned = Event(), Event(), Event()
        class BlockingClient:
            def chat(self, messages, **kwargs):
                entered.set()
                release.wait(5)
                returned.set()
                return ChatResult("late", {}, reasoning_content="late-secret")
        model = PassportChatModel(client=BlockingClient(), spec=SPEC, deadline=time.monotonic() + 0.05)
        started = time.monotonic()
        try:
            with self.assertRaises(TimeoutError):
                await model.request([], None, ModelRequestParameters())
            self.assertTrue(entered.is_set())
            self.assertFalse(returned.is_set())
            self.assertLess(time.monotonic() - started, 1)
        finally:
            release.set()
        await asyncio.sleep(0.02)
        self.assertEqual(model._reasoning, {})

    async def test_cancellation_is_prompt_and_does_not_store_late_response(self):
        entered, release = Event(), Event()
        class BlockingClient:
            def chat(self, messages, **kwargs):
                entered.set()
                release.wait(5)
                return ChatResult("late", {}, reasoning_content="late-secret")
        model = PassportChatModel(client=BlockingClient(), spec=SPEC)
        task = asyncio.create_task(model.request([], None, ModelRequestParameters()))
        try:
            for _ in range(100):
                if entered.is_set():
                    break
                await asyncio.sleep(0.002)
            self.assertTrue(entered.is_set())
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await asyncio.wait_for(task, 0.3)
        finally:
            release.set()
        await asyncio.sleep(0.02)
        self.assertEqual(model._reasoning, {})

    async def test_actual_agent_owns_tool_loop_and_returns_output(self):
        invoked = []
        def inspect(id: str) -> dict:
            invoked.append(id)
            return {"id": id, "text": "public source"}
        client = Client(ChatResult("", {}, tool_calls=[call()], reasoning_content="private"),
                        ChatResult("Confirmed", {"prompt_tokens": 10, "completion_tokens": 2}))
        model = PassportChatModel(client=client, spec=SPEC)
        agent = Agent(model=model, tools=[inspect], instructions="Keep evidence literal")
        result = await agent.run("start")
        self.assertEqual(result.output, "Confirmed")
        self.assertEqual(invoked, ["evidence-1"])
        self.assertEqual(len(client.calls), 2)
        self.assertEqual(client.calls[1][0][-1]["tool_call_id"], "call-1")
        self.assertIn("public source", client.calls[1][0][-1]["content"])
        self.assertNotIn(b"private", result.all_messages_json())

    async def test_actual_agent_output_tool_uses_same_transport(self):
        def finish(summary: str) -> str:
            return summary
        client = Client(ChatResult("", {}, tool_calls=[call("finish", '{"summary":"ready"}')]))
        agent = Agent(model=PassportChatModel(client=client, spec=SPEC),
                      output_type=ToolOutput(finish, name="finish"))
        result = await agent.run("start")
        self.assertEqual(result.output, "ready")
        self.assertEqual(len(client.calls), 1)
        self.assertEqual(client.calls[0][1]["tools"][0]["function"]["name"], "finish")

    async def test_real_planning_and_system_reminders_compose_with_transport(self):
        from pydantic_ai_harness.planning import Planning, InMemoryPlanStore, PlanItem
        from pydantic_ai_harness.system_reminders import SystemReminders, Reminder
        store = InMemoryPlanStore()
        await store.set_items([PlanItem(id="first", content="Read actual source", status="pending")])
        client = Client(ChatResult("ready", {}))
        agent = Agent(model=PassportChatModel(client=client, spec=SPEC), capabilities=[
            Planning(store=store), SystemReminders(reminders=[Reminder("FOCUS: save current evidence", tag=None)]),
        ])
        result = await agent.run("task")
        wire = client.calls[0][0]
        self.assertEqual(result.output, "ready")
        self.assertTrue(any(r["content"].startswith("FOCUS:") for r in wire if r["role"] == "user"))
        self.assertTrue(any("Read actual source" in r["content"] for r in wire))
        self.assertTrue(all(isinstance(r["content"], str) for r in wire))
        self.assertNotIn("CachePoint", json.dumps(wire))
        # Official capabilities inject ephemeral notices only into this request.
        self.assertNotIn(b"FOCUS:", result.all_messages_json())

    async def test_native_chat_client_local_http_multi_tool_finish_and_cache(self):
        """Exercise the real SDK/ChatClient boundary against localhost only."""
        payloads = []
        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                payloads.append(json.loads(self.rfile.read(int(self.headers["Content-Length"]))))
                first = len(payloads) == 1
                choices = [call("inspect", '{"id":"first"}', "first"),
                           call("inspect", '{"id":"second"}', "second")] if first else [
                               call("finish", '{"summary":"ready"}', "done")]
                body = json.dumps({"id": "provider-response", "object": "chat.completion", "created": 0,
                    "model": "glm-demo", "choices": [{"index": 0, "finish_reason": "tool_calls",
                        "message": {"role": "assistant", "content": None, "tool_calls": choices,
                                    "reasoning_content": "private-http-reasoning"}}],
                    "usage": {"prompt_tokens": 10, "completion_tokens": 4, "total_tokens": 14}}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = Thread(target=server.serve_forever, kwargs={"poll_interval": 0.01}, daemon=True)
        thread.start()
        observed = []
        def inspect(id: str) -> str:
            observed.append(id)
            return id
        def finish(summary: str) -> str:
            return summary
        try:
            with TemporaryDirectory() as cache_dir:
                spec = ModelSpec("passport", f"http://127.0.0.1:{server.server_port}/v1", "glm-demo", "fixture",
                                 extra_body={"thinking": {"type": "enabled"}})
                client = ChatClient(spec=spec, timeout=2, cache_dir=Path(cache_dir))
                try:
                    # New model/Agent objects repeat exactly the same public payload;
                    # private random response IDs must never poison the transport cache.
                    outputs = []
                    for _ in range(2):
                        agent = Agent(model=PassportChatModel(client=client, spec=spec, deadline=time.monotonic() + 5),
                                      tools=[inspect], output_type=ToolOutput(finish, name="finish"))
                        outputs.append(await agent.run("local scripted test"))
                    self.assertEqual([r.output for r in outputs], ["ready", "ready"])
                    self.assertEqual(len(payloads), 2)
                    self.assertEqual(set(observed), {"first", "second"})
                    self.assertEqual(payloads[0]["thinking"], {"type": "enabled"})
                    self.assertEqual(payloads[0]["tool_choice"], "auto")
                    tool_results = [r for r in payloads[1]["messages"] if r["role"] == "tool"]
                    self.assertEqual([r["tool_call_id"] for r in tool_results], ["first", "second"])
                    assistants = [r for r in payloads[1]["messages"] if r["role"] == "assistant"]
                    self.assertEqual(assistants[0]["reasoning_content"], "private-http-reasoning")
                    self.assertNotIn("_pko", json.dumps(payloads))
                    cached = [r for r in outputs[1].all_messages() if isinstance(r, ModelResponse)]
                    self.assertTrue(all(r.metadata["from_cache"] for r in cached))
                    self.assertEqual(outputs[1].usage.total_tokens, 0)
                    self.assertNotIn(b"private-http-reasoning", outputs[0].all_messages_json())
                finally:
                    client._client.close()
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=1)


if __name__ == "__main__":
    unittest.main()
