"""One real research loop owns scenarios, structure, traces and nested review."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest

from pko.llm.client import ChatResult
from pko.progress.passport_agent import run_passport_agent, _process_scenario_issues
from pko.progress.passport_workspace import sync_objects
from pko.progress.passport_connectivity import handle_research_connectivity
from pko.progress import passport_tools
from pko.progress.schema import HANDOFF_CHECKS, PlanItem
from test_passport_agentic import (
    SPEC, QUOTE, ReviewingScriptClient, complete_session_responses, corpus_fixture,
    tool, approve_current_versions,
)
from test_passport_system_research import research_session, purpose, flow, REFS


INTENT = "Клиент получает отчёт по явному запросу."
SCENARIO = {"title": "Получение отчёта", "entry": "Клиент запрашивает отчёт",
            "outcome": "Клиент получил отчёт", "steps": ["Подготовить отчёт", "Передать отчёт"],
            "critical": True, "bullets": [INTENT],
            "evidence": [{"id": "evidence-2", "quote": INTENT}]}


def result(*calls):
    return ChatResult(text="", usage={}, tool_calls=list(calls))


class ResearchClient(ReviewingScriptClient):
    def chat(self, messages, **kwargs):
        names = {s["function"]["name"] for s in kwargs.get("tools", [])}
        if "submit_checks" not in names:
            return super().chat(messages, **kwargs)
        self.review_messages.append(deepcopy(messages))
        packet = json.loads(messages[1]["content"])["objects"]
        if not any(m.get("role") == "tool" for m in messages):
            self.reviewed_packets.append(deepcopy(packet))
            return result(tool("read_passport_evidence", {"ids": ["evidence-1", "evidence-2"]}))
        checks = []
        for obj in packet:
            intent = obj["kind"] == "intent"
            checks.append({"object_id": obj["id"], "revision": obj["revision"], "result": "supported",
                           "reason": "Проверен смысл утверждения и его границы: неизвестная доставка не выдана за работающую.",
                           "evidence": [{"id": "evidence-2" if intent else "evidence-1",
                                         "quote": INTENT if intent else QUOTE}]})
        return result(tool("submit_checks", {"checks": checks}))


def research_responses():
    base = complete_session_responses()
    for call in base[3].tool_calls:
        args = json.loads(call["function"]["arguments"])
        if args["id"] == "bbb-1":
            args["bullets"] = [INTENT]
        if args["id"] == "process-1":
            args["scenarios"] = ["scenario-1"]
        call["function"]["arguments"] = json.dumps(args, ensure_ascii=False)
    trace = {"scenario_id": "scenario-1", "revision": 1,
             "handoffs": [{"step": 0, "kind": "call", "checks": [
                 {"check": c, "result": "unknown", "note": "Доступен вызов транспорта; весь клиентский путь не подтверждён.",
                  "evidence": []} for c in HANDOFF_CHECKS]}]}
    review_ids = ["journey-1", "process-1", "bbb-1", "operation-1", "risk-analysis",
                  "scenario:scenario-1", "trace:scenario-1", "system:purpose", "system:flow", "system:integrity"]
    return [
        result(tool("read_passport_evidence", {"ids": ["evidence-1", "evidence-2"]})),
        base[0],  # A business container may be discovered before scenarios.
        result(tool("submit_scenarios", {"scenarios": [deepcopy(SCENARIO)]})),
        result(tool("submit_system", purpose()), tool("submit_trace", trace)),
        *base[1:4],
        result(tool("bind_scenario_step", {"scenario": "scenario-1", "step": 0, "nodes": ["bbb-1"]}),
               tool("bind_scenario_step", {"scenario": "scenario-1", "step": 1, "nodes": ["operation-1"]})),
        result(tool("submit_flow", flow(complete=False, break_point="Доставка после вызова транспорта не проверена.")),
               tool("submit_integrity", {"level": "unknown", "note": "Вызов транспорта найден, но фактическая доставка и весь путь клиента ещё не подтверждены.",
                                         "evidence": deepcopy(REFS)})),
        base[4],
        result(tool("review_passport", {"ids": review_ids[:8]})),
        result(tool("review_passport", {"ids": review_ids[8:]})),
        base[-1],
    ]


class IntegratedResearchTests(unittest.TestCase):
    def test_one_loop_finishes_with_honest_unknowns_and_real_nested_review(self):
        client = ResearchClient(*research_responses())
        with tempfile.TemporaryDirectory() as tmp:
            checkpoint = Path(tmp) / "research.json"
            output = run_passport_agent([PlanItem(id="report", title="Отчёт", criteria=[INTENT])],
                {}, [], None, SPEC, client=client, max_steps=30, evidence_corpus=corpus_fixture(),
                agentic=True, research_enabled=True, source_digest="original-intent", checkpoint_path=checkpoint)
            saved = json.loads(checkpoint.read_text(encoding="utf-8"))
        data = output.passport_data
        self.assertEqual(data["completion"]["state"], "complete", data["completion"])
        self.assertEqual(data["completion"]["pending_reviews"], [])
        self.assertEqual(output.connectivity.scenarios[0].status, "unknown")
        self.assertEqual(output.connectivity.source_digest, "original-intent")
        self.assertEqual(output.integrity.level, "unknown")
        self.assertEqual(output.integrity.flaws, [])
        self.assertEqual(data["research_mode"], "integrated")
        self.assertEqual(data["connectivity"], output.connectivity.to_dict())
        self.assertEqual(data["integrity"], output.integrity.to_dict())
        self.assertEqual(saved["draft"]["connectivity"], data["connectivity"])
        self.assertEqual(saved["draft"]["completion"]["state"], "complete")
        reviewed = {o["id"] for packet in client.reviewed_packets for o in packet}
        self.assertTrue({"scenario:scenario-1", "trace:scenario-1", "system:integrity", "risk-analysis"} <= reviewed)
        self.assertNotIn("RESEARCHER_PRIVATE_MARKER", json.dumps(client.review_messages))

    def test_interruption_preserves_discovered_scenarios_and_partial_system(self):
        client = ResearchClient(*research_responses()[:4])
        output = run_passport_agent([PlanItem(id="report", title="Отчёт", criteria=[INTENT])],
            {}, [], None, SPEC, client=client, max_steps=5, evidence_corpus=corpus_fixture(),
            agentic=True, research_enabled=True)
        self.assertIsNotNone(output.connectivity)
        self.assertIsNotNone(output.integrity.purpose)
        self.assertNotEqual(output.passport_data["completion"]["state"], "complete")
        self.assertEqual(output.passport_data["connectivity"], output.connectivity.to_dict())

    def test_step_scope_receipt_expires_when_scenario_outcome_changes(self):
        state = research_session()
        self.assertNotIn("отклонён", handle_research_connectivity(state, "submit_scenarios", {"scenarios": [SCENARIO]}))
        target = "step:scenario-1:1"
        state.workspace.exclusions[target] = {"target": target, "disposition": "excluded",
            "reason": "Передача отчёта вне рассматриваемой границы процесса.", "evidence": SCENARIO["evidence"]}
        approve_current_versions(state)
        revision = state.workspace.objects["scope:" + target]["revision"]
        changed = {**SCENARIO, "id": "scenario-1", "revision": 1,
                   "outcome": "Клиент получил отчёт и подтверждение передачи"}
        self.assertNotIn("отклонён", handle_research_connectivity(state, "submit_scenarios", {"scenarios": [changed]}))
        sync_objects(state)
        self.assertNotEqual(state.workspace.objects["scope:" + target]["revision"], revision)
        self.assertNotIn("scope:" + target, state.workspace.reviews)

    def test_retirement_review_receives_previous_counterexample(self):
        state = research_session()
        retired_id = "trace:scenario-1"
        state.workspace.reject("review:" + retired_id, {"tool": "independent_review", "revision": "old"},
                               "Передаваемые данные теряются до вызова транспорта; прежний вывод не подтверждён.")
        decision_id = "retirement:scenario-1"
        state.workspace.retirements[decision_id] = {"kind": "intent", "object_id": "scenario:scenario-1",
            "retired_object_ids": [retired_id], "reason": "Сценарий ошибочно выведен из пункта о другом результате.",
            "evidence": SCENARIO["evidence"]}
        packets = []
        def reviewer(objects):
            packets.extend(deepcopy(objects))
            return {"findings": [{"object_id": obj["id"], "revision": obj["revision"],
                                   "result": "supported", "reason": "Отзыв учитывает прежний контрпример.", "evidence": []}
                                  for obj in objects]}
        state.reviewer = reviewer
        passport_tools.review(state, {"ids": [decision_id]})
        self.assertEqual(packets[0]["prior_findings"][0]["key"], "review:" + retired_id)
        self.assertIn("данные теряются", packets[0]["prior_findings"][0]["reason"])
        self.assertEqual(state.workspace.unresolved(), [])

    def test_scenario_discovery_rechecks_processes_filled_before_it(self):
        state = research_session()
        handle_research_connectivity(state, "submit_scenarios", {"scenarios": [SCENARIO]})
        state.nodes["process-1"].data["scenarios"] = ["scenario-1"]
        issues = _process_scenario_issues(state)
        self.assertTrue(any("process-2" in issue for issue in issues), issues)
        state.nodes["process-2"].data["scenarios"] = ["scenario-1"]
        self.assertEqual(_process_scenario_issues(state), [])


if __name__ == "__main__":
    unittest.main()
