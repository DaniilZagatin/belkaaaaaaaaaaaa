"""A broad search must leave capacity to inspect a concrete business handler."""
import unittest

from pko.extractors.runner import Extraction
from pko.progress.passport_broker import EvidenceBroker
from pko.progress.passport_evidence import EvidenceCorpus
from test_passport_broker import MemoryTree


class SearchBudgetTests(unittest.TestCase):
    def test_broad_search_does_not_starve_addressed_read(self):
        tree = MemoryTree({**{f'a{i}.py': 'unrelated_action()' for i in range(8)},
                           'z_handler.py': 'def send_notice():\n    deliver_notice()'})
        corpus = EvidenceCorpus()
        broker = EvidenceBroker(tree, Extraction(), corpus, max_source_files=4)
        found = broker.request({'kind': 'search', 'query': 'send_notice'})
        self.assertTrue(found['truncated'])
        self.assertIn('search_limit', found)
        self.assertEqual(found['usage']['source_files'], 3)
        # Repeating a search must not consume the reserve.
        broker.request({'kind': 'search', 'query': 'another_action'})
        result = broker.request({'kind': 'file', 'path': 'z_handler.py'})
        self.assertTrue(result['ok'], result)
        self.assertEqual(result['usage']['source_files'], 4)
        eid = result['records'][0]['id']
        self.assertNotIn(eid, corpus.shown)
        corpus.read([eid])
        self.assertFalse(corpus.citations([{'id': eid, 'quote': 'deliver_notice()'}], code=True))
        denied = broker.request({'kind': 'file', 'path': 'a7.py'})
        self.assertEqual(denied['error'], 'source_file_budget')
        self.assertEqual(len(tree.reads), 4)

    def test_character_reserve_keeps_global_limit(self):
        tree = MemoryTree({'a.py': 'a' * 45, 'b.py': 'b' * 40, 'z.py': 'helper()'})
        broker = EvidenceBroker(tree, Extraction(), EvidenceCorpus(), max_source_chars=100)
        found = broker.request({'kind': 'search', 'query': 'missing'})
        self.assertTrue(found['truncated'])
        # b.py did not fit the search share, but still fits the common hard cap.
        self.assertTrue(broker.request({'kind': 'file', 'path': 'b.py'})['ok'])
        self.assertLessEqual(broker.inventory()['usage']['source_chars'], 100)

    def test_large_discovery_files_are_not_read_forever(self):
        for size in (16, 30):
            with self.subTest(size=size):
                tree = MemoryTree({f'file{i}.py': 'a' * size for i in range(10)})
                broker = EvidenceBroker(tree, Extraction(), EvidenceCorpus(),
                                        max_source_files=2, max_source_chars=20)
                broker.request({'kind': 'search', 'query': 'missing'})
                first_reads = list(tree.reads)
                broker.request({'kind': 'search', 'query': 'another_missing'})
                self.assertEqual(first_reads, tree.reads)
                self.assertEqual(len(first_reads), 1)
                direct = broker.request({'kind': 'file', 'path': 'file0.py'})
                self.assertEqual(direct['ok'], size <= 20)
                self.assertLessEqual(direct['usage']['source_files'], 2)


if __name__ == '__main__':
    unittest.main()
