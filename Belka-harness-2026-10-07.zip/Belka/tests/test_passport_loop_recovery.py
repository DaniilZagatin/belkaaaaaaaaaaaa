"""New Healthchecks failure: reading keeps advancing but no conclusion is saved.

Scripted transports exercise the production loop and real evidence/review gates.
They test the feedback contract, not whether a live model follows that feedback.
"""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest

from pko.progress.passport_agent import run_passport_agent
from pko.progress.passport_focus import FOCUS_MARKER, RECOVERY_INTERVAL
from test_passport_agentic import SPEC, corpus_fixture
from test_passport_code_reconstruction import code_responses
from test_passport_integrated_research import ResearchClient, result, tool


class ReadingClient(ResearchClient):
    def __init__(self, *, recover):
        super().__init__(*code_responses())
        self.recover = recover
        self.read_steps = 0
        self.notices = []
        self.started_saving = False
        self.available_tools = []

    def chat(self, messages, **kwargs):
        names = {s["function"]["name"] for s in kwargs.get("tools", [])}
        if "submit_checks" in names:
            return super().chat(messages, **kwargs)
        self.available_tools.append(names)
        new_notices = [m["content"] for m in messages if m.get("role") == "user"
                       and str(m.get("content", "")).startswith(FOCUS_MARKER)]
        self.notices.extend(n for n in new_notices if n not in self.notices)
        if self.recover and (self.started_saving or new_notices):
            self.started_saving = True
            return super().chat(messages, **kwargs)
        self.messages.append(deepcopy(messages))
        self.read_steps += 1
        if self.recover:
            # Every read is new: the old idle guard would keep resetting.
            return result(tool("read_passport_evidence", {"ids": [f"evidence-{self.read_steps + 2}"]}))
        # Varying empty searches evade a detector of identical call signatures.
        return result(tool("search_passport_evidence", {"query": f"missing-{self.read_steps}"}))


class LoopRecoveryTests(unittest.TestCase):
    def test_new_reading_is_interrupted_by_early_feedback_then_grounded_research_can_finish(self):
        corpus = corpus_fixture()
        for i in range(40):
            corpus.add("code", f"fragment_{i}.py:1", f"1: def task_{i}():\n2:     return result_{i}()")
        client = ReadingClient(recover=True)
        with tempfile.TemporaryDirectory() as tmp:
            checkpoint = Path(tmp) / "passport.json"
            output = run_passport_agent([], {}, [], None, SPEC, client=client, max_steps=40,
                evidence_corpus=corpus, agentic=True, research_enabled=True, research_basis="code",
                capability_digest="OLD_TASK_WRAPPER: Сверяй буллиты; show_facts покажет остальное",
                checkpoint_path=checkpoint)
            saved = json.loads(checkpoint.read_text(encoding="utf-8"))
        self.assertEqual(client.read_steps, RECOVERY_INTERVAL)
        self.assertTrue(client.notices)
        self.assertEqual(output.passport_data["completion"]["state"], "complete", output.notes)
        self.assertTrue(client.reviewed_packets, "Completion still needs independent checks")
        self.assertEqual(output.integrity.level, "unknown")
        self.assertIn("evidence-3", saved["draft"]["research_focus"]["reads"])
        self.assertNotIn("OLD_TASK_WRAPPER", client.messages[0][1]["content"])
        self.assertTrue(all("submit_scenarios" in names and "request_passport_evidence" not in names
                            and "submit_node" in names and "read_passport_evidence" in names
                            for names in client.available_tools))

    def test_ignored_feedback_stops_incomplete_and_does_not_create_a_passport(self):
        client = ReadingClient(recover=False)
        output = run_passport_agent([], {}, [], None, SPEC, client=client, max_steps=80,
            evidence_corpus=corpus_fixture(), agentic=True, research_enabled=True, research_basis="code")
        self.assertTrue(client.notices)
        self.assertLess(output.steps, 40)
        self.assertEqual(output.passport_data["completion"]["state"], "incomplete")
        self.assertFalse(output.passport_data["agent_filled"])
        self.assertFalse(client.reviewed_packets)
        self.assertTrue(any("остановлено" in note for note in output.notes))


if __name__ == "__main__":
    unittest.main()
