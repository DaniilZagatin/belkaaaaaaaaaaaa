"""Regressions for reviewed coverage, structural revisions and retained findings."""
from copy import deepcopy
import json
import unittest

from pko.progress import passport_tools
from pko.progress.passport_agent import (
    _answer_call, _handle_bind_scenario_step, _handle_finish, _handle_submit_defect,
    _handle_submit_guardrail, _handle_submit_node, _progress_mark,
    _compact_agentic_history,
)
from pko.progress.passport_facts import Capability
from pko.progress.passport_workspace import sync_objects
from test_passport_agentic import (
    QUOTE, REASON, approve_current_versions, node_args, session_fixture, tool,
)


CODE = [{"id": "evidence-1", "quote": QUOTE}]
INTENT = [{"id": "evidence-2", "quote": "Клиент получает отчёт по явному запросу."}]


def scenario_session():
    state = session_fixture(filled=True)
    state.scenarios = {"scenario-1": ["Подготовить отчёт"], "scenario-2": ["Доставить отчёт"]}
    for i in (1, 2):
        state.nodes[f"process-{i}"].data["scenarios"] = [f"scenario-{i}"]
        state.nodes[f"operation-{i}"].data["scenario_steps"] = [{"scenario": f"scenario-{i}", "step": 0}]
    return state


def defect_args():
    return {"title": "Ошибка отправки прерывает обработку отчёта до завершения",
            "kind": "integration", "nodes": ["operation-2"], "where": "reports.py:2",
            "blocking": False, "evidence": deepcopy(CODE)}


def guardrail_args(state):
    quote = '2:     if not report: raise ValueError("report required")'
    state.evidence_corpus.add("code", "guards.py:1", "1: def check_report(report):\n" + quote)
    eid = next(reversed(state.evidence_corpus.records))
    # Only read makes the newly added fragment citable.
    state.evidence_corpus.read([eid])
    state.known_paths.add("guards.py")
    return {"name": "Запрет отправки пустого отчёта",
            "invariant": "Пустой отчёт не передаётся в дальнейшую обработку",
            "condition": "При проверке отсутствует содержимое переданного отчёта",
            "effect": "DENY", "targets": ["operation-2"],
            "source": "Установлено: guards.py:2 — проверка отклоняет пустой отчёт исключением.",
            "evidence": [{"id": eid, "quote": quote}]}


def claim_args(text="send_report вызывает отправку отчёта"):
    return {"kind": "effect", "text": text, "conditions": "Обработчик получил данные отчёта.",
            "limits": "Результат доставки клиенту не проверен.", "nodes": ["operation-1"],
            "evidence": deepcopy(CODE)}


class ScenarioOwnershipReviewTests(unittest.TestCase):
    def test_foreign_step_binding_rejects_before_replacing_valid_mapping(self):
        state = scenario_session()
        before = {nid: deepcopy(n.data) for nid, n in state.nodes.items()}
        reply = _handle_bind_scenario_step(state, {"scenario": "scenario-1", "step": 0,
                                                   "nodes": ["operation-2"], "replace": True})
        self.assertIn("отклонён", reply)
        self.assertIn("scenario-1", reply)
        self.assertEqual({nid: n.data for nid, n in state.nodes.items()}, before)

    def test_shared_process_can_bind_its_operation_to_both_scenarios(self):
        state = scenario_session()
        state.nodes["process-2"].data["scenarios"] = ["scenario-1", "scenario-2"]
        for sid in state.scenarios:
            self.assertNotIn("отклонён", _handle_bind_scenario_step(state,
                {"scenario": sid, "step": 0, "nodes": ["operation-2"], "replace": True}))
        self.assertEqual(state.unbound_steps(), [])
        self.assertEqual({row["scenario"] for row in state.nodes["operation-2"].data["scenario_steps"]},
                         {"scenario-1", "scenario-2"})

    def test_finish_rechecks_old_bindings_after_process_scenario_revision(self):
        state = scenario_session()
        for nid, scenarios in (("process-1", ["scenario-2"]),
                               ("process-2", ["scenario-1", "scenario-2"])):
            args = node_args(nid)
            args["scenarios"] = scenarios
            self.assertNotIn("отклонён", _handle_submit_node(state, args))
        # Every scenario is represented and every step is bound. Fresh receipts
        # must not waive the now-invalid ownership of operation-1's old step.
        self.assertEqual(state.unbound_steps(), [])
        state.risk_reviewed = True
        approve_current_versions(state)
        reply = _handle_finish(state, {})
        self.assertIn("отклонён", reply)
        self.assertIn("operation-1", reply)
        self.assertIn("scenario-1", reply)
        self.assertFalse(state.finished)


class AdditionalRecordReviewTests(unittest.TestCase):
    def test_defects_and_guardrails_require_read_code_and_independent_review(self):
        for kind, handler, factory in (("defect", _handle_submit_defect, lambda s: defect_args()),
                                       ("guardrail", _handle_submit_guardrail, guardrail_args)):
            with self.subTest(kind=kind):
                state = session_fixture(filled=True)
                args = factory(state)
                for evidence in ([], INTENT):
                    proposal = {**deepcopy(args), "evidence": deepcopy(evidence)}
                    self.assertIn("отклон", handler(state, proposal))
                    self.assertEqual(getattr(state, "defects" if kind == "defect" else "guardrails"), [])
                state.evidence_corpus.shown.clear()
                self.assertIn("отклон", handler(state, args))
                state.evidence_corpus.read([args["evidence"][0]["id"]])
                self.assertNotIn("отклон", handler(state, args))
                rows = getattr(state, "defects" if kind == "defect" else "guardrails")
                oid = kind + ":" + rows[0]["id"]
                state.risk_reviewed = True
                approve_current_versions(state)
                state.workspace.reviews.pop(oid)
                self.assertIn(oid, state.workspace.pending_reviews())
                self.assertIn("отклонён", _handle_finish(state, {}))
                self.assertFalse(state.finished)
                approve_current_versions(state)
                self.assertNotIn("отклонён", _handle_finish(state, {}))

    def test_record_revision_preserves_id_and_invalidates_its_receipt(self):
        for kind, handler, factory in (("defect", _handle_submit_defect, lambda s: defect_args()),
                                       ("guardrail", _handle_submit_guardrail, guardrail_args)):
            with self.subTest(kind=kind):
                state = session_fixture(filled=True)
                args = factory(state)
                self.assertNotIn("отклон", handler(state, args))
                rows = getattr(state, "defects" if kind == "defect" else "guardrails")
                rid = rows[0]["id"]
                approve_current_versions(state)
                oid = kind + ":" + rid
                old_revision = state.workspace.objects[oid]["revision"]
                args["id"] = rid
                args["blocking" if kind == "defect" else "condition"] = (
                    True if kind == "defect" else "При проверке передан отчёт без содержимого и реквизитов")
                self.assertNotIn("отклон", handler(state, args))
                sync_objects(state)
                self.assertEqual(len(rows), 1)
                self.assertEqual(rows[0]["id"], rid)
                self.assertNotEqual(state.workspace.objects[oid]["revision"], old_revision)
                self.assertIn(oid, state.workspace.pending_reviews())

    def test_explicit_capability_binding_counts_as_progress_and_needs_review(self):
        state = session_fixture(filled=True)
        state.capabilities = [Capability("cap-1", "ROUTE", "Отправить отчёт", "reports.py", 2, (1, 2))]
        state.capabilities_total = 1
        state.risk_reviewed = True
        approve_current_versions(state)
        before = _progress_mark(state)
        reply = _answer_call(state, tool("bind_capability", {"capability": "cap-1", "nodes": ["process-2"]}))
        self.assertNotIn("отклон", reply["content"])
        self.assertNotEqual(_progress_mark(state), before)
        mapped, _, unreviewed = state.capability_state()
        self.assertEqual(mapped["cap-1"], ["process-2"])
        self.assertEqual(unreviewed, [])
        self.assertIn("binding:cap-1", state.workspace.pending_reviews())
        self.assertIn("отклонён", _handle_finish(state, {}))
        approve_current_versions(state)
        self.assertNotIn("отклонён", _handle_finish(state, {}))

    def test_descendant_revision_invalidates_all_ancestor_receipts(self):
        state = session_fixture(filled=True)
        approve_current_versions(state)
        old = {nid: state.workspace.objects[nid]["revision"] for nid in
               ("journey-1", "process-1", "bbb-1", "operation-1")}
        reply = _handle_submit_node(state, node_args("operation-1",
            outcome="Отчёт передаётся транспорту; успешная доставка клиенту не проверена."))
        self.assertNotIn("отклонён", reply)
        sync_objects(state)
        for nid, revision in old.items():
            with self.subTest(node=nid):
                self.assertNotEqual(state.workspace.objects[nid]["revision"], revision)
                self.assertIn(nid, state.workspace.pending_reviews())


class RetainedWithdrawalReviewTests(unittest.TestCase):
    def test_withdrawn_claim_keeps_previous_content_and_reviewed_retirement(self):
        state = session_fixture(filled=True)
        args = claim_args()
        self.assertNotIn("отклон", passport_tools.claim(state, args))
        cid = next(iter(state.workspace.claims))
        previous = deepcopy(state.workspace.claims[cid])
        state.risk_reviewed = True
        approve_current_versions(state)
        self.assertNotIn("отклон", passport_tools.retire_record(state, {
            "kind": "claim", "id": cid, "reason": REASON, "evidence": deepcopy(CODE)}))
        self.assertNotIn(cid, state.workspace.claims)
        oid = "retirement:claim:" + cid
        sync_objects(state)
        self.assertNotIn(cid, state.workspace.objects)
        self.assertEqual(state.workspace.objects[oid]["content"]["previous"], previous)
        self.assertIn(oid, state.workspace.pending_reviews())
        state.risk_reviewed = True
        approve_current_versions(state)
        state.workspace.reviews.pop(oid)
        self.assertIn("отклонён", _handle_finish(state, {}))
        self.assertFalse(state.finished)
        approve_current_versions(state)
        self.assertNotIn("отклонён", _handle_finish(state, {}))

    def test_new_claim_never_overwrites_live_or_retired_claim_id(self):
        state = session_fixture(filled=True)
        for text in ("send_report вызывает отправку отчёта", "send_report передаёт отчёт транспорту"):
            self.assertNotIn("отклон", passport_tools.claim(state, claim_args(text)))
        first, second = list(state.workspace.claims)
        second_content = deepcopy(state.workspace.claims[second])
        self.assertNotIn("отклон", passport_tools.retire_record(state, {
            "kind": "claim", "id": first, "reason": REASON, "evidence": deepcopy(CODE)}))
        self.assertNotIn("отклон", passport_tools.claim(state, claim_args("send_report получает подготовленный отчёт")))
        self.assertEqual(len(state.workspace.claims), 2)
        self.assertEqual(state.workspace.claims[second], second_content)
        self.assertNotIn(first, state.workspace.claims)
        self.assertTrue(set(state.workspace.claims) - {first, second})

    def test_withdrawing_rejected_substantive_finding_requires_review(self):
        state = session_fixture(filled=True)
        fid = state.workspace.reject("submit_claim:", {"tool": "submit_claim", **claim_args()},
                                     "Цитата не подтверждает заявленный результат.")
        reply = passport_tools.resolve(state, {"id": fid, "resolution": "withdrawn",
            "reason": REASON, "evidence": deepcopy(CODE)})
        self.assertNotIn("отклон", reply)
        sync_objects(state)
        self.assertNotIn(fid, state.workspace.unresolved())
        self.assertIn("resolution:" + fid, state.workspace.pending_reviews())
        state.risk_reviewed = True
        approve_current_versions(state)
        state.workspace.reviews.pop("resolution:" + fid)
        self.assertIn("отклонён", _handle_finish(state, {}))


class CounterexampleAndContextTests(unittest.TestCase):
    def test_risk_catalog_and_context_are_discoverable_before_tree_completion(self):
        from pko.progress.risk_catalog import load_catalog
        state = session_fixture()
        catalog = passport_tools.read_state(state, {"section": "risk_catalog"})
        first_id = load_catalog()["patterns"][0]["id"]
        self.assertIn(first_id, catalog)
        reply = _answer_call(state, tool("read_risk_patterns", {"ids": [first_id]}))
        self.assertEqual(json.loads(reply["content"])["patterns"][0]["id"], first_id)
        self.assertTrue(passport_tools.read_state(state, {"section": "risk_context"}).strip())

    def test_same_version_cannot_repoll_away_a_counterexample(self):
        state = session_fixture(filled=True)
        packets = []
        def reviewer(objects):
            packets.append(deepcopy(objects))
            obj = objects[0]
            return {"findings": [{"object_id": obj["id"], "revision": obj["revision"],
                    "result": "contradicted" if len(packets) == 1 else "supported",
                    "reason": REASON, "evidence": deepcopy(CODE)}]}
        state.reviewer = reviewer
        passport_tools.review(state, {"ids": ["operation-1"]})
        self.assertTrue(state.workspace.unresolved())
        self.assertIn("отклонён", passport_tools.review(state, {"ids": ["operation-1"]}))
        self.assertEqual(len(packets), 1)
        finding = next(iter(state.workspace.findings))
        self.assertIn("отклонён", passport_tools.resolve(state, {"id": finding,
            "resolution": "withdrawn", "reason": REASON, "evidence": CODE}))
        state.nodes["operation-1"].data["explanation"] = "Результат передачи ограничен доступным кодом, доставка не доказана."
        passport_tools.review(state, {"ids": ["operation-1"]})
        self.assertEqual(len(packets), 2)
        self.assertEqual(packets[1][0]["prior_findings"][0]["proposal"]["result"], "contradicted")
        self.assertFalse(state.workspace.unresolved())

    def test_rejected_claim_can_be_retired_after_reviewing_withdrawal(self):
        state = session_fixture(filled=True)
        passport_tools.claim(state, claim_args())
        sync_objects(state)
        cid = next(iter(state.workspace.claims))
        obj = state.workspace.objects[cid]
        state.workspace.reject("review:" + cid, {"tool": "independent_review", "revision": obj["revision"]}, REASON)
        passport_tools.retire_record(state, {"kind": "claim", "id": cid, "reason": REASON, "evidence": CODE})
        state.reviewer = lambda objects: {"findings": [{"object_id": o["id"], "revision": o["revision"],
            "result": "supported", "reason": REASON, "evidence": CODE} for o in objects]}
        self.assertTrue(state.workspace.unresolved())
        passport_tools.review(state, {"ids": ["retirement:claim:" + cid]})
        self.assertFalse(state.workspace.unresolved())
        self.assertNotIn(cid, state.workspace.claims)

    def test_old_state_replies_compact_but_can_be_reloaded(self):
        state = session_fixture(filled=True)
        sync_objects(state)
        oid = "operation-1"
        state.nodes[oid].data["explanation"] = "Существенное условие. " * 300
        messages = []
        for i in range(40):
            call = tool("research_state", {"section": "object", "id": oid})
            call["id"] = str(i)
            messages.append({"role": "assistant", "tool_calls": [call]})
            messages.append({"role": "tool", "tool_call_id": str(i),
                             "content": passport_tools.read_state(state, {"section": "object", "id": oid})})
        before = sum(len(m.get("content", "")) for m in messages)
        latest = deepcopy(messages[-1])
        _compact_agentic_history(messages)
        self.assertLess(sum(len(m.get("content", "")) for m in messages), before / 3)
        self.assertEqual(messages[-1], latest)
        self.assertIn(state.nodes[oid].data["explanation"], passport_tools.read_state(state, {"section": "object", "id": oid}))

    def test_rename_preserves_object_identity_and_updates_generated_parent_name(self):
        state = session_fixture(filled=True)
        self.assertNotIn("отклон", _handle_submit_node(state, node_args("bbb-1")))
        original = state.nodes["bbb-1"].data["object-id"]
        self.assertNotIn("отклон", _handle_submit_node(state, node_args("bbb-1", name="Сбор сведений для отчёта")))
        self.assertEqual(state.nodes["bbb-1"].data["object-id"], original)
        self.assertIn("Сбор сведений для отчёта", state.nodes["operation-1"].data["fields"]["4.5.2"]["value"])

    def test_defect_cannot_borrow_real_quote_for_a_fictitious_location(self):
        state = session_fixture(filled=True)
        args = defect_args()
        args["where"] = "not_exists.py:500"
        self.assertIn("отклон", _handle_submit_defect(state, args))
        self.assertFalse(state.defects)


if __name__ == "__main__":
    unittest.main()
