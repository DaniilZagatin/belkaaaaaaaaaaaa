"""No-model regressions for same-snapshot, atomic passport continuation."""
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from pydantic_ai.messages import ModelRequest, ModelResponse, TextPart, ThinkingPart, ToolCallPart, ToolReturnPart, UserPromptPart
from pydantic_ai_harness.step_persistence import ContinuableSnapshot, StepPersistence

from pko.progress.passport_agent import _Node, _PassportSession
from pko.progress.passport_broker import EvidenceBroker
from pko.progress.passport_evidence import EvidenceCorpus
from pko.progress.passport_harness_state import ResumeError, prepare_store, source_identity
from pko.progress.passport_workspace import sync_objects


class Tree:
    def __init__(self, source=None):
        self.source = source or {"app.py": 'def run():\n    API_KEY = "sample-sensitive-value"\n    return 1\n',
                                 "other.py": "def other():\n    return 2\n", ".env": "NEVER_READ"}
        self.files = list(self.source)
        self.reads = []

    def read(self, path):
        self.reads.append(path)
        return self.source[path]


def session(tree=None):
    corpus = EvidenceCorpus(commit="sample")
    corpus.add("code", "app.py:1", "1: def run():")
    broker = EvidenceBroker(tree or Tree(), SimpleNamespace(facts=[]), corpus, max_requests=2)
    state = _PassportSession(agentic=True, research_enabled=True, research_basis="code",
                             evidence_corpus=corpus, evidence_broker=broker)
    state.nodes["journey-1"] = _Node("journey-1", "Работа", "Прочитанная реализация")
    return state


def messages():
    return [ModelRequest(parts=[UserPromptPart("Исследуй код")]),
            ModelResponse(parts=[ToolCallPart("read", {"ids": ["evidence-1"]}, "call-1")]),
            ModelRequest(parts=[ToolReturnPart("read", {"ok": True}, "call-1")])]


def snapshot(key="1:boundary", *, state="complete", history=None):
    return ContinuableSnapshot(run_id="sample-run", step_index=1,
                               messages=messages() if history is None else history,
                               state=state, idempotency_key=key)


class HarnessPersistenceTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / "run.harness.json"
        self.configuration = {"model": "offline-fixture", "prompt": "v1", "tools": "v1"}

    def prepare(self, state, *, resume=False, configuration=None):
        return prepare_store(state, self.path, configuration=configuration or self.configuration,
                             resume_path=self.path if resume else None)

    async def test_roundtrip_keeps_read_provenance_drafts_findings_and_broker_limits(self):
        state = session()
        store, _ = self.prepare(state)
        state.evidence_corpus.read(["evidence-1"])
        first = state.evidence_broker.request({"kind": "file", "path": "app.py"})
        state.evidence_broker.request({"kind": "file", "path": "other.py"})
        state.node_drafts["journey-1"] = {"revision": 3, "proposal": {"name": "Исправить"}}
        state.workspace.reject("journey-1", {"name": "Неподтверждённо"}, "Нет основания")
        state.research_focus = {"object": "journey-1", "read_count": 8}
        state.unresolved_relations[("journey-1", "process-1", "feeds")] = "Пробел"
        state.tool_calls = 17
        state.workspace.review_calls = 4
        state.stop_reason = "idle"
        await store.save_snapshot(snapshot())
        text = self.path.read_text(encoding="utf-8")
        self.assertNotIn("sample-sensitive-value", text)
        fresh = session()
        restored, history = self.prepare(fresh, resume=True)
        self.assertEqual(len(history), 3)
        self.assertEqual(restored.sequence, 1)
        self.assertEqual(fresh.tool_calls, 17)
        self.assertEqual(fresh.workspace.review_calls, 4)
        self.assertEqual(fresh.stop_reason, "")
        self.assertEqual(fresh.node_drafts, state.node_drafts)
        self.assertEqual(fresh.workspace.findings, state.workspace.findings)
        self.assertEqual(fresh.unresolved_relations, state.unresolved_relations)
        self.assertEqual(fresh.evidence_corpus.shown, {"evidence-1": ["1: def run():"]})
        self.assertIs(fresh.evidence_broker.corpus, fresh.evidence_corpus)
        # Inventory hydration is not a model read, and spent budget is retained.
        self.assertTrue(fresh.evidence_corpus.citations([{"id": first["records"][0]["id"],
                                                        "quote": "def run():"}]))
        cached = fresh.evidence_broker.request({"kind": "file", "path": "app.py"})
        self.assertTrue(cached["cached"])
        self.assertEqual(cached["records"], first["records"])
        denied = fresh.evidence_broker.request({"kind": "search", "query": "other"})
        self.assertEqual(denied["error"], "request_budget")

    async def test_changed_source_or_config_rejected_before_mutating_fresh_state(self):
        store, _ = self.prepare(session())
        await store.save_snapshot(snapshot())
        changed = session(Tree({"app.py": "def run(): return 999", "other.py": "unchanged"}))
        initial = changed.nodes["journey-1"]
        with self.assertRaisesRegex(ResumeError, "different sources or settings"):
            self.prepare(changed, resume=True)
        self.assertIs(changed.nodes["journey-1"], initial)
        with self.assertRaisesRegex(ResumeError, "different sources or settings"):
            self.prepare(session(), resume=True, configuration={"model": "different"})

    async def test_interrupted_batch_does_not_overwrite_last_settled_domain(self):
        state = session()
        store, _ = self.prepare(state)
        state.notes = ["settled"]
        await store.save_snapshot(snapshot())
        state.notes.append("unsettled mutation")
        await store.save_snapshot(snapshot("2:failure", state="interrupted", history=messages()[:-1]))
        fresh = session()
        self.prepare(fresh, resume=True)
        self.assertEqual(fresh.notes, ["settled"])

    async def test_idempotency_and_stale_sequence_cannot_mix_new_domain_with_old_history(self):
        state = session()
        store, _ = self.prepare(state)
        await store.save_snapshot(snapshot("2:ok"))
        before = self.path.read_bytes()
        state.notes.append("must not leak")
        await store.save_snapshot(snapshot("2:ok"))
        await store.save_snapshot(snapshot("1:old"))
        self.assertEqual(self.path.read_bytes(), before)

    async def test_atomic_write_failure_preserves_previous_checkpoint(self):
        state = session()
        store, _ = self.prepare(state)
        await store.save_snapshot(snapshot())
        before = self.path.read_bytes()
        state.notes.append("not committed")
        with patch("pko.progress.passport_harness_state.os.replace", side_effect=OSError):
            with self.assertRaises(OSError):
                await store.save_snapshot(snapshot("2:new"))
        self.assertEqual(self.path.read_bytes(), before)
        self.assertEqual(list(self.path.parent.glob("*.tmp")), [])
        self.assertEqual(store.sequence, 1)

    async def test_checksum_tamper_and_finished_rejected(self):
        state = session()
        store, _ = self.prepare(state)
        await store.save_snapshot(snapshot())
        data = json.loads(self.path.read_text(encoding="utf-8"))
        data["sequence"] += 1
        self.path.write_text(json.dumps(data), encoding="utf-8")
        with self.assertRaisesRegex(ResumeError, "checksum"):
            self.prepare(session(), resume=True)
        state.finished = True
        await store.save_snapshot(snapshot("2:finish"))
        with self.assertRaisesRegex(ResumeError, "already finished"):
            self.prepare(session(), resume=True)

    async def test_fingerprint_neither_reads_secret_file_nor_spends_evidence_budget(self):
        state = session()
        before = state.evidence_broker._usage()
        source_identity(state.evidence_broker)
        self.assertNotIn(".env", state.evidence_broker._snapshot._tree.reads)
        self.assertEqual(state.evidence_broker._usage(), before)
        self.assertEqual(state.evidence_corpus.shown, {})

    async def test_actual_step_persistence_pairs_tool_result_with_domain(self):
        from pydantic_ai import Agent
        from pydantic_ai.models.function import FunctionModel
        state = session()
        store, _ = self.prepare(state)
        def respond(history, info):
            if not any(isinstance(p, ToolReturnPart) for msg in history for p in msg.parts):
                return ModelResponse(parts=[ToolCallPart("save_fact", {}, "fact-1")])
            return ModelResponse(parts=[TextPart("Готово")])
        agent = Agent(FunctionModel(respond), capabilities=[StepPersistence(store=store)])
        @agent.tool_plain
        def save_fact() -> str:
            state.notes.append("accepted fact")
            return "Сохранено"
        await agent.run("Исследуй")
        fresh = session()
        _, history = self.prepare(fresh, resume=True)
        self.assertIn("accepted fact", fresh.notes)
        self.assertTrue(any(isinstance(p, ToolReturnPart) for msg in history for p in msg.parts))

    async def test_nested_research_and_exact_review_revisions_survive(self):
        from pko.progress.passport_connectivity import _get_state, CodeScenario
        from pko.progress.passport_system_research import _SystemResearch
        from pko.progress.schema import EvidenceRef, FlowTrace, Handoff, HandoffCheck, SystemPurpose
        state = session()
        store, _ = self.prepare(state)
        state.evidence_corpus.read(["evidence-1"])
        refs = [{"id": "evidence-1", "quote": "1: def run():"}]
        conn = _get_state(state)
        ev = EvidenceRef("app.py", 1, "run", True, "")
        conn.scenarios["scenario-1"] = CodeScenario("scenario-1", "Работа", "Вход", "Результат",
            ["Первый", "Второй"], handoffs=[Handoff(0, checks=[HandoffCheck("contract", "unknown", evidence=[ev])])])
        conn.order = ["scenario-1"]
        conn.revisions = {"scenario-1": 1}
        conn.scenario_evidence = {"scenario-1": refs}
        conn.next_id = 2
        state.scenarios = {"scenario-1": ["Первый", "Второй"]}
        state.nodes["journey-1"].filled = True
        state.nodes["journey-1"].data = {"fields": {}, "existence_evidence": refs}
        purpose = SystemPurpose("Работает", "Граница неизвестна", "code_derived", [ev])
        state.system_research_state = _SystemResearch(purpose=purpose,
            flow=FlowTrace("Вход", ["Первый", "Второй"], "Выход", evidence=[ev]),
            records={"system:purpose": {"type": "purpose", "value": purpose.to_dict(),
                     "research_basis": "code", "evidence": refs}})
        sync_objects(state)
        for oid, obj in state.workspace.objects.items():
            state.workspace.reviews[oid] = {"revision": obj["revision"], "result": "supported"}
        before = state.workspace.export()
        await store.save_snapshot(snapshot())
        fresh = session()
        fresh.max_review_calls = 99
        self.prepare(fresh, resume=True)
        self.assertEqual(fresh.workspace.export(), before)
        self.assertEqual(fresh.max_review_calls, 99)
        self.assertIsInstance(fresh.connectivity_state.scenarios["scenario-1"], CodeScenario)
        self.assertEqual(fresh.connectivity_state.scenarios["scenario-1"].handoffs[0].checks[0].evidence[0], ev)
        self.assertEqual(fresh.system_research_state.purpose, purpose)
        self.assertTrue(fresh.connectivity_state.tree.read("app.py"))
        self.assertEqual(fresh.workspace.pending_reviews(), [])

    async def test_cached_source_rehydrate_is_bounded(self):
        state = session()
        store, _ = self.prepare(state)
        state.evidence_broker.request({"kind": "file", "path": "app.py"})
        await store.save_snapshot(snapshot())
        fresh = session()
        fresh_store, _ = self.prepare(fresh)
        with patch("pko.progress.passport_harness_state.MAX_SOURCE_SECONDS", 0):
            with self.assertRaisesRegex(ResumeError, "time limit"):
                fresh_store.restore(self.path)
        self.assertEqual(fresh.evidence_corpus.shown, {})
        self.assertEqual(fresh.evidence_broker._requests, 0)

    async def test_private_reasoning_and_provider_metadata_never_reach_file(self):
        store, _ = self.prepare(session())
        await store.save_snapshot(snapshot())
        before = self.path.read_bytes()
        for response in (ModelResponse(parts=[ThinkingPart("PRIVATE_PROVIDER_THOUGHT"), TextPart("visible")]),
                         ModelResponse(parts=[TextPart("visible")], provider_details={"reasoning": "PRIVATE_PROVIDER_THOUGHT"})):
            with self.assertRaisesRegex(ResumeError, "Private provider"):
                await store.save_snapshot(snapshot("2:private", history=messages() + [response]))
        self.assertEqual(self.path.read_bytes(), before)
        self.assertNotIn(b"PRIVATE_PROVIDER_THOUGHT", before)

    async def test_loaded_boundary_cannot_replay_and_store_cannot_reset_twice(self):
        store, _ = self.prepare(session())
        await store.save_snapshot(snapshot("3:ok"))
        restored, _ = self.prepare(session(), resume=True)
        before = self.path.read_bytes()
        await restored.save_snapshot(snapshot("3:ok"))
        await restored.save_snapshot(snapshot("2:old"))
        self.assertEqual(self.path.read_bytes(), before)
        with self.assertRaisesRegex(ResumeError, "fresh harness store"):
            restored.restore(self.path)

    async def test_clock_settles_before_save_and_compaction_read_memory_survives(self):
        from pko.progress.passport_context import _Memory, _materials
        state = session()
        store, _ = self.prepare(state)
        state.evidence_corpus.read(["evidence-1"])
        state._passport_context = _Memory(compacted=True, evidence={"evidence-1": None},
                                         quotes={("evidence-1", "def run():"): None})
        store.before_save = lambda: setattr(state, "harness_elapsed_seconds", 42.5)
        await store.save_snapshot(snapshot())
        fresh = session()
        self.prepare(fresh, resume=True)
        self.assertEqual(fresh.harness_elapsed_seconds, 42.5)
        self.assertEqual(fresh._passport_context, state._passport_context)
        self.assertEqual(_materials(fresh._passport_context, fresh.evidence_corpus, [])["records"][0]["id"], "evidence-1")


if __name__ == "__main__":
    unittest.main()
