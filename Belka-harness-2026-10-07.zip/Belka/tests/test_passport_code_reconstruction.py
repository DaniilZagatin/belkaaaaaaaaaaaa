"""The production passport researches code even without, or outside, an OR."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import time
from types import SimpleNamespace
import unittest

from pko.progress.passport_agent import run_passport_agent, _handle_submit_node
from pko.progress.passport_connections import submit_connection_review, connection_blockers
from pko.progress.passport_workspace import sync_objects
from pko.progress import passport_tools
from pko.progress.schema import PlanItem
from test_passport_agentic import SPEC, QUOTE, corpus_fixture, node_args, approve_current_versions
from test_passport_integrated_research import ResearchClient, research_responses, result, tool
from test_passport_system_research import research_session, REFS


def connection_args(pid="process-1"):
    return {"process": pid, "checks": [
        {"aspect": aspect, "result": "unknown", "detail": "Вызов транспорта виден, но поставщик данных и продолжение вне фрагмента не проверены.",
         "nodes": [], "relations": [], "evidence": []}
        for aspect in ("input", "output", "dependencies", "recovery")]}


def code_responses():
    messages = research_responses()
    for message in messages:
        for call in message.tool_calls:
            fn = call["function"]
            args = json.loads(fn["arguments"])
            if fn["name"] == "submit_scenarios":
                for scenario in args["scenarios"]:
                    scenario.pop("bullets", None)
                    scenario["evidence"] = deepcopy(REFS)
            if fn["name"] == "submit_system":
                args.pop("verdict", None)
            if fn["name"] == "submit_node":
                args["existence_evidence"] = deepcopy(REFS)
            if fn["name"] == "review_passport" and len(args["ids"]) < 8:
                args["ids"].append("connection-review:process-1")
            fn["arguments"] = json.dumps(args, ensure_ascii=False)
    # The connections are investigated before risk analysis and both are reviewed.
    messages.insert(-4, result(tool("submit_connection_review", connection_args())))
    return messages


def code_session():
    state = research_session()
    state.research_basis = "code"
    return state


class CodeReconstructionTests(unittest.TestCase):
    def test_document_component_exclusion_uses_its_own_source_not_or(self):
        state = code_session()
        state.evidence_corpus.add("document", "docs/guide.md:1", "Это документация о формате отчётов, исполняемый механизм находится в приложении.")
        eid = list(state.evidence_corpus.records)[-1]
        state.evidence_corpus.read([eid])
        state.evidence_broker = SimpleNamespace(inventory=lambda: {"components": [
            {"path": "docs", "files": 1, "code_files": 0, "document_files": 1}]})
        args = {"target": "component:docs", "disposition": "excluded",
            "reason": "Документация объясняет формат; отдельного исполняемого бизнес-процесса в этом компоненте нет.",
            "evidence": [{"id": eid, "quote": "Это документация о формате отчётов"}]}
        self.assertNotIn("отклонён", passport_tools.scope(state, args))
        sync_objects(state)
        self.assertEqual(state.workspace.objects["scope:component:docs"]["kind"], "source_scope")
        args["evidence"] = [{"id": "evidence-2", "quote": "Клиент получает отчёт по явному запросу."}]
        self.assertIn("отклонён", passport_tools.scope(state, args))
        # A README cannot exempt code in the same component.
        args["evidence"] = [{"id": eid, "quote": "Это документация о формате отчётов"}]
        state.evidence_broker = SimpleNamespace(inventory=lambda: {"components": [
            {"path": "docs", "files": 2, "code_files": 1, "document_files": 1}]})
        self.assertIn("отклонён", passport_tools.scope(state, args))

    def test_source_scope_reviewer_rejects_intent_and_requires_own_document_read(self):
        from pko.progress.passport_reviewer import _ReviewSession, _submit_checks
        corpus = corpus_fixture()
        corpus.add("document", "docs/guide.md:1", "Документация описывает только формат предоставленного отчёта.")
        eid = list(corpus.records)[-1]
        state = _ReviewSession({"scope:docs": {"revision": "v1", "kind": "source_scope"}}, corpus, time.monotonic() + 30)
        check = {"object_id": "scope:docs", "revision": "v1", "result": "supported",
                 "reason": "Проверена граница документального компонента и состав исходных файлов.",
                 "evidence": [{"id": "evidence-2", "quote": "Клиент получает отчёт по явному запросу."}]}
        corpus.read(["evidence-2"])
        self.assertFalse(_submit_checks(state, {"checks": [check]})["ok"])
        check["evidence"] = [{"id": eid, "quote": "Документация описывает только формат предоставленного отчёта."}]
        self.assertFalse(_submit_checks(state, {"checks": [check]})["ok"])
        corpus.read([eid])
        self.assertTrue(_submit_checks(state, {"checks": [check]})["ok"])

    def test_complete_research_without_or_and_with_unrelated_or(self):
        outputs = []
        for criteria in ([], ["Создать несвязанный инвестиционный продукт вне изучаемого сервиса"]):
            client = ResearchClient(*code_responses())
            with tempfile.TemporaryDirectory() as tmp:
                path = Path(tmp) / "checkpoint.json"
                output = run_passport_agent([PlanItem(id="unrelated", title="Иной проект", criteria=criteria)],
                    {"after": "Несвязанный желаемый результат"}, [], None, SPEC,
                    client=client, max_steps=30, evidence_corpus=corpus_fixture(),
                    agentic=True, research_enabled=True, research_basis="code", checkpoint_path=path)
                saved = json.loads(path.read_text(encoding="utf-8"))
            data = output.passport_data
            self.assertEqual(data["completion"]["state"], "complete", data["completion"])
            self.assertEqual(data["research_mode"], "code_reconstruction")
            self.assertEqual(data["research_basis"], "code")
            self.assertEqual(output.integrity.purpose.verdict, "code_derived")
            self.assertEqual(output.connectivity.to_dict()["scenarios"][0]["origin"], "code")
            self.assertEqual(saved["draft"]["connection_review"], data["connection_review"])
            self.assertTrue(all(not n.get("bullets") for n in data["nodes"].values()))
            scenario = data["research"]["objects"]["scenario:scenario-1"]
            self.assertEqual(scenario["kind"], "claim")
            packets = [obj for packet in client.reviewed_packets for obj in packet]
            self.assertTrue(any(obj["id"] == "connection-review:process-1" for obj in packets))
            outputs.append((data["nodes"], data["connectivity"]))
            brief = client.messages[0][1]["content"]
            self.assertNotIn("Несвязанный желаемый результат", brief)
            self.assertNotIn("Создать несвязанный инвестиционный", brief)
        self.assertEqual(outputs[0], outputs[1])

    def test_missing_connections_block_completion_and_are_preserved_on_interrupt(self):
        messages = [m for m in code_responses() if not any(
            c["function"]["name"] in ("submit_connection_review", "review_passport", "finish") for c in m.tool_calls)]
        output = run_passport_agent([], {}, [], None, SPEC, client=ResearchClient(*messages),
            max_steps=30, evidence_corpus=corpus_fixture(), agentic=True, research_enabled=True, research_basis="code")
        self.assertNotEqual(output.passport_data["completion"]["state"], "complete")
        self.assertTrue(any("submit_connection_review" in b for b in output.passport_data["completion"]["blockers"]))

    def test_planned_node_cannot_be_just_an_intent(self):
        state = code_session()
        args = node_args("process-1")
        args["planned"] = True
        args["fact_check"]["execution"]["reachability"] = "planned"
        args["fact_check"]["execution"]["evidence"] = [{"id": "evidence-2", "quote": "Клиент получает отчёт по явному запросу."}]
        self.assertIn("отклонён", _handle_submit_node(state, args))
        args["existence_evidence"] = deepcopy(REFS)
        self.assertIn("planned-узлы", _handle_submit_node(state, args))

    def test_node_requires_its_own_code_basis_even_with_unknown_fields(self):
        state = code_session()
        args = node_args("process-1")
        self.assertIn("существование узла", _handle_submit_node(state, args))
        args["existence_evidence"] = [{"id": "evidence-2", "quote": "Клиент получает отчёт по явному запросу."}]
        self.assertIn("существование узла", _handle_submit_node(state, args))
        args["existence_evidence"] = deepcopy(REFS)
        self.assertNotIn("отклонён", _handle_submit_node(state, args))

    def test_unverified_candidate_is_not_published_as_a_current_node(self):
        from pko.progress.passport_agent import _build_passport_data
        state = code_session()
        # No candidate has submitted any literal code basis yet.
        data = _build_passport_data(state, "fixture", "2026-10-06")
        self.assertEqual(data["nodes"], {})
        self.assertEqual(data["tree"], [])
        self.assertFalse(data["agent_filled"])
        self.assertEqual(len(data["unpublished_nodes"]), len(state.nodes))

    def test_existing_code_stub_is_a_real_node_with_unimplemented_effect(self):
        from pko.progress.schema import passport_code_state
        state = code_session()
        state.evidence_corpus.add("code", "stub.py:1", '1: def deliver_report():\n2:     raise NotImplementedError("delivery")')
        eid = list(state.evidence_corpus.records)[-1]
        state.evidence_corpus.read([eid])
        state.known_paths.add("stub.py")
        ref = {"id": eid, "quote": 'raise NotImplementedError("delivery")',
               "path": "stub.py", "line": 2, "basis": "deliver_report"}
        args = node_args("operation-1")
        args["existence_evidence"] = [ref]
        args["fields"]["4.5.4"] = {"value": "Заготовка в коде: отправка отчёта не реализована.",
                                   "source": "Установлено: stub.py:2 прекращает работу исключением вместо отправки."}
        args["fact_check"]["fields"]["4.5.4"] = {"support": "code", "mechanism": "runtime",
            "evidence": [ref], "limits": "Проверена реализация существующей заготовки в снимке."}
        args["fact_check"]["execution"].update(reachability="definition_only",
            outcome="Отправка отчёта не реализована: вызов прекращается исключением.", evidence=[ref])
        reply = _handle_submit_node(state, args)
        self.assertNotIn("отклонён", reply)
        node = state.nodes["operation-1"]
        self.assertTrue(node.filled)
        self.assertFalse(node.planned)
        self.assertEqual(passport_code_state(node.data, "operation", False)[0], "not_implemented")

    def test_connection_review_requires_all_aspects_and_grounded_decisive_results(self):
        state = code_session()
        args = connection_args()
        self.assertNotIn("отклонён", submit_connection_review(state, args))
        self.assertFalse(any("process-1" in e for e in connection_blockers(state)))
        args["checks"][0]["result"] = "not_applicable"
        self.assertIn("отклонён", submit_connection_review(state, args))
        args["checks"][0]["evidence"] = [{"id": "evidence-1", "quote": QUOTE}]
        self.assertNotIn("отклонён", submit_connection_review(state, args))
        args["checks"][1]["aspect"] = "input"
        self.assertIn("отклонён", submit_connection_review(state, args))

    def test_trace_change_invalidates_connection_review_and_risk_receipt(self):
        from pko.progress.passport_connectivity import handle_research_connectivity
        from pko.progress.schema import HANDOFF_CHECKS
        state = code_session()
        args = {"title": "Получение отчёта", "entry": "Клиент запрашивает отчёт", "outcome": "Клиент получил отчёт",
                "steps": ["Подготовить отчёт", "Передать отчёт"], "critical": True, "evidence": deepcopy(REFS)}
        handle_research_connectivity(state, "submit_scenarios", {"scenarios": [args]})
        trace = {"scenario_id": "scenario-1", "revision": 1, "handoffs": [{"step": 0, "kind": "call", "checks": [
            {"check": c, "result": "unknown", "note": "Продолжение за вызовом транспорта не проверено.", "evidence": []} for c in HANDOFF_CHECKS]}]}
        handle_research_connectivity(state, "submit_trace", trace)
        submit_connection_review(state, connection_args())
        state.risk_reviewed = True
        approve_current_versions(state)
        oid = "connection-review:process-1"
        previous = state.workspace.objects[oid]["revision"]
        trace["handoffs"][0]["checks"][0]["note"] += " Новый материал требует проверки получателя."
        handle_research_connectivity(state, "submit_trace", trace)
        sync_objects(state)
        self.assertNotEqual(state.workspace.objects[oid]["revision"], previous)
        self.assertNotIn(oid, state.workspace.reviews)
        self.assertFalse(state.risk_reviewed)

    def test_process_retirement_preserves_connection_review_and_prior_finding(self):
        state = code_session()
        pid = "process-2"
        state.nodes[pid].children.clear()
        submit_connection_review(state, connection_args(pid))
        sync_objects(state)
        reply = passport_tools.structure(state, {"id": pid, "action": "retire",
            "reason": "Процесс ошибочно продублирован; исходный механизм остаётся в соседнем процессе."})
        self.assertNotIn("отклонён", reply)
        self.assertNotIn(pid, state.connection_review)
        decision = state.workspace.retirements["retirement:" + pid]
        self.assertIn("connection-review:" + pid, decision["retired_object_ids"])
        self.assertEqual(decision["connection_review"]["process"], pid)


if __name__ == "__main__":
    unittest.main()
