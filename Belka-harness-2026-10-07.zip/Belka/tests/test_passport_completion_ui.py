"""Saved completion states stay visible without changing implementation scores."""
import copy
import json
import re
import unittest

from pko.extractors.runner import Extraction
from pko.progress.passport_gate import normalize_passport
from pko.progress.plan_input import parse_plan_text
from pko.progress.schema import ProgressModel
from pko.render.client_journey_passport import (
    STATUS_BADGE_AGENT, STATUS_BADGE_FAILED, STATUS_BADGE_FALLBACK,
    STATUS_BADGE_INCOMPLETE, render_passport_from_model,
)


def passport_fixture():
    return normalize_passport({
        "agent_filled": True,
        "tree": [{"id": "journey-1", "type": "journey", "children": [
            {"id": "process-1", "type": "process", "children": [
                {"id": "bbb-1", "type": "bbb", "children": [
                    {"id": "operation-1", "type": "operation"},
                ]},
            ]},
        ]}],
        "nodes": {
            "journey-1": {"name": "Получение отчёта", "fields": {}},
            "process-1": {"name": "Подготовка отчёта", "fields": {}},
            "bbb-1": {"name": "Сбор данных", "fields": {}},
            "operation-1": {"name": "Чтение сохранённых результатов", "fields": {
                "4.5.4": {"value": "Получены результаты анализа.",
                          "source": "Установлено: reports.py:8 возвращает сохранённые результаты; доставка клиенту не проверена."},
            }},
        },
    })


def render_fixture(data):
    model = ProgressModel(meta={}, items={}, verdicts=[])
    model.passport_data = data
    plan = parse_plan_text("Клиентский путь: Получение отчёта\nПроект: Демо\n## Анализ\n- Отчёт доступен.\n")
    html = render_passport_from_model(model, plan, "demo/repo", Extraction(facts=[]), "abc1234", "main")
    match = re.search(r"var SCHEMA=(.*?); var meta=", html, re.S)
    return html, json.loads(match.group(1))


class PassportCompletionUiTests(unittest.TestCase):
    def test_durable_research_history_is_not_duplicated_in_presentation(self):
        data = passport_fixture()
        data.update(schema_version=2, research={"history": [{"object-id": "INTERNAL_RESEARCH_ONLY", "previous": "x" * 10000}]})
        before = copy.deepcopy(data)
        html, schema = render_fixture(data)
        self.assertNotIn("INTERNAL_RESEARCH_ONLY", html)
        self.assertNotIn("research", schema)
        self.assertEqual(data, before)

    def test_incomplete_overrides_filled_badge_and_preserves_pending_work(self):
        data = passport_fixture()
        data.update(schema_version=2, completion={
            "state": "incomplete", "reason": "Не проверены основания двух узлов.",
            "open_findings": [{"object_id": "operation-1", "reason": "Не подтверждена доставка клиенту."}],
            "pending_reviews": ["process-1"], "unfilled_nodes": ["bbb-1"],
        })
        before = copy.deepcopy(data)
        html, schema = render_fixture(data)
        self.assertEqual(schema["meta"]["filling"], STATUS_BADGE_INCOMPLETE)
        self.assertEqual(schema["completion"], data["completion"])
        self.assertEqual(schema["schema_version"], 2)
        self.assertNotIn(STATUS_BADGE_AGENT, html)
        self.assertIn("Не проверены основания двух узлов.", html)
        self.assertEqual(data, before)

    def test_failed_and_empty_passport_keeps_failure_instead_of_success(self):
        data = {"schema_version": 2, "agent_filled": False,
                "completion": {"state": "failed", "reason": "Истёк лимит времени анализа.",
                               "open_findings": 0, "pending_reviews": 1, "unfilled_nodes": 1}}
        html, schema = render_fixture(data)
        self.assertEqual(schema["meta"]["filling"], STATUS_BADGE_FAILED)
        self.assertEqual(schema["meta"]["filling_note"], STATUS_BADGE_FALLBACK)
        self.assertIn(STATUS_BADGE_FALLBACK, html)
        self.assertEqual(schema["completion"]["state"], "failed")
        self.assertNotIn(STATUS_BADGE_AGENT, html)
        self.assertIn("Истёк лимит времени анализа.", html)

    def test_completion_is_not_inferred_from_node_or_risk_counts(self):
        data = passport_fixture()
        data.update(schema_version=2, completion={"state": "complete", "reason": "Анализ завершён."})
        _, complete = render_fixture(data)
        data["completion"] = {"state": "incomplete", "reason": "Ожидается проверка."}
        _, incomplete = render_fixture(data)
        self.assertEqual(complete["nodes"], incomplete["nodes"])
        self.assertEqual(complete["summary"], incomplete["summary"])
        self.assertEqual(complete["meta"]["filling"], STATUS_BADGE_AGENT)
        self.assertEqual(incomplete["meta"]["filling"], STATUS_BADGE_INCOMPLETE)

    def test_legacy_without_completion_keeps_its_previous_badge(self):
        _, agent = render_fixture(passport_fixture())
        _, fallback = render_fixture(None)
        self.assertEqual(agent["meta"]["filling"], STATUS_BADGE_AGENT)
        self.assertEqual(fallback["meta"]["filling"], STATUS_BADGE_FALLBACK)
        self.assertNotIn("completion", agent)
        self.assertNotIn("completion", fallback)

    def test_completion_reason_cannot_close_the_embedded_script(self):
        data = passport_fixture()
        reason = "</script><script>alert('unsafe')</script>"
        data["completion"] = {"state": "incomplete", "reason": reason}
        html, schema = render_fixture(data)
        self.assertNotIn(reason, html)
        self.assertEqual(schema["completion"]["reason"], reason)

    def test_source_boundaries_and_current_risk_table_are_preserved(self):
        html, _ = render_fixture(passport_fixture())
        self.assertIn("доставка клиенту не проверена", html)
        self.assertIn("Основания и границы полей", html)
        self.assertIn("['Риск','Описание','Обоснование','Что сделать и проверить']", html)
        self.assertIn("Как проверяли риски", html)
        self.assertNotIn("'Что проверено'", html)


if __name__ == "__main__":
    unittest.main()
