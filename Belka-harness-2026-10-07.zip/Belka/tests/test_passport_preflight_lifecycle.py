"""Preflight regressions for decisions that replace independently rejected objects."""
from copy import deepcopy
import os
import unittest
from unittest.mock import patch

from pko.progress import passport_tools
from pko.llm.client import ChatResult
from pko.progress.passport_agent import (
    _handle_bind_capability, _handle_dismiss_capability, _handle_submit_risks, _env_number, run_passport_agent,
)
from pko.progress.passport_facts import Capability
from pko.progress.passport_workspace import sync_objects
from test_passport_agentic import QUOTE, SPEC, ScriptClient, corpus_fixture, session_fixture, tool, unknown_risk_review


class PassportPreflightLifecycleTests(unittest.TestCase):
    def test_nonfinite_environment_budgets_use_safe_default(self):
        for value in ("nan", "NaN", "inf", "-inf", "1e1000", "incorrect"):
            with self.subTest(value=value), patch.dict(os.environ, {"PKO_PASSPORT_MAX_SECONDS": value}):
                self.assertEqual(_env_number("PKO_PASSPORT_MAX_SECONDS", 120), 120)
        with patch.dict(os.environ, {"PKO_PASSPORT_MAX_SECONDS": "0"}):
            self.assertEqual(_env_number("PKO_PASSPORT_MAX_SECONDS", 120), 0)

    def test_tool_budget_stops_before_another_model_request(self):
        first = ChatResult(text="", usage={}, tool_calls=[
            tool("read_passport_evidence", {"ids": ["evidence-1"]}),
            tool("research_state", {"section": "summary"})])
        client = ScriptClient(first, AssertionError("No model call after tool budget exhaustion"))
        with patch("pko.progress.passport_agent.MAX_PASSPORT_TOOL_CALLS", 2):
            output = run_passport_agent([], {}, [], None, SPEC, client=client, max_steps=5,
                evidence_corpus=corpus_fixture(), agentic=True)
        self.assertEqual(len(client.messages), 1)
        self.assertEqual(output.passport_data["completion"]["state"], "incomplete")
        self.assertTrue(any("бюджет вызовов инструментов" in note for note in output.notes))

    def accept_review(self, state, ids):
        packets = []
        def reviewer(objects):
            packets.extend(deepcopy(objects))
            return {"findings": [{"object_id": obj["id"], "revision": obj["revision"],
                "result": "supported", "reason": "Новая версия явно учитывает прежнее возражение и границу знания.",
                "evidence": [{"id": "evidence-1", "quote": QUOTE}]} for obj in objects]}
        state.reviewer = reviewer
        self.assertNotIn("отклонён", passport_tools.review(state, {"ids": ids}))
        return packets

    def negative(self, state, oid, reason="Прежний вывод не учитывает фактический механизм передачи."):
        return state.workspace.reject("review:" + oid, {"tool": "independent_review",
            "revision": state.workspace.objects[oid]["revision"], "result": "contradicted", "reason": reason}, reason)

    def risk_state(self):
        state = session_fixture(filled=True)
        proposal = {"title": "Повторная доставка отчёта", "primary_node": "operation-2", "linked_nodes": ["operation-2"]}
        cid = state.workspace.candidate(proposal)
        state.workspace.risk_candidates[cid]["state"] = "accepted"
        state.risks = [deepcopy(proposal)]
        sync_objects(state)
        oid = next(oid for oid in state.workspace.objects if oid.startswith("risk:"))
        return state, proposal, cid, oid

    def withdraw(self, state, cid):
        reply = passport_tools.resolve(state, {"id": cid, "resolution": "refuted",
            "reason": "Источник подтверждает отправку, но опровергает заявленный механизм повторной доставки.",
            "evidence": [{"id": "evidence-1", "quote": QUOTE}]})
        self.assertNotIn("отклонён", reply)
        args = {"risks": [], "review": unknown_risk_review(state),
                "analysis": "Проверены вход, исполнение и сохранение результатов каждого процесса. "
                            "Заявленный механизм повторной доставки опровергнут; остаются вопросы внешнего транспорта."}
        self.assertNotIn("отклонён", _handle_submit_risks(state, args))
        sync_objects(state)

    def test_refuted_risk_review_is_transferred_to_resolution_before_closing(self):
        state, _, cid, oid = self.risk_state()
        fid = self.negative(state, oid)
        self.withdraw(state, cid)
        self.assertNotIn(oid, state.workspace.objects)
        self.assertEqual(state.workspace.findings[fid]["state"], "open")
        packet = self.accept_review(state, ["resolution:" + cid])[0]
        self.assertEqual(packet["prior_findings"][0]["key"], "review:" + oid)
        self.assertEqual(state.workspace.findings[fid]["state"], "corrected")

    def test_reinstated_candidate_inherits_failed_resolution_review(self):
        state, proposal, cid, _ = self.risk_state()
        self.withdraw(state, cid)
        fid = self.negative(state, "resolution:" + cid)
        # Same candidate, revised evidence/condition; this is the state after an
        # accepted resubmission, not another risk that can evade the old finding.
        revised = {**proposal, "title": proposal["title"].upper(), "trigger": "Повтор после неопределённого исхода."}
        self.assertEqual(state.workspace.candidate(revised), cid)
        state.workspace.risk_candidates[cid]["state"] = "accepted"
        state.risks = [revised]
        sync_objects(state)
        self.assertNotIn("resolution:" + cid, state.workspace.objects)
        oid = next(oid for oid in state.workspace.objects if oid.startswith("risk:"))
        packet = self.accept_review(state, [oid])[0]
        self.assertEqual(packet["prior_findings"][0]["id"], fid)
        self.assertFalse(state.workspace.unresolved())

    def test_risk_identity_survives_sanitized_title(self):
        state = session_fixture(filled=True)
        proposal = {"title": "Повторная\nдоставка отчёта", "primary_node": "operation-2"}
        cid = state.workspace.candidate(proposal)
        state.workspace.risk_candidates[cid]["state"] = "accepted"
        state.risks = [{**proposal, "id": "risk-1", "title": "Повторная доставка отчёта"}]
        sync_objects(state)
        oid = next(oid for oid in state.workspace.objects if oid.startswith("risk:"))
        self.assertIn("review:" + oid, state.workspace.review_keys("resolution:" + cid))

    def test_binding_reconsiders_counterexample_to_previous_dismissal(self):
        state = session_fixture(filled=True)
        state.capabilities = [Capability("cap-1", "FUNCTION", "send_report", "reports.py", 1, (1, 2))]
        state.capabilities_total = 1
        state.capability_dismissed["cap-1"] = {"reason": "legacy", "basis": "Предварительно сочли механизм неиспользуемым."}
        sync_objects(state)
        fid = self.negative(state, "dismissal:cap-1")
        self.assertNotIn("отклонён", _handle_bind_capability(state, {"capability": "cap-1", "nodes": ["operation-2"]}))
        sync_objects(state)
        self.assertNotIn("dismissal:cap-1", state.workspace.objects)
        self.assertEqual(state.workspace.findings[fid]["state"], "open")
        packet = self.accept_review(state, ["binding:cap-1"])[0]
        self.assertEqual(packet["prior_findings"][0]["id"], fid)
        self.assertFalse(state.workspace.unresolved())

    def test_explicit_binding_can_be_replaced_without_discarding_its_counterexample(self):
        state = session_fixture(filled=True)
        state.capabilities = [Capability("cap-1", "FUNCTION", "send_report", "reports.py", 1, (1, 2))]
        state.capabilities_total = 1
        _handle_bind_capability(state, {"capability": "cap-1", "nodes": ["operation-2"]})
        sync_objects(state)
        fid = self.negative(state, "binding:cap-1")
        args = {"capability": "cap-1", "reason": "legacy",
                "basis": "Механизм исключён из рассматриваемого процесса после проверки действующего вызова.",
                "evidence": [{"id": "evidence-1", "quote": QUOTE}]}
        self.assertIn("отклонён", _handle_dismiss_capability(state, args))
        self.assertIn("отклонён", _handle_dismiss_capability(state, {**args, "replace": True, "evidence": []}))
        self.assertEqual(state.capability_bound["cap-1"], ["operation-2"])
        self.assertNotIn("отклонён", _handle_dismiss_capability(state, {**args, "replace": True}))
        sync_objects(state)
        self.assertNotIn("binding:cap-1", state.workspace.objects)
        self.assertEqual(state.workspace.findings[fid]["state"], "open")
        packet = self.accept_review(state, ["dismissal:cap-1"])[0]
        self.assertEqual(packet["prior_findings"][0]["id"], fid)
        self.assertFalse(state.workspace.unresolved())
        # Actual node evidence cannot be excluded by overriding bookkeeping.
        state.nodes["operation-2"].data["fact_check"] = {"execution": {"evidence": args["evidence"]}}
        self.assertIn("отклонён", _handle_dismiss_capability(state, {**args, "replace": True}))

    def test_supported_related_object_cannot_erase_new_counterexample_in_same_batch(self):
        state, _, cid, oid = self.risk_state()
        # A resolution can coexist briefly with the old risk before submit_risks
        # removes it. A same-batch contradiction was not in either input packet.
        state.workspace.risk_candidates[cid].update(state="withdrawn", resolution_reason="Нужно исключить ошибочный риск.")
        sync_objects(state)
        resolution = "resolution:" + cid
        def reviewer(objects):
            return {"findings": [{"object_id": obj["id"], "revision": obj["revision"],
                "result": "contradicted" if obj["id"] == oid else "supported", "reason": "Проверены заявленные основания."}
                for obj in objects]}
        state.reviewer = reviewer
        passport_tools.review(state, {"ids": [oid, resolution]})
        findings = [f for f in state.workspace.findings.values() if f["key"] == "review:" + oid]
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["state"], "open")


if __name__ == "__main__":
    unittest.main()
