"""Regression checks for the code passport before a portable installation."""
import json
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from pko.extractors.runner import Extraction
from pko.progress.pipeline import _run_passport
from pko.progress.schema import passport_code_state
from test_passport_broker import MemoryTree
from test_passport_v2_model import execution


class PassportPreflightTests(unittest.TestCase):
    def code_state(self, outcome):
        return passport_code_state({
            "agent_contract": 2, "research_basis": "code",
            "fact_check": execution(outcome), "fields": {},
        }, "operation", False)[0]

    def test_existing_stub_keeps_absent_effect_across_prompt_wordings(self):
        for outcome in (
            "Заготовка в коде; действие не реализовано.",
            "Подготовка выдачи не реализована: функция возвращает пустой результат.",
            "Заготовка в коде. Основное действие не выполняется.",
        ):
            with self.subTest(outcome=outcome):
                self.assertEqual(self.code_state(outcome), "not_implemented")

    def test_conditional_failure_or_missing_recovery_is_not_an_absent_main_effect(self):
        for outcome in (
            "Если действие не реализовано, возвращается сообщение об ошибке.",
            "Основное действие выполняется; восстановление после сбоя не реализовано.",
            "Основное действие выполняется; раньше подготовка выдачи не выполнялась.",
            "Основное действие выполняется, но подготовка повторной попытки не реализована.",
            "Основное действие выполняется но восстановление не реализовано.",
            "Подготовка повторной попытки не реализована; основной результат сохранён.",
        ):
            with self.subTest(outcome=outcome):
                self.assertEqual(self.code_state(outcome), "implemented")

    def test_ungrounded_stub_claim_stays_unknown(self):
        audit = execution("Заготовка в коде; действие не реализовано.")
        audit["execution"]["evidence"] = []
        self.assertEqual(passport_code_state({
            "agent_contract": 2, "research_basis": "code", "fact_check": audit,
        }, "operation", False)[0], "unknown")

    def test_passport_failure_does_not_publish_raw_exception_text(self):
        result = SimpleNamespace(items=[], context={}, summary=None, verdicts=[])
        target = SimpleNamespace(tree=MemoryTree({"service.py": "def run():\n    return True\n"}),
                                 extraction=Extraction(facts=[]), sha="snapshot")
        events = []
        with patch("pko.progress.pipeline.passport_enabled", return_value=True), \
             patch("pko.progress.pipeline.run_passport_agent", side_effect=RuntimeError(
                 "https://user:PRIVATE_TEST_PASSWORD@example.invalid/api?token=PRIVATE_TEST_TOKEN")):
            output = _run_passport(result, SimpleNamespace(source_text=""), target,
                                   "demo", None, None, lambda name, payload: events.append((name, payload)))
        serialized = json.dumps({"notes": output.notes, "data": output.passport_data, "events": events})
        self.assertNotIn("PRIVATE_TEST_PASSWORD", serialized)
        self.assertNotIn("PRIVATE_TEST_TOKEN", serialized)
        self.assertIn("RuntimeError", " ".join(output.notes))
        self.assertEqual(output.passport_data["completion"]["state"], "failed")
        self.assertEqual(output.passport_data["nodes"], {})
        self.assertEqual(events[-1][0], "passport_incomplete")


if __name__ == "__main__":
    unittest.main()
