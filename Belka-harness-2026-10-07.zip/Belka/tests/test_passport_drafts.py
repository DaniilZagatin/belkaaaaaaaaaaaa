"""Amending a rejected node never bypasses full grounding or stale protection."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest

from pko.progress.passport_agent import _handle_submit_node, _handle_read_node, _checkpoint
from test_passport_code_reconstruction import code_session
from test_passport_agentic import node_args
from test_passport_system_research import REFS


def proposal(nid='operation-1'):
    return {**node_args(nid), 'existence_evidence': deepcopy(REFS)}


def unfilled_session():
    state = code_session()
    state.nodes['operation-1'].filled = False
    return state


class PassportDraftTests(unittest.TestCase):
    def test_rejected_node_can_be_repaired_with_one_field(self):
        state = unfilled_session()
        args = proposal()
        cell = args['fields'].pop('4.5.1')
        check = args['fact_check']['fields'].pop('4.5.1')
        original = deepcopy(args)
        rejected = _handle_submit_node(state, args)
        self.assertIn('отклонён', rejected)
        self.assertFalse(state.nodes['operation-1'].filled)
        saved = json.loads(_handle_read_node(state, {'id': 'operation-1'}))
        self.assertFalse(saved['draft']['accepted'])
        result = _handle_submit_node(state, {'id': 'operation-1', 'patch': True,
            'draft_revision': saved['draft']['revision'], 'fields': {'4.5.1': cell},
            'fact_check': {'fields': {'4.5.1': check}}})
        self.assertNotIn('отклонён', result, result)
        self.assertTrue(state.nodes['operation-1'].filled)
        self.assertEqual(state.nodes['operation-1'].data['fact_check']['execution'], original['fact_check']['execution'])
        self.assertEqual(args, original)  # No mutation of the caller's proposal.

    def test_patch_rechecks_unchanged_missing_existence(self):
        state = unfilled_session()
        args = proposal()
        args.pop('existence_evidence')
        _handle_submit_node(state, args)
        answer = _handle_submit_node(state, {'id': 'operation-1', 'patch': True,
                                            'draft_revision': 1, 'name': 'Отправка результата'})
        self.assertIn('существование узла', answer)
        self.assertFalse(state.nodes['operation-1'].filled)

    def test_patch_cannot_weaken_a_valid_node_with_fabricated_quote(self):
        state = code_session()
        self.assertNotIn('отклонён', _handle_submit_node(state, proposal()))
        accepted = deepcopy(state.nodes['operation-1'].data)
        refs = deepcopy(REFS)
        refs[0]['quote'] = 'imaginary_send_and_guarantee_delivery()'
        result = _handle_submit_node(state, {'id': 'operation-1', 'patch': True,
            'draft_revision': 1, 'existence_evidence': refs})
        self.assertIn('отклонён', result)
        self.assertEqual(state.nodes['operation-1'].data, accepted)
        self.assertFalse(state.node_drafts['operation-1']['accepted'])

    def test_old_revision_is_rejected_without_overwriting_current_draft(self):
        state = code_session()
        _handle_submit_node(state, proposal())
        _handle_submit_node(state, {'id': 'operation-1', 'patch': True,
                                    'draft_revision': 1, 'name': 'Отправка результата'})
        before = deepcopy(state.node_drafts)
        result = _handle_submit_node(state, {'id': 'operation-1', 'patch': True,
                                            'draft_revision': 1, 'name': 'Старое название'})
        self.assertIn('актуальный draft_revision', result)
        self.assertEqual(before, state.node_drafts)

    def test_checkpoint_preserves_rejected_draft_separately_from_map(self):
        state = unfilled_session()
        args = proposal()
        args['existence_evidence'] = []
        _handle_submit_node(state, args)
        with tempfile.TemporaryDirectory() as directory:
            state.checkpoint_path = Path(directory) / 'checkpoint.json'
            _checkpoint(state)
            saved = json.loads(state.checkpoint_path.read_text(encoding='utf-8'))
        self.assertFalse(saved['draft']['nodes']['operation-1']['filled'])
        self.assertFalse(saved['draft']['node_drafts']['operation-1']['accepted'])
        self.assertEqual(saved['draft']['node_drafts']['operation-1']['proposal']['existence_evidence'], [])

    def test_read_node_resubmission_does_not_nest_draft_metadata(self):
        state = code_session()
        _handle_submit_node(state, proposal())
        for _ in range(3):
            node = json.loads(_handle_read_node(state, {'id': 'operation-1'}))
            self.assertNotIn('отклонён', _handle_submit_node(state, node))
        self.assertNotIn('draft', state.node_drafts['operation-1']['proposal'])
        self.assertNotIn('field_contract', state.node_drafts['operation-1']['proposal'])

    def test_final_partial_checkpoint_keeps_latest_rejected_proposal(self):
        state = unfilled_session()
        args = proposal()
        args['existence_evidence'] = []
        _handle_submit_node(state, args)
        final_data = {'schema_version': 2, 'nodes': {}, 'completion': {'state': 'incomplete'}}
        with tempfile.TemporaryDirectory() as directory:
            state.checkpoint_path = Path(directory) / 'checkpoint.json'
            _checkpoint(state, final_data)
            saved = json.loads(state.checkpoint_path.read_text(encoding='utf-8'))
        self.assertFalse(saved['draft']['node_drafts']['operation-1']['accepted'])
        self.assertEqual(saved['draft']['node_drafts']['operation-1']['proposal']['existence_evidence'], [])
        self.assertNotIn('node_drafts', final_data)


if __name__ == '__main__':
    unittest.main()
