"""Real log regressions: field meaning, canonical resubmission and short code.

Synthetic source is never executed. These exercise normal production gates,
not softened acceptance or a mocked semantic reviewer.
"""
from copy import deepcopy
import json
from pathlib import Path
import re
import unittest

from pko.progress import passport_agent as agent
from pko.progress.passport_evidence import EvidenceCorpus, READ_SCHEMA, NODE_AUDIT_SCHEMA
from pko.progress.passport_fields import (
    CODE_OPTIONAL_FIELDS, GENERATED_FIELDS, NODE_FIELDS, field_contract, fields_schema,
)
from pko.progress.passport_system_research import verified_corpus_evidence
from test_passport_agentic import QUOTE, node_args, session_fixture
from test_passport_system_research import REFS


def code_state():
    state = session_fixture()
    state.research_basis = "code"
    return state


def code_args(nid, *, omit_management=False):
    args = node_args(nid)
    args["existence_evidence"] = deepcopy(REFS)
    if omit_management:
        for fid in CODE_OPTIONAL_FIELDS:
            args["fields"].pop(fid, None)
            args["fact_check"]["fields"].pop(fid, None)
    return args


class FieldContractTests(unittest.TestCase):
    def test_catalog_labels_match_actual_template_and_management_exception_is_exact(self):
        template = (Path(__file__).resolve().parents[1] / "passport-dpss-v3.html").read_text(encoding="utf-8")
        labels = dict(re.findall(r"<!-- ПОЛЕ (4\.[2-5]\.\d+) · ([^\n\r]+)", template))
        actual = {f["id"]: f["label"] for kind in NODE_FIELDS for f in field_contract(kind)["fields"]}
        self.assertEqual(actual, labels)
        optional = {f["id"] for kind in NODE_FIELDS for f in field_contract(kind)["fields"] if f["unknown_if_omitted"]}
        self.assertEqual(optional, {"4.2.3", "4.3.3", "4.3.9", "4.4.3", "4.4.7", "4.5.3"})
        for kind in NODE_FIELDS:
            self.assertEqual({f["id"] for f in field_contract(kind, "result_image")["fields"] if f["required"]},
                             NODE_FIELDS[kind] - GENERATED_FIELDS.get(kind, set()))

    def test_tool_schema_explains_owner_handoff_and_generated_fields(self):
        schema = fields_schema("code")
        self.assertIn("Бизнес-роль", schema["properties"]["4.3.3"]["description"])
        self.assertIn("Передача человеку", schema["properties"]["4.3.8"]["description"])
        self.assertIn("не передавай fact_check", schema["properties"]["4.3.2"]["description"])
        self.assertFalse(schema["additionalProperties"])
        self.assertEqual(READ_SCHEMA["function"]["parameters"]["properties"]["ids"]["maxItems"], 2)
        self.assertEqual(NODE_AUDIT_SCHEMA["properties"]["execution"]["properties"]["evidence"]["items"]["properties"]["quote"]["minLength"], 1)

    def test_declared_unfilled_node_exposes_its_exact_field_contract(self):
        state = code_state()
        result = json.loads(agent._handle_read_node(state, {"id": "process-1"}))
        self.assertEqual(result["id"], "process-1")
        self.assertEqual(result["type"], "process")
        self.assertEqual(result["name"], state.nodes["process-1"].name)
        self.assertFalse(result["filled"])
        self.assertEqual(result["field_contract"], field_contract("process"))

    def test_generated_parent_fields_round_trip_without_fabricated_audit(self):
        for nid, fid in (("process-1", "4.3.2"), ("operation-1", "4.5.2")):
            with self.subTest(node=nid):
                state = code_state()
                self.assertNotIn("отклонён", agent._handle_submit_node(state, code_args(nid)))
                args = json.loads(agent._handle_read_node(state, {"id": nid}))
                self.assertIn(fid, args["fields"])
                self.assertNotIn(fid, args["fact_check"]["fields"])
                before = deepcopy(args)
                self.assertNotIn("отклонён", agent._handle_submit_node(state, args))
                self.assertEqual(args, before)
                self.assertEqual(state.nodes[nid].data["fields"][fid], before["fields"][fid])
                self.assertNotIn(fid, state.nodes[nid].data["fact_check"]["fields"])

    def test_generated_claim_is_replaced_from_tree_not_trusted(self):
        state = code_state()
        args = code_args("process-1")
        args["fields"]["4.3.2"] = {"value": "Вымышленный родитель", "source": "Установлено: вымышленное основание"}
        args["fact_check"]["fields"]["4.3.2"] = {"support": "code", "evidence": [{"id": "fake", "quote": "fake"}]}
        before = deepcopy(args)
        self.assertNotIn("отклонён", agent._handle_submit_node(state, args))
        self.assertEqual(args, before)
        self.assertNotIn("Вымышленный", state.nodes["process-1"].data["fields"]["4.3.2"]["value"])
        self.assertNotIn("4.3.2", state.nodes["process-1"].data["fact_check"]["fields"])

    def test_only_absent_management_fields_get_transparent_unknown_and_round_trip(self):
        for nid in ("journey-1", "process-1", "bbb-1", "operation-1"):
            with self.subTest(node=nid):
                state = code_state()
                args = code_args(nid, omit_management=True)
                before = deepcopy(args)
                self.assertNotIn("отклонён", agent._handle_submit_node(state, args))
                self.assertEqual(args, before)
                data = state.nodes[nid].data
                expected = CODE_OPTIONAL_FIELDS & NODE_FIELDS[nid.split("-")[0]]
                self.assertEqual(set(data["auto_unknown_fields"]), expected)
                for fid in expected:
                    self.assertTrue(data["fields"][fid]["source"].startswith("Не установлено:"))
                    self.assertEqual(data["fact_check"]["fields"][fid]["support"], "unknown")
                    self.assertEqual(data["fact_check"]["fields"][fid]["mechanism"], "unknown")
                    self.assertEqual(data["fact_check"]["fields"][fid]["evidence"], [])
                again = json.loads(agent._handle_read_node(state, {"id": nid}))
                self.assertNotIn("отклонён", agent._handle_submit_node(state, again))
                self.assertEqual(set(state.nodes[nid].data["auto_unknown_fields"]), expected)

    def test_explicit_management_value_and_quote_are_preserved_and_still_checked(self):
        state = code_state()
        args = code_args("operation-1", omit_management=True)
        fid = "4.5.3"
        field = {"value": "Владелец требует подтверждения; вызов отправки виден, правила аудита не установлены.",
                 "source": "Не установлено: исследованный вызов отправки не раскрывает владельца и правила аудита."}
        audit = {"support": "unknown", "mechanism": "unknown", "evidence": [{"id": "evidence-1", "quote": QUOTE}],
                 "limits": "Роль владельца и наличие журнала операций требуют отдельного изучения."}
        args["fields"][fid], args["fact_check"]["fields"][fid] = deepcopy(field), deepcopy(audit)
        self.assertNotIn("отклонён", agent._handle_submit_node(state, args))
        self.assertEqual(state.nodes["operation-1"].data["fields"][fid], field)
        self.assertEqual(state.nodes["operation-1"].data["fact_check"]["fields"][fid], audit)
        self.assertNotIn(fid, state.nodes["operation-1"].data.get("auto_unknown_fields", []))
        args["fact_check"]["fields"][fid]["evidence"][0]["quote"] = "invented_owner_verification()"
        reply = agent._handle_submit_node(state, args)
        self.assertIn("отклонён", reply)
        self.assertIn("цитата не найдена", reply)
        self.assertEqual(state.nodes["operation-1"].data["fields"][fid], field)

    def test_missing_effect_entrypoint_and_existence_still_rejected(self):
        mutations = (
            lambda a: (a["fields"].pop("4.5.4"), a["fact_check"]["fields"].pop("4.5.4")),
            lambda a: a["fact_check"]["execution"].pop("outcome"),
            lambda a: a["fact_check"]["execution"].update(reachability="connected", entry_evidence=[]),
            lambda a: a.pop("existence_evidence"),
        )
        for mutate in mutations:
            state, args = code_state(), code_args("operation-1", omit_management=True)
            mutate(args)
            self.assertIn("отклонён", agent._handle_submit_node(state, args))
            self.assertFalse(state.nodes["operation-1"].filled)

    def test_legacy_mode_still_requires_management_fields(self):
        state = session_fixture()
        self.assertIn("Не проверены поля: 4.3.3, 4.3.9", agent._handle_submit_node(state, code_args("process-1", omit_management=True)))

    def test_reviewer_gets_one_shared_catalog_without_modifying_claim_revisions(self):
        from pko.errors import LlmError
        from pko.progress.passport_reviewer import review_passport_objects
        from test_passport_reviewer import ScriptClient, SPEC, object_fixture, corpus_fixture
        objects = [object_fixture("process-1", "revision-a"), object_fixture("process-2", "revision-b")]
        before = deepcopy(objects)
        client = ScriptClient(LlmError("Scripted stop after packet capture"))
        review_passport_objects(objects, corpus_fixture(), SPEC, client=client, max_steps=1)
        packet = json.loads(client.messages[0][1]["content"])
        self.assertEqual(set(packet["field_catalog"]), NODE_FIELDS["process"])
        self.assertEqual(packet["field_catalog"]["4.3.3"]["label"], "Владелец")
        self.assertIn("Передача человеку", packet["field_catalog"]["4.3.8"]["purpose"])
        self.assertEqual([obj["revision"] for obj in packet["objects"]], ["revision-a", "revision-b"])
        self.assertTrue(all("field_catalog" not in obj["content"] and "field_contract" not in obj["content"]
                            for obj in packet["objects"]))
        self.assertEqual(objects, before)


class ShortCodeCitationTests(unittest.TestCase):
    def setUp(self):
        self.corpus = EvidenceCorpus()
        self.corpus.add("code", "views.py:1", "1: def ping(\n2:     request):\n3:     if not rw:\n4:         pass\n5:     return None\n6:     ...\n7:     # comment\n8:     return ping(request)")

    def test_whole_short_lines_require_own_read_and_keep_literal_matching(self):
        ref = [{"id": "evidence-1", "quote": "if not rw:"}]
        self.assertIn("сначала прочитай", " ".join(self.corpus.citations(ref, code=True)))
        self.corpus.read(["evidence-1"])
        for quote in ("if not rw:", "def ping(", "pass", "return None", "3:     if not rw:"):
            with self.subTest(quote=quote):
                self.assertEqual(self.corpus.citations([{"id": "evidence-1", "quote": quote}], code=True), [])
        for quote in ("ping", "not rw", "...", "6:     ...", "…", "", "   ", "# comment", "if not wrong:"):
            with self.subTest(quote=quote):
                self.assertTrue(self.corpus.citations([{"id": "evidence-1", "quote": quote}], code=True))

    def test_missing_quote_unknown_id_and_literal_mismatch_have_distinct_diagnostics(self):
        self.corpus.read(["evidence-1"])
        def error(ref):
            return " ".join(self.corpus.citations([ref]))
        missing = error({"id": "evidence-1", "path": "views.py", "line": 3})
        self.assertIn("отсутствует quote", missing)
        self.assertNotIn("короткая", missing)
        self.assertIn("Неизвестный id", error({"id": "evidence-999", "quote": "if not rw:"}))
        self.assertIn("не найдена", error({"id": "evidence-1", "quote": "if not wrong:"}))
        self.assertIn("короткая", error({"id": "evidence-1", "quote": "ping"}))

    def test_short_document_is_not_code_and_code_anchor_still_checked(self):
        self.corpus.add("document", "README.md:1", "return None")
        self.corpus.read(["evidence-1", "evidence-2"])
        self.assertTrue(self.corpus.citations([{"id": "evidence-2", "quote": "return None"}], code=True))
        refs = [{"id": "evidence-1", "quote": "if not rw:", "path": "views.py", "line": 3, "basis": "ping"}]
        _, errors = verified_corpus_evidence(self.corpus, refs)
        self.assertEqual(errors, [])
        refs[0]["path"] = "invented.py"
        self.assertTrue(verified_corpus_evidence(self.corpus, refs)[1])


if __name__ == "__main__":
    unittest.main()
