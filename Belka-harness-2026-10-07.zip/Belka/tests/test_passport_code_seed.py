"""Code research starts from the snapshot, independently of prior OR evaluation."""
import json
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from pko.extractors.base import Fact
from pko.extractors.runner import Extraction
from pko.progress.passport_agent import PassportAgentResult, _PassportSession, _known_paths
from pko.progress.passport_broker import EvidenceBroker
from pko.progress.passport_evidence import EvidenceCorpus, claim_citation_errors
from pko.progress.passport_tools import request_evidence
from pko.progress.pipeline import _run_passport
from test_passport_broker import MemoryTree


FILES = {
    "reviewed_a.py": "def old_scope_a():\n" + "    pass\n" * 20,
    "reviewed_b.py": "def old_scope_b():\n" + "    pass\n" * 20,
    "outside.py": "def external_business():\n    deliver_result()\n    persist_result()\n",
}


def prior_verdicts(path):
    return [SimpleNamespace(criteria=[SimpleNamespace(
        evidence=[SimpleNamespace(path=path, line=1)])])]


class CodeCorpusSeedTests(unittest.TestCase):
    def test_project_seed_survives_small_budget_and_is_independent_of_or_evaluation(self):
        extraction = Extraction(facts=[Fact("ENTRYPOINT", "external_business", {}, "outside.py", 1)])
        snapshots = []
        for path, source in (("reviewed_a.py", "Цель первой инициативы."),
                             ("reviewed_b.py", "Другая цель второй инициативы."),
                             (None, "")):
            with self.subTest(evaluation=path):
                result = SimpleNamespace(items=[], context={}, summary=None,
                    verdicts=prior_verdicts(path) if path else [],
                    knowledge=[f"{path}:1: прежняя оценка поведения"] if path else [])
                target = SimpleNamespace(tree=MemoryTree(FILES), extraction=extraction, sha="same-snapshot")
                # A previous evaluator file fits individually, but together with
                # the outside entrypoint exceeds the limit: order matters here.
                with patch("pko.progress.passport_evidence.MAX_CODE_CHARS", 340), \
                     patch("pko.progress.pipeline.passport_enabled", return_value=True), \
                     patch("pko.progress.pipeline.run_passport_agent", return_value=PassportAgentResult()) as run:
                    output = _run_passport(result, SimpleNamespace(source_text=source),
                                           target, "project", None, None, None)
                self.assertEqual(output.notes, [])
                run.assert_called_once()
                kwargs = run.call_args.kwargs
                self.assertEqual(kwargs["research_basis"], "code")
                self.assertEqual(kwargs["knowledge"], [])
                corpus = kwargs["evidence_corpus"]
                code = [(row["label"], row["part"], row["text"])
                        for row in corpus.records.values() if row["kind"] == "code"]
                self.assertEqual([row[0] for row in code], ["outside.py:1"])
                self.assertIn("deliver_result()", code[0][2])
                self.assertFalse(any(row["label"].startswith("След оценки") for row in corpus.records.values()))
                self.assertEqual([cap.path for cap in kwargs["capabilities"]], ["outside.py"])
                # Optional intent is kept as intent, never counted as source code.
                self.assertEqual(any(row["kind"] == "intent" for row in corpus.records.values()), bool(source))
                snapshots.append((code, dict(corpus.included)))
        self.assertEqual(snapshots[0], snapshots[1])
        self.assertEqual(snapshots[1], snapshots[2])

    def test_prior_known_paths_do_not_restrict_fetching_new_snapshot_code(self):
        corpus = EvidenceCorpus()
        state = _PassportSession(agentic=True, research_enabled=True, research_basis="code",
            evidence_corpus=corpus, known_paths=_known_paths(prior_verdicts("reviewed_a.py"), []))
        state.evidence_broker = EvidenceBroker(MemoryTree(FILES), Extraction(facts=[]), corpus)
        self.assertNotIn("outside.py", state.known_paths)
        response = json.loads(request_evidence(state, {"kind": "file", "path": "outside.py", "line": 2}))
        self.assertTrue(response["ok"], response)
        self.assertIn("outside.py", state.known_paths)
        eid = response["records"][0]["id"]
        refs = [{"id": eid, "quote": "2:     deliver_result()"}]
        self.assertTrue(corpus.citations(refs, code=True))  # A handle still is not a read.
        corpus.read([eid])
        self.assertEqual(corpus.citations(refs, code=True), [])
        self.assertEqual(claim_citation_errors(corpus, "outside.py:2 deliver_result", refs), [])


if __name__ == "__main__":
    unittest.main()
