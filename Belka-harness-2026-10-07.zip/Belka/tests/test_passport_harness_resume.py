"""End-to-end local continuation through the real passport entry point."""
from copy import deepcopy
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from pko.progress.passport_agent import run_passport_agent
from pko.progress.passport_broker import EvidenceBroker
from pko.progress.passport_harness_state import _unpack
from test_passport_agentic import SPEC, ScriptClient, corpus_fixture, node_args, tool
from test_passport_integrated_research import result
from test_passport_system_research import REFS


class Source:
    def __init__(self, text="def send_report(report):\n    transport.send(report)\n"):
        self.text = text
        self.files = ["reports.py"]

    def read(self, path):
        return self.text if path == "reports.py" else None


def initial_responses():
    args = node_args("journey-1")
    args["existence_evidence"] = deepcopy(REFS)
    return [result(tool("read_passport_evidence", {"ids": ["evidence-1"]})),
            result(tool("submit_node", args))]


class FailingClient(ScriptClient):
    def chat(self, messages, **kwargs):
        if not self.responses:
            time.sleep(0.08)
        return super().chat(messages, **kwargs)


class PassportHarnessResumeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.checkpoint = Path(self.tmp.name) / "run.passport.json"
        self.resume = self.checkpoint.with_suffix(".harness.json")
        self.environment = patch.dict("os.environ", {"PKO_PASSPORT_RESUME": "", "PKO_PASSPORT_ENGINE": "pydantic",
            "PKO_PASSPORT_MAX_SECONDS": "60", "PYDANTIC_AI_NO_BANNER": "1"})
        self.environment.start()
        self.addCleanup(self.environment.stop)

    def run_agent(self, client, *, resume=False, steps=2, source=None):
        corpus = corpus_fixture()
        corpus.shown.clear()
        broker = EvidenceBroker(source or Source(), SimpleNamespace(facts=[]), corpus)
        return run_passport_agent([], {}, [], None, SPEC, client=client, max_steps=steps,
            evidence_corpus=corpus, evidence_broker=broker, agentic=True,
            research_enabled=True, research_basis="code", engine="pydantic",
            checkpoint_path=self.checkpoint, resume_path=self.resume if resume else None)

    def saved_session(self):
        raw = json.loads(self.resume.read_text(encoding="utf-8"))
        return _unpack(raw["domain"]["session"])

    def test_stop_and_resume_preserve_accepted_node_and_spent_steps(self):
        first_client = ScriptClient(*initial_responses())
        first = self.run_agent(first_client)
        self.assertEqual(len(first_client.messages), 2, first.notes)
        self.assertEqual(first.passport_data["completion"]["stop_reason"], "steps", first.notes)
        self.assertIn("journey-1", first.passport_data["nodes"], first.notes)
        self.assertEqual(self.saved_session()["harness_steps"], 2)
        old_node = deepcopy(first.passport_data["nodes"]["journey-1"])
        second_client = ScriptClient(
            result(tool("read_node", {"id": "journey-1"})),
            result(tool("update_research_plan", {"tasks": [{"id": "next", "task": "Проверить продолжение пути", "state": "doing"}]})))
        second = self.run_agent(second_client, resume=True, steps=4)
        self.assertEqual(len(second_client.messages), 2, second.notes)
        self.assertEqual(second.steps, 4)
        self.assertEqual(second.passport_data["nodes"]["journey-1"], old_node)
        self.assertEqual(second.passport_data["research"]["plan"][0]["id"], "next")
        saved = self.saved_session()
        self.assertEqual(saved["tool_calls"], 4)
        self.assertEqual(saved["harness_steps"], 4)
        self.assertEqual(set(saved["evidence_corpus"].shown), {"evidence-1"})
        self.assertTrue(any(m.get("role") == "tool" and "принят" in str(m.get("content"))
                            for m in second_client.messages[0]))

    def test_changed_source_refuses_resume_without_any_model_call(self):
        self.run_agent(ScriptClient(*initial_responses()))
        original = self.resume.read_bytes()
        client = ScriptClient(result(tool("finish")))
        changed = self.run_agent(client, resume=True, steps=5,
            source=Source("def send_report(report):\n    return None\n"))
        self.assertEqual(client.messages, [])
        self.assertEqual(changed.passport_data["completion"]["state"], "failed")
        self.assertTrue(any("different sources or settings" in note for note in changed.notes))
        self.assertEqual(self.resume.read_bytes(), original)

    def test_exhausted_steps_do_not_start_a_new_model_request_after_resume(self):
        self.run_agent(ScriptClient(*initial_responses()))
        client = ScriptClient(result(tool("finish")))
        resumed = self.run_agent(client, resume=True, steps=2)
        self.assertEqual(client.messages, [])
        self.assertEqual(resumed.passport_data["completion"]["stop_reason"], "steps")
        self.assertEqual(resumed.steps, 2)
        self.assertIn("journey-1", resumed.passport_data["nodes"])

    def test_failed_request_time_is_saved_and_cannot_be_regained_by_resume(self):
        client = FailingClient(*initial_responses())
        failed = self.run_agent(client, steps=8)
        self.assertEqual(failed.passport_data["completion"]["stop_reason"], "error")
        self.assertGreaterEqual(self.saved_session()["harness_elapsed_seconds"], 0.08)
        resumed_client = ScriptClient(result(tool("finish")))
        with patch.dict("os.environ", {"PKO_PASSPORT_MAX_SECONDS": "0.03"}):
            resumed = self.run_agent(resumed_client, resume=True, steps=8)
        self.assertEqual(resumed_client.messages, [])
        self.assertEqual(resumed.passport_data["completion"]["stop_reason"], "timeout")

    def test_explicit_resume_after_idle_allows_progress_without_resetting_spent_budget(self):
        client = ScriptClient(*(result(tool("read_node", {"id": "journey-1"})) for _ in range(6)))
        with patch("pko.progress.passport_agent.IDLE_STEPS_STOP", 2):
            stopped = self.run_agent(client, steps=4)
            self.assertEqual(stopped.passport_data["completion"]["stop_reason"], "idle", stopped.notes)
            spent = self.saved_session()
            next_client = ScriptClient(result(tool("update_research_plan", {"tasks": [
                {"id": "next", "task": "Проверить известную точку входа", "state": "doing"}]})),
                result(tool("read_node", {"id": "journey-1"})))
            continued = self.run_agent(next_client, resume=True, steps=4)
        self.assertGreater(len(next_client.messages), 0, continued.notes)
        self.assertEqual(continued.steps, 4)
        self.assertEqual(self.saved_session()["tool_calls"], spent["tool_calls"] + len(next_client.messages))
        self.assertEqual(continued.passport_data["research"]["plan"][0]["id"], "next")


if __name__ == "__main__":
    unittest.main()
