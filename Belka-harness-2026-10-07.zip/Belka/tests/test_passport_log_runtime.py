"""Runtime regressions extracted from the interrupted Healthchecks audit.

No model or target project is executed. Fixtures exercise real tool dispatch,
provenance, conversation compaction and the loop's progress detector.
"""
from copy import deepcopy
import json
import unittest

from pko.progress.passport_agent import (
    _PassportSession, _Node, _answer_call, _compact_agentic_history, _progress_mark,
)
from pko.progress.passport_context import (
    MAX_DYNAMIC_CHARS, MAX_MATERIAL_CHARS, MAX_RECENT_CHARS, MAX_STATE_CHARS,
    tool_rejected,
)
from pko.progress.passport_evidence import EvidenceCorpus


def call(name, args, cid="call-1"):
    return {"id": cid, "type": "function", "function": {
        "name": name, "arguments": json.dumps(args, ensure_ascii=False)}}


def batch(name, args, content, cid):
    return [{"role": "assistant", "content": None, "tool_calls": [call(name, args, cid)]},
            {"role": "tool", "tool_call_id": cid, "content": content}]


def serial(value):
    return json.dumps(value, ensure_ascii=False)


def session():
    return _PassportSession(agentic=True, evidence_corpus=EvidenceCorpus())


class ToolOutcomeTests(unittest.TestCase):
    def test_successful_source_read_with_rejection_and_error_words_stays_json(self):
        state = session()
        source = '1: def reject():\n2:     return {"error": "запрос отклонён"}'
        state.evidence_corpus.add("code", "service.py:1", source)
        result = _answer_call(state, call("read_passport_evidence", {"ids": ["evidence-1"]}))
        self.assertEqual(json.loads(result["content"])["records"][0]["text"], source)
        self.assertEqual(state.workspace.findings, {})
        self.assertEqual(state.evidence_corpus.citations([
            {"id": "evidence-1", "quote": source}], code=True), [])

    def test_read_argument_error_is_not_a_persistent_proposal(self):
        state = session()
        fid = state.workspace.reject("review:node", {"tool": "independent_review"}, "Контрпример")
        result = _answer_call(state, call("read_passport_evidence", {"ids": []}))
        self.assertIn("error", json.loads(result["content"]))
        self.assertEqual(state.workspace.unresolved(), [fid])

    def test_gate_prefixes_and_structured_envelopes_do_not_inspect_source_payload(self):
        for name, text in (("submit_node", "bbb-1 отклонён (основания): неверная цитата"),
                           ("declare_children", "дети process-1 отклонены:\nошибка"),
                           ("link_nodes", "связь отклонена:\nошибка"),
                           ("submit_trace", "submit_trace отклонён: устаревшая версия"),
                           ("submit_claim", '{"ok": false, "error": "bad input"}')):
            with self.subTest(text=text):
                self.assertTrue(tool_rejected(name, text))
        for text in ('{"records": [{"text": "запрос отклонён; error"}]}',
                     '{"ok": true, "result": {"error": "наблюдаемый факт"}}',
                     'Принято: описание «ошибочный запрос отклонён».'):
            self.assertFalse(tool_rejected("submit_node", text))


class ContextWindowTests(unittest.TestCase):
    def assert_valid_tool_pairs(self, messages):
        pending = set()
        for message in messages:
            if message["role"] == "assistant":
                self.assertFalse(pending, "assistant before all tool results")
                pending = {c["id"] for c in message.get("tool_calls", [])}
            elif message["role"] == "tool":
                self.assertIn(message["tool_call_id"], pending)
                pending.remove(message["tool_call_id"])
            else:
                self.assertFalse(pending, "non-tool inside an unfinished batch")
        self.assertFalse(pending)

    def test_long_research_history_drops_old_arguments_and_keeps_latest_batch(self):
        state = session()
        prefix = [{"role": "system", "content": "immutable policy"},
                  {"role": "user", "content": "original task"}]
        messages = deepcopy(prefix)
        maximum = 0
        for step in range(180):
            # These tools were not handled by the legacy argument compactor.
            name = ("submit_scenarios", "submit_trace", "submit_system")[step % 3]
            latest = batch(name, {"old_proposal": f"proposal-{step}:" + "аргумент " * 900},
                           "Отклонённое описание " * 500, f"c-{step}")
            messages.extend(latest)
            _compact_agentic_history(messages, state)
            self.assertEqual(messages[-2:], latest)
            self.assertEqual(messages[:2], prefix)
            self.assert_valid_tool_pairs(messages)
            maximum = max(maximum, len(serial(messages[2:])))
        self.assertLess(maximum, MAX_DYNAMIC_CHARS + 1500)
        self.assertNotIn("proposal-0:", serial(messages))
        self.assertLess(len(messages), 20)

    def test_latest_large_parallel_batch_is_seen_in_full(self):
        state = session()
        messages = [{"role": "system", "content": "policy"}]
        messages.extend(batch("submit_node", {"old": "x" * 70_000}, "old error", "old"))
        calls = [call("read_passport_evidence", {"ids": [f"evidence-{i}"]}, f"c{i}") for i in range(4)]
        latest = [{"role": "assistant", "tool_calls": calls, "content": None}]
        latest.extend({"role": "tool", "tool_call_id": c["id"], "content": "literal" * 6000} for c in calls)
        messages.extend(deepcopy(latest))
        _compact_agentic_history(messages, state)
        self.assertEqual(messages[-len(latest):], latest)
        self.assert_valid_tool_pairs(messages)
        self.assertNotIn('"old":', serial(messages))

    def test_old_active_literal_survives_without_reading_unseen_source(self):
        state = session()
        corpus = state.evidence_corpus
        for i in range(10):
            corpus.add("code", f"source{i}.py:1", f"1: def task_{i}():\n2:     return 'source-{i}'\n" + "# context\n" * 400)
        messages = [{"role": "system", "content": "policy"}]
        for i in range(1, 10):
            messages.extend(batch("read_passport_evidence", {"ids": [f"evidence-{i}"]},
                                  serial(corpus.read([f"evidence-{i}"])), f"read-{i}"))
        # A recent rejected node uses an old, real quote; it must stay available.
        quote = "2:     return 'source-0'"
        messages.extend(batch("submit_node", {"evidence": [{"id": "evidence-1", "quote": quote}],
                                               "padding": "x" * 30_000}, "bbb-1 отклонён: другое поле", "node"))
        before = deepcopy(corpus.shown)
        _compact_agentic_history(messages, state)
        for i in range(10):
            messages.extend(batch("research_state", {}, "snapshot", f"later-{i}"))
            _compact_agentic_history(messages, state)
        self.assertEqual(corpus.shown, before)
        self.assertIn("source-0", serial(messages))
        self.assertNotIn("source-9", serial(messages))
        self.assertNotIn("evidence-10", corpus.shown)
        self.assertEqual(corpus.citations([{"id": "evidence-1", "quote": quote}], code=True), [])
        # Only a single retained source page, even after many repeat compactions.
        self.assertEqual(serial(messages).count("1: def task_0()"), 1)

    def test_working_summary_bounds_unresolved_details_without_mutating_ledger(self):
        state = session()
        for i in range(80):
            state.nodes[f"bbb-{i}"] = _Node(f"bbb-{i}", "Содержательное имя " * 30, "")
            state.workspace.reject(f"submit_node:bbb-{i}", {"tool": "submit_node", "id": f"bbb-{i}"},
                                   "Контрпример с важным условием. " * 100)
        state.node_drafts = {"bbb-0": {"revision": 7, "accepted": False, "proposal": {"full": "draft"}}}
        before = deepcopy(state.workspace.export())
        messages = [{"role": "system", "content": "policy"}]
        for i in range(50):
            messages.extend(batch("research_state", {}, "large " * 200, str(i)))
        _compact_agentic_history(messages, state)
        self.assertEqual(state.workspace.export(), before)
        summary = next(m["content"] for m in messages if m["role"] == "user")
        self.assertIn('"open_findings_total": 80', summary)
        self.assertIn('"draft_revision": 7', summary)
        self.assertIn("read_node(id)", summary)
        self.assertLess(len(summary), MAX_STATE_CHARS + MAX_MATERIAL_CHARS + 1000)
        self.assertLess(len(serial(messages)), MAX_STATE_CHARS + MAX_MATERIAL_CHARS + MAX_RECENT_CHARS + 1000)

    def test_short_literal_guard_is_prioritised_without_requiring_another_read(self):
        state = session()
        corpus = state.evidence_corpus
        corpus.add("code", "guard.py:1", "1: if not rw:\n2:     return deny()")
        corpus.read(["evidence-1"])
        for i in range(8):
            corpus.add("code", f"other{i}.py:1", "# unrelated\n" * 400)
            corpus.read([f"evidence-{i + 2}"])
        messages = [{"role": "system", "content": "policy"}]
        for eid in corpus.records:
            messages.extend(batch("read_passport_evidence", {"ids": [eid]}, serial(corpus.read([eid])), eid))
        messages.extend(batch("submit_node", {"evidence": [{"id": "evidence-1", "quote": "if not rw:"}],
                                               "padding": "x" * 40_000}, "draft error", "node"))
        _compact_agentic_history(messages, state)
        for i in range(6):
            messages.extend(batch("research_state", {}, "state", f"state-{i}"))
            _compact_agentic_history(messages, state)
        self.assertIn("if not rw:", serial(messages))
        self.assertEqual(list(state._passport_context.evidence)[-1], "evidence-1")


class ProgressTests(unittest.TestCase):
    def test_rewording_same_rejected_proposal_does_not_reset_idle_budget(self):
        state = session()
        fid = state.workspace.reject("submit_node:bbb-1", {"tool": "submit_node", "field": "first"}, "Ошибка поля")
        first = _progress_mark(state)
        for i in range(10):
            self.assertEqual(state.workspace.reject("submit_node:bbb-1", {"tool": "submit_node", "field": str(i)},
                                                    f"Ошибка поля, вариант {i}"), fid)
            self.assertEqual(_progress_mark(state), first)
        state.workspace.accepted("submit_node:bbb-1")
        self.assertNotEqual(_progress_mark(state), first)

    def test_new_read_material_still_counts_as_research_progress(self):
        state = session()
        state.evidence_corpus.add("code", "main.py:1", "1: service.save(record)")
        before = _progress_mark(state)
        state.evidence_corpus.read(["evidence-1"])
        after = _progress_mark(state)
        self.assertNotEqual(before, after)
        state.evidence_corpus.read(["evidence-1"])
        self.assertEqual(after, _progress_mark(state))


if __name__ == "__main__":
    unittest.main()
