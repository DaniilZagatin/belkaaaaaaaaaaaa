"""Failed reviews remain obligations across edits, new evidence and retirement."""
from copy import deepcopy
import unittest

from pko.progress import passport_tools
from pko.progress.passport_workspace import ResearchWorkspace, sync_objects
from test_passport_agentic import QUOTE, session_fixture


class ReviewCounterexampleTests(unittest.TestCase):
    def state_with_checker(self, *outcomes):
        state = session_fixture(filled=True)
        state.workspace.claims["claim-1"] = {"text": "Вызывается отправка отчёта.", "nodes": []}
        packets = []
        outcomes = iter(outcomes)

        def reviewer(objects):
            packets.append(deepcopy(objects))
            result, reason = next(outcomes)
            return {"complete": True, "findings": [
                {"object_id": obj["id"], "revision": obj["revision"], "result": result,
                 "reason": reason, "evidence": [{"id": "evidence-1", "quote": QUOTE}]}
                for obj in objects]}

        state.reviewer = reviewer
        return state, packets

    def test_all_negative_versions_reach_next_review_and_supported_closes_all(self):
        first = "Данные теряются в обработчике ошибки до повторной отправки."
        second = "Получатель результата использует другой контракт сообщения."
        state, packets = self.state_with_checker(
            ("contradicted", first), ("insufficient", second),
            ("supported", "Оба прежних замечания учтены в уточнённых границах утверждения."))
        passport_tools.review(state, {"ids": ["claim-1"]})
        state.workspace.claims["claim-1"]["text"] += " Доставка не установлена."
        passport_tools.review(state, {"ids": ["claim-1"]})
        self.assertEqual(len(state.workspace.unresolved()), 2)
        # The current rejected version cannot be rerolled without a change.
        self.assertIn("отклонён", passport_tools.review(state, {"ids": ["claim-1"]}))
        self.assertEqual(len(packets), 2)
        state.workspace.claims["claim-1"]["text"] += " Контракт получателя не подтверждён."
        passport_tools.review(state, {"ids": ["claim-1"]})
        self.assertEqual({f["reason"] for f in packets[2][0]["prior_findings"]}, {first, second})
        self.assertEqual(state.workspace.unresolved(), [])
        self.assertEqual({f["state"] for f in state.workspace.findings.values()}, {"corrected"})

    def test_distinct_counterexamples_on_same_version_survive_new_materials(self):
        first, second = "Первый найденный контрпример о потере данных.", "Второй найденный контрпример о получателе."
        state, packets = self.state_with_checker(("contradicted", first), ("contradicted", second),
                                                ("insufficient", "Оба контрпримера всё ещё требуют проверки."))
        passport_tools.review(state, {"ids": ["claim-1"]})
        state.evidence_corpus.add("code", "consumer.py:1", "1: def consume(message): pass")
        passport_tools.review(state, {"ids": ["claim-1"]})
        state.evidence_corpus.add("code", "recovery.py:1", "1: def retry(message): pass")
        passport_tools.review(state, {"ids": ["claim-1"]})
        self.assertEqual(packets[0][0]["revision"], packets[2][0]["revision"])
        self.assertEqual({f["reason"] for f in packets[2][0]["prior_findings"]}, {first, second})
        self.assertEqual(len(state.workspace.unresolved()), 3)

    def test_same_conclusion_is_idempotent_and_regular_tool_findings_keep_id(self):
        ws = ResearchWorkspace()
        proposal = {"tool": "independent_review", "revision": "v1", "result": "contradicted",
                    "reason": "Получатель не получает результат.", "corpus_revision": 2}
        fid = ws.reject("review:claim-1", proposal, proposal["reason"])
        self.assertEqual(ws.reject("review:claim-1", {**proposal, "corpus_revision": 3}, proposal["reason"]), fid)
        self.assertEqual(len(ws.findings), 1)
        self.assertEqual(ws.findings[fid]["proposal"]["corpus_revision"], 3)
        ordinary = ws.reject("submit_node:bbb-1", {"tool": "submit_node", "id": "bbb-1"}, "Ошибка поля.")
        self.assertEqual(ws.reject("submit_node:bbb-1", {"tool": "submit_node", "id": "bbb-1", "name": "Другое"},
                                   "Другая ошибка поля."), ordinary)
        next_id = ws.reject("review:claim-1", {**proposal, "revision": "v2"}, proposal["reason"])
        self.assertNotIn(next_id, (fid, ordinary))

    def test_retirement_receives_and_closes_all_retired_counterexamples(self):
        state, packets = self.state_with_checker(("supported", "Отзыв учитывает все прежние контрпримеры."))
        for oid, version in (("claim-1", "v1"), ("claim-1", "v2"), ("connection-review:process-1", "v3")):
            state.workspace.reject("review:" + oid,
                {"tool": "independent_review", "revision": version}, "Открытый контрпример " + version)
        state.workspace.retirements["retirement:claim-1"] = {
            "object_id": "claim-1", "retired_object_ids": ["connection-review:process-1"],
            "reason": "Ошибка в исходном утверждении; решение сохраняет историю проверки."}
        state.workspace.claims.pop("claim-1")
        passport_tools.review(state, {"ids": ["retirement:claim-1"]})
        self.assertEqual(len(packets[0][0]["prior_findings"]), 3)
        self.assertEqual(state.workspace.unresolved(), [])

    def test_withdrawn_connection_proposal_remains_pending_independent_resolution(self):
        state = session_fixture(filled=True)
        fid = state.workspace.reject("submit_connection_review:process-1",
            {"tool": "submit_connection_review", "process": "process-1", "checks": []},
            "Новая проверка связей отклонена из-за неполных оснований.")
        reply = passport_tools.resolve(state, {"id": fid, "resolution": "withdrawn",
            "reason": "Отправка содержит ошибочную гипотезу о продолжении, решение нужно проверить."})
        self.assertNotIn("отклонён", reply)
        sync_objects(state)
        oid = "resolution:" + fid
        self.assertIn(oid, state.workspace.pending_reviews())
        self.assertEqual(state.workspace.objects[oid]["content"]["proposal"]["tool"], "submit_connection_review")


if __name__ == "__main__":
    unittest.main()
