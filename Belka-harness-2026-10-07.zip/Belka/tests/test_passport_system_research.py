"""Qualitative research shares the passport corpus, revision ledger and finish gate."""
from copy import deepcopy
from types import SimpleNamespace
import json
import unittest

from pko.progress.passport_evidence import EvidenceCorpus
from pko.progress.passport_system_research import (
    SYSTEM_RESEARCH_SCHEMAS, evidence_tree, verified_corpus_evidence,
    handle_system_research, system_review, system_research_blockers,
    sync_system_research_objects, system_research_schemas,
)
from pko.progress.schema import Handoff, HandoffCheck, IntegrityReview, Scenario
from pko.progress.verify import verify_evidence
from test_passport_agentic import QUOTE, _Node, session_fixture


REFS = [{"id": "evidence-1", "quote": QUOTE, "path": "reports.py", "line": 2,
         "basis": "send_report", "note": "Передаёт подготовленный отчёт транспорту."}]
DOES = ("Система принимает подготовленный отчёт и передаёт его транспортному сервису по явному запросу. "
        "Она обслуживает передачу результата между участниками обработки: получает готовые данные, "
        "запускает отправку и возвращает управление вызывающей стороне. Получение отчёта клиентом "
        "требует отдельного наблюдения и здесь не заявляется.")
NOT_DOES = ("Доступный материал не подтверждает фактическое получение отчёта клиентом и устойчивость "
            "доставки при отказе транспорта. Вывод относится к механизму отправки в переданном снимке, "
            "а не к результатам эксплуатации системы.")
DETAIL = ("Вызов отправки передаёт подготовленный отчёт транспортному сервису. В рассмотренном месте "
          "нет подтверждения получения результата потребителем, поэтому механизм передачи и "
          "фактическое завершение клиентского действия требуют отдельной проверки.")
NOTE = "Части исследованного механизма соединены от явного запроса до передачи подготовленного отчёта транспортному сервису."


def research_session():
    state = session_fixture(filled=True)
    state.research_enabled = True
    state.research_basis = "result_image"
    state.system_research_state = None
    state.plan_bullets = ["Клиент получает отчёт по явному запросу."]
    return state


def purpose(**updates):
    return {"does": DOES, "not_does": NOT_DOES, "verdict": "narrower", "evidence": deepcopy(REFS), **updates}


def flow(**updates):
    return {"entry": "Явный запрос подготовленного отчёта", "steps": ["Получение данных отчёта", "Передача отчёта транспорту"],
            "outcome": "Транспорт получил запрос отправки отчёта", "complete": True,
            "evidence": deepcopy(REFS), **updates}


def flaw(**updates):
    return {"kind": "result_not_delivered", "severity": "major", "title": "Получение результата не подтверждено",
            "detail": DETAIL, "evidence": deepcopy(REFS),
            "bullets": ["Клиент получает отчёт по явному запросу."], **updates}


def integrity(**updates):
    return {"level": "coherent", "note": NOTE, "evidence": deepcopy(REFS), **updates}


def approve(state):
    live = sync_system_research_objects(state)
    for oid in live:
        state.workspace.reviews[oid] = {"object_id": oid, "revision": state.workspace.objects[oid]["revision"],
                                        "result": "supported"}
    return live


class ReadCorpusTreeTests(unittest.TestCase):
    def test_original_lines_are_preserved_and_unread_files_are_inaccessible(self):
        corpus = EvidenceCorpus()
        corpus.add("code", "visible.py:100", "100: def prepare_report(report):\n101:     return report")
        corpus.add("code", "hidden.py:1", "1: def hidden_handler():\n2:     return True")
        corpus.read(["evidence-1"])
        tree = evidence_tree(corpus)
        self.assertEqual(tree.files_set, {"visible.py"})
        self.assertIsNone(tree.read("hidden.py"))
        self.assertEqual(tree.read("visible.py").splitlines()[99], "def prepare_report(report):")
        self.assertTrue(verify_evidence("visible.py", 101, "prepare_report", tree).ok)
        # A nearby, shown anchor must not make the unread line 99 evidence.
        self.assertFalse(verify_evidence("visible.py", 99, "prepare_report", tree).ok)

    def test_links_need_read_code_quote_correct_path_line_and_anchor(self):
        state = research_session()
        refs, errors = verified_corpus_evidence(state.evidence_corpus, REFS)
        self.assertEqual(errors, [])
        self.assertEqual((refs[0].path, refs[0].line, refs[0].verified), ("reports.py", 2, True))
        invalid = [
            [{**REFS[0], "path": "hidden.py"}], [{**REFS[0], "line": 1}],
            [{**REFS[0], "line": True}], [{**REFS[0], "basis": "invented_handler"}],
            [{"id": "evidence-2", "quote": "Клиент получает отчёт по явному запросу.",
              "path": "reports.py", "line": 2, "basis": "send_report"}],
        ]
        for proposal in invalid:
            with self.subTest(proposal=proposal):
                accepted, problems = verified_corpus_evidence(state.evidence_corpus, proposal)
                self.assertEqual(accepted, [])
                self.assertTrue(problems)
        state.evidence_corpus.shown.clear()
        self.assertTrue(verified_corpus_evidence(state.evidence_corpus, REFS)[1])

    def test_repeated_text_on_other_line_cannot_relocate_numbered_quote(self):
        corpus = EvidenceCorpus()
        corpus.add("code", "repeat.py:1", "1: send_report(report)\n2: send_report(report)")
        corpus.read(["evidence-1"])
        refs = [{"id": "evidence-1", "quote": "1: send_report(report)", "path": "repeat.py",
                 "line": 2, "basis": "send_report"}]
        self.assertTrue(verified_corpus_evidence(corpus, refs)[1])

    def test_large_coordinate_and_conflicting_windows_fail_closed(self):
        corpus = EvidenceCorpus()
        corpus.add("code", "reports.py:1000001", "1000001: send_report(report)")
        corpus.read(["evidence-1"])
        self.assertIsNone(evidence_tree(corpus).read("reports.py"))
        corpus.add("code", "same.py:1", "1: send_report(report)")
        corpus.add("code", "same.py:1", "1: delete_report(report)")
        corpus.read(["evidence-2", "evidence-3"])
        self.assertIsNone(evidence_tree(corpus).read("same.py"))


class SystemResearchLifecycleTests(unittest.TestCase):
    def submit(self, state, name, args):
        reply = handle_system_research(state, name, args)
        self.assertNotIn("отклонён", reply, reply)
        return reply

    def test_disabled_legacy_sessions_have_no_new_completion_requirements(self):
        state = session_fixture(filled=True)
        state.research_enabled = False
        self.assertEqual(system_research_blockers(state), [])
        self.assertEqual(sync_system_research_objects(state), set())
        self.assertIsNone(system_review(state))
        self.assertIn("отклонён", handle_system_research(state, "submit_system", purpose()))

    def test_partial_purpose_survives_without_flow_or_integrity(self):
        state = research_session()
        self.assertEqual(len(system_research_blockers(state)), 3)
        self.submit(state, "submit_system", purpose())
        review = system_review(state)
        self.assertIsInstance(review, IntegrityReview)
        self.assertEqual(review.level, "")
        self.assertIsNone(review.flow)
        self.assertEqual(review.purpose.does, DOES)
        self.assertTrue(review.purpose.evidence[0].verified)
        self.assertEqual(review.checked, 1)
        self.assertEqual(len(system_research_blockers(state)), 2)

    def test_tools_allow_revisits_and_no_fixed_first_or_once_call(self):
        state = research_session()
        self.submit(state, "submit_integrity", integrity())
        self.submit(state, "submit_flow", flow())
        self.submit(state, "submit_system", purpose())
        self.assertEqual(system_research_blockers(state), [])
        live = approve(state)
        old_revision = state.workspace.objects["system:flow"]["revision"]
        self.submit(state, "submit_flow", flow(outcome="Вызывающая сторона получает управление после передачи отчёта"))
        self.assertEqual(sync_system_research_objects(state), live)
        self.assertNotEqual(state.workspace.objects["system:flow"]["revision"], old_revision)
        self.assertNotIn("system:flow", state.workspace.reviews)
        self.assertNotIn("system:integrity", state.workspace.reviews)
        self.assertEqual(system_review(state).flow.outcome, "Вызывающая сторона получает управление после передачи отчёта")

    def test_flaw_upsert_retirement_and_new_ids_preserve_review_history(self):
        state = research_session()
        self.submit(state, "submit_flaw", flaw())
        fid = "system:flaw-1"
        approve(state)
        revision = state.workspace.objects[fid]["revision"]
        self.submit(state, "submit_flaw", flaw(id=fid, severity="blocker"))
        self.assertEqual(len(system_review(state).flaws), 1)
        self.assertNotEqual(state.workspace.objects[fid]["revision"], revision)
        self.assertNotIn(fid, state.workspace.reviews)
        self.submit(state, "submit_flaw", {"id": fid, "action": "withdraw", "evidence": deepcopy(REFS),
            "reason": "Исходная формулировка смешивала передачу отчёта и неподтверждённую доставку получателю."})
        self.assertEqual(system_review(state).flaws, [])
        rid = "retirement:" + fid
        self.assertIn(rid, sync_system_research_objects(state))
        self.assertEqual(state.workspace.objects[rid]["content"]["previous"]["value"]["severity"], "blocker")
        self.assertIn(rid, state.workspace.pending_reviews())
        self.assertNotIn(fid, state.workspace.objects)
        self.submit(state, "submit_flaw", flaw())
        self.assertIn("system:flaw-2", state.workspace.objects)
        self.assertTrue(any(e["action"] == "system_flaw_withdrawn" for e in state.workspace.history))

    def test_system_receipts_expire_on_business_and_scenario_trace_changes(self):
        state = research_session()
        self.submit(state, "submit_system", purpose())
        self.submit(state, "submit_flow", flow())
        self.submit(state, "submit_integrity", integrity())
        for mutate in (
            lambda: state.nodes["operation-1"].data.update(effect="Передан только заголовок отчёта"),
            lambda: state.scenarios.update({"scenario-1": ["Запросить отчёт", "Сохранить отчёт"]}),
            lambda: setattr(state, "connectivity_state", SimpleNamespace(
                scenarios={"scenario-1": Scenario(id="scenario-1", title="Получение отчёта", entry="Запрос", outcome="Отчёт",
                    steps=["Запросить", "Сохранить"], handoffs=[Handoff(step=0, checks=[
                        HandoffCheck(check="reachability", result="unknown", note="Вызов требует проверки")])])},
                revisions={"scenario-1": 1}, trace_versions={"scenario-1": 1})),
        ):
            live = approve(state)
            before = {oid: state.workspace.objects[oid]["revision"] for oid in live}
            mutate()
            self.assertEqual(sync_system_research_objects(state), live)
            for oid in live:
                self.assertNotEqual(state.workspace.objects[oid]["revision"], before[oid])
                self.assertNotIn(oid, state.workspace.reviews)

    def test_current_flaws_and_flow_are_rechecked_after_prior_integrity(self):
        state = research_session()
        self.submit(state, "submit_system", purpose())
        self.submit(state, "submit_flow", flow())
        self.submit(state, "submit_integrity", integrity())
        self.submit(state, "submit_flow", flow(complete=False, break_point="Передача обрывается при отказе транспорта"))
        self.assertTrue(any("путь" in s for s in system_research_blockers(state)))
        self.submit(state, "submit_flaw", flaw(severity="blocker"))
        self.assertIn("отклонён", handle_system_research(state, "submit_integrity", integrity()))
        self.submit(state, "submit_integrity", integrity(level="disconnected"))
        self.assertEqual(system_research_blockers(state), [])
        self.submit(state, "submit_system", purpose(verdict="different"))
        self.assertTrue(any("scope_mismatch" in s for s in system_research_blockers(state)))

    def test_unknown_integrity_accepts_explicit_limits_without_invented_flaw(self):
        state = research_session()
        self.submit(state, "submit_system", purpose())
        self.submit(state, "submit_flow", flow(complete=False,
            break_point="Доступные материалы не раскрывают дальнейшую доставку; продолжение пути не установлено."))
        self.submit(state, "submit_integrity", integrity(level="unknown",
            note="Передача отчёта установлена, но материалы не раскрывают продолжение доставки и её завершение для клиента."))
        self.assertEqual(system_research_blockers(state), [])
        self.assertEqual(system_review(state).level, "unknown")
        self.assertEqual(system_review(state).flaws, [])

    def test_coherent_is_blocked_if_scenario_later_has_verified_break(self):
        state = research_session()
        self.submit(state, "submit_system", purpose())
        self.submit(state, "submit_flow", flow())
        self.submit(state, "submit_integrity", integrity())
        refs, errors = verified_corpus_evidence(state.evidence_corpus, REFS)
        self.assertEqual(errors, [])
        broken = Scenario(id="scenario-1", title="Доставка", entry="Запрос", outcome="Отчёт",
            steps=["Отправить", "Получить"], handoffs=[Handoff(step=0, checks=[
                HandoffCheck(check="reachability", result="broken", note="Доставка прекращена", evidence=refs)])])
        self.assertEqual(broken.status, "broken")
        state.connectivity_state = SimpleNamespace(scenarios={broken.id: broken}, order=[broken.id])
        self.assertTrue(any("scenario-1" in error for error in system_research_blockers(state)))
        self.assertIn("отклонён", handle_system_research(state, "submit_integrity", integrity()))

    def test_medium_business_tree_and_long_evidence_fit_independent_review(self):
        from pko.progress.passport_reviewer import _prepare_objects
        state = research_session()
        # Forty real node envelopes with large field explanations. These must
        # affect the hash without being duplicated inside every system object.
        for i in range(3, 36):
            nid = f"operation-{i}"
            state.nodes[nid] = _Node(nid, f"Подготовка результата этапа {i}", "Этап обработки отчёта",
                parents=["bbb-1"], filled=True, data={"fields": {
                    "4.5.4": {"value": "Подготовлен результат", "source": "Подробное основание. " * 300}}})
            state.nodes["bbb-1"].children.append(nid)
        state.plan_bullets = [f"Требование {i}: " + "содержательное условие обработки отчёта " * 50 for i in range(10)]
        large = "1: def send_report(report):\n" + QUOTE + "\n" + "\n".join(
            f"{i}:     result = report + 'дополнительное содержимое отчёта'" for i in range(3, 75))
        state.evidence_corpus.add("code", "reports.py:1", large)
        eid = next(reversed(state.evidence_corpus.records))
        state.evidence_corpus.read([eid])
        refs = [{**REFS[0], "id": eid, "quote": large}] * 12
        self.submit(state, "submit_system", purpose(evidence=refs))
        self.submit(state, "submit_flow", flow(evidence=refs))
        for i in range(12):
            self.submit(state, "submit_flaw", flaw(title=f"Граница подтверждения доставки {i}",
                evidence=refs, bullets=state.plan_bullets))
        self.submit(state, "submit_integrity", integrity(level="fragmented", evidence=refs))
        live = sync_system_research_objects(state)
        for oid in live:
            _, errors = _prepare_objects([state.workspace.objects[oid]])
            self.assertEqual(errors, [], oid)
        packet = [state.workspace.objects[oid] for oid in ("system:purpose", "system:flow", "system:integrity")]
        self.assertEqual(_prepare_objects(packet)[1], [])
        content = state.workspace.objects["system:integrity"]["content"]
        self.assertEqual(content["context"]["business_nodes"]["total"], 40)
        self.assertTrue(content["context"]["business_nodes"]["items"])
        self.assertNotIn("Подробное основание. Подробное основание.", json.dumps(packet, ensure_ascii=False))
        self.assertTrue(all("quote" not in ref and "quote_sha256" in ref for ref in content["evidence"]))

    def test_reviewed_flaw_retirement_resolves_prior_independent_challenge(self):
        from pko.progress import passport_tools
        from pko.progress.passport_workspace import sync_objects
        state = research_session()
        self.submit(state, "submit_flaw", flaw())
        fid = "system:flaw-1"
        finding = state.workspace.reject("review:" + fid,
            {"tool": "independent_review", "object_id": fid, "revision": state.workspace.objects[fid]["revision"]},
            "Вывод о доставке шире показанного механизма передачи отчёта.")
        self.submit(state, "submit_flaw", {"id": fid, "action": "withdraw", "evidence": deepcopy(REFS),
            "reason": "Исходная формулировка смешивала передачу отчёта и неподтверждённую доставку получателю."})
        rid = "retirement:" + fid
        self.assertEqual(state.workspace.retirements[rid]["object_id"], fid)
        state.reviewer = lambda objects: {"findings": [{"object_id": obj["id"], "revision": obj["revision"],
            "result": "supported", "reason": "Отзыв сохраняет факт передачи и корректно ограничивает вывод о доставке.",
            "evidence": deepcopy(REFS)} for obj in objects]}
        self.assertNotIn("отклонён", passport_tools.review(state, {"ids": [rid]}))
        self.assertEqual(state.workspace.findings[finding]["state"], "corrected")
        revision = state.workspace.objects[rid]["revision"]
        sync_objects(state)
        self.assertEqual(state.workspace.objects[rid]["revision"], revision)
        self.assertNotIn(rid, state.workspace.pending_reviews())

    def test_rejected_revision_is_atomic_and_keeps_accepted_content(self):
        state = research_session()
        self.submit(state, "submit_system", purpose())
        previous = system_review(state).to_dict()
        for args in (purpose(does="Слишком коротко"), purpose(does="send_report " + DOES),
                     purpose(does=DOES * 3), purpose(evidence=[])):
            reply = handle_system_research(state, "submit_system", args)
            self.assertTrue(reply.startswith("submit_system отклонён:"), reply)
            self.assertEqual(system_review(state).to_dict(), previous)
        self.assertTrue(handle_system_research(state, "submit_flow", flow(complete="false")).startswith("submit_flow отклонён:"))

    def test_adapter_does_not_read_broker_and_exports_only_verified_links(self):
        state = research_session()
        class ForbiddenBroker:
            def request(self, args):
                raise AssertionError("The adapter must never read new source implicitly")
        state.evidence_broker = ForbiddenBroker()
        self.submit(state, "submit_system", purpose())
        self.assertEqual(system_review(state).to_dict()["purpose"]["links"][0]["line"], 2)
        self.assertEqual(state.plan_bullets, ["Клиент получает отчёт по явному запросу."])

    def test_all_public_tools_advertise_literal_source_contract(self):
        names = {schema["function"]["name"] for schema in SYSTEM_RESEARCH_SCHEMAS}
        self.assertEqual(names, {"submit_system", "submit_flow", "submit_flaw", "submit_integrity"})
        for schema in SYSTEM_RESEARCH_SCHEMAS:
            params = schema["function"]["parameters"]
            self.assertIn("evidence", params["required"])
            self.assertEqual(set(params["properties"]["evidence"]["items"]["required"]),
                             {"id", "quote", "path", "line", "basis"})

    def test_new_or_revised_system_facts_invalidate_accepted_risk_analysis(self):
        state = research_session()
        for name, args in (("submit_system", purpose()), ("submit_flow", flow()),
                           ("submit_flaw", flaw())):
            with self.subTest(tool=name):
                state.risk_reviewed = True
                self.submit(state, name, args)
                self.assertFalse(state.risk_reviewed)
        for name, args in (("submit_system", purpose(verdict="same_purpose")),
                           ("submit_flow", flow(outcome="Управление возвращено после отправки отчёта")),
                           ("submit_flaw", flaw(id="system:flaw-1", severity="blocker"))):
            with self.subTest(revised_tool=name):
                state.risk_reviewed = True
                self.submit(state, name, args)
                self.assertFalse(state.risk_reviewed)

    def test_idempotent_system_resubmission_keeps_risk_analysis_current(self):
        state = research_session()
        submissions = [("submit_system", purpose()), ("submit_flow", flow()),
                       ("submit_flaw", flaw())]
        for name, args in submissions:
            self.submit(state, name, args)
        submissions[-1] = ("submit_flaw", flaw(id="system:flaw-1"))
        for name, args in submissions:
            with self.subTest(tool=name):
                state.risk_reviewed = True
                self.submit(state, name, args)
                self.assertTrue(state.risk_reviewed)
        # A qualitative label alone adds no new system fact for risk analysis.
        self.submit(state, "submit_integrity", integrity(level="fragmented"))
        self.assertTrue(state.risk_reviewed)

    def test_withdrawing_system_flaw_requires_fresh_risk_analysis(self):
        state = research_session()
        self.submit(state, "submit_flaw", flaw())
        state.risk_reviewed = True
        self.submit(state, "submit_flaw", {"id": "system:flaw-1", "action": "withdraw",
            "reason": "Исходная формулировка смешивала передачу отчёта и неподтверждённую доставку получателю.",
            "evidence": deepcopy(REFS)})
        self.assertFalse(state.risk_reviewed)


def code_session():
    state = research_session()
    state.research_basis = "code"
    state.plan_bullets = []
    return state


def code_purpose(**updates):
    args = purpose()
    args.pop("verdict")
    return {**args, **updates}


def code_flaw(**updates):
    args = flaw()
    args.pop("bullets")
    return {**args, **updates}


class CodeSystemResearchTests(unittest.TestCase):
    submit = SystemResearchLifecycleTests.submit

    def test_code_schema_has_no_comparison_contract_and_leaves_legacy_unchanged(self):
        before = deepcopy(SYSTEM_RESEARCH_SCHEMAS)
        schemas = {s["function"]["name"]: s["function"] for s in system_research_schemas("code")}
        params = schemas["submit_system"]["parameters"]
        self.assertNotIn("verdict", params["properties"])
        self.assertNotIn("verdict", params["required"])
        params = schemas["submit_flaw"]["parameters"]
        self.assertNotIn("bullets", params["properties"])
        self.assertNotIn("scope_mismatch", params["properties"]["kind"]["enum"])
        self.assertIn("nodes", params["properties"])
        self.assertIn("scenarios", params["properties"])
        text = json.dumps(schemas, ensure_ascii=False)
        self.assertNotIn("инициатив", text)
        self.assertNotIn("same_purpose", text)
        self.assertEqual(SYSTEM_RESEARCH_SCHEMAS, before)
        legacy = system_research_schemas("result_image")[0]["function"]["parameters"]
        self.assertIn("verdict", legacy["required"])
        self.assertNotIn("code_derived", legacy["properties"]["verdict"]["enum"])

    def test_code_purpose_and_honest_unknown_finish_without_any_result_image(self):
        state = code_session()
        self.submit(state, "submit_system", code_purpose())
        self.submit(state, "submit_flow", flow(complete=False,
            break_point="Дальнейшее поведение транспорта и получение отчёта клиентом не установлены."))
        self.submit(state, "submit_integrity", integrity(level="unknown"))
        self.assertEqual(system_research_blockers(state), [])
        review = system_review(state)
        self.assertEqual(review.purpose.verdict, "code_derived")
        self.assertEqual(review.checked, 0)
        self.assertEqual(review.flaws, [])
        self.assertTrue(review.purpose.evidence[0].verified)
        self.assertEqual(review.to_dict()["purpose"]["verdict_label"], "Назначение восстановлено по коду")
        for oid in sync_system_research_objects(state):
            content = state.workspace.objects[oid]["content"]
            self.assertEqual(content["research_basis"], "code")
            self.assertNotIn("intent_evidence_ids", content["context"])

    def test_code_verdict_is_host_owned_and_rejections_are_atomic(self):
        state = code_session()
        self.submit(state, "submit_system", code_purpose())
        prior = deepcopy(state.system_research_state.records)
        for verdict in ("same_purpose", "narrower", "different", "code_derived", None):
            reply = handle_system_research(state, "submit_system", code_purpose(verdict=verdict))
            self.assertTrue(reply.startswith("submit_system отклонён:"), reply)
            self.assertEqual(state.system_research_state.records, prior)
        legacy = research_session()
        self.assertIn("отклонён", handle_system_research(legacy, "submit_system", purpose(verdict="code_derived")))

    def test_code_flaw_exports_business_scope_without_bullets_and_rechecks_retirements(self):
        state = code_session()
        state.scenarios = {"scenario-1": ["Запрос", "Доставка"]}
        self.submit(state, "submit_flaw", code_flaw(nodes=["operation-2"], scenarios=["scenario-1"]))
        row = system_review(state).flaws[0].to_dict()
        self.assertEqual(row["nodes"], ["operation-2"])
        self.assertEqual(row["scenarios"], ["scenario-1"])
        self.assertEqual(row["bullets"], [])
        content = state.workspace.objects["system:flaw-1"]["content"]
        self.assertNotIn("bullet_indices", content["value"])
        self.assertEqual(content["value"]["scenarios"], ["scenario-1"])
        self.submit(state, "submit_system", code_purpose())
        self.submit(state, "submit_flow", flow())
        self.submit(state, "submit_integrity", integrity(level="fragmented"))
        self.assertEqual(system_research_blockers(state), [])
        approve(state)
        del state.nodes["operation-2"]
        del state.scenarios["scenario-1"]
        sync_system_research_objects(state)
        self.assertNotIn("system:flaw-1", state.workspace.reviews)
        blockers = system_research_blockers(state)
        self.assertTrue(any("nodes:" in error for error in blockers), blockers)
        self.assertTrue(any("scenarios:" in error for error in blockers), blockers)
        self.submit(state, "submit_flaw", code_flaw(id="system:flaw-1"))
        self.assertEqual(system_research_blockers(state), [])

    def test_code_flaw_rejects_comparative_scope_and_unknown_or_duplicate_ids(self):
        state = code_session()
        state.scenarios = {"scenario-1": ["Запрос", "Доставка"]}
        for updates in ({"bullets": []}, {"kind": "scope_mismatch"}, {"nodes": ["operation-99"]},
                        {"scenarios": ["scenario-99"]}, {"nodes": ["operation-1", "operation-1"]},
                        {"scenarios": "scenario-1"}, {"nodes": [None]}):
            with self.subTest(updates=updates):
                reply = handle_system_research(state, "submit_flaw", code_flaw(**updates))
                self.assertTrue(reply.startswith("submit_flaw отклонён:"), reply)
                self.assertFalse(getattr(state.system_research_state, "flaws", {}))
        # A general system flaw is valid before business objects have been named.
        self.submit(state, "submit_flaw", code_flaw())

    def test_new_scope_revises_stable_flaw_and_risk_analysis_but_same_scope_does_not(self):
        state = code_session()
        self.submit(state, "submit_flaw", code_flaw(nodes=["operation-1"]))
        fid = "system:flaw-1"
        approve(state)
        before = state.workspace.objects[fid]["revision"]
        state.risk_reviewed = True
        self.submit(state, "submit_flaw", code_flaw(id=fid, nodes=["operation-1"]))
        self.assertTrue(state.risk_reviewed)
        self.assertEqual(state.workspace.objects[fid]["revision"], before)
        self.submit(state, "submit_flaw", code_flaw(id=fid, nodes=["operation-2"]))
        self.assertFalse(state.risk_reviewed)
        self.assertNotEqual(state.workspace.objects[fid]["revision"], before)
        self.assertNotIn(fid, state.workspace.reviews)
        self.assertEqual(list(state.system_research_state.flaws), [fid])

    def test_basis_change_invalidates_receipts_and_requires_explicit_research_revision(self):
        state = research_session()
        self.submit(state, "submit_system", purpose())
        self.submit(state, "submit_flow", flow())
        self.submit(state, "submit_integrity", integrity())
        approve(state)
        state.risk_reviewed = True
        state.research_basis = "code"
        sync_system_research_objects(state)
        self.assertFalse(state.risk_reviewed)
        self.assertTrue(all(oid not in state.workspace.reviews for oid in state.system_research_state.records))
        self.assertEqual(len([error for error in system_research_blockers(state) if "другому основанию" in error]), 3)
        self.submit(state, "submit_system", code_purpose())
        self.submit(state, "submit_flow", flow())
        self.submit(state, "submit_integrity", integrity())
        self.assertEqual(system_research_blockers(state), [])

    def test_code_mode_still_requires_actually_read_code_for_each_conclusion(self):
        state = code_session()
        state.evidence_corpus.shown.clear()
        for name, args in (("submit_system", code_purpose()), ("submit_flow", flow()),
                           ("submit_flaw", code_flaw()), ("submit_integrity", integrity(level="unknown"))):
            reply = handle_system_research(state, name, args)
            self.assertTrue(reply.startswith(name + " отклонён:"), reply)
        self.assertIsNone(system_review(state))


if __name__ == "__main__":
    unittest.main()
