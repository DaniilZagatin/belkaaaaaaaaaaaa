"""The reviewer enforces provenance and coverage, not semantic truth by regex."""
from copy import deepcopy
import json
from threading import Event
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from pko.errors import LlmError
from pko.audit import AuditedClient
from pko.llm.client import ChatClient, ChatResult
from pko.llm.registry import ModelSpec
from pko.progress.context_window import ReasoningWindowClient
from pko.progress.passport_evidence import EvidenceCorpus
from pko.progress.passport_reviewer import review_passport_objects, MAX_TOOL_CALLS, _review_client
from pko.progress.passport_broker import EvidenceBroker


SPEC = ModelSpec(role="passport_reviewer", base_url="http://unused.invalid", model="fixture", api_key="")
QUOTE = "2: transport.send(report)"


def corpus_fixture():
    corpus = EvidenceCorpus()
    corpus.add("code", "reports.py:1", "1: def send_report(report):\n2: transport.send(report)")
    corpus.add("intent", "Исходный ОР", "Отчёт отправляется по явному запросу пользователя.")
    corpus.add("summary", "След оценки", "Отчёт всегда доставляется успешно и без задержки.")
    return corpus


def object_fixture(oid="node-1", revision="hash-1", kind="node"):
    return {"id": oid, "revision": revision, "kind": kind,
            "content": {"name": "Отправка отчёта", "outcome": "Вызывается отправка отчёта; доставка не установлена."}}


def finding(oid="node-1", revision="hash-1", result="supported", evidence=None):
    return {"object_id": oid, "revision": revision, "result": result,
            "reason": "Прочитанный обработчик вызывает отправку; успешная доставка остаётся вне проверки.",
            "evidence": [{"id": "evidence-1", "quote": QUOTE}] if evidence is None else evidence}


def tool(name, args=None, call_id="call-1"):
    return {"id": call_id, "type": "function", "function": {
        "name": name, "arguments": json.dumps(args or {}, ensure_ascii=False)}}


def answer(*calls):
    return ChatResult(text="", usage={}, tool_calls=list(calls))


def read_answer(*ids):
    return answer(tool("read_passport_evidence", {"ids": list(ids)}))


def submit_answer(*checks):
    return answer(tool("submit_checks", {"checks": list(checks)}))


class ScriptClient:
    spec = SPEC

    def __init__(self, *answers):
        self.answers = list(answers)
        self.messages = []
        self.kwargs = []

    def chat(self, messages, **kwargs):
        self.messages.append(deepcopy(messages))
        self.kwargs.append(kwargs)
        if not self.answers:
            raise LlmError("Скриптованный ответ закончился.")
        result = self.answers.pop(0)
        if isinstance(result, Exception):
            raise result
        if callable(result):
            return result(messages)
        return result


class PassportReviewerTest(unittest.TestCase):
    def run_review(self, client, *, objects=None, corpus=None, **kwargs):
        return review_passport_objects(objects if objects is not None else [object_fixture()],
                                       corpus if corpus is not None else corpus_fixture(), SPEC,
                                       client=client, **kwargs)

    def test_own_read_and_exact_version_are_required_for_completion(self):
        corpus = corpus_fixture()
        client = ScriptClient(read_answer("evidence-1"), submit_answer(finding()))
        result = self.run_review(client, corpus=corpus)
        self.assertTrue(result["complete"])
        self.assertFalse(result["semantic_truth_verified"])
        self.assertEqual(result["findings"], [finding()])
        self.assertEqual(result["reviewer_reads"], ["evidence-1"])
        self.assertEqual(result["steps"], 2)
        self.assertEqual(corpus.shown, {})

    def test_researcher_reads_and_embedded_quotes_do_not_count(self):
        corpus = corpus_fixture()
        corpus.read(["evidence-1"])
        obj = object_fixture()
        obj["content"]["evidence"] = finding()["evidence"]
        client = ScriptClient(submit_answer(finding()))
        result = self.run_review(client, corpus=corpus, objects=[obj], max_steps=1)
        self.assertFalse(result["complete"])
        self.assertEqual(result["findings"], [])
        self.assertEqual(result["reviewer_reads"], [])
        self.assertEqual(result["pending"], [{"id": "node-1", "revision": "hash-1"}])
        self.assertIn("evidence-1", corpus.shown)

    def test_search_results_do_not_count_as_read_and_rejection_can_be_repaired(self):
        client = ScriptClient(answer(tool("search_passport_evidence", {"query": "reports"})),
                              submit_answer(finding()), read_answer("evidence-1"), submit_answer(finding()))
        result = self.run_review(client)
        self.assertTrue(result["complete"])
        rejected = json.loads(client.messages[2][-1]["content"])
        self.assertFalse(rejected["ok"])
        self.assertIn("сначала прочитай", str(rejected))

    def test_summary_and_intent_cannot_support_runtime_or_contradict_it(self):
        for result_kind in ("supported", "contradicted"):
            with self.subTest(result=result_kind):
                corpus = corpus_fixture()
                refs = [{"id": "evidence-3", "quote": corpus.records["evidence-3"]["text"]}]
                client = ScriptClient(read_answer("evidence-3"), submit_answer(finding(result=result_kind, evidence=refs)))
                result = self.run_review(client, corpus=corpus, max_steps=2)
                self.assertFalse(result["complete"])
                self.assertEqual(result["findings"], [])

    def test_intended_planned_object_is_checked_against_original_intent(self):
        corpus = corpus_fixture()
        refs = [{"id": "evidence-2", "quote": corpus.records["evidence-2"]["text"]}]
        obj = object_fixture(kind="intent")
        obj["content"]["planned"] = True
        client = ScriptClient(read_answer("evidence-2"), submit_answer(finding(evidence=refs)))
        result = self.run_review(client, corpus=corpus, objects=[obj])
        self.assertTrue(result["complete"])
        self.assertEqual(result["findings"][0]["result"], "supported")

    def test_code_alone_does_not_confirm_an_intended_promise(self):
        client = ScriptClient(read_answer("evidence-1"), submit_answer(finding()))
        result = self.run_review(client, objects=[object_fixture(kind="intent")], max_steps=2)
        self.assertFalse(result["complete"])

    def test_observed_result_requires_read_document_and_cannot_use_static_code(self):
        corpus = corpus_fixture()
        corpus.add("document", "verification.txt:1", "2026-10-06: один отчёт доставлен тестовому получателю в изолированном контуре.")
        refs = [{"id": "evidence-4", "quote": corpus.records["evidence-4"]["text"]}]
        obj = object_fixture(kind="observed_outcome")
        client = ScriptClient(read_answer("evidence-1"), submit_answer(finding()),
                              read_answer("evidence-4"), submit_answer(finding(evidence=refs)))
        result = self.run_review(client, corpus=corpus, objects=[obj])
        self.assertTrue(result["complete"])
        self.assertFalse(json.loads(client.messages[2][-1]["content"])["ok"])
        self.assertEqual(result["findings"][0]["evidence"], refs)

    def test_insufficient_can_be_complete_coverage_without_fabricated_citations(self):
        check = finding(result="insufficient", evidence=[])
        check["reason"] = "В корпусе нет обработчика внешнего исполнителя; его контракт и гарантия доставки неизвестны."
        result = self.run_review(ScriptClient(submit_answer(check)))
        self.assertTrue(result["complete"])
        self.assertFalse(result["semantic_truth_verified"])
        self.assertEqual(result["findings"][0]["result"], "insufficient")
        self.assertEqual(result["reviewer_reads"], [])

    def test_stale_revision_invented_objects_and_duplicates_cannot_replace_checks(self):
        client = ScriptClient(read_answer("evidence-1"),
                              submit_answer(finding(revision="old-hash"), finding(oid="invented")),
                              submit_answer(finding(), finding(result="contradicted")))
        result = self.run_review(client)
        self.assertTrue(result["complete"])
        self.assertEqual(result["findings"], [finding()])
        previous = json.loads(client.messages[2][-1]["content"])
        self.assertEqual(len(previous["errors"]), 2)

    def test_exact_revision_type_matters(self):
        obj = object_fixture(revision=1)
        result = self.run_review(ScriptClient(read_answer("evidence-1"), submit_answer(finding(revision=True))),
                                 objects=[obj], max_steps=2)
        self.assertFalse(result["complete"])

    def test_partial_findings_survive_provider_failure_and_input_is_unchanged(self):
        objects = [object_fixture(), object_fixture("node-2", "hash-2")]
        original = deepcopy(objects)
        client = ScriptClient(read_answer("evidence-1"), submit_answer(finding()), LlmError("Эндпоинт недоступен."))
        result = self.run_review(client, objects=objects)
        self.assertFalse(result["complete"])
        self.assertEqual(result["findings"], [finding()])
        self.assertEqual(result["pending"], [{"id": "node-2", "revision": "hash-2"}])
        self.assertEqual(objects, original)
        self.assertIn("Эндпоинт недоступен", str(result["notes"]))

    def test_context_is_new_and_does_not_import_researcher_reasoning_buffer(self):
        obj = object_fixture()
        obj["content"]["reasoning_content"] = "RESEARCHER_PRIVATE_TEXT"
        obj["reasoning"] = "TOP_LEVEL_PRIVATE_TEXT"
        delegate = ScriptClient(submit_answer(finding(result="insufficient", evidence=[])))
        wrapper = ReasoningWindowClient(delegate)
        original_message = {"role": "assistant", "reasoning_content": None}
        wrapper._removed.append((original_message, "REMOVED_RESEARCHER_REASONING"))
        result = self.run_review(wrapper, objects=[obj])
        self.assertTrue(result["complete"])
        initial = json.dumps(delegate.messages[0])
        for secret in ("RESEARCHER_PRIVATE_TEXT", "TOP_LEVEL_PRIVATE_TEXT", "REMOVED_RESEARCHER_REASONING"):
            self.assertNotIn(secret, initial)
        self.assertEqual(len(delegate.messages[0]), 2)
        self.assertIsNone(original_message["reasoning_content"])

    def test_reviewer_does_not_replace_researcher_audit_message_buffer(self):
        delegate = ScriptClient(submit_answer(finding(result="insufficient", evidence=[])))
        audited = AuditedClient(delegate)
        original_messages = [{"role": "user", "content": "RESEARCHER_CONTEXT"}]
        audited.messages = original_messages
        result = self.run_review(ReasoningWindowClient(audited))
        self.assertTrue(result["complete"])
        self.assertIs(audited.messages, original_messages)
        self.assertNotIn("RESEARCHER_CONTEXT", json.dumps(delegate.messages[0]))

    def test_prior_findings_are_separate_cleaned_and_not_counted_as_read(self):
        obj = object_fixture()
        prior = finding(revision="previous-hash", result="contradicted")
        prior["reason"] = "Обработчик вызывает отправку, но исходный текст обещал гарантированную доставку."
        prior["reasoning_content"] = "PRIOR_PRIVATE_REASONING"
        prior["details"] = {"reasoning": "NESTED_PRIVATE_REASONING", "boundary": "Доставка не наблюдалась."}
        obj["prior_findings"] = [prior]
        original = deepcopy(obj)
        client = ScriptClient(submit_answer(finding()),
                              submit_answer(finding(result="insufficient", evidence=[])))
        result = self.run_review(client, objects=[obj])
        self.assertTrue(result["complete"])
        submitted = json.loads(client.messages[0][1]["content"])["objects"][0]
        self.assertEqual(submitted["content"], original["content"])
        self.assertEqual(submitted["revision"], "hash-1")
        self.assertEqual(submitted["prior_findings"][0]["revision"], "previous-hash")
        self.assertEqual(submitted["prior_findings"][0]["reason"], prior["reason"])
        self.assertEqual(submitted["prior_findings"][0]["evidence"], prior["evidence"])
        self.assertEqual(submitted["prior_findings"][0]["details"], {"boundary": "Доставка не наблюдалась."})
        self.assertNotIn("PRIOR_PRIVATE_REASONING", json.dumps(submitted))
        self.assertNotIn("NESTED_PRIVATE_REASONING", json.dumps(submitted))
        self.assertEqual(result["reviewer_reads"], [])
        self.assertFalse(json.loads(client.messages[1][-1]["content"])["ok"])
        self.assertEqual(obj, original)

    def test_no_invented_citation_is_accepted(self):
        check = finding(evidence=[{"id": "evidence-1", "quote": "2: transport.guarantees_delivery(report)"}])
        result = self.run_review(ScriptClient(read_answer("evidence-1"), submit_answer(check)), max_steps=2)
        self.assertFalse(result["complete"])

    def test_empty_and_invalid_packets_do_not_call_model(self):
        client = ScriptClient()
        self.assertTrue(self.run_review(client, objects=[])["complete"])
        result = self.run_review(client, objects=[object_fixture(), object_fixture()])
        self.assertFalse(result["complete"])
        self.assertTrue(result["notes"])
        huge = object_fixture()
        huge["content"] = "а" * 80_001
        self.assertFalse(self.run_review(client, objects=[huge])["complete"])
        invalid_prior = {**object_fixture(), "prior_findings": "not a list"}
        self.assertFalse(self.run_review(client, objects=[invalid_prior])["complete"])
        self.assertEqual(client.messages, [])

    def test_exhausted_budget_never_calls_model(self):
        for kwargs in ({"max_steps": 0}, {"max_seconds": 0}, {"max_seconds": -1}, {"max_seconds": float("nan")}):
            with self.subTest(**kwargs):
                client = ScriptClient()
                result = self.run_review(client, **kwargs)
                self.assertFalse(result["complete"])
                self.assertEqual(result["steps"], 0)
                self.assertEqual(client.messages, [])

    def test_slow_provider_cannot_accept_findings_after_deadline(self):
        release, finished = Event(), Event()

        def slow(messages):
            release.wait(2)
            finished.set()
            return submit_answer(finding(result="insufficient", evidence=[]))

        client = ScriptClient(slow)
        started = time.monotonic()
        try:
            result = self.run_review(client, max_seconds=0.08)
            self.assertLess(time.monotonic() - started, 1)
            self.assertFalse(result["complete"])
            self.assertEqual(result["findings"], [])
            self.assertIn("запоздалый ответ", str(result["notes"]))
        finally:
            release.set()
            finished.wait(1)
        self.assertEqual(result["findings"], [])

    def test_tool_budget_denies_overflow_instead_of_executing_unbounded_batch(self):
        calls = [tool("search_passport_evidence", {"query": ""}, f"call-{i}") for i in range(MAX_TOOL_CALLS)]
        calls.append(tool("submit_checks", {"checks": [finding(result="insufficient", evidence=[])]}, "overflow"))
        result = self.run_review(ScriptClient(answer(*calls)), max_steps=1)
        self.assertFalse(result["complete"])
        self.assertEqual(result["findings"], [])

    def test_malformed_calls_are_observations_and_reviewer_cannot_mutate_passport(self):
        wrong = tool("submit_checks")
        wrong["function"]["arguments"] = "[1,2]"
        client = ScriptClient(answer(tool("submit_node", {"id": "node-1"}), wrong),
                              submit_answer(finding(result="insufficient", evidence=[])))
        result = self.run_review(client)
        self.assertTrue(result["complete"])
        results = [json.loads(m["content"]) for m in client.messages[1] if m["role"] == "tool"]
        self.assertEqual(len(results), 2)
        self.assertTrue(all(not r["ok"] for r in results))

    def test_three_plain_text_answers_do_not_complete_review(self):
        client = ScriptClient(*(ChatResult(text="Всё правильно", usage={}) for _ in range(3)))
        result = self.run_review(client)
        self.assertFalse(result["complete"])
        self.assertEqual(result["steps"], 3)

    def test_complete_only_fixture_does_not_trigger_real_client(self):
        class CompleteOnly:
            def complete(self, *args, **kwargs):
                raise AssertionError("complete must not replace a tool review")

        result = self.run_review(CompleteOnly())
        self.assertFalse(result["complete"])
        self.assertIn("не поддерживает chat", str(result["notes"]))

    def test_broker_discovery_requires_reviewer_read_and_does_not_mark_researcher_read(self):
        class Tree:
            files = ["other.py"]

            def read(self, path):
                return "def deliver(report):\n    transport.send(report)\n"

        corpus = corpus_fixture()
        broker = EvidenceBroker(Tree(), SimpleNamespace(facts=[]), corpus)
        extended_id = "evidence-4"
        check = finding(evidence=[{"id": extended_id, "quote": "transport.send(report)"}])
        client = ScriptClient(answer(tool("request_passport_evidence", {"kind": "file", "path": "other.py", "line": 1})),
                              submit_answer(check), read_answer(extended_id), submit_answer(check))
        result = self.run_review(client, corpus=corpus, broker=broker)
        self.assertTrue(result["complete"])
        self.assertIn(extended_id, corpus.records)
        self.assertEqual(corpus.shown, {})
        self.assertEqual(result["reviewer_reads"], [extended_id])
        rejection = json.loads(client.messages[2][-1]["content"])
        self.assertFalse(rejection["ok"])

    def test_broker_refusal_is_observation_without_invented_evidence(self):
        class Tree:
            files = [".env"]

            def read(self, path):
                raise AssertionError("Secret file must not be read")

        corpus = corpus_fixture()
        broker = EvidenceBroker(Tree(), SimpleNamespace(facts=[]), corpus)
        client = ScriptClient(answer(tool("request_passport_evidence", {"kind": "file", "path": ".env", "line": 1})),
                              submit_answer(finding(result="insufficient", evidence=[])))
        result = self.run_review(client, corpus=corpus, broker=broker)
        self.assertTrue(result["complete"])
        self.assertEqual(result["findings"][0]["result"], "insufficient")
        self.assertFalse(json.loads(client.messages[1][-1]["content"])["ok"])
        self.assertEqual(result["reviewer_reads"], [])

    def test_broker_exception_is_returned_to_model_without_leaking_error_text(self):
        class BrokenBroker:
            def request(self, args):
                raise RuntimeError("SECRET_ERROR_TEXT")

        client = ScriptClient(answer(tool("request_passport_evidence", {"kind": "search", "query": "send"})),
                              submit_answer(finding(result="insufficient", evidence=[])))
        result = self.run_review(client, broker=BrokenBroker())
        self.assertTrue(result["complete"])
        observation = client.messages[1][-1]["content"]
        self.assertNotIn("SECRET_ERROR_TEXT", observation)
        self.assertIn("RuntimeError", observation)

    def test_native_client_uses_remaining_timeout_without_changing_shared_client(self):
        options = []
        transport = SimpleNamespace()
        transport.chat = SimpleNamespace(completions=SimpleNamespace(create=lambda **kwargs: "provider-result"))

        def with_options(**kwargs):
            options.append(kwargs)
            return transport

        transport.with_options = with_options
        original = object.__new__(ChatClient)
        original.__dict__.update(spec=SPEC, timeout=180, _client=transport, use_cache=False, cache_dir=None)
        wrapper = _review_client(original, SPEC, time.monotonic() + 5)
        while hasattr(wrapper, "delegate"):
            wrapper = wrapper.delegate
        self.assertEqual(wrapper._create({"model": "fixture"}), "provider-result")
        self.assertEqual(options[0]["max_retries"], 0)
        self.assertGreater(options[0]["timeout"], 0)
        self.assertLessEqual(options[0]["timeout"], 5)
        self.assertEqual(original.timeout, 180)
        self.assertNotIn("_review_deadline", original.__dict__)

    def test_injected_request_transport_is_not_replaced_with_a_network_call(self):
        original = object.__new__(ChatClient)
        original.__dict__.update(spec=SPEC, timeout=180, _client=object(), use_cache=False, cache_dir=None)
        with patch.object(ChatClient, "_create", return_value="scripted-provider") as custom:
            wrapper = _review_client(original, SPEC, time.monotonic() + 5)
            while hasattr(wrapper, "delegate"):
                wrapper = wrapper.delegate
            self.assertEqual(wrapper._create({"model": "fixture"}), "scripted-provider")
            custom.assert_called_once_with({"model": "fixture"})
        self.assertIs(wrapper, original)

    def test_nested_review_uses_its_own_shorter_deadline(self):
        original = object.__new__(ChatClient)
        original.__dict__.update(spec=SPEC, timeout=180, _client=object(), use_cache=False, cache_dir=None)
        outer_deadline = time.monotonic() + 30
        outer = _review_client(original, SPEC, outer_deadline)
        inner_deadline = time.monotonic() + 5
        inner = _review_client(outer, SPEC, inner_deadline)
        while hasattr(outer, "delegate"):
            outer = outer.delegate
        while hasattr(inner, "delegate"):
            inner = inner.delegate
        self.assertEqual(outer._review_deadline, outer_deadline)
        self.assertEqual(inner._review_deadline, inner_deadline)
        self.assertIsNot(outer, inner)

    def test_transport_patched_before_reviewer_import_is_preserved(self):
        import importlib
        import pko.progress.passport_reviewer as reviewer

        original = object.__new__(ChatClient)
        original.__dict__.update(spec=SPEC, timeout=180, _client=object(), use_cache=False, cache_dir=None)
        calls = []

        def scripted_create(client, payload, extra_body=None):
            calls.append(payload)
            return "late-import-scripted-provider"

        try:
            with patch.object(ChatClient, "_create", new=scripted_create):
                # The production pipeline imports the reviewer only after the
                # fixture has replaced ChatClient._create with a plain function.
                importlib.reload(reviewer)
                wrapper = reviewer._review_client(original, SPEC, time.monotonic() + 5)
                while hasattr(wrapper, "delegate"):
                    wrapper = wrapper.delegate
                self.assertIs(wrapper, original)
                self.assertEqual(wrapper._create({"model": "fixture"}), "late-import-scripted-provider")
                self.assertEqual(calls, [{"model": "fixture"}])
        finally:
            importlib.reload(reviewer)

    def test_every_tool_is_dispatched_through_tracing(self):
        import pko.progress.passport_reviewer as reviewer

        calls = []
        real_trace = reviewer.trace_tool_call

        def observed(handler, state, call):
            calls.append(call["function"]["name"])
            return real_trace(handler, state, call)

        with patch.object(reviewer, "trace_tool_call", side_effect=observed):
            result = self.run_review(ScriptClient(read_answer("evidence-1"), submit_answer(finding())))
        self.assertTrue(result["complete"])
        self.assertEqual(calls, ["read_passport_evidence", "submit_checks"])

    def test_nested_review_gets_separate_session_and_step_trace_context(self):
        try:
            from opentelemetry.sdk.trace import TracerProvider
            from opentelemetry.sdk.trace.export import SimpleSpanProcessor
            from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
        except ImportError:
            self.skipTest("Optional tracing SDK unavailable")
        from pko.llm import tracing

        exporter = InMemorySpanExporter()
        provider = TracerProvider(span_limits=tracing.span_limits())
        provider.add_span_processor(SimpleSpanProcessor(exporter))
        self.addCleanup(provider.shutdown)
        with patch.object(tracing, "_tracer", provider.get_tracer("review-test")):
            with tracing.trace_span("passport_session"):
                with tracing.trace_span("passport.step", step=1):
                    result = self.run_review(ScriptClient(read_answer("evidence-1"), submit_answer(finding())))
        self.assertTrue(result["complete"])
        spans = exporter.get_finished_spans()
        self.assertEqual(len({span.context.trace_id for span in spans}), 1)
        review = next(span for span in spans if span.attributes.get("pko.span") == "passport_review_session")
        self.assertEqual(review.attributes["openinference.span.kind"], "AGENT")
        steps = [span for span in spans if span.parent and span.parent.span_id == review.context.span_id]
        self.assertEqual(len(steps), 2)
        for step in steps:
            self.assertTrue(step.name.startswith("шаг "))
            children = [span for span in spans if span.parent and span.parent.span_id == step.context.span_id]
            self.assertEqual(sorted(span.attributes["openinference.span.kind"] for span in children), ["LLM", "TOOL"])


if __name__ == "__main__":
    unittest.main()
