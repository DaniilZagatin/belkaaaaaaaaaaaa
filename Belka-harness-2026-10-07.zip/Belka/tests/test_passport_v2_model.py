"""Version-two passport identities and local state stay separate from criteria."""
import unittest

import test_passport_gate as fixtures
from pko.progress.passport_gate import normalize_passport
from pko.progress.schema import (
    ConnectivityReview, Handoff, HandoffCheck, Scenario,
    passport_code_state, passport_completion_state, passport_node_state,
    passport_reachability,
)
from pko.render.passport_map import build_passport_map


def v2_data():
    data = fixtures._valid()
    data["schema_version"] = 2
    data["research"] = {"claims": [{"id": "claim-3", "nodes": ["operation-3"]}]}
    data["completion"] = {"state": "incomplete", "blockers": [{"node": "operation-3"}]}
    data["source_metadata"] = {"archive_sha256": "original-archive-hash"}
    return data


def execution(outcome="Подготовлен результат расчёта", reachability="unknown"):
    return {"execution": {"reachability": reachability, "outcome": outcome,
            "entrypoint": "Точка входа требует отдельной проверки", "conditions": "Передан запрос",
            "limits": "Доставка результата во внешней системе не проверена",
            "evidence": [{"id": "evidence-7", "quote": "return prepare_result()"}]},
            "fields": {fid: {"support": "code", "mechanism": "runtime", "evidence": [
                {"id": "evidence-7", "quote": "return prepare_result()"}]} for fid in ("4.5.4", "4.5.5")}}


class PassportV2ModelTests(unittest.TestCase):
    def build(self, data, scenarios=(), partial=False):
        model = fixtures.PassportMapTest()._model(normalize_passport(data))
        if partial:
            model.verdicts[0].criteria[1].status = "partial"
        if scenarios:
            model.connectivity = ConnectivityReview(scenarios=list(scenarios))
        return build_passport_map(model)

    def test_reorder_and_move_preserve_ids_references_and_object_ids(self):
        data = normalize_passport(v2_data())
        original_ids = set(data["nodes"])
        original_objects = {nid: node["object-id"] for nid, node in data["nodes"].items()}
        root = data["tree"][0]
        first, second = root["children"][:2]
        moved = second["children"].pop(0)
        first["children"].insert(0, moved)
        data["nodes"][moved["id"]]["parents"] = [first["id"]]
        root["children"][:2] = [second, first]
        result = normalize_passport(data)
        self.assertEqual(set(result["nodes"]), original_ids)
        self.assertEqual({nid: node["object-id"] for nid, node in result["nodes"].items()}, original_objects)
        self.assertEqual(result["nodes"]["bbb-3"]["parents"], ["process-1"])
        self.assertEqual(result["nodes"]["operation-3"]["parents"], ["bbb-3"])
        self.assertEqual(result["research"], data["research"])
        self.assertEqual(result["completion"], data["completion"])
        self.assertEqual(result["registry"][1]["id"], "process-2")

    def test_retirement_does_not_reuse_ids_or_rewrite_research_history(self):
        data = normalize_passport(v2_data())
        data["tree"][0]["children"][0]["children"].pop(1)
        data["retired_nodes"] = {nid: data["nodes"].pop(nid) for nid in ("bbb-2", "operation-2")}
        result = normalize_passport(data)
        self.assertNotIn("operation-2", result["nodes"])
        self.assertIn("operation-3", result["nodes"])
        self.assertEqual(result["retired_nodes"], data["retired_nodes"])
        self.assertEqual(result["research"], data["research"])
        self.assertEqual(result["source_metadata"], data["source_metadata"])

    def test_risk_ids_and_nested_provenance_survive_reorder(self):
        data = v2_data()
        data["risks"] = [{"id": "risk-12", "title": "Сбой доставки", "scope": "local", "confidence": "inferred",
                          "primary_node": "operation-3", "linked_nodes": ["operation-3"],
                          "hypothesis_id": "hypothesis-9", "source_metadata": {"claim": "claim-3"},
                          "evidence": [{"where": "source.py:3", "basis": "Вызван транспорт", "id": "evidence-7"}]},
                         {"id": "risk-4", "title": "Отказ сервиса", "scope": "local", "confidence": "inferred",
                          "primary_node": "operation-1", "linked_nodes": ["operation-1"]}]
        first = normalize_passport(data)
        first["risks"].reverse()
        result = normalize_passport(first)
        self.assertEqual([row["id"] for row in result["risks"]], ["risk-4", "risk-12"])
        risk = result["risks"][1]
        self.assertEqual(risk["hypothesis_id"], "hypothesis-9")
        self.assertEqual(risk["source_metadata"], {"claim": "claim-3"})
        self.assertEqual(risk["evidence"][0]["id"], "evidence-7")

    def test_new_risk_does_not_take_existing_later_id(self):
        data = v2_data()
        data["risks"] = [{"title": "Новый риск", "scope": "local", "confidence": "inferred"},
                         {"id": "risk-1", "title": "Существующий риск", "scope": "local", "confidence": "inferred"}]
        risks = normalize_passport(data)["risks"]
        self.assertEqual([row["id"] for row in risks], ["risk-2", "risk-1"])

    def test_local_implemented_ignores_wide_partial_criterion(self):
        data = v2_data()
        node = data["nodes"]["operation-1"]
        node.update(bullets=["Показан оффер."], basis="Большой сценарий частично реализован: иной шаг отключён",
                    fact_check=execution())
        result = self.build(data, partial=True)
        item = next(n for n in result["nodes"] if n["id"] == "operation-1")
        self.assertEqual(item["implementation_status"], "implemented")
        self.assertEqual(item["assessment_inputs"]["criteria"], "Реализован частично")
        self.assertEqual(item["assessment_source"], "local")
        self.assertEqual(item["readiness"], 25)
        self.assertEqual(passport_node_state("unknown", "partial", contract_version=2), "unknown")
        self.assertEqual(passport_node_state("implemented", "unknown", contract_version=2), "implemented")

    def test_known_disabled_effect_remains_absent_with_done_criterion(self):
        data = v2_data()
        node = data["nodes"]["operation-1"]
        node.update(bullets=["Подобран продукт."], fact_check=execution(), fields={
            "4.5.4": fixtures._f("Основной вызов закомментирован и заменён нулём.", fixtures.EST),
            "4.5.5": fixtures._f("Должны возвращаться данные клиента.", fixtures.EST)})
        item = next(n for n in self.build(data)["nodes"] if n["id"] == "operation-1")
        self.assertEqual(item["implementation_status"], "not_implemented")

    def test_unknown_reachability_and_confirmed_disconnection_are_separate(self):
        data = v2_data()
        data["nodes"]["operation-1"]["fact_check"] = execution(reachability="unknown")
        unknown = next(n for n in self.build(data)["nodes"] if n["id"] == "operation-1")
        data["nodes"]["operation-1"]["fact_check"] = execution(reachability="disconnected")
        disconnected = next(n for n in self.build(data)["nodes"] if n["id"] == "operation-1")
        self.assertEqual(unknown["implementation_status"], "implemented")
        self.assertEqual(disconnected["implementation_status"], "implemented")
        self.assertFalse(unknown["reachability_confirmed"])
        self.assertTrue(disconnected["reachability_confirmed"])
        self.assertNotEqual(unknown["reachability_label"], disconnected["reachability_label"])
        self.assertEqual(disconnected["mark"], "")
        fact_check = execution(reachability="disconnected")
        fact_check["execution"]["evidence"] = []
        self.assertEqual(passport_reachability({"fact_check": fact_check})["status"], "unknown")

    def test_unknown_execution_does_not_erase_grounded_fields(self):
        raw = {"agent_contract": 2, "fact_check": execution("Результат не установлен"), "fields": {
            "4.5.4": fixtures._f("Подготовлен расчёт по входным данным", fixtures.EST),
            "4.5.5": fixtures._f("Входные данные и рассчитанный результат", fixtures.EST)}}
        self.assertEqual(passport_code_state(raw, "operation", False)[0], "implemented")

    def test_intent_and_schema_fields_do_not_establish_local_implementation(self):
        for mechanism in ("intent", "prompt", "schema", "unknown"):
            with self.subTest(mechanism=mechanism):
                audit = execution("Результат не установлен")
                for row in audit["fields"].values():
                    row.update(support="inference", mechanism=mechanism)
                raw = {"agent_contract": 2, "fact_check": audit, "fields": {
                    "4.5.4": fixtures._f("Ожидается сохранённый результат", "Выведено: намерение автора"),
                    "4.5.5": fixtures._f("Ожидается запрос и результат", "Выведено: намерение автора")}}
                self.assertEqual(passport_code_state(raw, "operation", False)[0], "unknown")

    def test_process_can_belong_to_two_scenarios_without_losing_traces(self):
        data = v2_data()
        data["nodes"]["process-1"]["scenarios"] = ["scenario-1", "scenario-2", "scenario-1"]
        data["nodes"]["process-2"]["scenarios"] = ["scenario-2"]
        data["nodes"]["operation-1"]["scenario_steps"] = [
            {"scenario": sid, "step": 0} for sid in ("scenario-1", "scenario-2")]
        data["nodes"]["operation-2"]["scenario_steps"] = [
            {"scenario": sid, "step": 1} for sid in ("scenario-1", "scenario-2")]
        scenarios = [Scenario(id=f"scenario-{i}", title=f"Сценарий {i}", entry="Пришёл запрос", outcome="Получен результат",
                             steps=["Вход", "Выход"], handoffs=[Handoff(step=0, checks=[
                                 HandoffCheck(check="reachability", result="unknown", note="Вход требует проверки")])])
                     for i in (1, 2)]
        result = self.build(data, scenarios)
        node = next(n for n in result["nodes"] if n["id"] == "process-1")
        self.assertEqual(node["scenarios"], ["scenario-1", "scenario-2"])
        self.assertEqual(node["scenario"], "scenario-1")
        self.assertEqual([row["id"] for row in node["scenario_contexts"]], ["scenario-1", "scenario-2"])
        self.assertEqual(result["paths"][1]["processes"], ["process-1", "process-2"])
        self.assertTrue(all(row["steps_mapped"] == 2 for row in result["paths"]))
        self.assertEqual(len(result["handoffs"]), 2)
        self.assertEqual(result["research"], data["research"])
        self.assertEqual(result["completion"], data["completion"])

    def test_one_planned_process_linked_to_two_scenarios_has_two_contextual_breaks(self):
        data = v2_data()
        data["nodes"]["process-1"].update(planned=True, scenarios=["scenario-1", "scenario-2"])
        scenarios = [Scenario(id=f"scenario-{i}", title=f"Сценарий {i}", entry="Запрос", outcome="Результат", steps=["Обещанный шаг"])
                     for i in (1, 2)]
        result = self.build(data, scenarios)
        breaks = [row for row in result["breaks"] if row.get("node") == "process-1"]
        self.assertEqual({row["scenario"] for row in breaks}, {"scenario-1", "scenario-2"})

    def test_empty_v2_map_preserves_completion_and_source_metadata(self):
        data = v2_data()
        data.update(tree=[], nodes={})
        result = self.build(data)
        self.assertEqual(result["nodes"], [])
        self.assertEqual(result["schema_version"], 2)
        for key in ("research", "completion", "source_metadata"):
            self.assertEqual(result[key], data[key])

    def test_legacy_renumbering_and_criterion_combination_remain_unchanged(self):
        data = fixtures._valid()
        root = data["tree"][0]
        root["children"][:2] = list(reversed(root["children"][:2]))
        result = normalize_passport(data)
        self.assertEqual(result["nodes"]["process-1"]["name"], data["nodes"]["process-2"]["name"])
        self.assertEqual(passport_node_state("implemented", "partial"), "partial")
        self.assertNotIn("agent_contract", result["nodes"]["process-1"])

    def test_completion_is_not_inferred_from_clean_exit_or_empty_blockers(self):
        self.assertEqual(passport_completion_state([], "finished", finished=True), "complete")
        self.assertEqual(passport_completion_state(["unread control"], "finished", finished=True), "incomplete")
        self.assertEqual(passport_completion_state([], "step_limit"), "incomplete")
        self.assertEqual(passport_completion_state([], "error", finished=True), "failed")
        self.assertEqual(passport_completion_state([], "exception"), "failed")


if __name__ == "__main__":
    unittest.main()
