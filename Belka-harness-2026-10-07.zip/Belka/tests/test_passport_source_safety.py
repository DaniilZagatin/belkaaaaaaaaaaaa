"""Preparation obeys the same snapshot boundary as subsequent broker reads."""
import json
import unittest
from unittest.mock import patch

from pko.extractors.base import Fact
from pko.progress.passport_evidence import build_corpus
from pko.progress.passport_facts import capabilities, exposure_facts, neighbour_anchors, route_usage
from test_passport_broker import MemoryTree


UNSAFE = (".env.py", "config/.env/private.py", "private.key/code.py", "cert.pem",
          "../outside.py", "/absolute.py", "C:/outside.py", "dir\\outside.py",
          "node_modules/pkg/index.py", "dir/../outside.py", "dir/\tname.py")
SOURCE = "import os\nSERVICE_HOST = os.getenv('SERVICE_HOST', 'private.invalid')\ndef run_job(): return True"


class PassportSourceSafetyTests(unittest.TestCase):
    def test_initial_and_extra_corpus_never_read_forbidden_or_unlisted_paths(self):
        for extra_mode in (False, True):
            with self.subTest(extra_mode=extra_mode):
                tree = MemoryTree({**{path: SOURCE for path in UNSAFE}, "safe.py": "run_public_service()"})
                requested = {*UNSAFE, "safe.py", "unlisted.py"}
                corpus = build_corpus(tree, set() if extra_mode else requested, [], "",
                    extra={path: ("entrypoint", {1}) for path in requested} if extra_mode else None)
                self.assertEqual(tree.reads, ["safe.py"])
                self.assertEqual(set(corpus.included), {"safe.py"})
                self.assertNotIn("private.invalid", json.dumps(corpus.records))
                self.assertEqual(len(corpus.omitted), len(UNSAFE) + 1)

    def test_single_unreadable_source_preserves_safe_materials_without_error_content(self):
        tree = MemoryTree({"bad.py": RuntimeError("password=fixture-private /host/private/location"),
                           "good.py": "run_public_service()"})
        corpus = build_corpus(tree, set(tree.files), [], "")
        self.assertEqual(corpus.index("run_public_service")["total"], 1)
        self.assertTrue(any("bad.py" in row for row in corpus.omitted))
        self.assertNotIn("fixture-private", json.dumps(corpus.manifest()))
        self.assertNotIn("/host/private/location", json.dumps(corpus.manifest()))

    def test_rejected_paths_do_not_consume_the_safe_file_budget(self):
        tree = MemoryTree({".env/private.py": SOURCE, "good.py": "run_public_service()"})
        with patch("pko.progress.passport_evidence.MAX_FILES", 1):
            corpus = build_corpus(tree, set(tree.files), [], "")
        self.assertEqual(tree.reads, ["good.py"])
        self.assertEqual(corpus.index("run_public_service")["total"], 1)

    def test_fact_preparation_excludes_forbidden_paths_before_any_read(self):
        tree = MemoryTree({**{path: SOURCE for path in UNSAFE}, "safe.py": SOURCE,
                           ".env/client.ts": "fetch('/private')", "client.ts": "fetch('/public')"})
        facts = [Fact("ROUTE", "GET /private", {"path": "/private", "method": "GET"}, path, 3)
                 for path in (*UNSAFE, "unlisted.py")]
        facts.append(Fact("ROUTE", "GET /public", {"path": "/public", "method": "GET"}, "safe.py", 3))
        facts.extend(Fact("LLM_CALL", "external", None, path, 1) for path in UNSAFE)
        usage = route_usage(tree, facts)
        caps, total = capabilities(tree, facts, limit=None)
        exposures = exposure_facts(tree, facts)
        self.assertEqual(total, 1)
        self.assertEqual([cap.path for cap in caps], ["safe.py"])
        self.assertEqual([route.path for route in usage.routes], ["/public"])
        self.assertTrue(usage.routes[0].called)
        self.assertEqual(usage.frontend_files, 1)
        self.assertEqual({path for row in exposures for path, _ in row["anchors"]}, {"safe.py"})
        self.assertTrue(set(tree.reads) <= {"safe.py", "client.ts"}, tree.reads)

    def test_neighbour_expansion_never_introduces_a_forbidden_source(self):
        facts = [Fact("FUNCTION", "private_job", None, ".env/private.py", 1),
                 Fact("CALLS", "private_job", {"caller": "public_job", "callee": "private_job"}, "safe.py", 2),
                 Fact("FUNCTION", "public_job", None, "safe.py", 1),
                 Fact("CALLS", "public_job", {"caller": "private_job", "callee": "public_job"}, "../outside.py", 2)]
        self.assertEqual(neighbour_anchors(facts, {"safe.py"}), {})


if __name__ == "__main__":
    unittest.main()
