"""Large connection reviews stay reviewable without losing graph dependencies."""
from copy import deepcopy
from itertools import combinations, islice
import unittest

from pko.progress.passport_connections import submit_connection_review, sync_connection_objects
from pko.progress.passport_gate import PassportCheck, check_relation
from pko.progress.passport_reviewer import _prepare_objects
from test_passport_code_reconstruction import code_session, connection_args


OBJECT_ID = "connection-review:process-1"
BASIS = "Наблюдаемый переход передаёт подготовленный результат следующей операции. " * 7


def large_graph():
    state = code_session()
    ids = [f"operation-{n}" for n in range(10, 90)]
    for nid in ids:
        node = deepcopy(state.nodes["operation-1"])
        node.id = nid
        node.name = "Подготовка промежуточного результата " + nid
        state.nodes[nid] = node
        state.nodes["bbb-1"].children.append(nid)
    state.relations = [{"from": src, "to": dst, "kind": "precedes", "basis": BASIS}
                       for src, dst in islice(combinations(ids, 2), 200)]
    return state


class ConnectionReviewBoundsTests(unittest.TestCase):
    def test_large_valid_graph_fits_independent_reviewer_and_discloses_preview(self):
        state = large_graph()
        gate, seen = PassportCheck(), set()
        for row in state.relations:
            check_relation(gate, row, set(state.nodes), seen)
        self.assertFalse(gate.errors, gate.errors)
        self.assertNotIn("отклонён", submit_connection_review(state, connection_args()))
        sync_connection_objects(state)

        obj = state.workspace.objects[OBJECT_ID]
        prepared, errors = _prepare_objects([obj])
        self.assertEqual(errors, [], errors)
        self.assertIn(OBJECT_ID, prepared)
        content = obj["content"]
        scope = content["context_scope"]
        self.assertEqual(scope["kind"], "bounded_preview")
        self.assertEqual((scope["nodes_total"], scope["nodes_shown"]), (87, 80))
        self.assertEqual((scope["relations_total"], scope["relations_shown"]), (200, 120))
        self.assertTrue(all(set(row) == {"from", "to", "kind"} for row in content["graph_relations"]))
        self.assertTrue(all(row["basis"] == BASIS for row in state.relations),
                        "The full accepted graph retains its explanations.")

    def test_change_outside_preview_invalidates_existing_review(self):
        state = large_graph()
        self.assertNotIn("отклонён", submit_connection_review(state, connection_args()))
        sync_connection_objects(state)
        before = deepcopy(state.workspace.objects[OBJECT_ID])
        state.workspace.reviews[OBJECT_ID] = {"revision": before["revision"], "result": "supported"}
        visible = {(r["from"], r["to"], r["kind"]) for r in before["content"]["graph_relations"]}
        omitted = next(r for r in state.relations if (r["from"], r["to"], r["kind"]) not in visible)
        omitted["basis"] += " Уточнено условие передачи результата."
        sync_connection_objects(state)
        after = state.workspace.objects[OBJECT_ID]

        self.assertEqual(before["content"]["graph_relations"], after["content"]["graph_relations"])
        self.assertNotEqual(before["content"]["graph_revision"], after["content"]["graph_revision"])
        self.assertNotEqual(before["revision"], after["revision"])
        self.assertNotIn(OBJECT_ID, state.workspace.reviews)
        self.assertIn(OBJECT_ID, state.workspace.pending_reviews())


if __name__ == "__main__":
    unittest.main()
