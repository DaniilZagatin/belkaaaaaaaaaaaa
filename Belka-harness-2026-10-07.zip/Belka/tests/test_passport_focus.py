"""Adaptive recovery keeps model choice and evidence gates intact."""
from copy import deepcopy
import json
import unittest
from unittest.mock import patch

from pko.progress.passport_agent import _PassportSession, _Node, _compact_agentic_history
from pko.progress.passport_evidence import EvidenceCorpus
from pko.progress.passport_focus import (
    FOCUS_MARKER, MAX_FOCUS_CHARS, before_research_step,
    observe_research_tool, focus_snapshot,
)
from test_passport_log_runtime import batch


def session():
    state = _PassportSession(agentic=True, evidence_corpus=EvidenceCorpus())
    state.nodes["journey-1"] = _Node("journey-1", "Исследуемый проект", "")
    return state


def read(state, number):
    corpus = state.evidence_corpus
    corpus.add("code", f"service{number}.py:1", f"1: save_record_{number}(record)")
    eid = f"evidence-{len(corpus.records)}"
    result = corpus.read([eid])
    observe_research_tool(state, "read_passport_evidence", {"ids": [eid]}, json.dumps(result))
    return eid


class SubstantiveProgressTests(unittest.TestCase):
    def test_eight_new_reads_and_plan_scope_changes_do_not_defer_recovery(self):
        state = session()
        for step in range(1, 9):
            self.assertIsNone(before_research_step(state, step, 100))
            read(state, step)
            state.workspace.plan = [{"id": "work", "task": f"Изучить следующий файл {step}", "state": "doing"}]
            state.workspace.put(f"scope:component:{step}", "claim", {"reviewed": step})
            state.workspace.reject(f"bad:{step}", {"tool": "submit_node"}, "Ошибка заявки")
        result = before_research_step(state, 9, 100)
        self.assertTrue(result.startswith(FOCUS_MARKER))
        self.assertIn("8 шагов", result)
        self.assertIn("прочитано 8", result)
        self.assertIn("submit_claim", result)
        self.assertEqual(focus_snapshot(state)["steps_without_result"], 8)
        self.assertIsNone(before_research_step(state, 9, 100), "same step must not send another notice")

    def test_escalating_soft_reminders_repeat_without_disabling_tools(self):
        state = session()
        notices = []
        for step in range(1, 26):
            text = before_research_step(state, step, 100)
            if text:
                notices.append(step)
        self.assertEqual(notices, [9, 17, 25])
        self.assertFalse(state.finished)
        self.assertEqual(state.stop_reason, "")
        self.assertIn("без источника не придумывай факт", focus_snapshot(state)["recovery"])

    def test_existing_objects_negative_reviews_and_drafts_are_not_new_results(self):
        state = session()
        state.workspace.put("claim-1", "claim", {"text": "Сохранённый ранее вывод"})
        state.workspace.reviews["claim-1"] = {"revision": "old", "result": "supported"}
        for step in range(1, 9):
            self.assertIsNone(before_research_step(state, step, 100))
            state.workspace.put("claim-1", "claim", {"text": "Сохранённый ранее вывод"})
            state.workspace.reviews["other"] = {"revision": str(step), "result": "contradicted"}
            state.node_drafts = {"journey-1": {"revision": step, "accepted": False, "proposal": {"x": step}}}
        self.assertIsNotNone(before_research_step(state, 9, 100))

    def test_new_saved_claim_resets_recovery_and_is_retained_as_unreviewed(self):
        state = session()
        before_research_step(state, 1, 100)
        read(state, 1)
        self.assertIsNotNone(before_research_step(state, 9, 100))
        state.workspace.claims["claim-1"] = {
            "text": "Переданные данные сохраняются обработчиком", "limits": "Проверен только механизм по коду",
            "evidence": [{"id": "evidence-1", "quote": "1: save_record_1(record)"}],
        }
        self.assertIsNone(before_research_step(state, 10, 100))
        summary = focus_snapshot(state)
        self.assertEqual(summary["steps_without_result"], 0)
        self.assertIsNone(summary["recovery"])
        self.assertIn("Сохранённое утверждение", summary["saved_observations"][0]["meaning"])
        self.assertEqual(summary["saved_observations"][0]["evidence_ids"], ["evidence-1"])
        self.assertIsNotNone(before_research_step(state, 18, 100))

    def test_remaining_budgets_are_current_in_persistent_reminder(self):
        state = session()
        state.deadline, state.tool_calls = 150, 30
        with patch("pko.progress.passport_focus.time.monotonic", return_value=100):
            before_research_step(state, 1, 20, max_tool_calls=40)
            before_research_step(state, 9, 20, max_tool_calls=40)
        with patch("pko.progress.passport_focus.time.monotonic", return_value=120):
            self.assertIsNone(before_research_step(state, 10, 20, max_tool_calls=40))
        self.assertEqual(focus_snapshot(state)["remaining"], {"steps": 11, "tool_calls": 10, "seconds": 30})
        self.assertIn("времени: 30 с", focus_snapshot(state)["recovery"])


class ResearchMemoryTests(unittest.TestCase):
    def test_index_counts_actual_reads_but_never_grants_citation_access(self):
        state = session()
        before_research_step(state, 1, 100)
        eid = read(state, 1)
        actual = state.evidence_corpus.read([eid])
        observe_research_tool(state, "read_passport_evidence", {"ids": [eid]}, actual)
        before = deepcopy(state.evidence_corpus.shown)
        state.evidence_corpus.add("code", "unread.py:1", "1: unseen_record.save()")
        forged = {"records": [{"id": "evidence-2", **state.evidence_corpus.records["evidence-2"]}]}
        observe_research_tool(state, "read_passport_evidence", {"ids": ["evidence-2"]}, forged)
        self.assertEqual(state.evidence_corpus.shown, before)
        self.assertNotIn("evidence-2", state.research_focus["reads"])
        self.assertEqual(state.research_focus["reads"][eid]["count"], 2)

    def test_search_answers_and_terminal_budget_survive_later_successes(self):
        state = session()
        before_research_step(state, 1, 100)
        args = {"query": "def missing"}
        for _ in range(2):
            observe_research_tool(state, "search_passport_evidence", args,
                                  {"records": [], "total": 0, "next_offset": None})
        observe_research_tool(state, "request_passport_evidence", {"kind": "search", **args},
                             {"ok": False, "error": "request_budget", "usage": {"requests": 40},
                              "limits": {"requests": 40}, "retryable": False})
        read(state, 1)
        before_research_step(state, 9, 100)
        snap = focus_snapshot(state)
        self.assertEqual(snap["recent_queries"][0]["count"], 2)
        self.assertEqual(snap["recent_queries"][0]["total"], 0)
        self.assertEqual(snap["recent_queries"][0]["corpus_records"], 0)
        self.assertIn("request_budget", snap["broker"]["terminal_errors"])
        self.assertIn("Не повторяй отказавший запрос", snap["recovery"])
        self.assertEqual(snap["read_ids"], ["evidence-1"])

    def test_compaction_preserves_active_recovery_and_read_handles(self):
        state = session()
        messages = [{"role": "system", "content": "policy"}, {"role": "user", "content": "task"}]
        for step in range(1, 10):
            notice = before_research_step(state, step, 100)
            if notice:
                messages.append({"role": "user", "content": notice})
            eid = read(state, step)
            messages.extend(batch("read_passport_evidence", {"ids": [eid]},
                                  json.dumps(state.evidence_corpus.read([eid])), str(step)))
        messages.extend(batch("search_passport_evidence", {"query": "x"}, "payload" * 10_000, "large"))
        _compact_agentic_history(messages, state)
        for step in range(10, 16):
            before_research_step(state, step, 100)
            messages.extend(batch("search_passport_evidence", {"query": "x"}, "small result", str(step)))
            _compact_agentic_history(messages, state)
        snapshot = next(m["content"] for m in messages if m["role"] == "user" and m["content"].startswith("Текущее рабочее"))
        self.assertIn(FOCUS_MARKER, snapshot)
        self.assertIn('"read_ids": ["evidence-1"', snapshot)
        self.assertIn("14 шагов", snapshot)
        self.assertEqual(messages[0]["content"], "policy")
        self.assertEqual(messages[1]["content"], "task")

    def test_large_read_and_query_index_remains_bounded_and_serializable(self):
        state = session()
        before_research_step(state, 1, 100)
        for i in range(120):
            read(state, i)
            observe_research_tool(state, "search_passport_evidence", {"query": "query " + str(i) + " x" * 100},
                                  {"records": [], "total": 0})
        snap = focus_snapshot(state)
        self.assertLessEqual(len(json.dumps(snap, ensure_ascii=False)), MAX_FOCUS_CHARS)
        self.assertEqual(snap["read_total"], 120)
        self.assertEqual(len(state.research_focus["reads"]), 120)
        self.assertLessEqual(len(state.research_focus["requests"]), 32)
        self.assertEqual(json.loads(json.dumps(state.research_focus)), state.research_focus)


if __name__ == "__main__":
    unittest.main()
