"""Build an sdist, install its wheel and render outside the source checkout.

Only local packaging tools are used: dependency resolution and indexes are
disabled. No target repository or language model is invoked.
"""
from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile


ROOT = Path(__file__).resolve().parents[1]
PROMPTS = (
    "agent_system.md", "critic_system.md", "coherence_system.md",
    "passport_system.md", "passport_agentic_system.md", "passport_code_system.md",
    "passport_reviewer_system.md", "risk_hypothesis_guide.md",
)


def _run(*args: str, cwd: Path) -> subprocess.CompletedProcess:
    env = {key: value for key, value in os.environ.items()
           if not key.startswith("PKO_") and key not in {"PYTHONPATH", "PYTHONHOME"}}
    env["PYTHONIOENCODING"] = "utf-8"
    result = subprocess.run(
        [sys.executable, "-I", *args], cwd=cwd, env=env,
        capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120,
    )
    if result.returncode:
        raise AssertionError(f"Packaging command failed ({result.returncode}): "
                             f"{args}\n{result.stdout[-6000:]}\n{result.stderr[-6000:]}")
    return result


class DistributionTests(unittest.TestCase):
    def test_sdist_wheel_is_self_contained_for_current_cli(self):
        # A curated source copy avoids packaging reports, environments or keys.
        with tempfile.TemporaryDirectory(prefix="pko-package-test-") as temporary:
            work = Path(temporary)
            source = work / "source"
            source.mkdir()
            for name in ("pyproject.toml", "setup.py", "MANIFEST.in", "README.md",
                         "passport-dpss-v3.html"):
                shutil.copy2(ROOT / name, source / name)
            for requirements in ROOT.glob("requirements*.txt"):
                shutil.copy2(requirements, source / requirements.name)
            shutil.copytree(
                ROOT / "backend" / "pko", source / "backend" / "pko",
                ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".env*", "*.key", "*.pem"),
            )
            sdist_dir, wheel_dir, target = (work / name for name in ("sdist", "wheels", "installed"))
            _run("setup.py", "sdist", "--dist-dir", str(sdist_dir), cwd=source)
            sdist, = sdist_dir.glob("*.tar.gz")
            _run("-m", "pip", "--isolated", "--no-cache-dir", "wheel", "--no-deps", "--no-index",
                 "--no-build-isolation", "--wheel-dir", str(wheel_dir), str(sdist), cwd=work)
            wheel, = wheel_dir.glob("*.whl")
            with zipfile.ZipFile(wheel) as archive:
                names = set(archive.namelist())
                self.assertEqual(archive.read("pko/render/passport-dpss-v3.html"),
                                 (ROOT / "passport-dpss-v3.html").read_bytes())
                required = {f"pko/progress/{name}" for name in PROMPTS} | {
                    "pko/progress/risk_patterns.json", "pko/initiatives/catalog.json",
                    "pko/render/dashboard_template.html",
                    *(f"pko/render/assets/dpss/SBSansDisplay-{weight}.woff2"
                      for weight in (400, 600, 700)),
                }
                self.assertFalse(required - names, required - names)
                self.assertFalse(any(Path(name).name.startswith(".env") or
                                     name.endswith((".pem", ".key")) for name in names))
            _run("-m", "pip", "--isolated", "--no-cache-dir", "install", "--no-deps", "--no-index",
                 "--target", str(target), str(wheel), cwd=work)

            # Third-party dependencies may come from a test --target directory;
            # never pass the checkout or its editable import hook to the worker.
            dependency_roots = set()
            for module in ("openai", "httpx", "dotenv"):
                spec = importlib.util.find_spec(module)
                self.assertIsNotNone(spec, f"Install requirements-test.txt: {module}")
                dependency_roots.add(str(Path(spec.origin).resolve().parents[1]))
            outside = work / "outside"
            outside.mkdir()
            (outside / "initiative.md").write_text(
                "Проект: Установка\n\n## Результат\n- Получить подтверждение\n", encoding="utf-8")
            bootstrap = (
                "import sys\n"
                f"sys.path[:0] = {json.dumps([str(target), *sorted(dependency_roots)])}\n"
                "import socket\n"
                "def no_network(*a, **kw): raise AssertionError('Network is forbidden')\n"
                "socket.socket.connect = no_network\n"
                "socket.create_connection = no_network\n"
                "import pko\n"
                f"assert pko.__file__.startswith({str(target)!r}), pko.__file__\n"
            )
            smoke = bootstrap + '''
from pathlib import Path
from pko.extractors.runner import Extraction
from pko.initiatives.catalog import all_initiatives
from pko.progress.plan_input import parse_plan_text
from pko.progress.risk_catalog import load_catalog
from pko.progress.schema import ProgressModel
from pko.render.client_journey_passport import _TEMPLATE_PATH, render_client_journey_passport
from pko.render.dashboard_html import render_dashboard_html
assert _TEMPLATE_PATH.parent == Path(pko.__file__).parent / 'render'
assert all_initiatives()
assert load_catalog()['patterns']
for path in (Path(pko.__file__).parent / 'progress').glob('*system.md'):
    assert path.read_text(encoding='utf-8').strip()
plan = parse_plan_text(Path('initiative.md').read_text(encoding='utf-8'))
model = ProgressModel(passport_data={'schema_version': 2, 'research_basis': 'code',
    'nodes': {}, 'tree': [], 'completion': {'state': 'incomplete', 'blockers': []}})
passport = render_client_journey_passport(model, plan, 'portable', Extraction(), 'abc123', 'main')
assert '<html' in passport.lower()
assert 'data:font/woff2;base64,' in passport
dashboard = render_dashboard_html({'meta': {}, 'readiness': 0, 'readiness_prod': 0,
    'items': [], 'summary': {}})
assert '<html' in dashboard.lower() and '/*__DATA__*/' not in dashboard
print('installed wheel resources and both reports: OK')
'''
            result = _run("-c", smoke, cwd=outside)
            self.assertIn("both reports: OK", result.stdout)
            for args in (["--help"], ["initiatives"], ["parse", "--journey-file", "initiative.md", "--json"]):
                with self.subTest(cli=args):
                    _run("-c", bootstrap + f"sys.argv = {['pko', *args]!r}\n"
                         "from pko.cli import run\nrun()\n", cwd=outside)


if __name__ == "__main__":
    unittest.main()
