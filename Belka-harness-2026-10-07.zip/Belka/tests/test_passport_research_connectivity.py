"""Research-cycle connectivity must preserve intent, provenance and revisions."""
from copy import deepcopy
from dataclasses import asdict
import json
from types import SimpleNamespace
import unittest

from pko.progress.passport_connectivity import (
    RESEARCH_CONNECTIVITY_SCHEMAS, connectivity_blockers, connectivity_review,
    handle_research_connectivity, research_connectivity_schemas, sync_connectivity_objects,
)
from pko.progress.passport_evidence import EvidenceCorpus
from pko.progress.passport_workspace import ResearchWorkspace
from pko.progress.schema import HANDOFF_CHECKS


BULLET = "Клиент запрашивает и получает сформированный отчёт."
SECOND_BULLET = "Клиент просматривает историю отправленных отчётов."
INTENT = BULLET + "\n" + SECOND_BULLET
CODE = "10: def send_report(report):\n11:     transport.send(report)\n12:     return report"


def session(*, research=True, basis="result_image"):
    corpus = EvidenceCorpus()
    corpus.add("intent", "Исходный образ результата", INTENT)
    corpus.add("code", "reports.py:10", CODE)
    corpus.add("code", "elsewhere.py:10", "10: def unused_report():\n11:     return None")
    corpus.add("summary", "Оценка", "Все отчёты гарантированно доставляются без задержки.")
    corpus.read(["evidence-1", "evidence-2"])

    class ForbiddenBroker:
        @property
        def tree(self):
            raise AssertionError("No hidden repository reads")

    return SimpleNamespace(research_enabled=research, research_basis=basis, research_source_digest="source-image-hash",
        connectivity_state=None, evidence_corpus=corpus, evidence_broker=ForbiddenBroker(),
        workspace=ResearchWorkspace(), plan_bullets=[BULLET], nodes={}, scenarios={},
        scenario_context={}, scenario_titles={}, risk_reviewed=True, defects=[], risks=[],
        guardrails=[], status_disputes=[])


def scenario(**overrides):
    return {"title": "Получение отчёта", "entry": "Клиент запрашивает отчёт.",
            "outcome": "Сформированный отчёт передан клиенту.",
            "steps": ["Получить запрос", "Передать сформированный отчёт"],
            "critical": True, "bullets": [BULLET],
            "evidence": [{"id": "evidence-1", "quote": BULLET}], **overrides}


def code_ref(**overrides):
    return {"id": "evidence-2", "quote": "11:     transport.send(report)", "path": "reports.py",
            "line": 11, "basis": "send_report", **overrides}


def code_scenario(**overrides):
    item = scenario(**{"evidence": [code_ref()], **overrides})
    item.pop("bullets", None)
    return item


def trace(*, sid="scenario-1", revision=1, result="ok", checks=None):
    names = HANDOFF_CHECKS if checks is None else checks
    return {"scenario_id": sid, "revision": revision, "handoffs": [{"step": 0, "kind": "call",
        "checks": [{"check": check, "result": result,
                    "note": "Передача сформированного отчёта исследована в указанной границе.",
                    "support": "code", "confidence": "high",
                    "evidence": [] if result == "unknown" else [code_ref()]} for check in names]}]}


def node(nid, **data):
    return SimpleNamespace(id=nid, data=data)


class ResearchConnectivityTest(unittest.TestCase):
    def call(self, state, name, args):
        return handle_research_connectivity(state, name, args)

    def accepted(self, state, name, args):
        result = self.call(state, name, args)
        self.assertFalse(result.startswith(name + " отклонён:"), result)
        parsed = json.loads(result)
        self.assertTrue(parsed["ok"])
        return parsed

    def declare(self, state, *items):
        return self.accepted(state, "submit_scenarios", {"scenarios": list(items or [scenario()])})

    def test_scenarios_and_trace_use_existing_deterministic_assessment(self):
        state = session()
        self.declare(state)
        self.assertEqual(state.scenario_titles, {"scenario-1": "Получение отчёта"})
        self.assertEqual(state.scenario_context["scenario-1"]["entry"], scenario()["entry"])
        self.assertEqual(state.scenarios["scenario-1"], scenario()["steps"])
        self.accepted(state, "submit_trace", trace())
        review = connectivity_review(state)
        self.assertEqual(review.source_digest, "source-image-hash")
        self.assertEqual(review.percent(), 100)
        self.assertEqual(review.scenarios[0].status, "assembled")
        self.assertEqual(connectivity_blockers(state), [])
        self.assertTrue(all(e.verified for h in review.scenarios[0].handoffs for c in h.checks for e in c.evidence))
        self.assertEqual(sync_connectivity_objects(state), {"scenario:scenario-1", "trace:scenario-1"})
        self.assertEqual(state.workspace.objects["scenario:scenario-1"]["kind"], "intent")
        self.assertEqual(state.workspace.objects["trace:scenario-1"]["kind"], "claim")

    def test_upsert_preserves_ids_omitted_scenarios_and_exact_repeats(self):
        state = session()
        state.plan_bullets.append(SECOND_BULLET)
        first = self.declare(state)
        second = scenario(title="Просмотр истории", entry="Клиент открывает историю.",
                          outcome="История отправок показана клиенту.",
                          steps=["Открыть историю", "Показать отправленные отчёты"],
                          bullets=[SECOND_BULLET], evidence=[{"id": "evidence-1", "quote": SECOND_BULLET}])
        self.declare(state, second)
        repeated = self.declare(state, scenario())
        self.assertEqual([s["id"] for s in repeated["scenarios"]], ["scenario-1", "scenario-2"])
        self.assertEqual(repeated["changed"], [])
        self.assertEqual(first["scenarios"][0]["revision"], 1)
        self.assertEqual(state.connectivity_state.revisions, {"scenario-1": 1, "scenario-2": 1})

    def test_empty_source_digest_is_preserved_as_supplied_by_pipeline(self):
        state = session()
        state.research_source_digest = ""
        self.declare(state)
        self.assertEqual(connectivity_review(state).source_digest, "")

    def test_revision_requires_current_version_and_keeps_previous_trace_on_rejection(self):
        state = session()
        self.declare(state)
        self.accepted(state, "submit_trace", trace())
        old = connectivity_review(state).to_dict()
        for bad in (scenario(outcome="Отчёт сохранён для дальнейшей выдачи."),
                    scenario(id="scenario-1", revision=0, outcome="Отчёт сохранён для дальнейшей выдачи."),
                    scenario(id="scenario-1", revision=True)):
            result = self.call(state, "submit_scenarios", {"scenarios": [bad]})
            self.assertTrue(result.startswith("submit_scenarios отклонён:"), result)
            self.assertEqual(connectivity_review(state).to_dict(), old)

    def test_changed_steps_clear_only_their_bindings_scopes_and_trace_with_history(self):
        state = session()
        self.declare(state)
        self.accepted(state, "submit_trace", trace())
        old_revision = state.workspace.objects["scenario:scenario-1"]["revision"]
        state.workspace.reviews["scenario:scenario-1"] = {"revision": old_revision, "result": "supported"}
        state.workspace.reviews["trace:scenario-1"] = {"result": "supported"}
        keep = {"scenario": "scenario-2", "step": 1}
        state.nodes["operation-1"] = node("operation-1", scenario_steps=[{"scenario": "scenario-1", "step": 1}, keep])
        state.workspace.exclusions = {"step:scenario-1:1": {"disposition": "excluded"},
                                      "step:scenario-2:1": {"disposition": "excluded"}}
        old_scope_id = "scope:step:scenario-1:1"
        state.workspace.findings["review:" + old_scope_id] = {
            "id": "review:" + old_scope_id, "key": "review:" + old_scope_id,
            "state": "open", "proposal": {"object_id": old_scope_id},
            "reason": "Исключение обязательного шага противоречит исходному обещанию."}
        updated = scenario(id="scenario-1", revision=1,
                           steps=["Получить запрос", "Сформировать отчёт", "Передать сформированный отчёт"])
        self.declare(state, updated)
        self.assertEqual(state.connectivity_state.revisions["scenario-1"], 2)
        self.assertEqual(state.nodes["operation-1"].data["scenario_steps"], [keep])
        self.assertNotIn("step:scenario-1:1", state.workspace.exclusions)
        self.assertIn("step:scenario-2:1", state.workspace.exclusions)
        self.assertNotIn("trace:scenario-1", state.workspace.objects)
        self.assertNotIn("scenario:scenario-1", state.workspace.reviews)
        self.assertNotIn("trace:scenario-1", state.workspace.reviews)
        self.assertEqual(connectivity_review(state).scenarios[0].handoffs, [])
        self.assertTrue(any(e["action"] == "scenario_step_bindings_reset" for e in state.workspace.history))
        self.assertTrue(any(e["action"] == "scenario_revised" and e.get("previous_trace") for e in state.workspace.history))
        retirement = state.workspace.retirements["retirement:scenario-1:steps:2"]
        self.assertEqual(retirement["kind"], "intent")
        self.assertEqual(retirement["retired_object_ids"], [old_scope_id])
        self.assertEqual(retirement["previous_scopes"][0]["decision"], {"disposition": "excluded"})
        self.assertEqual(retirement["scenario"]["steps"], updated["steps"])
        # Only the later independent review may close this earlier counterexample.
        self.assertEqual(state.workspace.findings["review:" + old_scope_id]["state"], "open")
        self.assertTrue(self.call(state, "submit_trace", trace()).startswith("submit_trace отклонён:"))

    def test_changed_metadata_keeps_step_bindings_but_invalidates_trace(self):
        state = session()
        self.declare(state)
        self.accepted(state, "submit_trace", trace())
        refs = [{"scenario": "scenario-1", "step": 0}]
        state.nodes["bbb-1"] = node("bbb-1", scenario_steps=deepcopy(refs))
        self.declare(state, scenario(id="scenario-1", revision=1, critical=False))
        self.assertEqual(state.nodes["bbb-1"].data["scenario_steps"], refs)
        self.assertEqual(state.connectivity_state.trace_versions, {})

    def test_bulk_scenario_validation_is_atomic_and_not_fuzzy(self):
        state = session()
        bad = scenario(title="Другой сценарий", bullets=[BULLET[:25]])
        result = self.call(state, "submit_scenarios", {"scenarios": [scenario(), bad]})
        self.assertTrue(result.startswith("submit_scenarios отклонён:"))
        self.assertIsNone(connectivity_review(state))
        self.assertEqual(state.scenarios, {})
        self.assertEqual(state.connectivity_state.next_id, 1)
        self.declare(state)

    def test_target_scenario_requires_read_intent_and_cannot_use_summary_or_code(self):
        for eid, quote in (("evidence-2", "11:     transport.send(report)"),
                           ("evidence-4", "Все отчёты гарантированно доставляются без задержки.")):
            with self.subTest(eid=eid):
                state = session()
                state.evidence_corpus.read([eid])
                result = self.call(state, "submit_scenarios", {"scenarios": [scenario(evidence=[{"id": eid, "quote": quote}])]})
                self.assertTrue(result.startswith("submit_scenarios отклонён:"))
        state = session()
        state.evidence_corpus.shown.clear()
        self.assertTrue(self.call(state, "submit_scenarios", {"scenarios": [scenario()]}).startswith("submit_scenarios отклонён:"))

    def test_unread_wrong_path_wrong_line_and_invented_quotes_cannot_support_trace(self):
        bad_refs = [code_ref(id="evidence-3", path="elsewhere.py", quote="11:     return None", basis="unused_report"),
                    code_ref(path="elsewhere.py"), code_ref(line=10),
                    code_ref(quote="11:     transport.guarantees_delivery(report)"),
                    {"path": "reports.py", "line": 11, "basis": "send_report"}]
        for ref in bad_refs:
            with self.subTest(ref=ref):
                state = session()
                self.declare(state)
                args = trace()
                args["handoffs"][0]["checks"][0]["evidence"] = [ref]
                result = self.call(state, "submit_trace", args)
                self.assertTrue(result.startswith("submit_trace отклонён:"), result)
                self.assertEqual(connectivity_review(state).scenarios[0].handoffs, [])

    def test_ok_or_broken_without_citation_cannot_use_legacy_semantic_shortcut(self):
        state = session()
        self.declare(state)
        for outcome in ("ok", "broken"):
            args = trace(result=outcome)
            args["handoffs"][0]["checks"][0]["evidence"] = []
            self.assertTrue(self.call(state, "submit_trace", args).startswith("submit_trace отклонён:"))

    def test_trace_replacement_keeps_history_and_invalidates_its_receipt(self):
        state = session()
        self.declare(state)
        self.accepted(state, "submit_trace", trace())
        oid = "trace:scenario-1"
        original = state.workspace.objects[oid]["revision"]
        state.workspace.reviews[oid] = {"revision": original, "result": "supported"}
        self.accepted(state, "submit_trace", trace(result="broken"))
        self.assertNotEqual(state.workspace.objects[oid]["revision"], original)
        self.assertNotIn(oid, state.workspace.reviews)
        review = connectivity_review(state)
        self.assertEqual(review.percent(), 0)
        self.assertEqual([s.id for s in review.blocked()], ["scenario-1"])
        self.assertEqual(connectivity_blockers(state), [])
        self.assertTrue(any(e["action"] == "scenario_trace_revised" and e.get("previous_submission") for e in state.workspace.history))

    def test_long_read_quotes_stay_in_ledger_without_bloating_review_object(self):
        state = session()
        long_code = "1: def prepare_report(report):\n" + "2:     payload = '" + "а" * 4800 + "'\n3:     return report"
        state.evidence_corpus.add("code", "prepare.py:1", long_code)
        eid = next(key for key, row in state.evidence_corpus.records.items() if row["label"] == "prepare.py:1")
        state.evidence_corpus.read([eid])
        self.declare(state)
        args = trace()
        long_ref = code_ref(id=eid, quote=long_code, path="prepare.py", line=3, basis="prepare_report")
        for check in args["handoffs"][0]["checks"]:
            check["evidence"] = [deepcopy(long_ref)]
        self.accepted(state, "submit_trace", args)
        content = state.workspace.objects["trace:scenario-1"]["content"]
        self.assertLess(len(json.dumps(content, ensure_ascii=False)), 10_000)
        self.assertNotIn(long_code, json.dumps(content, ensure_ascii=False))
        self.assertEqual(content["handoffs"][0]["checks"][0]["evidence"][0]["id"], eid)
        stored = next(e for e in state.workspace.history if e["action"] == "scenario_trace_revised")
        self.assertEqual(stored["submission"], args["handoffs"])
        original_revision = state.workspace.objects["trace:scenario-1"]["revision"]
        for check in args["handoffs"][0]["checks"]:
            check["evidence"][0]["quote"] = "3:     return report"
        self.accepted(state, "submit_trace", args)
        self.assertNotEqual(state.workspace.objects["trace:scenario-1"]["revision"], original_revision)

    def test_unknown_can_be_fully_researched_without_becoming_assembled(self):
        state = session()
        self.declare(state)
        self.accepted(state, "submit_trace", trace(result="unknown"))
        self.assertEqual(connectivity_blockers(state), [])
        self.assertEqual(connectivity_review(state).percent(), 0)
        self.assertEqual(connectivity_review(state).scenarios[0].status, "unknown")

    def test_every_handoff_and_check_must_be_explicitly_researched(self):
        state = session()
        self.declare(state, scenario(steps=["Получить запрос", "Сформировать отчёт", "Передать отчёт"]))
        self.accepted(state, "submit_trace", trace(checks=["reachability", "contract", "data_continuity"]))
        blockers = connectivity_blockers(state)
        self.assertTrue(any("переход 0" in error and "obligation" in error for error in blockers))
        self.assertTrue(any("переход 1" in error for error in blockers))

    def test_intent_only_supports_obligation_not_implementation_or_break(self):
        state = session()
        self.declare(state)
        args = trace(result="unknown")
        check = args["handoffs"][0]["checks"][-1]
        self.assertEqual(check["check"], "obligation")
        check.update(result="ok", support="result_image", evidence=[{"id": "evidence-1", "quote": BULLET}])
        self.accepted(state, "submit_trace", args)
        self.assertEqual(connectivity_review(state).scenarios[0].status, "unknown")
        check["check"] = "reachability"
        self.assertTrue(self.call(state, "submit_trace", args).startswith("submit_trace отклонён:"))
        check.update(check="obligation", result="broken")
        self.assertTrue(self.call(state, "submit_trace", args).startswith("submit_trace отклонён:"))

    def test_production_requires_coverage_and_legacy_direct_calls_are_compatible(self):
        state = session(research=False)
        self.assertEqual(connectivity_blockers(state), [])
        self.assertIsNone(connectivity_review(state))
        state.research_enabled = True
        self.assertTrue(connectivity_blockers(state))
        state.plan_bullets.append(SECOND_BULLET)
        self.declare(state)
        self.accepted(state, "submit_trace", trace(result="unknown"))
        self.assertTrue(any("bullet:1" in error for error in connectivity_blockers(state)))
        state.workspace.exclusions["bullet:1"] = {"disposition": "unknown"}
        self.assertTrue(any("bullet:1" in error for error in connectivity_blockers(state)))
        state.workspace.exclusions["bullet:1"]["disposition"] = "excluded"
        self.assertEqual(connectivity_blockers(state), [])

    def test_retirement_preserves_decision_resets_bindings_and_never_reuses_id(self):
        state = session()
        self.declare(state)
        self.accepted(state, "submit_trace", trace(result="unknown"))
        state.nodes["process-1"] = node("process-1", scenarios=["scenario-1"], scenario="scenario-1")
        state.nodes["bbb-1"] = node("bbb-1", scenario_steps=[{"scenario": "scenario-1", "step": 0}])
        state.workspace.exclusions["step:scenario-1:0"] = {"disposition": "excluded"}
        self.accepted(state, "retire_scenario", {"scenario_id": "scenario-1", "revision": 1,
            "reason": "Ошибочно выделенный сценарий будет заменён точным обещанием из исходного образа результата.",
            "evidence": [{"id": "evidence-1", "quote": BULLET}]})
        self.assertEqual(state.scenarios, {})
        self.assertEqual(state.nodes["process-1"].data["scenarios"], [])
        self.assertEqual(state.nodes["bbb-1"].data["scenario_steps"], [])
        self.assertNotIn("scenario:scenario-1", state.workspace.objects)
        decision = state.workspace.retirements["retirement:scenario-1"]
        self.assertEqual(decision["kind"], "intent")
        self.assertEqual(decision["retired_object_ids"], ["scenario:scenario-1", "trace:scenario-1", "scope:step:scenario-1:0"])
        self.assertTrue(connectivity_blockers(state))
        self.declare(state)
        self.assertEqual(list(state.scenarios), ["scenario-2"])

    def test_retirement_refuses_to_drop_referenced_fact(self):
        state = session()
        self.declare(state)
        state.defects = [{"id": "defect-1", "scenario": "scenario-1", "text": "Внешний контракт не установлен."}]
        result = self.call(state, "retire_scenario", {"scenario_id": "scenario-1", "revision": 1,
            "reason": "Сценарий ошибочно выделен отдельно от другого обещанного результата.",
            "evidence": [{"id": "evidence-1", "quote": BULLET}]})
        self.assertTrue(result.startswith("retire_scenario отклонён:"))
        self.assertIn("scenario-1", state.scenarios)
        self.assertEqual(state.workspace.retirements, {})

    def test_tools_do_not_change_legacy_schema(self):
        from pko.progress.connectivity import CONNECTIVITY_TOOL_SCHEMAS
        self.assertEqual([s["function"]["name"] for s in RESEARCH_CONNECTIVITY_SCHEMAS],
                         ["submit_scenarios", "submit_trace", "retire_scenario"])
        self.assertNotIn("revision", CONNECTIVITY_TOOL_SCHEMAS[1]["function"]["parameters"]["properties"])

    def test_code_scenario_and_obligation_are_grounded_without_any_result_image(self):
        state = session(basis="code")
        state.plan_bullets = []
        state.evidence_corpus.shown.pop("evidence-1")
        state.evidence_corpus.add("code", "queue.py:20", "20: def enqueue_report(report):\n21:     outbox.append(report)\n22:     return report")
        state.evidence_corpus.read(["evidence-5"])
        ref = code_ref(id="evidence-5", quote="21:     outbox.append(report)", path="queue.py", line=21, basis="enqueue_report")
        declared = code_scenario()
        declared.update(outcome="Отчёт включён в очередь отправки.",
                        steps=["Принять сформированный отчёт", "Поставить отчёт в очередь отправки"], evidence=[ref])
        response = self.declare(state, declared)
        self.assertEqual(response["research_basis"], "code")
        args = trace()
        for check in args["handoffs"][0]["checks"]:
            check["evidence"] = [ref]
            check["note"] = "Сформированный отчёт включается в очередь отправки; доставка за пределами этого сценария."
        self.accepted(state, "submit_trace", args)
        review = connectivity_review(state)
        self.assertEqual(review.percent(), 100)
        self.assertEqual(review.scenarios[0].handoffs[0].checks[-1].check, "obligation")
        self.assertEqual(review.scenarios[0].handoffs[0].checks[-1].result, "ok")
        self.assertEqual(review.scenarios[0].bullets, [])
        self.assertEqual(connectivity_blockers(state), [])
        for serial in (review.to_dict(), asdict(review)):
            self.assertEqual(serial["research_basis"], "code")
            self.assertEqual(serial["scenarios"][0]["origin"], "code")
        for oid in ("scenario:scenario-1", "trace:scenario-1"):
            self.assertEqual(state.workspace.objects[oid]["kind"], "claim")
            self.assertEqual(state.workspace.objects[oid]["content"]["research_basis"], "code")

    def test_code_mode_does_not_require_result_image_coverage_but_still_requires_traces(self):
        state = session(basis="code")
        state.plan_bullets.append(SECOND_BULLET)
        self.declare(state, code_scenario())
        blockers = connectivity_blockers(state)
        self.assertTrue(any("трассы" in error for error in blockers))
        self.assertFalse(any("bullet:" in error for error in blockers))
        self.accepted(state, "submit_trace", trace(result="unknown"))
        self.assertEqual(connectivity_blockers(state), [])
        self.assertEqual(connectivity_review(state).percent(), 0)

    def test_code_mode_rejects_intent_summary_unread_or_mislocated_scenario_evidence(self):
        variants = [
            [{"id": "evidence-1", "quote": BULLET}],
            [{"id": "evidence-4", "quote": "Все отчёты гарантированно доставляются без задержки."}],
            [code_ref(id="evidence-3", path="elsewhere.py", line=11, quote="11:     return None", basis="unused_report")],
            [code_ref(path="elsewhere.py")], [code_ref(line=10)],
            [code_ref(quote="11:     transport.fake_delivery(report)")],
        ]
        for refs in variants:
            with self.subTest(refs=refs):
                state = session(basis="code")
                state.evidence_corpus.read(["evidence-4"])
                item = code_scenario()
                item["evidence"] = refs
                self.assertTrue(self.call(state, "submit_scenarios", {"scenarios": [item]}).startswith("submit_scenarios отклонён:"))
                self.assertIsNone(connectivity_review(state))

    def test_code_obligation_cannot_be_confirmed_by_result_image_under_any_support(self):
        state = session(basis="code")
        self.declare(state, code_scenario())
        for support in ("result_image", "code", "inference"):
            args = trace(result="unknown")
            args["handoffs"][0]["checks"][-1].update(
                result="ok", support=support, evidence=[{"id": "evidence-1", "quote": BULLET}])
            self.assertTrue(self.call(state, "submit_trace", args).startswith("submit_trace отклонён:"))
        self.assertEqual(connectivity_review(state).scenarios[0].handoffs, [])

    def test_code_scenario_preserves_required_but_broken_continuation(self):
        state = session(basis="code")
        source = ("1: def submit_report(report):\n2:     receipt = persist_report(report)\n3:     return receipt\n"
                  "4: def persist_report(report):\n5:     raise NotImplementedError('storage unavailable')")
        state.evidence_corpus.add("code", "storage.py:1", source)
        state.evidence_corpus.read(["evidence-5"])
        call = code_ref(id="evidence-5", quote="2:     receipt = persist_report(report)", path="storage.py", line=2, basis="submit_report")
        failure = code_ref(id="evidence-5", quote="5:     raise NotImplementedError('storage unavailable')", path="storage.py", line=5, basis="persist_report")
        item = code_scenario()
        item.update(outcome="Сохранение отчёта подтверждено клиенту.",
                    steps=["Принять отчёт", "Сохранить отчёт", "Подтвердить сохранение"], evidence=[call, failure])
        self.declare(state, item)
        args = trace()
        for check in args["handoffs"][0]["checks"]:
            check["evidence"] = [call]
        broken_handoff = trace(result="unknown")["handoffs"][0]
        broken_handoff["step"] = 1
        broken_handoff["checks"][-1].update(result="broken", evidence=[failure],
            note="Сохранение прекращается с исключением, поэтому подтверждение сохранённого отчёта не возникает.")
        args["handoffs"].append(broken_handoff)
        self.accepted(state, "submit_trace", args)
        review = connectivity_review(state)
        self.assertEqual(review.scenarios[0].steps, item["steps"])
        self.assertEqual(review.scenarios[0].outcome, item["outcome"])
        self.assertEqual(review.scenarios[0].status, "broken")
        self.assertEqual(review.percent(), 0)
        self.assertEqual([s.id for s in review.blocked()], ["scenario-1"])
        self.assertEqual(connectivity_blockers(state), [])

    def test_code_revision_and_scope_retirement_keep_claim_basis_and_stale_trace_guard(self):
        state = session(basis="code")
        self.declare(state, code_scenario())
        self.accepted(state, "submit_trace", trace())
        oid = "scenario:scenario-1"
        state.workspace.reviews[oid] = {"revision": state.workspace.objects[oid]["revision"], "result": "supported"}
        state.workspace.exclusions["step:scenario-1:1"] = {"disposition": "excluded"}
        changed = code_scenario(id="scenario-1", revision=1, steps=["Принять отчёт", "Проверить отчёт", "Передать отчёт"])
        self.declare(state, changed)
        self.assertNotIn(oid, state.workspace.reviews)
        decision = state.workspace.retirements["retirement:scenario-1:steps:2"]
        self.assertEqual(decision["kind"], "claim")
        self.assertEqual(decision["research_basis"], "code")
        self.assertEqual(decision["evidence"], [code_ref()])
        self.assertTrue(self.call(state, "submit_trace", trace()).startswith("submit_trace отклонён:"))

    def test_code_retirement_uses_newly_read_code_and_preserves_old_counterexample(self):
        state = session(basis="code")
        self.declare(state, code_scenario())
        negative = {"id": "finding-1", "key": "review:scenario:scenario-1", "state": "open",
                    "proposal": {"object_id": "scenario:scenario-1"}, "reason": "Заявленный самостоятельный результат не подтверждён."}
        state.workspace.findings["finding-1"] = deepcopy(negative)
        args = {"scenario_id": "scenario-1", "revision": 1,
                "reason": "Новый прочитанный обработчик показал, что самостоятельный результат выделен ошибочно.",
                "evidence": [{"id": "evidence-1", "quote": BULLET}]}
        self.assertTrue(self.call(state, "retire_scenario", args).startswith("retire_scenario отклонён:"))
        state.evidence_corpus.read(["evidence-3"])
        args["evidence"] = [code_ref(id="evidence-3", path="elsewhere.py", line=11,
                                     quote="11:     return None", basis="unused_report")]
        self.accepted(state, "retire_scenario", args)
        decision = state.workspace.retirements["retirement:scenario-1"]
        self.assertEqual(decision["kind"], "claim")
        self.assertEqual(decision["research_basis"], "code")
        self.assertEqual(decision["evidence"], args["evidence"])
        self.assertEqual(state.workspace.findings["finding-1"], negative)
        self.assertEqual(state.scenarios, {})

    def test_mode_cannot_relabel_previously_accepted_intent_as_code(self):
        state = session()
        self.declare(state)
        original = deepcopy(state.workspace.objects["scenario:scenario-1"])
        state.research_basis = "code"
        self.assertTrue(self.call(state, "submit_trace", trace()).startswith("submit_trace отклонён:"))
        self.assertTrue(any("Основание исследования изменено" in error for error in connectivity_blockers(state)))
        self.assertEqual(state.workspace.objects["scenario:scenario-1"], original)

    def test_code_schema_is_separate_and_never_fabricates_result_image_requirement(self):
        before = deepcopy(RESEARCH_CONNECTIVITY_SCHEMAS)
        schemas = research_connectivity_schemas("code")
        item = schemas[0]["function"]["parameters"]["properties"]["scenarios"]["items"]
        self.assertNotIn("bullets", item["required"])
        self.assertEqual(set(item["properties"]["evidence"]["items"]["required"]), {"id", "quote", "path", "line", "basis"})
        check = schemas[1]["function"]["parameters"]["properties"]["handoffs"]["items"]["properties"]["checks"]["items"]
        self.assertNotIn("result_image", check["properties"]["support"]["enum"])
        self.assertEqual(RESEARCH_CONNECTIVITY_SCHEMAS, before)
        self.assertEqual(research_connectivity_schemas(), before)

    def test_code_mode_allows_32_active_scenarios_without_legacy_eight_scenario_ceiling(self):
        state = session(basis="code")

        def numbered(number):
            return code_scenario(title=f"Обработка обращения {number}",
                                 entry=f"Поступает обращение вида {number}.",
                                 outcome=f"Зафиксирован результат обработки вида {number}.")

        self.declare(state, *[numbered(i) for i in range(1, 10)])
        self.assertEqual(len(state.scenarios), 9)
        self.declare(state, *[numbered(i) for i in range(10, 33)])
        self.assertEqual(len(state.scenarios), 32)
        self.assertEqual(len(connectivity_blockers(state)), 32)  # Every trace is still required.
        result = self.call(state, "submit_scenarios", {"scenarios": [numbered(33)]})
        self.assertTrue(result.startswith("submit_scenarios отклонён:"))
        self.assertEqual(len(state.scenarios), 32)
        self.accepted(state, "retire_scenario", {"scenario_id": "scenario-1", "revision": 1,
            "reason": "Проверка кода показала, что самостоятельный результат был выделен ошибочно.",
            "evidence": [code_ref()]})
        self.declare(state, numbered(33))
        self.assertEqual(len(state.scenarios), 32)
        self.assertIn("scenario-33", state.scenarios)
        self.assertNotIn("scenario-1", state.scenarios)
        self.assertEqual(research_connectivity_schemas("code")[0]["function"]["parameters"]["properties"]["scenarios"]["maxItems"], 32)
        self.assertEqual(research_connectivity_schemas()[0]["function"]["parameters"]["properties"]["scenarios"]["maxItems"], 8)

    def test_result_image_mode_keeps_its_eight_active_scenario_limit(self):
        state = session()
        args = {"scenarios": [scenario(title=f"Обработка обращения {i}",
                                      entry=f"Поступает обращение вида {i}.",
                                      outcome=f"Зафиксирован результат обработки вида {i}.") for i in range(9)]}
        self.assertTrue(self.call(state, "submit_scenarios", args).startswith("submit_scenarios отклонён:"))
        self.assertEqual(state.scenarios, {})


if __name__ == "__main__":
    unittest.main()
