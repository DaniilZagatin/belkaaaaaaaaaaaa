"""Prevent budget feedback from sending a research loop back to exhausted I/O."""
from copy import deepcopy
import unittest

from pko.extractors.runner import Extraction
from pko.progress.passport_broker import EvidenceBroker
from pko.progress.passport_evidence import EvidenceCorpus
from test_passport_broker import MemoryTree


class ReadFeedbackTests(unittest.TestCase):
    def broker(self, files=None, **limits):
        tree = MemoryTree(files or {"handler.py": "def handle():\n    return send_result()"})
        corpus = EvidenceCorpus()
        return EvidenceBroker(tree, Extraction(), corpus, **limits), tree, corpus

    def test_exact_completed_request_reuses_handles_after_budget_without_authorizing_citation(self):
        broker, tree, corpus = self.broker(max_requests=1)
        args = {"kind": "file", "path": "handler.py", "line": 1}
        first = broker.request(args)
        repeat = broker.request(dict(reversed(list(args.items()))))
        self.assertTrue(repeat["ok"])
        self.assertTrue(repeat["cached"])
        self.assertEqual(repeat["records"], first["records"])
        self.assertEqual(repeat["usage"]["requests"], 1)
        self.assertEqual(repeat["usage"]["request_calls"], 2)
        self.assertEqual(repeat["usage"]["cache_hits"], 1)
        self.assertEqual(tree.reads, ["handler.py"])
        self.assertFalse(repeat["availability"]["new_requests"])
        self.assertTrue(repeat["availability"]["cached_requests"])
        ref = [{"id": repeat["records"][0]["id"], "quote": "return send_result()"}]
        self.assertTrue(corpus.citations(ref, code=True))
        self.assertEqual(corpus.shown, {})
        corpus.read([ref[0]["id"]])
        self.assertFalse(corpus.citations(ref, code=True))
        self.assertEqual([row["request"] for row in broker.inventory()["audit"]], [1, 2])

    def test_exhausted_budget_is_terminal_for_new_requests_but_corpus_remains_usable(self):
        broker, tree, corpus = self.broker({"handler.py": "send_result()", "other.py": "other_result()"}, max_requests=1)
        original = broker.request({"kind": "file", "path": "handler.py"})
        for args in ({"kind": "file", "path": "other.py"}, {"kind": "search", "query": "other_result"}):
            result = broker.request(args)
            self.assertEqual(result["error"], "request_budget")
            self.assertFalse(result["retryable"])
            self.assertEqual(result["next_action"], "use_existing_evidence_or_record_limit")
            self.assertNotIn("other.py", tree.reads)
        repeated = broker.request({"kind": "file", "path": "handler.py"})
        self.assertTrue(repeated["cached"])
        self.assertEqual(repeated["records"], original["records"])
        found = corpus.index("send_result")
        self.assertFalse(found["records"][0]["already_read"])
        self.assertEqual(corpus.shown, {})
        self.assertEqual(corpus.read([found["records"][0]["id"]])["newly_read_ids"], [found["records"][0]["id"]])

    def test_cached_complete_search_is_immutable_and_does_not_spend_new_budget(self):
        broker, tree, corpus = self.broker(max_requests=1)
        args = {"kind": "search", "query": "send_result"}
        first = broker.request(args)
        tree.content["handler.py"] = "live_change_must_not_appear()"
        second = broker.request(args)
        self.assertTrue(second["cached"])
        self.assertEqual(second["records"], first["records"])
        self.assertEqual(second["usage"]["requests"], 1)
        self.assertEqual(tree.reads, ["handler.py"])
        self.assertEqual(corpus.shown, {})

    def test_truncated_search_is_not_cached_and_can_see_addressed_read(self):
        files = {"a.py": "other_action()", "b.py": "other_action()", "c.py": "other_action()", "d.py": "target_action()"}
        broker, tree, corpus = self.broker(files, max_source_files=4)
        args = {"kind": "search", "query": "target_action"}
        first = broker.request(args)
        self.assertTrue(first["truncated"])
        self.assertEqual(first["records"], [])
        self.assertNotIn("d.py", tree.reads)
        addressed = broker.request({"kind": "file", "path": "d.py"})
        self.assertTrue(addressed["ok"])
        again = broker.request(args)
        self.assertFalse(again["cached"])
        self.assertTrue(again["records"])
        self.assertFalse(again["truncated"])
        self.assertEqual(corpus.shown, {})

    def test_read_status_is_session_local_and_repeat_does_not_fake_new_information(self):
        broker, _, researcher = self.broker()
        result = broker.request({"kind": "file", "path": "handler.py"})
        eid = result["records"][0]["id"]
        self.assertNotIn("already_read", result["records"][0])
        first = researcher.read([eid])
        self.assertFalse(first["records"][0]["already_read"])
        self.assertEqual(first["newly_read_ids"], [eid])
        again = researcher.read([eid])
        self.assertTrue(again["records"][0]["already_read"])
        self.assertEqual(again["newly_read_ids"], [])
        self.assertEqual(again["already_read_ids"], [eid])
        self.assertEqual(again["records"][0]["text"], first["records"][0]["text"])
        reviewer = EvidenceCorpus(records=researcher.records)
        self.assertFalse(reviewer.index()["records"][0]["already_read"])
        self.assertTrue(researcher.index()["records"][0]["already_read"])
        refs = [{"id": eid, "quote": "return send_result()"}]
        self.assertTrue(reviewer.citations(refs, code=True))
        cached = broker.request({"kind": "file", "path": "handler.py"})
        self.assertNotIn("already_read", cached["records"][0])
        self.assertTrue(reviewer.citations(refs, code=True))
        reviewer.read([eid])
        self.assertFalse(reviewer.citations(refs, code=True))

    def test_returned_cache_mutation_does_not_change_saved_answer_or_source(self):
        broker, tree, _ = self.broker(max_requests=1)
        args = {"kind": "file", "path": "handler.py"}
        first = broker.request(args)
        expected = deepcopy(first["records"])
        first["records"][0]["id"] = "fabricated-id"
        repeat = broker.request(args)
        self.assertEqual(repeat["records"], expected)
        self.assertEqual(tree.reads, ["handler.py"])


if __name__ == "__main__":
    unittest.main()
