"""Exercise the production Agent loop with actual passport acceptance gates."""
from copy import deepcopy
import json
import unittest

from pko.llm.client import ChatResult
from pko.progress.passport_agent import run_passport_agent
from test_passport_agentic import SPEC, ScriptClient, corpus_fixture, tool
from test_passport_code_reconstruction import code_responses
from test_passport_integrated_research import ResearchClient, result


def run(client, steps=30, **kwargs):
    return run_passport_agent([], {}, [], None, SPEC, client=client, max_steps=steps,
        evidence_corpus=corpus_fixture(), agentic=True, research_enabled=True,
        research_basis="code", **kwargs)


class PassportHarnessTests(unittest.TestCase):
    def test_schema_error_is_repairable_without_domain_mutation(self):
        bad = tool("declare_children", {"parent": "journey-1", "children": "wrong type"})
        client = ResearchClient(result(bad), *code_responses())
        output = run(client)
        self.assertEqual(output.passport_data["completion"]["state"], "complete", output.notes)
        self.assertEqual(len(output.passport_data["nodes"]), 4)
        replies = [m for history in client.messages for m in history if m.get("tool_call_id") == bad["id"]]
        self.assertTrue(any('"rule": "type"' in m["content"] for m in replies))
        self.assertEqual(output.passport_data["runtime"]["engine"], "pydantic-ai-harness")
        rejected = [event for event in output.passport_data["research"]["history"]
                    if event["action"] == "tool_arguments_rejected"]
        self.assertEqual(len(rejected), 1)
        self.assertEqual(rejected[0]["tool"], "declare_children")

    def test_rejected_finish_never_becomes_success_after_retries(self):
        client = ScriptClient(*(result(tool("finish")) for _ in range(8)))
        output = run(client, steps=8)
        self.assertNotEqual(output.passport_data["completion"]["state"], "complete")
        self.assertTrue(output.passport_data["completion"]["blockers"])
        self.assertLessEqual(len(client.messages), 8)

    def test_text_alone_is_not_a_completed_passport(self):
        client = ScriptClient(*(ChatResult(text="Паспорт готов", usage={}, tool_calls=[]) for _ in range(8)))
        output = run(client, steps=8)
        self.assertEqual(output.passport_data["completion"]["stop_reason"], "malformed")
        self.assertNotEqual(output.passport_data["completion"]["state"], "complete")

    def test_no_tools_after_accepted_finish_and_no_final_model_call(self):
        responses = code_responses()
        late = tool("declare_children", {"parent": "journey-1", "children": [
            {"name": "Лишний процесс", "basis": "После завершения изменения запрещены"}]})
        responses[-1].tool_calls.append(late)
        client = ResearchClient(*responses)
        output = run(client)
        self.assertEqual(output.passport_data["completion"]["state"], "complete", output.notes)
        self.assertEqual(len(output.passport_data["nodes"]), 4)
        self.assertEqual(len(client.messages), len(responses))
        self.assertEqual(client.responses, [])

    def test_steps_and_legacy_choice_remain_explicit(self):
        for engine in ("pydantic", "legacy"):
            with self.subTest(engine=engine):
                client = ScriptClient(result(tool("read_passport_evidence", {"ids": ["evidence-1"]})))
                output = run(client, steps=1, engine=engine)
                self.assertEqual(len(client.messages), 1)
                self.assertEqual(output.passport_data["completion"]["stop_reason"], "steps")
                self.assertEqual(output.passport_data["runtime"]["engine"],
                                 "legacy" if engine == "legacy" else "pydantic-ai-harness")


if __name__ == "__main__":
    unittest.main()
