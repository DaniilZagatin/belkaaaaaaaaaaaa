"""A text-only draft patch cannot restore a binding withdrawn by another tool."""
from copy import deepcopy
import unittest

from pko.progress.passport_agent import _handle_bind_scenario_step, _handle_submit_node
from pko.progress.passport_drafts import submit
from test_passport_agentic import node_args
from test_passport_agentic_review import scenario_session


class DraftBindingsLifecycleTests(unittest.TestCase):
    def accepted_draft(self):
        state = scenario_session()
        state.node_drafts = {}
        args = node_args("operation-1")
        args["scenario_steps"] = [{"scenario": "scenario-1", "step": 0}]
        reply = submit(state, args, _handle_submit_node)
        self.assertIn("принят.", reply.splitlines()[0])
        self.assertTrue(state.node_drafts["operation-1"]["accepted"])
        return state

    def move_binding(self, state):
        reply = _handle_bind_scenario_step(state, {
            "scenario": "scenario-1", "step": 0, "nodes": ["bbb-1"], "replace": True,
        })
        self.assertNotIn("отклонён", reply)
        self.assertEqual(state.nodes["operation-1"].data["scenario_steps"], [])

    def field_patch(self, state):
        return {"id": "operation-1", "patch": True,
                "draft_revision": state.node_drafts["operation-1"]["revision"],
                "fields": {"4.5.1": {
                    "value": "Не установлено: роль операции требует дополнительных сведений.",
                    "source": "Не установлено: доступные материалы не раскрывают эти условия.",
                }}}

    def test_accepted_draft_cannot_resurrect_replaced_scenario_binding(self):
        state = self.accepted_draft()
        self.move_binding(state)
        before = {nid: deepcopy(node.data) for nid, node in state.nodes.items()}
        reply = submit(state, self.field_patch(state), _handle_submit_node)
        self.assertIn("отклонён", reply)
        self.assertIn("read_node", reply)
        self.assertEqual({nid: node.data for nid, node in state.nodes.items()}, before)

    def test_rejected_draft_also_expires_after_external_binding_change(self):
        state = self.accepted_draft()
        bad = self.field_patch(state)
        bad["fields"]["4.5.1"] = {"value": "Не установлено: нет подтверждённого назначения."}
        self.assertIn("отклонён", submit(state, bad, _handle_submit_node))
        self.assertFalse(state.node_drafts["operation-1"]["accepted"])
        self.move_binding(state)
        before = {nid: deepcopy(node.data) for nid, node in state.nodes.items()}
        reply = submit(state, self.field_patch(state), _handle_submit_node)
        self.assertIn("отклонён", reply)
        self.assertIn("read_node", reply)
        self.assertEqual({nid: node.data for nid, node in state.nodes.items()}, before)


if __name__ == "__main__":
    unittest.main()
