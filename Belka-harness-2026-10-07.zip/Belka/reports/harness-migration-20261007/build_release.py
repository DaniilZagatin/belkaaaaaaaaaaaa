"""Task-local source release. Run only after the owner freezes a green suite.

First: build_release.py --frozen
Then: verify_portable.py
Finally: build_release.py --frozen --include-portable-proof
The final ZIP includes proof for the identical runtime/resource payload.
Dependencies are declared in requirements; installed test dependencies are not
vendored into this source ZIP.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OUTPUT = ROOT / "dist" / "Belka-harness-2026-10-07.zip"
DIRECTORIES = {"backend", "baselines", "docs", "frontend-app", "monitoring", "scripts", "tests"}
ROOT_FILES = {".dockerignore", ".env.example", ".gitignore", "ЗАПУСК.md", "ИЗМЕНЕНИЯ.md",
              "Реестр_инициатив.md", "AGENTS.md", "CLAUDE.md", "FILL_SPEC_v3.md",
              "instrukciya-zapolneniya-pasporta-v3.md", "Makefile", "MANIFEST.in",
              "METHODOLOGY.md", "passport-dpss-v3.html", "pyproject.toml", "README.md",
              "requirements-phoenix.txt", "requirements-postgres.txt", "requirements-test.txt",
              "requirements.txt", "setup.py", "uv.lock"}
SKIP = {"__pycache__", ".git", ".venv", "node_modules", ".pytest_cache", ".mypy_cache", ".ruff_cache", "certs"}
PROOFS = ("final/TESTS.txt", "final/junit.xml", "final/baseline.txt", "verification.md",
          "build_release.py", "verify_portable.py", "run_full.py")


def sha(blob: bytes) -> str:
    return hashlib.sha256(blob).hexdigest()


def include(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if path.is_symlink() or any(part in SKIP or part.endswith(".egg-info") for part in rel.parts):
        return False
    if rel.parts[:3] == ("tests", "fixtures", "mini_repo"):
        return False  # Fixture helper rebuilds this on the destination host.
    if rel.parts[:2] == ("monitoring", "data"):
        return False
    name = path.name.lower()
    if ((name.startswith(".env") and name != ".env.example")
            or path.suffix.lower() in {".pyc", ".pyo", ".pem", ".key", ".p12", ".pfx", ".bak"}):
        return False
    return rel.parts[0] in DIRECTORIES or (len(rel.parts) == 1 and path.name in ROOT_FILES)


def final_suite() -> dict:
    xml_path = HERE / "final/junit.xml"
    report = ET.parse(xml_path).getroot()
    cases = list(report.iter("testcase"))
    assert cases and not list(report.iter("failure")) and not list(report.iter("error")), "Final tests must pass before bundling"
    for suite in report.iter("testsuite"):
        assert int(suite.get("failures", 0)) == 0 and int(suite.get("errors", 0)) == 0, "Suite reports an error"
    assert (HERE / "final/TESTS.txt").is_file(), "The human-readable final test proof is missing"
    return {"cases": len(cases), "skipped": len(list(report.iter("skipped"))), "junit_sha256": sha(xml_path.read_bytes())}


def build(*, include_portable_proof: bool = False) -> dict:
    suite = final_suite()
    paths = [path for name in DIRECTORIES for path in (ROOT / name).rglob("*") if path.is_file() and include(path)]
    paths += [path for path in ROOT.iterdir() if path.is_file() and include(path)]
    paths += [HERE / name for name in PROOFS if (HERE / name).is_file()]
    if include_portable_proof:
        assert (HERE / "portable-smoke.json").is_file(), "Verify the initial ZIP first"
        paths.append(HERE / "portable-smoke.json")
    blobs = [(path.relative_to(ROOT).as_posix(), path.read_bytes()) for path in sorted(set(paths))]
    manifest = [{"path": name, "bytes": len(blob), "sha256": sha(blob)} for name, blob in blobs]
    payload = sorted(("Belka/" + row["path"], row["sha256"]) for row in manifest
                     if not row["path"].startswith(("docs/", "reports/")))
    payload_sha = sha(json.dumps(payload, ensure_ascii=False).encode())
    if include_portable_proof:
        proof = json.loads((HERE / "portable-smoke.json").read_text(encoding="utf-8"))
        assert proof["status"] == "passed" and proof["payload_sha256"] == payload_sha, "Verified code/resource payload changed"
        assert proof["final_suite"]["junit_sha256"] == suite["junit_sha256"], "The final suite proof changed"
    OUTPUT.parent.mkdir(exist_ok=True)
    pending = OUTPUT.with_suffix(".pending.zip")
    with zipfile.ZipFile(pending, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, blob in blobs:
            archive.writestr("Belka/" + name, blob)
    pending.replace(OUTPUT)
    result = {"archive": str(OUTPUT), "bytes": OUTPUT.stat().st_size, "sha256": sha(OUTPUT.read_bytes()),
              "payload_sha256": payload_sha, "final_suite": suite, "portable_proof_included": include_portable_proof,
              "dependencies": "Declared requirements; not vendored", "files": manifest}
    (HERE / "portable-manifest.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: len(value) if key == "files" else value for key, value in result.items()}, ensure_ascii=False))
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--frozen", action="store_true", help="Owner confirmed the tested source is frozen")
    parser.add_argument("--include-portable-proof", action="store_true")
    args = parser.parse_args()
    if not args.frozen:
        parser.error("Wait for the owner's freeze and a green final suite, then pass --frozen")
    build(include_portable_proof=args.include_portable_proof)


if __name__ == "__main__":
    main()
