"""Run the normal suite with a task-local progress marker for long runs."""
from datetime import datetime
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT / "tests"), str(ROOT / "backend")]
import run_tests

original = run_tests._Recorder.startTest
count = 0


def start_test(self, test):
    global count
    count += 1
    (HERE / "test-progress.txt").write_text(
        f"{datetime.now().isoformat()} · {count} · {test.id()}\n", encoding="utf-8")
    original(self, test)


run_tests._Recorder.startTest = start_test
raise SystemExit(run_tests.main())
