"""Verify the frozen source ZIP with current dependencies and no network/model.

The scripted transport exercises the actual Pydantic Agent and independent
reviewer loops and the domain acceptance gates. This checks packaging/runtime,
not the quality, speed, or availability of a live model on another laptop.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
ARCHIVE = ROOT / "dist/Belka-harness-2026-10-07.zip"
DEPS = HERE / "test-deps"


def verify() -> dict:
    assert DEPS.is_dir(), "Install the pinned test dependencies into this task's test-deps first"
    stage = Path(tempfile.mkdtemp(prefix="portable-smoke-", dir=HERE))
    with zipfile.ZipFile(ARCHIVE) as bundle:
        payload = [(name, hashlib.sha256(bundle.read(name)).hexdigest()) for name in sorted(bundle.namelist())
                   if not name.startswith(("Belka/docs/", "Belka/reports/"))]
        for item in bundle.infolist():
            destination = (stage / item.filename).resolve()
            assert destination.is_relative_to(stage.resolve())
            assert item.filename.startswith("Belka/") and not item.filename.startswith(("/", "\\"))
            assert not (destination.name.startswith(".env") and destination.name != ".env.example")
            assert destination.suffix.lower() not in {".pem", ".key", ".p12", ".pfx", ".pyc"}
        bundle.extractall(stage)
    source = stage / "Belka"
    report_path = source / "reports/harness-migration-20261007/final/junit.xml"
    suite = ET.parse(report_path).getroot()
    assert list(suite.iter("testcase")) and not list(suite.iter("failure")) and not list(suite.iter("error"))
    final_suite = {"cases": len(list(suite.iter("testcase"))), "skipped": len(list(suite.iter("skipped"))),
                   "junit_sha256": hashlib.sha256(report_path.read_bytes()).hexdigest()}
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(("PKO_", "OTEL_", "OPENAI_", "GLM_")) and key not in {"PYTHONPATH", "PYTHONHOME"}}
    env.update(PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1", PYDANTIC_AI_NO_BANNER="1")
    bootstrap = f'''import sys, socket
sys.dont_write_bytecode = True
sys.path[:0] = {[str(source / "backend"), str(source / "tests"), str(DEPS)]!r}
# Windows asyncio's self-pipe uses stdlib socketpair, which itself makes
# a loopback connection. Reserve its one IPC pair before disabling network.
# The agent, providers and tools still cannot make any socket connection.
_loop_ipc_pairs = [socket.socketpair()]
def loop_ipc_pair(*args, **kwargs):
    assert not args and not kwargs and _loop_ipc_pairs, "Only the preallocated event-loop IPC pair is allowed"
    return _loop_ipc_pairs.pop()
socket.socketpair = loop_ipc_pair
def forbidden(*args, **kwargs): raise AssertionError("Network is forbidden")
socket.socket.connect = forbidden
socket.socket.connect_ex = forbidden
socket.socket.sendto = forbidden
socket.create_connection = forbidden
socket.getaddrinfo = forbidden
from pathlib import Path
import pko, pydantic_ai, pydantic_ai_harness
assert Path(pko.__file__).is_relative_to(Path({str(source)!r})), pko.__file__
assert Path(pydantic_ai.__file__).is_relative_to(Path({str(DEPS)!r})), pydantic_ai.__file__
assert Path(pydantic_ai_harness.__file__).is_relative_to(Path({str(DEPS)!r})), pydantic_ai_harness.__file__
'''
    invocations = []

    def run(label: str, code: str) -> str:
        result = subprocess.run([sys.executable, "-I", "-X", "utf8", "-c", bootstrap + code],
                                cwd=source, env=env, capture_output=True, text=True, encoding="utf-8", timeout=90)
        invocations.append({"check": label, "returncode": result.returncode})
        assert result.returncode == 0, (label, result.stdout[-3000:], result.stderr[-3000:])
        return result.stdout

    (source / "initiative.md").write_text(
        "Проект: Проверка переноса\n\n## Результат\n- Получить подтверждение\n", encoding="utf-8")
    for label, args in (("help", ["--help"]), ("initiatives", ["initiatives"]),
                        ("parse", ["parse", "--journey-file", "initiative.md", "--json"])):
        assert run(label, f"sys.argv = {['pko', *args]!r}\nfrom pko.cli import run\nrun()\n").strip()
    run("html_resources", '''
from pko.extractors.runner import Extraction
from pko.progress.plan_input import parse_plan_text
from pko.progress.schema import ProgressModel
from pko.render.client_journey_passport import _TEMPLATE_PATH, render_client_journey_passport
from pko.render.dashboard_html import render_dashboard_html
assert _TEMPLATE_PATH == Path.cwd() / 'passport-dpss-v3.html'
plan = parse_plan_text(Path('initiative.md').read_text(encoding='utf-8'))
model = ProgressModel(passport_data={'schema_version': 2, 'research_basis': 'code',
    'nodes': {}, 'tree': [], 'completion': {'state': 'incomplete', 'blockers': []}})
html = render_client_journey_passport(model, plan, 'portable', Extraction(), 'abc123', 'main')
assert '<html' in html.lower() and 'data:font/woff2;base64,' in html
html = render_dashboard_html({'meta': {}, 'readiness': 0, 'readiness_prod': 0,
    'items': [], 'summary': {}})
assert '<html' in html.lower() and '/*__DATA__*/' not in html
''')
    baseline = run("frozen_reviewer_baseline", "import runpy\nrunpy.run_path('scripts/check_reviewer_baseline.py', run_name='__main__')\n")
    assert "code-reviewer-v2" in baseline and baseline.startswith("OK:"), baseline
    harness = json.loads(run("harness_complete_code_reconstruction", '''
import json
from importlib.metadata import version
from pko.progress.passport_agent import run_passport_agent
from pko.progress.schema import ProgressModel
from pko.progress.plan_input import parse_plan_text
from pko.extractors.runner import Extraction
from pko.render.client_journey_passport import render_client_journey_passport
from test_passport_agentic import SPEC, corpus_fixture
from test_passport_code_reconstruction import code_responses
from test_passport_integrated_research import ResearchClient
client = ResearchClient(*code_responses())
output = run_passport_agent([], {}, [], None, SPEC, client=client, max_steps=30,
    evidence_corpus=corpus_fixture(), agentic=True, research_enabled=True,
    research_basis='code', engine='pydantic')
data = output.passport_data
assert data['runtime']['engine'] == 'pydantic-ai-harness', data.get('runtime')
assert data['completion']['state'] == 'complete', (data['completion'], output.notes)
assert data['completion']['pending_reviews'] == [], data['completion']
assert len(data['nodes']) == 4 and data['research_mode'] == 'code_reconstruction'
assert client.responses == [], 'The fixture did not reach its final response'
assert client.review_messages and client.reviewed_packets, 'Independent reviewer was not exercised'
reviewed = sorted({obj['id'] for packet in client.reviewed_packets for obj in packet})
assert {'connection-review:process-1', 'risk-analysis', 'scenario:scenario-1', 'trace:scenario-1'} <= set(reviewed)
assert output.integrity.level == 'unknown', 'Unknown boundaries must remain explicit'
assert output.connectivity.scenarios[0].status == 'unknown'
plan = parse_plan_text(Path('initiative.md').read_text(encoding='utf-8'))
model = ProgressModel(passport_data=data, connectivity=output.connectivity, integrity=output.integrity)
html = render_client_journey_passport(model, plan, 'portable harness fixture', Extraction(), 'fixture', 'main')
assert '<html' in html.lower() and 'Получение отчёта' in html
Path('harness-fixture-passport.html').write_text(html, encoding='utf-8')
print(json.dumps({'engine': data['runtime']['engine'], 'completion': data['completion']['state'],
    'nodes': len(data['nodes']), 'scenarios': len(output.connectivity.scenarios),
    'scripted_research_requests': len(client.messages), 'scripted_review_requests': len(client.review_messages),
    'reviewed_objects': reviewed, 'honest_unknown_integrity': output.integrity.level,
    'dependencies': {name: version(name) for name in ('pydantic-ai-harness', 'pydantic-ai-slim', 'pydantic', 'openai', 'jsonschema')}
}, ensure_ascii=False))
'''))
    receipt = {"status": "passed", "archive_sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
               "payload_sha256": hashlib.sha256(json.dumps(payload, ensure_ascii=False).encode()).hexdigest(),
               "final_suite": final_suite, "checks": invocations,
               "cli": ["help", "initiatives", "parse"], "html": ["dashboard", "passport", "complete harness fixture passport"],
               "baseline": baseline.strip(), "harness": harness,
               "network": "HTTP/DNS/new connections blocked; preallocated local asyncio wakeup socketpair only", "live_llm_calls": 0,
               "python": sys.version.split()[0], "staging_directory": str(stage),
               "scope": "Extracted source ZIP on the same Windows host; pinned task dependencies; scripted model transport",
               "limitations": ["No live model quality/latency check", "No second laptop executed", "Dependencies are not vendored in the source ZIP"]}
    (HERE / "portable-smoke.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(receipt, ensure_ascii=False))
    return receipt


if __name__ == "__main__":
    verify()
