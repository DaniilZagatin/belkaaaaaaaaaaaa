# Первый запуск на другом компьютере

Нужны **Python 3.11+**, **Git** и доступ к выбранной модели с
OpenAI-совместимым API. Node.js не нужен. Ниже команды для PowerShell;
выполняйте их в корне распакованной Белки, рядом с `pyproject.toml`.

## 1. Установить

```powershell
python --version
git --version
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m pip install -e .
Copy-Item .env.example .env
```

Если PowerShell запрещает активацию, её можно пропустить и во всех командах
использовать `.\.venv\Scripts\python.exe` вместо `python`,
`.\.venv\Scripts\pko.exe` вместо `pko`.
На macOS/Linux окружение активируется командой `source .venv/bin/activate`.

## 2. Настроить модель

Откройте новый `.env` и вручную заполните доступные на этом компьютере значения:

```dotenv
PKO_ASSEMBLER_BASE_URL=https://<ваш-сервис>/v1
PKO_ASSEMBLER_MODEL=<имя-модели>
PKO_ASSEMBLER_API_KEY=<ключ>
PKO_CRITIC=true
PKO_PASSPORT=true
PKO_PHOENIX_ENABLED=false
PKO_MONITOR_ENABLED=false
```

Не полагайтесь на встроенные корпоративные адреса. Если заданы
`PKO_MATCHER_*`, они переопределяют общий выбор модели. Для mTLS задайте
пути к собственным сертификату и ключу согласно `.env.example`.
Рабочие `.env`, ключи и сертификаты переносите отдельно защищённым способом.

При этой установке `.env` рядом с `pyproject.toml` загружается автоматически
и перекрывает одноимённые переменные окружения. Если ставите готовый wheel
вместо исходников, задавайте настройки переменными окружения: произвольный
`.env` в текущей папке не подхватывается. HTML-шаблоны, шрифты, промпты и
каталоги входят в wheel; исходная папка для рендера ему не нужна.

## 3. Проверить установку без модели

Сохраните небольшой `initiative.md` в UTF-8:

```markdown
Проект: Проверка установки

## Результат
- Пользователь получает подтверждение обработки заказа
```

```powershell
pko --help
pko initiatives
pko parse --journey-file .\initiative.md
```

Эти команды не вызывают модель. Проверьте, что парсер показывает один пункт.

## 4. Выполнить первый анализ

Положите рядом небольшой ZIP **с исходниками анализируемого проекта**,
например `project.zip`, и выполните:

```powershell
pko progress --journey-file .\initiative.md --zip .\project.zip --out .\first-run-out
```

Это уже обращение к настроенной модели. Для локального Git-репозитория
замените `--zip .\project.zip` на `--repo-path C:\projects\target`.
Всегда задавайте источник явно. Анализ не запускает код целевого проекта.

После код-ревью появится `first-run-out/dashboard.html`. Затем единый
паспортный агент исследует код, строит карту реализации и проверяет её.
Итоговые файлы — `client_journey_passport.html` и `progress_model.json`;
частичное исследование имеет соответствующую пометку. Открывайте HTML
обычным браузером. Журнал и контрольная копия паспорта находятся в `audit/`
каталога результата. Первый запуск может занять десятки минут.

При необходимости проверить саму Белку без модели:

```powershell
python -m pip install -r requirements-test.txt
python scripts/check_reviewer_baseline.py
python tests/run_tests.py
```

Герметичные тесты используют локальные фикстуры и подставные ответы модели.
Скрипты `run_tests_live.py`, `smoke_deepseek.py`, `use_deepseek.py` не входят
в эту проверку и для первого запуска не нужны.
